#include "codec_m4a.h"
#include "../third_party/faad2/include/neaacdec.h"
#include <string.h>
#define TAG(a,b,c,d) (((uint32_t)(a)<<24)|((uint32_t)(b)<<16)|((uint32_t)(c)<<8)|(uint32_t)(d))
typedef struct {size_t at,end,data;uint32_t type;} box;
typedef struct {
    NeAACDecHandle decoder;
    box stsz,stsc,stco;
    uint32_t count,index,default_size,chunk,chunk_count,chunk_used,per_chunk;
    uint32_t sc_entry,sc_count,next_chunk;
    uint64_t chunk_at,skip,remaining;
    int16_t *pcm;
    size_t pcm_frames,pcm_used;
    uint8_t packet[16384];
    uint8_t io_fault;
} m4a;
static uint32_t be32(const uint8_t *p){return (uint32_t)p[0]<<24|(uint32_t)p[1]<<16|(uint32_t)p[2]<<8|p[3];}
static uint64_t be64(const uint8_t *p){return (uint64_t)be32(p)<<32|be32(p+4);}
static int readbytes(codec *c,size_t at,void *dst,size_t n)
{
    if(at>c->source.size || n>c->source.size-at || !c->source.read(c->source.context,at,dst,n)) {((m4a *)c->implementation)->io_fault=1;return 0;}return 1;
}
static int u32(codec *c,size_t at,uint32_t *v){uint8_t b[4];if(!readbytes(c,at,b,4))return 0;*v=be32(b);return 1;}
static int atom(codec *c,size_t at,size_t end,box *out)
{
    uint8_t b[16];if(at>end || end-at<8 || !readbytes(c,at,b,8))return 0;
    uint64_t n=be32(b);size_t header=8;
    if(n==1){if(end-at<16 || !readbytes(c,at+8,b+8,8))return 0;n=be64(b+8);header=16;}
    else if(!n)n=end-at;
    if(n<header || n>end-at)return 0;
    *out=(box){at,at+(size_t)n,at+header,be32(b+4)};return 1;
}
static int child(codec *c,box parent,uint32_t type,box *out)
{
    size_t at=parent.data;unsigned examined=0;
    while(at<parent.end && ++examined<=4096){box b;if(!atom(c,at,parent.end,&b))return 0;if(b.type==type){*out=b;return 1;}at=b.end;}return 0;
}
static int fullbox_count(codec *c,box b,uint32_t *n,size_t width)
{
    uint32_t flags;
    return b.end-b.data>=8 && u32(c,b.data,&flags) && !flags && u32(c,b.data+4,n) && *n<=(b.end-b.data-8)/width;
}
static int descriptor(const uint8_t *b,size_t size,size_t *at,unsigned tag,size_t *end)
{
    if(*at>=size || b[(*at)++]!=tag)return 0;
    size_t n=0;unsigned k=0;uint8_t v;
    do {if(*at>=size || ++k>4)return 0;v=b[(*at)++];n=(n<<7)|(v&127);}while(v&128);
    if(n>size-*at)return 0;
    *end=*at+n;return 1;
}
static int audio_config(codec *c,box stsd,uint8_t asc[64],unsigned *asc_size)
{
    uint32_t n;if(!fullbox_count(c,stsd,&n,8) || n!=1)return 0;box mp4a,esds;
    if(!atom(c,stsd.data+8,stsd.end,&mp4a) || mp4a.type!=TAG('m','p','4','a') || mp4a.end-mp4a.data<28)return 0;
    uint8_t a[28];if(!readbytes(c,mp4a.data,a,28) || a[8] || a[9])return 0; /* AudioSampleEntry version0 only. */
    mp4a.data+=28;if(!child(c,mp4a,TAG('e','s','d','s'),&esds) || esds.end-esds.data>256 || esds.end-esds.data<8)return 0;
    uint8_t b[256];size_t size=esds.end-esds.data;if(!readbytes(c,esds.data,b,size) || be32(b))return 0;
    size_t at=4,end;if(!descriptor(b,size,&at,3,&end) || end-at<3)return 0;
    unsigned flags=b[at+2];at+=3;
    if(flags&128)at+=2;
    if(flags&64){if(at>=end)return 0;unsigned len=b[at++];at+=len;}
    if(flags&32)at+=2;
    size_t dend;if(at>end || !descriptor(b,end,&at,4,&dend) || dend-at<13 || b[at]!=0x40)return 0;
    at+=13;size_t send;if(!descriptor(b,dend,&at,5,&send) || send-at<2 || send-at>64 || b[at]>>3!=2)return 0;
    *asc_size=(unsigned)(send-at);memcpy(asc,b+at,*asc_size);return 1;
}
static int edit_list(codec *c,box trak,uint32_t movie_scale,uint32_t rate,uint64_t *skip,uint64_t *total)
{
    box edts,elst;if(!child(c,trak,TAG('e','d','t','s'),&edts) || !child(c,edts,TAG('e','l','s','t'),&elst))return 0;
    uint8_t b[28];size_t n=elst.end-elst.data;if(n<20 || !readbytes(c,elst.data,b,n<28?n:28))return 0;
    if(b[1] || b[2] || b[3] || be32(b+4)!=1)return 0;
    uint64_t duration,media;uint32_t speed;
    if(b[0]==0){duration=be32(b+8);media=be32(b+12);speed=be32(b+16);if(media>INT32_MAX)return 0;}
    else if(b[0]==1 && n>=28){duration=be64(b+8);media=be64(b+16);speed=be32(b+24);if(media>INT64_MAX)return 0;}
    else return 0;
    if(speed!=0x10000u || !movie_scale || duration>(UINT64_MAX-movie_scale/2)/rate)return 0;
    *skip=media;*total=(duration*rate+movie_scale/2)/movie_scale;return *total!=0;
}
static int chunk_config(codec *c,m4a *m)
{
    if(m->chunk>=m->chunk_count)return 0;
    if(m->chunk+1==m->next_chunk){
        if(++m->sc_entry>=m->sc_count)return 0;
        size_t at=m->stsc.data+8+(size_t)m->sc_entry*12;uint32_t first,id;
        if(!u32(c,at,&first) || first!=m->chunk+1 || !u32(c,at+4,&m->per_chunk) || !m->per_chunk || !u32(c,at+8,&id) || id!=1)return 0;
        m->next_chunk=UINT32_MAX;
        if(m->sc_entry+1<m->sc_count && (!u32(c,at+12,&m->next_chunk) || m->next_chunk<=first))return 0;
    }
    uint8_t b[8];size_t width=m->stco.type==TAG('c','o','6','4')?8:4;
    if(!readbytes(c,m->stco.data+8+(size_t)m->chunk*width,b,width))return 0;
    m->chunk_at=width==8?be64(b):be32(b);m->chunk_used=0;return m->chunk_at<c->source.size;
}
codec_status codec_m4a_open(codec *c)
{
    /* The smaller arena requires a worker that can unwind an allocation fault
     * before a provider touches a failed allocation. */
    if(c->arena_size<(CODEC_FAULT_ON_ALLOC ? 96u : 128u)*1024u)return CODEC_MEMORY;
    m4a *m=codec_pool_alloc(c,sizeof(*m));if(!m)return CODEC_MEMORY;memset(m,0,sizeof(*m));c->implementation=m;
    box file={0,c->source.size,0,0},moov,mvhd,trak,mdia,hdlr,minf,stbl,stsd,mdhd;
    if(!child(c,file,TAG('m','o','o','v'),&moov) || !child(c,moov,TAG('m','v','h','d'),&mvhd))return CODEC_INVALID;
    uint8_t b[32];if(mvhd.end-mvhd.data<20 || !readbytes(c,mvhd.data,b,20))return CODEC_INVALID;
    uint32_t movie_scale;if(b[0]==0)movie_scale=be32(b+12);else if(b[0]==1){if(!u32(c,mvhd.data+20,&movie_scale))return CODEC_INVALID;}else return CODEC_UNSUPPORTED;
    size_t at=moov.data;unsigned tracks=0;int found=0;
    while(at<moov.end && ++tracks<=4096){box x;if(!atom(c,at,moov.end,&x))return CODEC_INVALID;at=x.end;if(x.type!=TAG('t','r','a','k'))continue;
        if(child(c,x,TAG('m','d','i','a'),&mdia) && child(c,mdia,TAG('h','d','l','r'),&hdlr) && hdlr.end-hdlr.data>=12 && readbytes(c,hdlr.data+8,b,4) && be32(b)==TAG('s','o','u','n')){trak=x;found=1;break;}}
    if(!found || !child(c,mdia,TAG('m','i','n','f'),&minf) || !child(c,minf,TAG('s','t','b','l'),&stbl) || !child(c,stbl,TAG('s','t','s','d'),&stsd) || !child(c,stbl,TAG('s','t','s','z'),&m->stsz) || !child(c,stbl,TAG('s','t','s','c'),&m->stsc) || (!child(c,stbl,TAG('s','t','c','o'),&m->stco) && !child(c,stbl,TAG('c','o','6','4'),&m->stco)) || !child(c,mdia,TAG('m','d','h','d'),&mdhd))return CODEC_INVALID;
    if(m->stsz.end-m->stsz.data<12 || !readbytes(c,m->stsz.data,b,12) || be32(b))return CODEC_INVALID;
    m->default_size=be32(b+4);m->count=be32(b+8);if(!m->count || (!m->default_size && m->count>(m->stsz.end-m->stsz.data-12)/4))return CODEC_INVALID;
    if(!fullbox_count(c,m->stsc,&m->sc_count,12) || !m->sc_count || !fullbox_count(c,m->stco,&m->chunk_count,m->stco.type==TAG('c','o','6','4')?8:4) || !m->chunk_count)return CODEC_INVALID;
    uint32_t first,id;if(!u32(c,m->stsc.data+8,&first) || first!=1 || !u32(c,m->stsc.data+12,&m->per_chunk) || !m->per_chunk || !u32(c,m->stsc.data+16,&id) || id!=1)return CODEC_INVALID;
    m->next_chunk=UINT32_MAX;if(m->sc_count>1 && (!u32(c,m->stsc.data+20,&m->next_chunk) || m->next_chunk<=1))return CODEC_INVALID;
    uint8_t asc[64];unsigned asc_size;if(!audio_config(c,stsd,asc,&asc_size) || (((asc[0]&7u)<<1)|(asc[1]>>7))==15 || (asc[1]&4u))return CODEC_UNSUPPORTED;
    m->decoder=NeAACDecOpen();if(!m->decoder)return CODEC_MEMORY;
    NeAACDecConfigurationPtr config=NeAACDecGetCurrentConfiguration(m->decoder);config->outputFormat=FAAD_FMT_16BIT;config->defObjectType=LC;
    if(!NeAACDecSetConfiguration(m->decoder,config))return CODEC_UNSUPPORTED;
    unsigned long rate;unsigned char channels;if(NeAACDecInit2(m->decoder,asc,asc_size,&rate,&channels)<0 || channels<1 || channels>2 || rate<8000 || rate>96000)return CODEC_UNSUPPORTED;
    if(mdhd.end-mdhd.data<20 || !readbytes(c,mdhd.data,b,20))return CODEC_INVALID;
    uint32_t scale;if(b[0]==0)scale=be32(b+12);else if(b[0]==1){if(!u32(c,mdhd.data+20,&scale))return CODEC_INVALID;}else return CODEC_UNSUPPORTED;
    uint64_t skip,total;if(scale!=rate || !edit_list(c,trak,movie_scale,(uint32_t)rate,&skip,&total) || skip<1024 || skip>8192 || total>UINT64_MAX-skip || (uint64_t)m->count*1024<total+skip)return CODEC_UNSUPPORTED;
    c->info=(codec_info){.rate=(uint32_t)rate,.channels=channels,.bits=16,.total_frames=total,.total_known=1,.delay_frames=(uint32_t)skip,.delay_known=1,.padding_frames=(uint32_t)((uint64_t)m->count*1024-total-skip),.padding_known=1,.trimming_applied=1};
    /* FAAD decoder.c:1193 already suppresses first1024 PCM frames. */
    m->skip=skip-1024;m->remaining=total;if(!chunk_config(c,m))return CODEC_INVALID;return CODEC_OK;
}
codec_status codec_m4a_read(codec *c,int16_t *out,size_t capacity,size_t *frames)
{
    m4a *m=c->implementation;*frames=0;
    if(!m->remaining)return CODEC_END;
    /* At most2 empty/priming frames per call; callers may receive0 with OK. */
    unsigned packets=0;
    while(*frames<capacity && m->remaining){
        if(m->pcm_used==m->pcm_frames){
            if(m->index>=m->count)return CODEC_INVALID;
            if(++packets>2)return CODEC_OK;
            if(m->chunk_used==m->per_chunk){++m->chunk;if(!chunk_config(c,m))return CODEC_INVALID;}
            uint32_t size=m->default_size;if(!size && !u32(c,m->stsz.data+12+(size_t)m->index*4,&size))return CODEC_INVALID;
            if(!size || size>sizeof(m->packet) || m->chunk_at>SIZE_MAX || !readbytes(c,(size_t)m->chunk_at,m->packet,size))return m->io_fault?CODEC_IO:CODEC_UNSUPPORTED;
            m->chunk_at+=size;++m->index;++m->chunk_used;
            NeAACDecFrameInfo f;void *pcm=NeAACDecDecode(m->decoder,&f,m->packet,size);
            if(f.error || f.channels!=c->info.channels || f.samplerate!=c->info.rate || f.samples>2048 || (f.samples && !pcm))return CODEC_INVALID;
            m->pcm=pcm;m->pcm_frames=f.samples/c->info.channels;m->pcm_used=0;
            size_t skip=m->skip<m->pcm_frames?(size_t)m->skip:m->pcm_frames;m->pcm_used=skip;m->skip-=skip;
        }
        size_t n=m->pcm_frames-m->pcm_used;if(n>capacity-*frames)n=capacity-*frames;if(n>m->remaining)n=(size_t)m->remaining;
        if(n)memcpy(out+*frames*c->info.channels,m->pcm+m->pcm_used*c->info.channels,n*c->info.channels*sizeof(int16_t));
        *frames+=n;m->pcm_used+=n;m->remaining-=n;
    }
    return CODEC_OK;
}
void codec_m4a_close(codec *c){m4a *m=c->implementation;if(m && m->decoder)NeAACDecClose(m->decoder);}
