#include "ui.h"
#include "ui_font.h"

#define RGB(v) ((uint16_t)((((v)>>19)&31)<<11 | (((v)>>10)&63)<<5 | (((v)>>3)&31)))
#define BG RGB(0x111215u)
#define PANEL RGB(0x17181cu)
#define RAISED RGB(0x1c1d21u)
#define INK RGB(0xe9e8e1u)
#define MUTED RGB(0x9798a5u)
#define LINE RGB(0x2b2d33u)
#define ACID RGB(0xdeef64u)
#define VIOLET RGB(0xb56affu)
#define CYAN RGB(0x57dbeeu)
#define PINK RGB(0xef68c8u)

void ui_init(ui_state *s, int input_available)
{
    *s=(ui_state){.input_available=!!input_available, .revision=1};
}
void ui_set_battery(ui_state *s,const battery_state *b)
{
    if (!s || !b) return;
    if (s->battery.valid!=b->valid || (b->valid &&
        (s->battery.bars!=b->bars || s->battery.low!=b->low ||
         s->battery.charge!=b->charge || s->battery.millivolts/10!=b->millivolts/10))) ++s->revision;
    s->battery=*b;
}
void ui_event(ui_state *s, ui_key key)
{
    if (!s || s->screen>=UI_SCREEN_COUNT || (unsigned)key>=UI_KEY_COUNT) return;
    if (key==UI_MENU || key==UI_BACK) {
        if (s->opened) s->opened=0;
        else s->content_focus=0;
    } else if (!s->content_focus) {
        if (key==UI_LEFT) s->screen=(s->screen+UI_SCREEN_COUNT-1)%UI_SCREEN_COUNT;
        if (key==UI_RIGHT) s->screen=(s->screen+1)%UI_SCREEN_COUNT;
        if (key==UI_DOWN || key==UI_SELECT) s->content_focus=1;
        s->opened=0;
    } else if (s->screen==UI_LIBRARY) {
        if (!s->opened) {
            if (key==UI_UP) {
                if (s->category) --s->category; else s->content_focus=0;
            }
            if (key==UI_DOWN && s->category<3) ++s->category;
            if (key==UI_SELECT || key==UI_RIGHT) s->opened=1;
            if (key==UI_LEFT) s->content_focus=0;
        }
    } else if ((s->screen==UI_NOW_PLAYING || s->screen==UI_QUEUE) && key==UI_SELECT) {
        s->screen=UI_LIBRARY;
        s->category=s->opened=0;
    } else if (key==UI_UP || key==UI_LEFT) s->content_focus=0;
    ++s->revision;
}
static void pixel(int x, uint16_t color, uint8_t *out)
{
    if (x<0 || x>=UI_WIDTH) return;
    out[2*x]=(uint8_t)(color>>8); out[2*x+1]=(uint8_t)color;
}
static void rect(unsigned y,int x,int top,int w,int h,uint16_t color,uint8_t *out)
{
    if ((int)y<top || (int)y>=top+h || w<=0) return;
    int end=x+w; if (end>UI_WIDTH) end=UI_WIDTH;
    if (x<0) x=0;
    for (;x<end;++x) pixel(x,color,out);
}
static void border(unsigned y,int x,int top,int w,int h,uint16_t color,uint8_t *out)
{
    rect(y,x,top,w,1,color,out); rect(y,x,top+h-1,w,1,color,out);
    rect(y,x,top,1,h,color,out); rect(y,x+w-1,top,1,h,color,out);
}
static const ui_font *ui_font_for(unsigned size)
{
    return size == 2 ? &font_title : size == 1 ? &font_body : &font_small;
}

static unsigned display_glyph(const char *text, unsigned *offset)
{
    unsigned lead = (unsigned char)text[(*offset)++];
    if (lead >= 32 && lead <= 126)
        return lead - 32;
    unsigned length = lead >= 0xc2 && lead <= 0xdf ? 2 :
                      lead >= 0xe0 && lead <= 0xef ? 3 :
                      lead >= 0xf0 && lead <= 0xf4 ? 4 : 0;
    if (!length)
        return '?' - 32;
    unsigned codepoint = lead & (0x7fu >> length);
    unsigned tail = *offset;
    for (unsigned i = 1; i < length; ++i) {
        if (tail >= 96)
            return '?' - 32;
        unsigned byte = (unsigned char)text[tail];
        if ((byte & 0xc0) != 0x80)
            return '?' - 32;
        codepoint = (codepoint << 6) | (byte & 0x3f);
        ++tail;
    }
    *offset = tail;
    if ((length == 3 && codepoint < 0x800) ||
        (length == 4 && (codepoint < 0x10000 || codepoint > 0x10ffff)) ||
        (codepoint >= 0xd800 && codepoint <= 0xdfff))
        return '?' - 32;
    if (codepoint >= 0xc0 && codepoint <= 0xff) {
        static const char latin[] =
            "AAAAAAACEEEEIIIIDNOOOOOxOUUUUYTs"
            "aaaaaaaceeeeiiiidnooooo/ouuuuyty";
        return latin[codepoint - 0xc0] - 32;
    }
    switch (codepoint) {
    case 0xa0: return 0;
    case 0x2013:
    case 0x2014: return '-' - 32;
    case 0x2018:
    case 0x2019: return '\'' - 32;
    case 0x201c:
    case 0x201d: return '"' - 32;
    case 0x2026: return '.' - 32;
    default: return '?' - 32;
    }
}

static unsigned measure_text(const ui_font *font, const char *text)
{
    unsigned width = 0;
    for (unsigned i = 0; i < 96 && text[i];)
        width += font->advance[display_glyph(text, &i)];
    return width;
}

unsigned ui_text_width(unsigned size, const char *text)
{
    unsigned pixels = text ? measure_text(ui_font_for(size), text) : 0;
#ifdef WXP_ECHO_MINI
    return (pixels * 3 + 1) / 2;
#else
    return pixels;
#endif
}

static void glyph_pixel(int x, uint16_t color, uint8_t *out)
{
#ifdef WXP_ECHO_MINI
    x = x * 3 / 2;
#endif
    pixel(x, color, out);
}

static void text_row(unsigned y,int x,int top,int width,unsigned size,const char *text,
                     uint16_t color,int animate,unsigned time,uint8_t out[960])
{
    const ui_font *f=ui_font_for(size);
#ifdef WXP_ECHO_MINI
    /* Compose glyphs on the panel pixel grid. The scaler samples logical
       column floor(3*x/2), so write ink directly to that column. */
    int right = ((x + width) * 2) / 3;
    x = (x * 2 + 2) / 3;
    width = right - x;
    y = y * 170 / 222;
    top = (top * 170 + 221) / 222;
#endif
    if (!text || !out || y>=UI_HEIGHT || top < -64 || top>UI_HEIGHT ||
        (int)y<top || (int)y>=top+(int)f->height || width<=0) return;
    /* Bound public coordinates before arithmetic; product layouts stay inside. */
    if (x < -UI_WIDTH || x>UI_WIDTH || width>UI_WIDTH) return;
    int edge=x+width, pen=x;
    if (animate) {
        int full=(int)measure_text(f,text);
        if (full>width) {
            unsigned over=(unsigned)(full-width);
            unsigned position=(time/100)%(20+over/2);
            unsigned shift=position>10?(position-10)*2:0;
            pen-=(int)(shift>over?over:shift);
        }
    }
    unsigned row=(unsigned)((int)y-top);
    for (unsigned n=0;n<96 && text[n];) {
        unsigned c=display_glyph(text,&n);
        unsigned advance=f->advance[c];
        if (!animate && pen+(int)advance>edge) {
            /* Visible bounded truncation marker; no half glyph at right edge. */
            for (int dot=edge-9;dot<edge;dot+=3) {
                if (dot>=x && (row==f->height-6 || row==f->height-5)) glyph_pixel(dot,color,out);
            }
            break;
        }
        #ifdef UI_FONT_COMPACT
        uint32_t bits=ui_font_row(f,c*f->height+row);
#else
        uint32_t bits=f->rows[c*f->height+row];
#endif
        for (unsigned i=0;i<advance;++i)
            if (pen+(int)i>=x && pen+(int)i<edge && (bits&(1u<<i)))
                glyph_pixel(pen+(int)i,color,out);
        pen+=(int)advance;
        if (pen>=edge)
            break;
    }
}
void ui_text_row(unsigned y,int x,int top,int width,unsigned size,const char *text,
                 uint16_t color,uint8_t out[960])
{ text_row(y,x,top,width,size,text,color,0,0,out); }
void ui_marquee_row(unsigned y,int x,int top,int width,unsigned size,const char *text,
                    uint16_t color,unsigned time,uint8_t out[960])
{ text_row(y,x,top,width,size,text,color,1,time,out); }
static void label(unsigned y,int x,int top,int w,unsigned size,const char *s,uint16_t c,uint8_t *out)
{ ui_text_row(y,x,top,w,size,s,c,out); }
int ui_render_chrome(const ui_state *s,unsigned y,uint8_t *out,size_t capacity)
{
    static const char *const tabs[]={"Library","Now Playing","Queue","Settings"};
    if (!s || !out || y>=UI_HEIGHT || capacity<960 || s->screen>=UI_SCREEN_COUNT || s->category>=4) return 0;
    for (int x=0;x<UI_WIDTH;++x) pixel(x,BG,out);
    label(y,12,2,180,1,"We4ZlDaP",ACID,out);
    /* Fixed header allocation x380..469, outside branding and navigation. */
    const battery_state *b=&s->battery;
    uint16_t battery_color=b->valid?(b->low?PINK:ACID):MUTED;
    char voltage[6]="--.--";
    if (b->valid && b->millivolts<=9999) {
        voltage[0]=(char)('0'+b->millivolts/1000); voltage[1]='.';
        voltage[2]=(char)('0'+b->millivolts/100%10);
        voltage[3]=(char)('0'+b->millivolts/10%10); voltage[4]='V';
    }
    label(y,380,5,48,0,voltage,battery_color,out);
    border(y,432,7,34,16,battery_color,out);
    rect(y,466,11,3,8,battery_color,out);
    if (b->valid) {
        for (unsigned i=0;i<4;++i)
            rect(y,436+(int)i*7,11,4,8,i<b->bars?battery_color:LINE,out);
        if (b->charge==BATTERY_CHARGING) {
            rect(y,447,9,4,6,CYAN,out); rect(y,444,14,4,7,CYAN,out);
        }
    } else label(y,444,8,14,0,"?",MUTED,out);
    rect(y,12,29,456,1,LINE,out);
    /* Give the longest label room without shrinking the font. */
    static const unsigned tab_x[]={12,128,280,370};
    static const unsigned tab_width[]={108,144,82,98};
    for (unsigned i=0;i<4;++i) {
        int x=(int)tab_x[i], w=(int)tab_width[i];
        uint16_t color=s->screen==i?ACID:MUTED;
        rect(y,x,36,w,29,s->screen==i?RAISED:PANEL,out);
        if (s->screen==i) {
            rect(y,x,63,w,2,ACID,out);
            if (!s->content_focus) border(y,x,36,w,29,ACID,out);
        }
        unsigned text_width=0;
        for (const char *p=tabs[i];*p;++p) text_width+=font_body.advance[(unsigned char)*p-32];
        label(y,x+(w-(int)text_width)/2,40,(int)text_width,1,tabs[i],color,out);
    }
    rect(y,12,201,456,1,LINE,out);
    label(y,12,205,456,0,s->input_available?"Play: select   Menu: tabs   Repeat: back":"Buttons not configured",MUTED,out);
    return 1;
}

int ui_render_row(const ui_state *s,unsigned y,uint8_t *out,size_t capacity)
{
    static const char *const cats[]={"Albums","Artists","Songs","Playlists"};
    if(!ui_render_chrome(s,y,out,capacity))return 0;
    if (s->screen==UI_LIBRARY) {
        for (unsigned i=0;i<4;++i) {
            int top=76+(int)i*30;
            rect(y,12,top,132,25,PANEL,out);
            if (s->category==i) {
                rect(y,12,top,3,25,ACID,out);
                if (s->content_focus && !s->opened) border(y,12,top,132,25,ACID,out);
            }
            label(y,24,top+2,112,1,cats[i],s->category==i?ACID:INK,out);
        }
        rect(y,158,76,1,115,LINE,out);
        label(y,174,76,284,2,cats[s->category],INK,out);
        label(y,174,111,284,1,"Storage not mounted",INK,out);
        label(y,174,140,284,0,"No music library is available yet.",MUTED,out);
        if (s->opened) label(y,174,163,284,0,"No library has been loaded.",MUTED,out);
    } else if (s->screen==UI_NOW_PLAYING) {
        label(y,24,80,432,2,"No track selected",INK,out);
        label(y,24,117,432,1,"Choose music from Library",MUTED,out);
        rect(y,24,159,184,30,PANEL,out);
        border(y,24,159,184,30,s->content_focus?ACID:LINE,out);
        label(y,39,163,154,1,"Browse Library",ACID,out);
        label(y,236,166,220,0,"Audio unavailable",MUTED,out);
    } else if (s->screen==UI_QUEUE) {
        label(y,24,76,432,2,"Queue",INK,out);
        label(y,24,112,432,1,"No tracks queued",MUTED,out);
        rect(y,24,160,172,28,PANEL,out);
        border(y,24,160,172,28,s->content_focus?ACID:LINE,out);
        label(y,36,163,148,1,"Browse Library",ACID,out);
    } else {
        static const char *const names[]={"Device","Music storage","Audio output","Buttons"};
        const char *values[]={"ECHO F4402E / HW 1.1.7","Not mounted","Unavailable",s->input_available?"Mapped this session":"Hardware mapping pending"};
        for (unsigned i=0;i<4;++i) {
            int top=76+(int)i*29;
            label(y,24,top,130,1,names[i],i?MUTED:CYAN,out);
            label(y,166,top,302,0,values[i],INK,out);
            rect(y,24,top+25,432,1,LINE,out);
        }
    }
    return 1;
}
