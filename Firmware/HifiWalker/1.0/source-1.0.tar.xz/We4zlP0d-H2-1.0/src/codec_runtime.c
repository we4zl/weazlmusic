/* Freestanding codec support. No allocation and no hosted I/O. qsort uses
 * in-place heapsort: O(n log n) comparisons, O(1) scratch and bounded stack.
 * Compile -fno-builtin; AEABI helpers already in runtime.c stay there. */
#include <stddef.h>
#include <stdint.h>
typedef uint32_t alias_word __attribute__((__may_alias__));
static void copy_forward(uint8_t *a,const uint8_t *b,size_t n)
{
 if(((uintptr_t)a&3u)==((uintptr_t)b&3u)){
  while(n && ((uintptr_t)a&3u)){*a++=*b++;--n;}
  while(n>=4){*(alias_word *)a=*(const alias_word *)b;a+=4;b+=4;n-=4;}
 }
 while(n--)*a++=*b++;
}
void *memcpy(void *d,const void *s,size_t n){copy_forward(d,s,n);return d;}
void *memset(void *d,int c,size_t n)
{
 uint8_t*a=d;while(n && ((uintptr_t)a&3u)){*a++=(uint8_t)c;--n;}
 uint32_t word=(uint8_t)c*0x01010101u;
 while(n>=4){*(alias_word *)a=word;a+=4;n-=4;}while(n--)*a++=(uint8_t)c;return d;
}
void *memmove(void *d,const void *s,size_t n)
{
 uint8_t*a=d;const uint8_t*b=s;
 if((uintptr_t)a>(uintptr_t)b){
  a+=n;b+=n;
  if(((uintptr_t)a&3u)==((uintptr_t)b&3u)){
   while(n && ((uintptr_t)a&3u)){*--a=*--b;--n;}
   while(n>=4){a-=4;b-=4;*(alias_word *)a=*(const alias_word *)b;n-=4;}
  }
  while(n--)*--a=*--b;
 }else copy_forward(a,b,n);
 return d;
}
int memcmp(const void *d,const void *s,size_t n){const uint8_t*a=d,*b=s;while(n--){if(*a!=*b)return (int)*a-*b;++a;++b;}return 0;}
int abs(int v){return v<0?-v:v;}long labs(long v){return v<0?-v:v;}
void __aeabi_memclr8(void*d,size_t n){memset(d,0,n);}
void __aeabi_memmove4(void*d,const void*s,size_t n){memmove(d,s,n);}

#ifndef CODEC_RUNTIME_COOPERATIVE_PROGRESS
#define CODEC_RUNTIME_COOPERATIVE_PROGRESS 0
#endif
static void sort_checkpoint(void)
{
#if CODEC_RUNTIME_COOPERATIVE_PROGRESS
 extern void codec_runtime_checkpoint(void);
 codec_runtime_checkpoint();
#endif
}
static void swap(uint8_t*a,uint8_t*b,size_t n){while(n--){uint8_t t=*a;*a++=*b;*b++=t;}}
static void sift(uint8_t *a,size_t count,size_t root,size_t w,int(*cmp)(const void*,const void*))
{while(root<count/2){size_t child=2*root+1;if(child+1<count && cmp(a+child*w,a+(child+1)*w)<0)++child;if(cmp(a+root*w,a+child*w)>=0)return;swap(a+root*w,a+child*w,w);root=child;}}
void qsort(void *p,size_t n,size_t w,int(*cmp)(const void*,const void*))
{
 if(n<2||!w)return;uint8_t*a=p;unsigned progress=0;sort_checkpoint();
 for(size_t i=n/2;i;){--i;sift(a,n,i,w,cmp);if(++progress==16){progress=0;sort_checkpoint();}}
 for(size_t i=n-1;i;--i){swap(a,a+i*w,w);sift(a,i,0,w,cmp);if(++progress==16){progress=0;sort_checkpoint();}}
}

/* Upstream Opus supports -DOVERRIDE_celt_fatal. A failed worker must never
 * resume: the resident adapter latches fault and yields to its scheduler. */
extern _Noreturn void codec_runtime_fault(unsigned reason);
_Noreturn void celt_fatal(const char *message,const char *file,int line)
{(void)message;(void)file;(void)line;codec_runtime_fault(1u);}
