#include "fs.h"
#include <stdint.h>

static void clear(void *p,size_t n) { uint8_t *b=p;while(n--)*b++=0; }
static void copy(void *p,const void *q,size_t n) { uint8_t *b=p;const uint8_t *a=q;while(n--)*b++=*a++; }

static uint16_t le16(const uint8_t *p) { return (uint16_t)(p[0] | (uint16_t)p[1]<<8); }
static uint32_t le32(const uint8_t *p) { return (uint32_t)le16(p) | (uint32_t)le16(p+2)<<16; }
static int cluster_ok(const fs *v,uint32_t c) { return c>=2 && c-2<v->cluster_count; }
static fs_status sector(fs *v,uint32_t s) {
    if (!v || !v->reader || s>=v->total_sectors) return FS_CORRUPT;
    v->io_pending=0;
    if (v->cache_valid && v->cache_sector==s) return FS_OK;
    v->cache_valid=0;
    if(s>v->device_sectors-v->partition-1)return FS_IO;
    int response=v->reader(v->context,v->partition+s,v->cache);
    if(response<0){v->io_pending=1;return FS_AGAIN;}
    if(!response)return FS_IO;
    v->cache_sector=s;v->cache_valid=1;return FS_OK;
}
void fs_unmount(fs *v) { if(v) clear(v,sizeof(*v)); }
fs_status fs_mount(fs *v,fs_sector_reader reader,void *ctx,uint32_t count,uint32_t part) {
    uint32_t total,fatsz,reserved,rootsectors,first,clusters,root;uint8_t nf,spc;uint16_t roots;
    fs_status status=FS_CORRUPT;
    if(!v) return FS_INVALID;
    fs_unmount(v);
    if(!reader || !count || part>=count) return FS_INVALID;
    int response=reader(ctx,part,v->cache);
    if(response<0){v->io_pending=1;return FS_AGAIN;}
    if(!response)return FS_IO;
    if(v->cache[510]!=0x55 || v->cache[511]!=0xaa) goto fail;
    if(le16(v->cache+11)!=512) { status=FS_UNSUPPORTED;goto fail; }
    spc=v->cache[13];reserved=le16(v->cache+14);nf=v->cache[16];roots=le16(v->cache+17);
    total=le16(v->cache+19);if(!total)total=le32(v->cache+32);
    fatsz=le16(v->cache+22);if(!fatsz)fatsz=le32(v->cache+36);
    if(!spc || spc>128 || (spc&(spc-1)) || !reserved || !nf || nf>2 || !fatsz ||
       !total || total>count-part)goto fail;
    rootsectors=((uint32_t)roots*32+511)/512;
    if(fatsz>(total-reserved)/nf || reserved>=total)goto fail;
    first=reserved+fatsz*nf;
    if(rootsectors>total-first)goto fail;
    first+=rootsectors;clusters=(total-first)/spc;
    if(clusters<4085) {status=FS_UNSUPPORTED;goto fail;}
    if(clusters>=0x0ffffff5u)goto fail;
    if(clusters<65525) {
        if(!roots || !le16(v->cache+22) || (uint64_t)(clusters+2)*2>(uint64_t)fatsz*512)goto fail;
        v->fat_bits=16;root=0;
    } else {
        uint16_t flags=le16(v->cache+40);
        if(roots || le16(v->cache+22) || le16(v->cache+42) ||
           (uint64_t)(clusters+2)*4>(uint64_t)fatsz*512)goto fail;
        root=le32(v->cache+44);
        if(root<2 || root-2>=clusters)goto fail;
        v->fat_bits=32;
        uint16_t info=le16(v->cache+48);
        if(info<reserved)v->info_sector=info;
        if(flags&0x80) {uint32_t active=flags&15;if(active>=nf)goto fail;reserved+=active*fatsz;}
    }
    v->reader=reader;v->context=ctx;v->device_sectors=count;v->partition=part;
    v->total_sectors=total;v->fat_start=reserved;v->fat_sectors=fatsz;
    v->data_start=first;v->cluster_count=clusters;v->root_cluster=root;
    v->root_entries=roots;v->sectors_per_cluster=spc;
    v->root_start=first-rootsectors;v->cache_sector=0;v->cache_valid=1;
    return FS_OK;
fail:fs_unmount(v);return status;
}
uint32_t fs_free_sectors(fs *v) {
    if(!v || !v->info_sector || sector(v,v->info_sector)!=FS_OK ||
       le32(v->cache)!=0x41615252 || le32(v->cache+484)!=0x61417272 ||
       le32(v->cache+508)!=0xaa550000)return UINT32_MAX;
    uint32_t free_clusters=le32(v->cache+488);
    return free_clusters<=v->cluster_count?free_clusters*v->sectors_per_cluster:UINT32_MAX;
}
static fs_status next_cluster(fs *v,uint32_t c,uint32_t *out) {
    uint32_t byte,value;fs_status s;
    if(!cluster_ok(v,c))return FS_CORRUPT;
    byte=c*(v->fat_bits/8);
    if(byte/512>=v->fat_sectors)return FS_CORRUPT;
    s=sector(v,v->fat_start+byte/512);if(s!=FS_OK)return s;
    value=v->fat_bits==16?le16(v->cache+byte%512):(le32(v->cache+byte%512)&0x0fffffff);
    if(value>=(v->fat_bits==16?0xfff8u:0x0ffffff8u))return FS_END;
    if(value>=(v->fat_bits==16?0xfff0u:0x0ffffff0u) || !cluster_ok(v,value))return FS_CORRUPT;
    *out=value;return FS_OK;
}
/* Floyd cycle check uses two scalar cursors, constant memory. The fast cursor
 * can reach EOF before the data cursor; malformed future links fail early. */
static fs_status advance(fs *v,uint32_t *cluster,uint32_t *slow,uint32_t *fast,uint32_t *hops) {
    uint32_t c,s=*slow,f=*fast;fs_status result;
    if(*hops>=v->cluster_count)return FS_CORRUPT;
    result=next_cluster(v,*cluster,&c);if(result!=FS_OK)return result;
    if(f) {
        result=next_cluster(v,s,&s);if(result!=FS_OK && result!=FS_END)return result;
        for(unsigned i=0;i<2 && f;i++) {
            result=next_cluster(v,f,&f);
            if(result==FS_END)f=0;else if(result!=FS_OK)return result;
        }
        if(f && f==s)return FS_CORRUPT;
    }
    *cluster=c;*slow=s;*fast=f;(*hops)++;
    return FS_OK;
}
static void dir_init(fs *v,uint32_t c,fs_dir *d) {
    clear(d,sizeof(*d));d->volume=v;d->cluster=c;d->slow=c;d->fast=c;
    d->fixed_root=(uint8_t)(v->fat_bits==16 && c==0);
}
static fs_status raw_entry(fs_dir *d,uint8_t out[32]) {
    fs *v=d->volume;uint32_t s,within;fs_status r;
    if(d->ended)return FS_END;
    if(d->fixed_root) {
        if(d->slot>=v->root_entries){d->ended=1;return FS_END;}
        s=v->root_start+d->slot/16;within=d->slot%16;
    } else {
        if(!cluster_ok(v,d->cluster))return FS_CORRUPT;
        if(d->slot==(uint32_t)v->sectors_per_cluster*16) {
            r=advance(v,&d->cluster,&d->slow,&d->fast,&d->hops);
            if(r==FS_END)d->ended=1;
            if(r!=FS_OK)return r;
            d->slot=0;
        }
        s=v->data_start+(d->cluster-2)*v->sectors_per_cluster+d->slot/16;within=d->slot%16;
    }
    r=sector(v,s);if(r!=FS_OK)return r;
    copy(out,v->cache+within*32,32);d->slot++;return FS_OK;
}
static uint8_t checksum(const uint8_t *p) {
    uint8_t c=0;for(unsigned i=0;i<11;i++)c=(uint8_t)((c>>1)|(c<<7))+p[i];return c;
}
static int utf8(const uint16_t *in,unsigned count,char *out) {
    unsigned n=0;int terminated=0;
    for(unsigned i=0;i<count;i++) {
        uint32_t c=in[i];
        if(c==0){terminated=1;continue;}
        if(terminated){if(c!=0xffff)return 0;continue;}
        if(c==0xffff || i>=255)return 0;
        if(c>=0xd800 && c<=0xdbff) {
            if(i+1>=count || i+1>=255 || in[i+1]<0xdc00 || in[i+1]>0xdfff)return 0;
            c=0x10000+((c-0xd800)<<10)+(in[++i]-0xdc00);
        } else if(c>=0xdc00 && c<=0xdfff)return 0;
        if(c=='/' || c=='\\' || c<32)return 0;
        unsigned encoded=c<128?1:c<2048?2:c<65536?3:4;
        if(n+encoded>=FS_NAME_BYTES)return 0;
        if(c<128)out[n++]=(char)c;
        else if(c<2048){out[n++]=(char)(0xc0|(c>>6));out[n++]=(char)(0x80|(c&63));}
        else if(c<65536){out[n++]=(char)(0xe0|(c>>12));out[n++]=(char)(0x80|((c>>6)&63));out[n++]=(char)(0x80|(c&63));}
        else{out[n++]=(char)(0xf0|(c>>18));out[n++]=(char)(0x80|((c>>12)&63));out[n++]=(char)(0x80|((c>>6)&63));out[n++]=(char)(0x80|(c&63));}
        if(n>=FS_NAME_BYTES)return 0;
    }
    out[n]=0;return n!=0;
}
static char sfn_char(uint8_t c,int lower) {
    if(lower && c>='A' && c<='Z')c=(uint8_t)(c+32);
    return c>=32 && c<127?(char)c:'?';
}
static void short_name(const uint8_t e[32],char *out) {
    unsigned n=0;
    for(unsigned i=0;i<8 && e[i]!=' ';i++)out[n++]=sfn_char(e[i],e[12]&8);
    if(e[8]!=' '){out[n++]='.';for(unsigned i=8;i<11 && e[i]!=' ';i++)out[n++]=sfn_char(e[i],e[12]&16);}
    out[n]=0;
}
static fs_status dir_next(fs_dir *d,fs_entry *out,unsigned *budget) {
    static const uint8_t positions[13]={1,3,5,7,9,14,16,18,20,22,24,28,30};
    uint8_t e[32];fs_status r;
    if(!d || !out || !d->volume || !d->volume->reader)return FS_INVALID;
    while(*budget) {
        --*budget;
        r=raw_entry(d,e);if(r!=FS_OK)return r;
        if(!e[0]){d->ended=1;return FS_END;}
        if(e[0]==0xe5){d->lfn_expected=0;d->lfn_count=0;continue;}
        if(e[11]==15) {
            unsigned ord=e[0]&31;
            if((e[0]&0x40) && !(e[0]&0xa0) && ord && ord<=20) {
                for(unsigned i=0;i<260;i++)d->lfn[i]=0xffff;
                d->lfn_expected=(uint8_t)ord;d->lfn_count=(uint8_t)ord;d->lfn_checksum=e[13];
            }
            if(!ord || ord!=d->lfn_expected || e[13]!=d->lfn_checksum || e[12] || le16(e+26) || (e[0]&0xa0)) {
                d->lfn_count=0;d->lfn_expected=0;continue;
            }
            for(unsigned i=0;i<13;i++)d->lfn[(ord-1)*13+i]=le16(e+positions[i]);
            d->lfn_expected--;continue;
        }
        if((e[0]=='.' && (e[1]==' ' || (e[1]=='.' && e[2]==' '))) || (e[11]&8)){d->lfn_count=0;d->lfn_expected=0;continue;}
        if(!d->lfn_count || d->lfn_expected || checksum(e)!=d->lfn_checksum ||
           !utf8(d->lfn,d->lfn_count*13,out->name))short_name(e,out->name);
        d->lfn_count=0;d->lfn_expected=0;
        out->attributes=e[11];out->size=le32(e+28);out->modified=le32(e+22);
        out->cluster=le16(e+26);
        if(d->volume->fat_bits==32)out->cluster|=(uint32_t)le16(e+20)<<16;
        if((out->cluster && !cluster_ok(d->volume,out->cluster)) ||
           (!out->cluster && (out->size || (out->attributes&16))))return FS_CORRUPT;
        return FS_OK;
    }
    return FS_AGAIN;
}
fs_status fs_dir_next(fs_dir *d,fs_entry *out) {
    unsigned budget=32;return dir_next(d,out,&budget);
}
static int match(const char *name,const char *part,size_t n) {
    size_t i=0;for(;i<n && name[i];i++) {
        unsigned a=(uint8_t)name[i],b=(uint8_t)part[i];
        if(a>='A'&&a<='Z')a+=32;
        if(b>='A'&&b<='Z')b+=32;
        if(a!=b)return 0;
    }
    return i==n && !name[i];
}
fs_status fs_lookup_begin(fs *v,const char *path,fs_lookup *l) {
    size_t n=0;
    if(!v || !v->reader || !path || !l)return FS_INVALID;
    while(path[n]){if(n>=FS_PATH_BYTES)return FS_INVALID;n++;}
    clear(l,sizeof(*l));l->volume=v;l->cursor=path;
    l->entry.cluster=v->root_cluster;l->entry.attributes=16;
    return FS_OK;
}
fs_status fs_lookup_step(fs_lookup *l,fs_entry *out) {
    unsigned budget=32;fs_status r;
    if(!l || !out || !l->volume || !l->volume->reader)return FS_INVALID;
    if(l->done){copy(out,&l->entry,sizeof(*out));return FS_OK;}
    while(budget) {
        if(!l->searching) {
            while(*l->cursor=='/')l->cursor++;
            if(!*l->cursor){l->done=1;copy(out,&l->entry,sizeof(*out));return FS_OK;}
            l->component=l->cursor;
            while(*l->cursor && *l->cursor!='/')l->cursor++;
            l->component_bytes=(size_t)(l->cursor-l->component);
            if(l->component_bytes>=FS_NAME_BYTES ||
               (l->component_bytes==1 && l->component[0]=='.') ||
               (l->component_bytes==2 && l->component[0]=='.' && l->component[1]=='.'))return FS_INVALID;
            if(!(l->entry.attributes&16))return FS_NOT_DIRECTORY;
            dir_init(l->volume,l->entry.cluster,&l->directory);l->searching=1;
        }
        r=dir_next(&l->directory,&l->entry,&budget);
        if(r==FS_END)return FS_NOT_FOUND;
        if(r!=FS_OK)return r;
        if(match(l->entry.name,l->component,l->component_bytes))l->searching=0;
    }
    return FS_AGAIN;
}
fs_status fs_dir_open_entry(fs *v,const fs_entry *e,fs_dir *out) {
    if(!v || !v->reader || !e || !out)return FS_INVALID;
    if(!(e->attributes&16))return FS_NOT_DIRECTORY;
    if(!cluster_ok(v,e->cluster) && !(v->fat_bits==16 && !e->cluster))return FS_CORRUPT;
    dir_init(v,e->cluster,out);return FS_OK;
}
fs_status fs_open_entry(fs *v,const fs_entry *e,fs_file *out) {
    if(!v || !v->reader || !e || !out)return FS_INVALID;
    if(e->attributes&16)return FS_IS_DIRECTORY;
    if((e->cluster && !cluster_ok(v,e->cluster)) || (!e->cluster && e->size))return FS_CORRUPT;
    clear(out,sizeof(*out));out->volume=v;out->size=e->size;
    out->cluster=out->start_cluster=e->cluster;out->slow=e->cluster;out->fast=e->cluster;
    return FS_OK;
}
static fs_status lookup(fs *v,const char *path,fs_entry *e) {
    size_t total=0;fs_dir d;const char *p;fs_status r;
    if(!v || !v->reader || !path)return FS_INVALID;
    while(path[total]){if(total>=FS_PATH_BYTES)return FS_INVALID;total++;}
    p=path;while(*p=='/')p++;
    e->cluster=v->root_cluster;e->attributes=16;e->size=0;e->modified=0;e->name[0]=0;
    while(*p) {
        const char *start=p;size_t n;
        while(*p && *p!='/')p++;
        n=(size_t)(p-start);
        if(!n || n>=FS_NAME_BYTES || (n==1 && start[0]=='.') ||
           (n==2 && start[0]=='.' && start[1]=='.'))return FS_INVALID;
        if(!(e->attributes&16))return FS_NOT_DIRECTORY;
        dir_init(v,e->cluster,&d);
        do{r=fs_dir_next(&d,e);}while((r==FS_AGAIN && !v->io_pending) || (r==FS_OK && !match(e->name,start,n)));
        if(r==FS_END)return FS_NOT_FOUND;
        if(r!=FS_OK)return r;
        while(*p=='/')p++;
    }
    return FS_OK;
}
fs_status fs_dir_open(fs *v,const char *path,fs_dir *out) {
    fs_entry e;fs_status r;if(!out)return FS_INVALID;
    r=lookup(v,path,&e);if(r!=FS_OK)return r;
    if(!(e.attributes&16))return FS_NOT_DIRECTORY;
    dir_init(v,e.cluster,out);return FS_OK;
}
fs_status fs_open(fs *v,const char *path,fs_file *out) {
    fs_entry e;fs_status r;if(!out)return FS_INVALID;
    r=lookup(v,path,&e);if(r!=FS_OK)return r;
    if(e.attributes&16)return FS_IS_DIRECTORY;
    clear(out,sizeof(*out));out->volume=v;out->size=e.size;
    out->cluster=out->start_cluster=e.cluster;out->slow=e.cluster;out->fast=e.cluster;
    return FS_OK;
}
static fs_status locate(fs_file *f,uint32_t offset) {
    uint32_t wanted=offset/((uint32_t)f->volume->sectors_per_cluster*512);fs_status r;
    if(wanted<f->cluster_index){f->cluster=f->start_cluster;f->cluster_index=0;f->hops=0;f->slow=f->fast=f->start_cluster;}
    while(f->cluster_index<wanted) {
        r=advance(f->volume,&f->cluster,&f->slow,&f->fast,&f->hops);
        if(r!=FS_OK)return r==FS_END?FS_CORRUPT:r;
        f->cluster_index++;
    }
    return cluster_ok(f->volume,f->cluster)?FS_OK:FS_CORRUPT;
}
fs_status fs_seek(fs_file *f,uint32_t offset) {
    fs_status r;
    if(!f || !f->volume || !f->volume->reader || f->failed || offset>f->size)return FS_INVALID;
    if(offset<f->size){r=locate(f,offset);if(r!=FS_OK){if(r!=FS_AGAIN)f->failed=1;return r;}}
    f->offset=offset;return FS_OK;
}
fs_status fs_read(fs_file *f,void *dst,size_t bytes,size_t *got) {
    uint8_t *out=dst;fs_status r;size_t n;uint32_t s;
    if(got)*got=0;
    if(!f || !f->volume || !f->volume->reader || f->failed || !got || (!out && bytes))return FS_INVALID;
    if(bytes>f->size-f->offset)bytes=f->size-f->offset;
    while(bytes) {
        r=locate(f,f->offset);if(r!=FS_OK){if(r!=FS_AGAIN)f->failed=1;return r;}
        s=f->volume->data_start+(f->cluster-2)*f->volume->sectors_per_cluster+
          (f->offset/512)%f->volume->sectors_per_cluster;
        r=sector(f->volume,s);if(r!=FS_OK){if(r!=FS_AGAIN)f->failed=1;return r;}
        n=512-f->offset%512;if(n>bytes)n=bytes;
        copy(out,f->volume->cache+f->offset%512,n);
        out+=n;bytes-=n;*got+=n;f->offset+=(uint32_t)n;
    }
    return FS_OK;
}
