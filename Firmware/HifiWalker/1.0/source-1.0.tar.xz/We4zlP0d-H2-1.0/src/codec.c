#include "codec.h"
#include "codec_m4a.h"
#include "codec_ogg.h"
#include "codec_vorbis.h"
#include "codec_mp3.h"
#include <string.h>
#include <stdlib.h>
#include <limits.h>
static codec *active;
static void progress_checkpoint(void)
{
#if CODEC_COOPERATIVE_PROGRESS
    extern void codec_runtime_checkpoint(void);
    codec_runtime_checkpoint(); /* Ownership stays active across worker yield. */
#endif
}
/* Eight-byte block headers: total span and requested size (zero means free).
 * Caller arena is the sole allocation source. Coalesce/split fixed bounded blocks. */
static void block_write(uint8_t *p,uint32_t span,uint32_t used)
{
    uint32_t h[2]={span,used};memcpy(p,h,sizeof(h));
}
static void arena_free(codec *c,void *p)
{
    if(!c || !p)return;
    size_t at=0;
    while(at<c->arena_used){uint32_t h[2];memcpy(h,c->arena+at,8);
        if(h[0]<8 || h[0]>c->arena_used-at)return;
        if(c->arena+at+8==(uint8_t *)p){block_write(c->arena+at,h[0],0);return;}
        at+=h[0];
    }
}
static void *arena_alloc(codec *c,size_t n)
{
    if(!c)return NULL;
    if(n>UINT32_MAX-15u){c->allocation_failed=1;return NULL;}
    size_t count=(n+15u)&~(size_t)7u,at=0;
    while(at<c->arena_used){uint32_t h[2];memcpy(h,c->arena+at,8);
        if(h[0]<8 || h[0]>c->arena_used-at)return NULL;
        if(!h[1]){
            while(at+h[0]<c->arena_used){uint32_t next[2];memcpy(next,c->arena+at+h[0],8);
                if(next[0]<8 || next[0]>c->arena_used-at-h[0])return NULL;
                if(next[1])break;
                h[0]+=next[0];block_write(c->arena+at,h[0],0);
            }
            if(h[0]>=count){
                if(h[0]-count>=16){block_write(c->arena+at+count,h[0]-(uint32_t)count,0);h[0]=(uint32_t)count;}
                block_write(c->arena+at,h[0],n?(uint32_t)n:1);return c->arena+at+8;
            }
        }
        at+=h[0];
    }
    if(c->arena_used>c->arena_size || count>c->arena_size-c->arena_used){c->allocation_failed=1;return NULL;}
    uint8_t *p=c->arena+c->arena_used;c->arena_used+=count;
    if(c->arena_peak<c->arena_used)c->arena_peak=c->arena_used;
    block_write(p,(uint32_t)count,n?(uint32_t)n:1);return p+8;
}
static void *arena_realloc(codec *c,void *p,size_t n)
{
    if(!c)return NULL;
    if(!p)return arena_alloc(c,n);
    if(!n){arena_free(c,p);return NULL;}
    if(n>UINT32_MAX-15u){c->allocation_failed=1;return NULL;}
    uint32_t h[2];memcpy(h,(uint8_t *)p-8,8);
    size_t count=(n+15u)&~(size_t)7u;
    if(count<=h[0]){block_write((uint8_t *)p-8,h[0],(uint32_t)n);return p;}
    size_t at=(size_t)((uint8_t *)p-8-c->arena),available=h[0];
    while(at+available<c->arena_used){uint32_t next[2];memcpy(next,c->arena+at+available,8);
        if(next[0]<8 || next[0]>c->arena_used-at-available || next[1])break;
        available+=next[0];
    }
    if(available<count && at+available==c->arena_used && count-available<=c->arena_size-c->arena_used){
        c->arena_used+=count-available;available=count;
        if(c->arena_peak<c->arena_used)c->arena_peak=c->arena_used;
    }
    if(available>=count){
        if(available-count>=16)block_write(c->arena+at+count,(uint32_t)(available-count),0);
        else count=available;
        block_write(c->arena+at,(uint32_t)count,(uint32_t)n);return p;
    }
    void *q=arena_alloc(c,n);if(!q)return NULL;
    memcpy(q,p,h[1]);arena_free(c,p);return q;
}
static void *allocation_result(codec *c,void *p)
{
    if(!p && c){
        c->allocation_failed=1;
#if CODEC_FAULT_ON_ALLOC
        extern _Noreturn void codec_runtime_fault(unsigned reason);
        c->status=CODEC_MEMORY;codec_runtime_fault(2u);
#endif
    }
    if(c && p)progress_checkpoint();
    return p;
}
void *codec_pool_alloc(codec *c,size_t n) {return arena_alloc(c,n);}
void *codec_library_malloc(size_t n) {return allocation_result(active,arena_alloc(active,n));}
void codec_library_free(void *p) {arena_free(active,p);if(active && p)progress_checkpoint();}
void *codec_library_calloc(size_t n,size_t bytes)
{
    if(bytes && n>SIZE_MAX/bytes)return allocation_result(active,NULL);
    void *p=allocation_result(active,arena_alloc(active,n*bytes));if(p)memset(p,0,n*bytes);return p;
}
void *codec_library_realloc(void *p,size_t n) {void *q=arena_realloc(active,p,n);return n?allocation_result(active,q):q;}

#if CODEC_ENABLE_MP3 && !CODEC_MP3_FIXED
#define malloc(n) arena_alloc(active,n)
#define realloc(p,n) arena_realloc(active,p,n)
#define free(p) arena_free(active,p)
#define MINIMP3_IMPLEMENTATION
#define MINIMP3_NO_STDIO
#define MINIMP3_NO_SIMD
#define MINIMP3_ONLY_MP3
#define MINIMP3_IO_SIZE (32*1024)
#define MINIMP3_SCAN_LIMIT (256*1024)
#include "../third_party/minimp3/minimp3_ex.h"
#undef malloc
#undef realloc
#undef free

#endif
#if CODEC_ENABLE_FLAC
#define DR_FLAC_IMPLEMENTATION
#define DR_FLAC_NO_STDIO
#define DR_FLAC_NO_OGG
#define DR_FLAC_NO_SIMD
#define DRFLAC_ASSERT(x) ((void)0)
#define DRFLAC_MALLOC(n) ((void)(n),(void *)0)
#define DRFLAC_REALLOC(p,n) ((void)(p),(void)(n),(void *)0)
#define DRFLAC_FREE(p) ((void)(p))
#ifndef DRFLAC_COOPERATIVE_SAMPLES
#define DRFLAC_COOPERATIVE_SAMPLES 128
#endif
#ifndef DRFLAC_ON_COOPERATIVE_SLICE
#define DRFLAC_ON_COOPERATIVE_SLICE()
#endif
#if CODEC_COOPERATIVE_PROGRESS
extern void codec_runtime_checkpoint(void);
#undef DRFLAC_ON_COOPERATIVE_SLICE
#define DRFLAC_ON_COOPERATIVE_SLICE() codec_runtime_checkpoint()
#endif
#include "../third_party/dr_libs/dr_flac.h"

#endif
#if CODEC_ENABLE_FLAC || (CODEC_ENABLE_MP3 && !CODEC_MP3_FIXED)
typedef struct {
#if CODEC_ENABLE_FLAC
    drflac *flac;
#endif
#if CODEC_ENABLE_MP3 && !CODEC_MP3_FIXED
    mp3dec_ex_t mp3;
    mp3dec_io_t mp3io;
#endif
    size_t cursor;
    int io_fault;
} implementation;
static size_t stream_read(codec *c,void *p,size_t n)
{
    implementation *i=c->implementation;
    if(i->cursor>c->source.size){i->io_fault=1;return 0;}
    size_t left=c->source.size-i->cursor;if(n>left)n=left;
    if(n && !c->source.read(c->source.context,i->cursor,p,n)){i->io_fault=1;return 0;}
    i->cursor+=n;return n;
}
#endif
#if CODEC_ENABLE_FLAC
static size_t flac_read(void *p,void *out,size_t n){return stream_read(p,out,n);}
static drflac_bool32 flac_seek(void *p,int offset,drflac_seek_origin origin)
{
    codec *c=p;implementation *i=c->implementation;
    int64_t base=origin==DRFLAC_SEEK_SET?0:origin==DRFLAC_SEEK_CUR?(int64_t)i->cursor:-1;
    if(base<0 || (offset<0 && base<-(int64_t)offset))return 0;
    uint64_t at=(uint64_t)(base+offset);if(at>c->source.size)return 0;
    i->cursor=(size_t)at;return 1;
}
static drflac_bool32 flac_tell(void *p,drflac_int64 *at){*at=(drflac_int64)((implementation *)((codec *)p)->implementation)->cursor;return 1;}
static void *flac_alloc(size_t n,void *p){return allocation_result(p,arena_alloc(p,n));}
static void *flac_realloc(void *old,size_t n,void *p){void *q=arena_realloc(p,old,n);return n?allocation_result(p,q):q;}
static void flac_free(void *old,void *p){arena_free(p,old);}
#endif
#if CODEC_ENABLE_MP3 && !CODEC_MP3_FIXED
static size_t mp3_read(void *out,size_t n,void *p){return stream_read(p,out,n);}
static int mp3_seek(uint64_t at,void *p)
{
    codec *c=p;if(at>c->source.size)return -1;
    ((implementation *)c->implementation)->cursor=(size_t)at;return 0;
}
#endif
static int enabled(codec_kind kind)
{
    switch(kind){
    case CODEC_FLAC:return CODEC_ENABLE_FLAC;
    case CODEC_MP3:return CODEC_ENABLE_MP3;
    case CODEC_AAC_M4A:return CODEC_ENABLE_AAC;
    case CODEC_OGG_VORBIS:return CODEC_ENABLE_VORBIS;
    case CODEC_OGG_OPUS:return CODEC_ENABLE_OPUS;
    }
    return 0;
}
codec_status codec_open(codec *c,codec_kind kind,const wav_reader *source,void *arena,size_t bytes)
{
    if(active)return CODEC_BUSY;
    if(!c || !source || !source->read || source->size>UINT32_MAX || bytes>UINT32_MAX || !arena || ((uintptr_t)arena&7u) || (unsigned)kind>CODEC_OGG_VORBIS)return CODEC_INVALID;
    *c=(codec){.source=*source,.kind=kind,.arena=arena,.arena_size=bytes,.status=CODEC_INVALID};
    if(!enabled(kind))return c->status=CODEC_UNSUPPORTED;
    active=c;
#if CODEC_ENABLE_MP3 && CODEC_MP3_FIXED
    if(kind==CODEC_MP3)c->status=codec_mp3_open(c);
#endif
#if CODEC_ENABLE_VORBIS
    if(kind==CODEC_OGG_VORBIS)c->status=codec_vorbis_open(c);
#endif
#if CODEC_ENABLE_OPUS
    if(kind==CODEC_OGG_OPUS)c->status=codec_ogg_open(c);
#endif
#if CODEC_ENABLE_AAC
    if(kind==CODEC_AAC_M4A)c->status=codec_m4a_open(c);
#endif
#if CODEC_ENABLE_FLAC || (CODEC_ENABLE_MP3 && !CODEC_MP3_FIXED)
    if(kind==CODEC_FLAC || (kind==CODEC_MP3 && !CODEC_MP3_FIXED)){
        implementation *i=arena_alloc(c,sizeof(*i));
        if(!i)c->status=CODEC_MEMORY;
        else{
            memset(i,0,sizeof(*i));c->implementation=i;
#if CODEC_ENABLE_FLAC
            if(kind==CODEC_FLAC){
                drflac_allocation_callbacks a={c,flac_alloc,flac_realloc,flac_free};
                i->flac=drflac_open(flac_read,flac_seek,flac_tell,c,&a);
                if(!i->flac)c->status=c->allocation_failed?CODEC_MEMORY:i->io_fault?CODEC_IO:CODEC_INVALID;
                else{
                    drflac *f=i->flac;
                    c->info=(codec_info){.rate=f->sampleRate,.channels=f->channels,.bits=f->bitsPerSample,.total_frames=f->totalPCMFrameCount,.total_known=f->totalPCMFrameCount!=0,.delay_known=1,.padding_known=1,.trimming_applied=1};
                    c->status=f->channels<1 || f->channels>2 || f->bitsPerSample!=16 || f->sampleRate<8000 || f->sampleRate>96000 || f->maxBlockSizeInPCMFrames>4096?CODEC_UNSUPPORTED:CODEC_OK;
                }
            }
#endif
#if CODEC_ENABLE_MP3 && !CODEC_MP3_FIXED
            if(kind==CODEC_MP3){
                i->mp3io=(mp3dec_io_t){mp3_read,c,mp3_seek,c};
                int result=mp3dec_ex_open_cb(&i->mp3,&i->mp3io,MP3D_DO_NOT_SCAN);
                if(result)c->status=result==MP3D_E_MEMORY?CODEC_MEMORY:i->io_fault?CODEC_IO:CODEC_INVALID;
                else{
                    mp3dec_ex_t *m=&i->mp3;
                    c->info=(codec_info){.rate=(uint32_t)m->info.hz,.channels=(uint16_t)m->info.channels,.bits=16,.total_frames=m->info.channels?m->samples/(unsigned)m->info.channels:0,.total_known=m->vbr_tag_found!=0,.delay_frames=m->info.channels?(uint32_t)m->start_delay/(unsigned)m->info.channels:0,.delay_known=m->vbr_tag_found!=0,.trimming_applied=m->vbr_tag_found!=0};
                    c->status=m->info.layer!=3 || m->info.channels<1 || m->info.channels>2 || m->info.hz<8000 || m->info.hz>48000?CODEC_UNSUPPORTED:CODEC_OK;
                }
            }
#endif
        }
    }
#endif
    active=NULL;return c->status;
}
codec_status codec_read(codec *c,int16_t *out,size_t capacity,size_t *frames)
{
    if(!c || !frames || !out || !capacity || capacity>4096)return CODEC_INVALID;
    *frames=0;if(active)return CODEC_BUSY;
    if(c->status!=CODEC_OK)return c->status;
    if(!c->implementation)return CODEC_INVALID;
    active=c;codec_status result=CODEC_UNSUPPORTED;
#if CODEC_ENABLE_MP3 && CODEC_MP3_FIXED
    if(c->kind==CODEC_MP3)result=codec_mp3_read(c,out,capacity,frames);
#endif
#if CODEC_ENABLE_VORBIS
    if(c->kind==CODEC_OGG_VORBIS)result=codec_vorbis_read(c,out,capacity,frames);
#endif
#if CODEC_ENABLE_OPUS
    if(c->kind==CODEC_OGG_OPUS)result=codec_ogg_read(c,out,capacity,frames);
#endif
#if CODEC_ENABLE_AAC
    if(c->kind==CODEC_AAC_M4A)result=codec_m4a_read(c,out,capacity,frames);
#endif
#if CODEC_ENABLE_FLAC || (CODEC_ENABLE_MP3 && !CODEC_MP3_FIXED)
    if(c->kind==CODEC_FLAC || (c->kind==CODEC_MP3 && !CODEC_MP3_FIXED)){
        implementation *i=c->implementation;size_t n=0;
#if CODEC_ENABLE_FLAC
        if(c->kind==CODEC_FLAC)n=(size_t)drflac_read_pcm_frames_s16(i->flac,capacity,out);
#endif
#if CODEC_ENABLE_MP3 && !CODEC_MP3_FIXED
        if(c->kind==CODEC_MP3)n=mp3dec_ex_read(&i->mp3,out,capacity*c->info.channels)/c->info.channels;
#endif
        result=CODEC_OK;
        if(i->io_fault)result=CODEC_IO;
#if CODEC_ENABLE_MP3 && !CODEC_MP3_FIXED
        else if(c->kind==CODEC_MP3 && i->mp3.last_error)result=CODEC_INVALID;
#endif
        else if(!n)result=c->info.total_known && c->position<c->info.total_frames?CODEC_INVALID:CODEC_END;
        *frames=n;
    }
#endif
    active=NULL;c->position+=*frames;c->status=result;return result;
}
codec_status codec_seek(codec *c,uint64_t frame)
{
    if(!c || !c->implementation)return CODEC_INVALID;
    if(active)return CODEC_BUSY;
#if CODEC_ENABLE_FLAC
    if(c->kind==CODEC_FLAC){
        if(c->info.total_known && frame>c->info.total_frames)return CODEC_INVALID;
        implementation *i=c->implementation;active=c;
        int ok=drflac_seek_to_pcm_frame(i->flac,frame);active=NULL;
        if(ok){c->position=frame;c->status=CODEC_OK;}
        return ok?CODEC_OK:CODEC_INVALID;
    }
#else
    (void)frame;
#endif
    return CODEC_UNSUPPORTED;
}
codec_status codec_reset(codec *c)
{
    if(!c)return CODEC_INVALID;
    wav_reader source=c->source;codec_kind kind=c->kind;void *arena=c->arena;size_t n=c->arena_size;
    codec_close(c);return codec_open(c,kind,&source,arena,n);
}
void codec_close(codec *c)
{
    if(!c || !c->implementation || active)return;
    active=c;
#if CODEC_ENABLE_MP3 && CODEC_MP3_FIXED
    if(c->kind==CODEC_MP3)codec_mp3_close(c);
#endif
#if CODEC_ENABLE_VORBIS
    if(c->kind==CODEC_OGG_VORBIS)codec_vorbis_close(c);
#endif
#if CODEC_ENABLE_OPUS
    if(c->kind==CODEC_OGG_OPUS)codec_ogg_close(c);
#endif
#if CODEC_ENABLE_AAC
    if(c->kind==CODEC_AAC_M4A)codec_m4a_close(c);
#endif
#if CODEC_ENABLE_FLAC
    if(c->kind==CODEC_FLAC){implementation *i=c->implementation;if(i->flac)drflac_close(i->flac);}
#endif
#if CODEC_ENABLE_MP3 && !CODEC_MP3_FIXED
    if(c->kind==CODEC_MP3){implementation *i=c->implementation;mp3dec_ex_close(&i->mp3);}
#endif
    active=NULL;c->implementation=NULL;c->status=CODEC_INVALID;
}

codec_status codec_abandon(codec *c)
{
    if(!c)return CODEC_INVALID;
    if(active && active!=c)return CODEC_BUSY;
    active=NULL;c->implementation=NULL;c->arena_used=0;c->position=0;
    c->info=(codec_info){0};c->allocation_failed=0;c->status=CODEC_INVALID;
    return CODEC_OK;
}

codec_status codec_next(codec *c,const wav_reader *next)
{
    if(active)return CODEC_BUSY;
    if(!c || !next || !next->read || next->size>UINT32_MAX || !c->implementation)return CODEC_INVALID;
    if(c->status!=CODEC_END && !(c->info.total_known && c->position==c->info.total_frames))return CODEC_BUSY;
#if CODEC_ENABLE_VORBIS
    if(c->kind==CODEC_OGG_VORBIS){
        active=c;codec_status result=codec_vorbis_next(c,next);active=NULL;
        if(result==CODEC_OK){c->position=0;c->status=CODEC_OK;}
        return result;
    }
#endif
    return CODEC_UNSUPPORTED;
}
