#include "codec_mp3.h"
#include <limits.h>
#include <string.h>
#include "../third_party/libmad/fixed.h"
#include "../third_party/libmad/timer.h"
#include "../third_party/libmad/stream.h"
#include "../third_party/libmad/frame.h"
#include "../third_party/libmad/synth.h"
extern void *codec_pool_alloc(codec *,size_t);
typedef struct {
 struct mad_stream stream;struct mad_frame frame;struct mad_synth synth;
 size_t cursor,bytes;uint32_t skip;unsigned pcm_at;uint8_t eof;
 uint8_t input[8192+MAD_BUFFER_GUARD];
} mp3_state;
static uint32_t be32(const uint8_t*p){return (uint32_t)p[0]<<24|(uint32_t)p[1]<<16|(uint32_t)p[2]<<8|p[3];}
static int rd(codec*c,size_t at,void*p,size_t n){return at<=c->source.size && n<=c->source.size-at && c->source.read(c->source.context,at,p,n);}
/* Xing/LAME field layout and529 decoder-delay convention corroborated by
 * pinned CC0 minimp3 mp3dec_check_vbrtag; no whole-track scan/seek index. */
static codec_status header(codec*c,mp3_state*s)
{
 uint8_t h[10];if(!rd(c,0,h,10))return CODEC_IO;size_t start=0;
 if(!memcmp(h,"ID3",3)){
  if(h[3]<2 || h[3]>4 || ((h[6]|h[7]|h[8]|h[9])&128))return CODEC_UNSUPPORTED;
  start=10+((size_t)h[6]<<21| (size_t)h[7]<<14 | (size_t)h[8]<<7 | h[9]);if(h[3]==4 && (h[5]&16))start+=10;
 }
 if(!rd(c,start,h,4))return CODEC_IO;
 unsigned version=(h[1]>>3)&3,layer=(h[1]>>1)&3,bi=h[2]>>4,ri=(h[2]>>2)&3;
 if(h[0]!=255 || (h[1]&224)!=224 || version==1 || layer!=1 || !bi || bi==15 || ri==3)return CODEC_UNSUPPORTED;
 static const unsigned rate[3]={44100,48000,32000},br1[15]={0,32,40,48,56,64,80,96,112,128,160,192,224,256,320},br2[15]={0,8,16,24,32,40,48,56,64,80,96,112,128,144,160};
 unsigned hz=rate[ri]>>(version==3?0:version==2?1:2),channels=(h[3]>>6)==3?1:2;
 unsigned size=(version==3?144000:72000)*(version==3?br1[bi]:br2[bi])/hz+((h[2]>>1)&1),samples=version==3?1152:576;
 if(size<16 || size>sizeof(s->input) || !rd(c,start,s->input,size))return CODEC_IO;
 c->info=(codec_info){.rate=hz,.channels=(uint16_t)channels,.bits=16};s->cursor=start;
 size_t at=4+(!(h[1]&1)?2:0)+(version==3?(channels==1?17:32):(channels==1?9:17));
 if(at+12<=size && (!memcmp(s->input+at,"Xing",4) || !memcmp(s->input+at,"Info",4))){
  uint32_t flags=be32(s->input+at+4);if(!(flags&1) || (flags&~15u))return CODEC_UNSUPPORTED;
  uint32_t frames=be32(s->input+at+8);at+=12;
  if(flags&2)at+=4;if(flags&4)at+=100;if(flags&8)at+=4;if(at>size || !frames)return CODEC_INVALID;
  uint64_t total=(uint64_t)frames*samples;
  if(size-at>=36 && s->input[at]){
   unsigned delay=((unsigned)s->input[at+21]<<4)|(s->input[at+22]>>4),padding=((s->input[at+22]&15u)<<8)|s->input[at+23];
   if(padding<529 || (uint64_t)delay+padding>=total)return CODEC_UNSUPPORTED;
   s->skip=delay+529;c->info.delay_frames=s->skip;c->info.padding_frames=padding-529;
   c->info.delay_known=c->info.padding_known=c->info.trimming_applied=1;total-=delay+padding;
  }
  c->info.total_frames=total;c->info.total_known=1;s->cursor=start+size;
 }
 return CODEC_OK;
}
codec_status codec_mp3_open(codec*c)
{
 mp3_state*s=codec_pool_alloc(c,sizeof(*s));if(!s)return CODEC_MEMORY;memset(s,0,sizeof(*s));c->implementation=s;
 mad_stream_init(&s->stream);mad_frame_init(&s->frame);mad_synth_init(&s->synth);return header(c,s);
}
static codec_status refill(codec*c,mp3_state*s)
{
 if(s->eof)return CODEC_END;size_t remain=0;
 if(s->stream.next_frame){const uint8_t*p=s->stream.next_frame;if(p<s->input || p>s->input+s->bytes)return CODEC_INVALID;remain=s->bytes-(size_t)(p-s->input);memmove(s->input,p,remain);}
 if(remain>=8192)return CODEC_INVALID;
 size_t n=8192-remain;if(n>c->source.size-s->cursor)n=c->source.size-s->cursor;
 if(n && !rd(c,s->cursor,s->input+remain,n))return CODEC_IO;s->cursor+=n;s->bytes=remain+n;
 if(s->cursor==c->source.size){memset(s->input+s->bytes,0,MAD_BUFFER_GUARD);s->bytes+=MAD_BUFFER_GUARD;s->eof=1;}
 mad_stream_buffer(&s->stream,s->input,(unsigned long)s->bytes);return CODEC_OK;
}
codec_status codec_mp3_read(codec*c,int16_t*out,size_t capacity,size_t*frames)
{
 mp3_state*s=c->implementation;*frames=0;unsigned decoded=0;
 while(*frames<capacity){
  if(c->info.total_known && c->position+*frames>=c->info.total_frames)return *frames?CODEC_OK:CODEC_END;
  if(s->pcm_at==s->synth.pcm.length){
   if(++decoded>2)return CODEC_OK;
   if(!s->bytes){codec_status z=refill(c,s);if(z!=CODEC_OK)return z;}
   if(mad_frame_decode(&s->frame,&s->stream)){
    if(s->stream.error==MAD_ERROR_BUFLEN){codec_status z=refill(c,s);if(z==CODEC_END)return c->info.total_known?CODEC_INVALID:(*frames?CODEC_OK:CODEC_END);if(z!=CODEC_OK)return z;--decoded;continue;}
    return c->allocation_failed?CODEC_MEMORY:CODEC_INVALID;
   }
   if(s->frame.header.layer!=MAD_LAYER_III || s->frame.header.samplerate!=c->info.rate || (s->frame.header.mode==MAD_MODE_SINGLE_CHANNEL?1u:2u)!=c->info.channels)return CODEC_UNSUPPORTED;
   mad_synth_frame(&s->synth,&s->frame);s->pcm_at=0;
   unsigned skip=s->skip<s->synth.pcm.length?s->skip:s->synth.pcm.length;s->skip-=skip;s->pcm_at=skip;
  }
  size_t n=s->synth.pcm.length-s->pcm_at;if(n>capacity-*frames)n=capacity-*frames;
  if(c->info.total_known && n>c->info.total_frames-c->position-*frames)n=(size_t)(c->info.total_frames-c->position-*frames);
  for(size_t j=0;j<n;++j)for(unsigned ch=0;ch<c->info.channels;++ch){int64_t v=(int64_t)s->synth.pcm.samples[ch][s->pcm_at+j]+(1<<12);v>>=13;if(v>32767)v=32767;if(v< -32768)v=-32768;out[(*frames+j)*c->info.channels+ch]=(int16_t)v;}
  s->pcm_at+=(unsigned)n;*frames+=n;
 }
 return CODEC_OK;
}
void codec_mp3_close(codec*c){mp3_state*s=c->implementation;if(s){mad_frame_finish(&s->frame);mad_stream_finish(&s->stream);}}
