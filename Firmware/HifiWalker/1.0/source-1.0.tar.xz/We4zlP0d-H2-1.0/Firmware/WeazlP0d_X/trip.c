#include "trip.h"

enum { HEADER = 16, RECORD = 80, VIEW_BYTES = 60, ADPCM_BYTES = 512, ADPCM_FRAMES = 505 };
enum { ALBUM_BITS = 12, ALBUM_MASK = (1u << ALBUM_BITS) - 1, ALBUM_ENTRY = 8,
       INDEX_HEADER = 12, LYRIC_CUE = 52 };

static uint32_t table_end(const trip_player *p)
{
    return p->header + (p->count + p->stations) * p->stride + p->views * VIEW_BYTES;
}

static uint32_t le32(const uint8_t *p)
{
    return (uint32_t)p[0] | (uint32_t)p[1] << 8 | (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24;
}

static uint32_t indexed_end(const trip_player *p, uint32_t base, uint32_t magic)
{
    uint8_t header[INDEX_HEADER];
    uint32_t remaining = p->size - base;
    if (remaining < sizeof header || p->count > (remaining - sizeof header) / 4 ||
        !p->read(p->context, 0, base, header, sizeof header) || le32(header) != magic ||
        le32(header + 4) != p->count)
        return 0;
    uint32_t size = le32(header + 8);
    return size >= sizeof header + 4 * p->count && size <= remaining ? base + size : 0;
}

static void read_long_labels(trip_player *p, uint32_t row)
{
    if (!p->metadata_map || row >= p->count)
        return;
    uint8_t pointer[4], lengths[2], text[2 * TRIP_LABEL_BYTES];
    uint32_t base = p->metadata_map, bytes = p->metadata_end - base;
    if (!p->read(p->context, 0, base + INDEX_HEADER + 4 * row, pointer, sizeof pointer))
        return;
    uint32_t offset = le32(pointer);
    if (offset < INDEX_HEADER + 4 * p->count || offset > bytes - sizeof lengths ||
        !p->read(p->context, 0, base + offset, lengths, sizeof lengths))
        return;
    unsigned title = lengths[0], artist = lengths[1];
    if (title > TRIP_LABEL_BYTES || artist > TRIP_LABEL_BYTES || (!title && !artist) ||
        title + artist > bytes - offset - sizeof lengths ||
        !p->read(p->context, 0, base + offset + sizeof lengths, text, title + artist))
        return;
    for (unsigned i = 0; i < title; ++i)
        p->title[i] = (char)text[i];
    for (unsigned i = 0; i < artist; ++i)
        p->artist[i] = (char)text[title + i];
    p->title[title] = p->artist[artist] = 0;
}

int trip_select(trip_player *p, uint32_t index, uint32_t ms)
{
    uint8_t row[84];
    if (index >= p->count + p->stations ||
        !p->read(p->context, 0, p->header + index * p->stride, row, p->stride))
        return 0;
    uint32_t offset = le32(row), frames = le32(row + 4);
    if (!frames || (p->header == 24 ? (offset < 2 || offset > 0x0fffffff) :
        (offset < table_end(p) || offset % 4 || offset > p->size ||
         frames > (p->size - offset) / 4)))
        return 0;
    uint32_t cover = p->stride == 84 ? le32(row + 80) : 0;
    uint32_t art_base = p->lyric_end ? p->lyric_end :
                        p->album_map ? p->album_map + p->count * ALBUM_ENTRY : table_end(p);
    if (p->queue_fingerprint)
        art_base += 8;
    if (p->metadata_end)
        art_base = p->metadata_end;
    if (p->favorite_map)
        art_base = p->favorite_lookup + 8 * p->favorite_entries;
    if (cover && (cover < art_base || cover > p->size ||
                  p->size - cover < 12800))
        return 0;
    p->cover = cover;
    p->index = index;
    p->offset = offset;
    p->frames = frames;
    p->position = ms <= frames / 48 ? ms * 48 : frames;
    for (unsigned i = 0; i < 48; ++i)
        p->title[i] = (char)row[8 + i];
    for (unsigned i = 0; i < 24; ++i)
        p->artist[i] = (char)row[56 + i];
    p->title[48] = p->artist[24] = 0;
    read_long_labels(p, index);
    return 1;
}

int trip_open(trip_player *p, trip_read read, void *context, uint32_t size)
{
    uint8_t h[HEADER];
    *p = (trip_player){.read = read, .context = context, .size = size};
    if (size < HEADER || !read(context, 0, 0, h, sizeof(h)))
        return 0;
    if (h[0] != 'W' || h[1] != 'X' || h[2] != 'P' || h[3] < '1' || h[3] > '3')
        return 0;
    uint32_t count = le32(h + 4);
    p->header = HEADER;
    p->stride = RECORD;
    if (h[3] != '1') {
        uint8_t extra[8];
        p->header = h[3] == '3' ? 24 : 20;
        if (size < p->header || !read(context, 0, 16, extra, p->header - 16))
            return 0;
        p->stride = 84;
        p->stations = le32(extra);
        if (p->header == 24)
            p->views = le32(extra + 4);
    }
    uint32_t start = le32(h + 8);
    uint32_t position = le32(h + 12);
    int radio_only = !count && p->header == 24 && p->stations && !p->views && !start;
    int library_only = p->views && start == UINT32_MAX && !position;
    if ((!radio_only && !library_only && start >= count) || p->stations > 6 ||
        count > (size - p->header) / p->stride ||
        p->stations > (size - p->header) / p->stride - count)
        return 0;
    p->count = count;
    p->play_end = count;
    if (p->views > 4096 || p->views > (size - p->header - (count + p->stations) * p->stride) / VIEW_BYTES) {
        p->count = 0;
        return 0;
    }
    if (p->views) {
        trip_view first;
        if (!trip_view_at(p, 0, &first) || first.first ||
            (library_only ? first.kind == TRIP_CONTINUE : first.kind != TRIP_CONTINUE || start >= first.count)) {
            p->count = 0;
            return 0;
        }
        p->play_end = first.count;
        unsigned previous = TRIP_CONTINUE;
        for (unsigned i = 0; i < p->views; ++i) {
            trip_view v;
            if (!trip_view_at(p, i, &v) || v.kind < previous || v.kind >= TRIP_VIEW_KINDS) {
                p->count = 0;
                return 0;
            }
            if (!p->view_count[v.kind])
                p->view_first[v.kind] = (uint16_t)i;
            ++p->view_count[v.kind];
            previous = v.kind;
        }
        uint8_t map_header[8];
        uint32_t base = table_end(p);
        if (size - base >= sizeof map_header &&
            count <= (size - base - sizeof map_header) / ALBUM_ENTRY &&
            read(context, 0, base, map_header, sizeof map_header) &&
            le32(map_header) == 0x314c4158u && le32(map_header + 4) == count) { /* XAL1 */
            p->album_map = base + sizeof map_header;
            base = p->album_map + count * ALBUM_ENTRY;
            p->lyric_end = indexed_end(p, base, 0x31594c58u); /* XLY1 */
            if (p->lyric_end) {
                p->lyric_map = base;
                base = p->lyric_end;
            }
            uint8_t queue_stamp[8];
            if (size - base >= sizeof queue_stamp && read(context, 0, base, queue_stamp, sizeof queue_stamp) &&
                le32(queue_stamp) == 0x31485158u) { /* XQH1 */
                p->queue_fingerprint = le32(queue_stamp + 4);
                if (p->queue_fingerprint)
                    base += sizeof queue_stamp;
            }
            p->metadata_end = indexed_end(p, base, 0x31444d58u); /* XMD1 */
            if (p->metadata_end) {
                p->metadata_map = base;
                base = p->metadata_end;
            }
            uint8_t favorites[INDEX_HEADER];
            if (size - base >= sizeof favorites && count <= (size - base - sizeof favorites) / 8 &&
                read(context, 0, base, favorites, sizeof favorites) &&
                le32(favorites) == 0x31564658u && le32(favorites + 4) == count) { /* XFV1 */
                uint32_t map = base + sizeof favorites, lookup = map + 8 * count;
                uint32_t entries = le32(favorites + 8);
                if (entries <= (size - lookup) / 8) {
                    base = lookup + entries * 8;
                }
                if (entries && entries <= (size - lookup) / 8) {
                    p->favorite_map = map;
                    p->favorite_lookup = lookup;
                    p->favorite_entries = entries;
                    base = lookup + entries * 8;
                }
            }
            uint8_t warez[8];
            if (size - base >= sizeof warez && read(context, 0, base, warez, sizeof warez) &&
                le32(warez) == 0x315a5758u) { /* XWZ1: ordinals in TRIP_ALBUMS */
                uint32_t n = le32(warez + 4), prior = 0;
                int valid = n <= p->view_count[TRIP_ALBUMS] && n <= (size - base - 8) / 4;
                for (uint32_t i = 0; valid && i < n; ++i) {
                    uint8_t ordinal[4] = {0};
                    valid = read(context, 0, base + 8 + i * 4, ordinal, 4);
                    uint32_t value = le32(ordinal);
                    valid = valid && value < p->view_count[TRIP_ALBUMS] && (!i || value > prior);
                    prior = value;
                }
                if (valid) { p->warez_map = base + 8; p->warez_count = n; }
            }
        }
    }
    if (trip_select(p, library_only ? 0 : start, position))
        return 1;
    p->count = 0;
    return 0;
}

int trip_view_at(const trip_player *p, uint32_t index, trip_view *view)
{
    uint8_t bytes[VIEW_BYTES];
    if (index >= p->views || !p->read(p->context, 0,
        p->header + (p->count + p->stations) * p->stride + index * VIEW_BYTES,
        bytes, sizeof bytes))
        return 0;
    view->kind = le32(bytes);
    view->first = le32(bytes + 4);
    view->count = le32(bytes + 8);
    if (!view->count || view->first >= p->count || view->count > p->count - view->first)
        return 0;
    for (unsigned i = 0; i < 48; ++i)
        view->title[i] = (char)bytes[12+i];
    view->title[48] = 0;
    return 1;
}

unsigned trip_view_count(const trip_player *p, unsigned kind)
{
    if (kind == TRIP_WAREZ) return p->warez_count;
    return kind < TRIP_VIEW_KINDS ? p->view_count[kind] : 0;
}

int trip_view_by_kind(const trip_player *p, unsigned kind, unsigned index, trip_view *out)
{
    if (kind == TRIP_WAREZ) {
        uint8_t ordinal[4];
        if (index >= p->warez_count || !p->read(p->context, 0, p->warez_map + index * 4, ordinal, 4)) return 0;
        if (!trip_view_by_kind(p, TRIP_ALBUMS, le32(ordinal), out)) return 0;
        out->kind = TRIP_WAREZ;
        return 1;
    }
    return index < trip_view_count(p, kind) &&
           trip_view_at(p, p->view_first[kind] + index, out) && out->kind == kind;
}

uint32_t trip_favorite_key(const trip_player *p, uint32_t row, int album)
{
    uint8_t key[4];
    return p->favorite_map && row < p->count &&
           p->read(p->context, 0, p->favorite_map + 8 * row + (album ? 4 : 0), key, sizeof key) ?
           le32(key) : 0;
}

int trip_favorite_target(const trip_player *p, uint32_t key, uint32_t *target)
{
    uint32_t first = 0, end = p->favorite_entries;
    while (first < end) {
        uint8_t record[8];
        uint32_t middle = first + (end - first) / 2;
        if (!p->read(p->context, 0, p->favorite_lookup + 8 * middle, record, sizeof record))
            return 0;
        uint32_t candidate = le32(record);
        if (candidate < key)
            first = middle + 1;
        else if (candidate > key)
            end = middle;
        else {
            uint32_t row = le32(record + 4);
            if (row & TRIP_FAVORITE_ALBUM) {
                if ((row & ~TRIP_FAVORITE_ALBUM) >= trip_view_count(p, TRIP_ALBUMS))
                    return 0;
            } else if (row >= p->count) {
                return 0;
            }
            *target = row;
            return 1;
        }
    }
    return 0;
}

int trip_spoken_queue(const trip_player *p, trip_view *view)
{
    for (unsigned kind = TRIP_BOOKS; kind <= TRIP_QURAN; ++kind) {
        unsigned first = 0, end = trip_view_count(p, kind);
        while (first < end) {
            unsigned middle = first + (end - first) / 2;
            if (!trip_view_by_kind(p, kind, middle, view))
                return 0;
            if (view->first < p->play_first)
                first = middle + 1;
            else if (view->first > p->play_first)
                end = middle;
            else
                return view->count == p->play_end - p->play_first;
        }
    }
    return 0;
}

int trip_lyric(const trip_player *p, char line[49], uint32_t bounds[2])
{
    uint8_t cue[LYRIC_CUE];
    *line = 0;
    bounds[0] = 0;
    bounds[1] = UINT32_MAX;
    if (!p->lyric_map || p->index >= p->count ||
        !p->read(p->context, 0, p->lyric_map + INDEX_HEADER + 4 * p->index, cue, 4))
        return 0;
    uint32_t start = le32(cue), bytes = p->lyric_end - p->lyric_map;
    if (start < INDEX_HEADER + 4 * p->count || start > bytes - 4 ||
        !p->read(p->context, 0, p->lyric_map + start, cue, 4))
        return 0;
    unsigned end = le32(cue), first = 0;
    if (end > (bytes - start - 4) / LYRIC_CUE)
        return 0;
    uint32_t offset = p->lyric_map + start + 4, time = p->position / 48;
    while (first < end) {
        unsigned middle = first + (end - first) / 2;
        if (!p->read(p->context, 0, offset + middle * LYRIC_CUE, cue, 4))
            return 0;
        uint32_t milliseconds = le32(cue);
        if (milliseconds <= time)
            first = middle + 1;
        else {
            end = middle;
            bounds[1] = milliseconds;
        }
    }
    if (!first || !p->read(p->context, 0, offset + (first - 1) * LYRIC_CUE, cue, sizeof cue))
        return 0;
    bounds[0] = le32(cue);
    for (unsigned i = 0; i < 48; ++i)
        line[i] = (char)cue[i + 4];
    line[48] = 0;
    return *line != 0;
}

uint32_t trip_permute(uint32_t index, uint32_t count, uint32_t seed)
{
    if (count < 2 || index >= count)
        return index;
    unsigned half = 1;
    while (half < 16 && (1u << (2 * half)) < count)
        ++half;
    uint32_t mask = (1u << half) - 1;
    do {
        uint32_t left = index >> half, right = index & mask;
        for (unsigned round = 0; round < 4; ++round) {
            uint32_t hash = right ^ (seed + 0x9e3779b9u * round);
            hash = (hash ^ (hash >> 16)) * 0x7feb352du;
            hash = (hash ^ (hash >> 15)) * 0x846ca68bu;
            uint32_t next = left ^ ((hash ^ (hash >> 16)) & mask);
            left = right;
            right = next;
        }
        index = left << half | right;
    } while (index >= count);
    return index;
}

static int album_member(const trip_player *p, unsigned *album, uint32_t *track, trip_view *view)
{
    unsigned count = trip_view_count(p, TRIP_ALBUMS);
    if (p->index >= p->count || !count)
        return 0;
    if (p->album_map) {
        uint8_t row[ALBUM_ENTRY];
        if (!p->read(p->context, 0, p->album_map + p->index * sizeof row, row, sizeof row))
            return 0;
        *album = le32(row);
        *track = le32(row + 4);
        return trip_view_by_kind(p, TRIP_ALBUMS, *album, view) && *track < view->count &&
               p->read(p->context, 0, p->header + (view->first + *track) * p->stride, row, 4) &&
               le32(row) == p->offset;
    }
    /* Older packs can identify rows within their canonical album shelf. */
    unsigned first = 0, end = count;
    while (first < end) {
        unsigned middle = first + (end - first) / 2;
        if (!trip_view_by_kind(p, TRIP_ALBUMS, middle, view))
            return 0;
        if (p->index < view->first)
            end = middle;
        else if (p->index - view->first >= view->count)
            first = middle + 1;
        else {
            *album = middle;
            *track = p->index - view->first;
            return 1;
        }
    }
    return 0;
}

void trip_shuffle(trip_player *p, uint32_t seed)
{
    if (p->album_anchor && p->index < p->count &&
        (p->index < p->play_first || p->index >= p->play_end)) {
        unsigned album;
        uint32_t track;
        trip_view view;
        if (album_member(p, &album, &track, &view)) {
            p->play_first = view.first;
            p->play_end = view.first + view.count;
        }
    }
    p->album_anchor = 0;
    p->draw_total = 0;
    p->shuffle_seed = p->play_first <= p->index && p->index < p->play_end ? seed : 0;
    p->shuffle_anchor = p->index;
    p->shuffle_cursor = p->play_first;
}

int trip_shuffle_albums(trip_player *p, uint32_t seed)
{
    unsigned album;
    uint32_t track;
    trip_view view;
    if (!album_member(p, &album, &track, &view) || track > (UINT32_MAX >> ALBUM_BITS))
        return 0;
    p->album_anchor = album + 1;
    p->draw_total = 0;
    p->shuffle_seed = seed | 1u;
    p->shuffle_cursor = track << ALBUM_BITS;
    return 1;
}

int trip_draw(trip_player *p, uint32_t seed, unsigned slot, uint32_t milliseconds)
{
    trip_view songs;
    if (!seed || !trip_view_by_kind(p, TRIP_SONGS, 0, &songs))
        return 0;
    trip_player draw = *p;
    trip_clear_up_next(&draw);
    draw.local_rows = 0;
    draw.play_first = songs.first;
    draw.play_end = songs.first + (songs.count > TRIP_NEEDLE_LIMIT ? TRIP_NEEDLE_LIMIT : songs.count);
    draw.draw_total = songs.count;
    draw.album_anchor = 0;
    draw.shuffle_seed = seed;
    if (slot >= draw.play_end - draw.play_first ||
        !trip_queue_select(&draw, draw.play_first + slot, milliseconds))
        return 0;
    *p = draw;
    return 1;
}

static int shuffled_album(const trip_player *p, unsigned position, trip_view *view)
{
    unsigned count = trip_view_count(p, TRIP_ALBUMS);
    if (position >= count)
        return 0;
    unsigned index = p->album_anchor - 1;
    if (position) {
        index = trip_permute(position - 1, count - 1, p->shuffle_seed);
        index += index >= p->album_anchor - 1;
    }
    return trip_view_by_kind(p, TRIP_ALBUMS, index, view);
}

#define CURRENT_UP_NEXT UINT32_MAX
#define FIRST_UP_NEXT (CURRENT_UP_NEXT - TRIP_UP_NEXT_LIMIT)

void trip_clear_up_next(trip_player *p)
{
    p->up_next_count = p->from_up_next = 0;
}

void trip_open_local_queue(trip_player *p, const uint32_t *rows, uint32_t count)
{
    trip_clear_up_next(p);
    p->play_first = p->local_cursor = 0;
    p->play_end = count;
    p->local_rows = rows;
    p->album_anchor = p->shuffle_seed = p->draw_total = 0;
}

int trip_enqueue(trip_player *p, uint32_t row, int next)
{
    if (p->up_next_count >= TRIP_UP_NEXT_LIMIT || row >= p->count)
        return 0;
    trip_player entry = *p;
    if (!trip_select(&entry, row, 0))
        return 0;
    unsigned slot = next ? 0 : p->up_next_count;
    for (unsigned i = p->up_next_count; i > slot; --i)
        p->up_next[i] = p->up_next[i - 1];
    p->up_next[slot] = row;
    ++p->up_next_count;
    return 1;
}

static uint32_t base_cursor(const trip_player *p)
{
    if (p->local_rows && p->index < p->count)
        return p->local_cursor;
    return p->shuffle_seed && p->index < p->count ? p->shuffle_cursor : p->index;
}

uint32_t trip_queue_cursor(const trip_player *p)
{
    return p->from_up_next ? CURRENT_UP_NEXT : base_cursor(p);
}

static int base_step(const trip_player *p, uint32_t cursor, int next, int wrap, uint32_t *result)
{
    if (p->album_anchor) {
        uint32_t track = cursor >> ALBUM_BITS;
        unsigned place = cursor & ALBUM_MASK;
        unsigned albums = trip_view_count(p, TRIP_ALBUMS);
        trip_view view;
        if (!shuffled_album(p, place, &view) || track >= view.count)
            return 0;
        if (next ? track + 1 < view.count : track > 0) {
            track = next ? track + 1 : track - 1;
        } else {
            if (next ? place + 1 < albums : place > 0)
                place = next ? place + 1 : place - 1;
            else if (wrap)
                place = next ? 0 : albums - 1;
            else
                return 0;
            if (!next && !shuffled_album(p, place, &view))
                return 0;
            track = next ? 0 : view.count - 1;
        }
        if (track > (UINT32_MAX >> ALBUM_BITS))
            return 0;
        uint32_t packed = (track << ALBUM_BITS) | place;
        if (packed >= FIRST_UP_NEXT)
            return 0;
        *result = packed;
        return 1;
    }
    if (cursor < p->play_first || cursor >= p->play_end)
        return 0;
    if (next ? cursor + 1 < p->play_end : cursor > p->play_first)
        *result = next ? cursor + 1 : cursor - 1;
    else if (wrap)
        *result = next ? p->play_first : p->play_end - 1;
    else
        return 0;
    return 1;
}

int trip_queue_step(const trip_player *p, uint32_t cursor, int next, int wrap, uint32_t *result)
{
    uint32_t anchor = p->from_up_next ? p->up_next_anchor : base_cursor(p);
    if (cursor == CURRENT_UP_NEXT && p->from_up_next) {
        if (!next || p->up_next_count) {
            *result = next ? FIRST_UP_NEXT : anchor;
            return 1;
        }
        return base_step(p, anchor, next, wrap, result);
    }
    if (cursor >= FIRST_UP_NEXT) {
        unsigned slot = cursor - FIRST_UP_NEXT;
        if (slot >= p->up_next_count)
            return 0;
        if (next) {
            if (slot + 1 >= p->up_next_count)
                return base_step(p, anchor, next, wrap, result);
            *result = cursor + 1;
        } else {
            *result = slot ? cursor - 1 : trip_queue_cursor(p);
        }
        return 1;
    }
    if (next && cursor == anchor && (p->from_up_next || p->up_next_count)) {
        *result = p->from_up_next ? CURRENT_UP_NEXT : FIRST_UP_NEXT;
        return 1;
    }
    return base_step(p, cursor, next, wrap, result);
}

int trip_queue_select(trip_player *p, uint32_t cursor, uint32_t milliseconds)
{
    if (cursor == CURRENT_UP_NEXT)
        return p->from_up_next && trip_select(p, p->index, milliseconds);
    if (cursor >= FIRST_UP_NEXT) {
        unsigned slot = cursor - FIRST_UP_NEXT;
        if (slot >= p->up_next_count)
            return 0;
        uint32_t anchor = p->from_up_next ? p->up_next_anchor : base_cursor(p);
        if (!trip_select(p, p->up_next[slot], milliseconds))
            return 0;
        p->up_next_anchor = anchor;
        p->from_up_next = 1;
        p->up_next_count -= slot + 1;
        for (unsigned i = 0; i < p->up_next_count; ++i)
            p->up_next[i] = p->up_next[i + slot + 1];
        return 1;
    }
    uint32_t row = cursor;
    if (p->local_rows) {
        if (cursor >= p->play_end)
            return 0;
        row = p->local_rows[cursor];
    } else if (p->album_anchor) {
        trip_view view;
        uint32_t track = cursor >> ALBUM_BITS;
        if (!shuffled_album(p, cursor & ALBUM_MASK, &view) || track >= view.count)
            return 0;
        row = view.first + track;
    } else if (cursor < p->play_first || cursor >= p->play_end) {
        return 0;
    } else if (p->draw_total) {
        row = p->play_first + trip_permute(cursor - p->play_first, p->draw_total, p->shuffle_seed);
    } else if (p->shuffle_seed) {
        if (cursor == p->play_first) {
            row = p->shuffle_anchor;
        } else {
            row = p->play_first + trip_permute(cursor - p->play_first - 1,
                                               p->play_end - p->play_first - 1, p->shuffle_seed);
            row += row >= p->shuffle_anchor;
        }
    }
    int changes_track = p->from_up_next || cursor != base_cursor(p);
    if (!trip_select(p, row, milliseconds))
        return 0;
    if (changes_track)
        trip_clear_up_next(p);
    p->local_cursor = cursor;
    p->shuffle_cursor = cursor;
    return 1;
}

int trip_queue_restart(trip_player *p)
{
    trip_clear_up_next(p);
    return trip_queue_select(p, p->album_anchor ? 0 : p->play_first, 0);
}

int trip_last(const trip_player *p)
{
    uint32_t next;
    return p->index >= p->count || !trip_queue_step(p, trip_queue_cursor(p), 1, 0, &next);
}

static const uint16_t step_sizes[89] = {
    7,8,9,10,11,12,13,14,16,17,19,21,23,25,28,31,34,37,41,45,50,
    55,60,66,73,80,88,97,107,118,130,143,157,173,190,209,230,253,279,
    307,337,371,408,449,494,544,598,658,724,796,876,963,1060,1166,1282,
    1411,1552,1707,1878,2066,2272,2499,2749,3024,3327,3660,4026,4428,
    4871,5358,5894,6484,7132,7845,8630,9493,10442,11487,12635,13899,
    15289,16818,18500,20350,22385,24623,27086,29794,32767
};

static int unpack_adpcm(trip_player *p, int16_t *pcm, unsigned capacity)
{
    uint8_t block[ADPCM_BYTES];
    unsigned within = p->position % ADPCM_FRAMES;
    unsigned n = ADPCM_FRAMES - within;
    if (n > capacity)
        n = capacity;
    if (!p->read(p->context, (int)p->offset, p->position / ADPCM_FRAMES * ADPCM_BYTES,
                 block, sizeof block))
        return -1;
    for (unsigned ch = 0; ch < 2; ++ch) {
        int value = (int16_t)(block[ch*4] | (uint16_t)block[ch*4+1] << 8);
        int index = block[ch*4+2];
        if (index > 88 || block[ch*4+3])
            return -1;
        if (!within)
            pcm[ch] = (int16_t)value;
        for (unsigned i = 1; i < within + n; ++i) {
            unsigned j = i - 1;
            unsigned nibble = block[8+(j/8)*8+ch*4+(j%8)/2] >> (4*(j&1)) & 15;
            unsigned step = step_sizes[index], magnitude = nibble&7;
            int delta = (int)((step*(2*magnitude+1)) >> 3);
            value += nibble&8 ? -delta : delta;
            value = value < -32768 ? -32768 : value > 32767 ? 32767 : value;
            index += magnitude < 4 ? -1 : (int)(2*magnitude-6);
            index = index < 0 ? 0 : index > 88 ? 88 : index;
            if (i >= within)
                pcm[(i-within)*2+ch] = (int16_t)value;
        }
    }
    return (int)n;
}

int trip_pull(trip_player *p, int16_t *pcm, unsigned capacity)
{
    if (!p->frames || !capacity || capacity > 128)
        return -1;
    if (p->position == p->frames) {
        uint32_t next;
        if (p->index >= p->count || !trip_queue_step(p, trip_queue_cursor(p), 1, 0, &next))
            return 0;
        if (!trip_queue_select(p, next, 0))
            return -1;
    }
    unsigned n = p->frames - p->position;
    if (n > capacity)
        n = capacity;
    if (p->header == 24) {
        int received = unpack_adpcm(p, pcm, n);
        if (received > 0)
            p->position += (unsigned)received;
        return received;
    }
    if (!p->read(p->context, 1, p->offset + 4 * p->position, pcm, 4 * n))
        return -1;
    p->position += n;
    return (int)n;
}
