#!/usr/bin/env bash
set -euo pipefail
board=$(cd "$(dirname "$0")" && pwd -P)
root=$(git -C "$board" rev-parse --show-toplevel)
work="$root/build/hifih2/nand-read"
mkdir -p "$work"
flags=(--target=mipsel-none-elf -march=mips32r2 -msoft-float -mno-abicalls -fno-pic -G0 -Os -ffreestanding -fno-builtin -fno-stack-protector -Wall -Wextra -Werror)
for f in nand_read sd_read nand_trial media_probe hci_probe pmic avdtp_probe sdp_source sbc_source; do clang "${flags[@]}" -I"$root/include" -I"$board/../.." -c "$board/$f.c" -o "$work/$f.o"; done
clang "${flags[@]}" -c "$board/nand-trial-entry.S" -o "$work/nand-trial-entry.o"
clang "${flags[@]}" -I"$root/include" -c "$root/src/fs.c" -o "$work/fs.o"
clang "${flags[@]}" -c "$board/../../trip.c" -o "$work/trip.o"
patch="$root/build/hifih2/v22-root/lib/firmware/BCM4343A1_001.002.009.0122.0538.hcd"
printf '%s  %s\n' '9873217acdeaee78bd502a31fa876dc1b120c9d07ca8c16420853bc44ba64972' "$patch" | sha256sum -c >&2
clang "${flags[@]}" -DH2_RADIO_PATCH='"'"$patch"'"' -c "$board/radio-patch.S" -o "$work/radio-patch.o"
ld.lld -m elf32ltsmip -T "$board/nand-trial.ld" "$work/nand-trial-entry.o" "$work/nand_read.o" "$work/sd_read.o" "$work/nand_trial.o" "$work/media_probe.o" "$work/hci_probe.o" "$work/pmic.o" "$work/avdtp_probe.o" "$work/sdp_source.o" "$work/sbc_source.o" "$work/radio-patch.o" "$work/fs.o" "$work/trip.o" -o "$work/nand-trial.elf"
llvm-objcopy -O binary "$work/nand-trial.elf" "$work/nand-trial.bin"
llvm-readelf -h "$work/nand-trial.elf" | awk '/Entry point address/ {e=tolower($NF)} END {exit e!="0xa0400018"}'
