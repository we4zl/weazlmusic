/* X1000 32 MiB mDDR bring-up. 24 MHz EXTAL, 600 MHz MPLL, 200 MHz DDR.
 * Initialize while executing from TCSM. USB retains its ROM clock source. */
#include <stdint.h>
#define IO(base, offset) (*(volatile uint32_t *)((uintptr_t)(base) + (offset)))
#define CPM(offset) IO(0xb0000000u, offset)
#define PHY(offset) IO(0xb3011000u, offset)
#define APB(offset) IO(0xb3012000u, offset)
#define DDR(offset) IO(0xb34f0000u, offset)
#define OST(offset) IO(0xb2000000u, offset)

static int wait_bits(volatile uint32_t *reg, uint32_t mask, uint32_t value)
{
    for (unsigned count = 120000; count; --count)
        if ((*reg & mask) == value)
            return 1;
    return 0;
}

static void delay_3ms(void)
{
    uint32_t start = OST(0x20);
    for (unsigned count=180000; count && OST(0x20)-start<18000; --count) {}
}

static unsigned verify_memory(void)
{
    volatile uint32_t *scratch = (volatile uint32_t *)0xa0100000u;
    for (uint32_t bit = 1; bit; bit <<= 1) {
        scratch[0] = bit;
        scratch[1] = ~bit;
        if (scratch[0] != bit || scratch[1] != ~bit)
            return 20;
    }
    scratch[0] = 0x6a5225a6;
    for (unsigned n=2; n<=0x400000; n<<=1)
        scratch[n] = 0x83244521 ^ n;
    if (scratch[0] != 0x6a5225a6)
        return 21;
    for (unsigned n=2; n<=0x400000; n<<=1)
        if (scratch[n] != (0x83244521 ^ n))
            return 22;
    for (uint32_t n=0; n<16384; ++n)
        scratch[n] = (n * 0x9e3779b9) ^ 0x55aa55aa;
    for (uint32_t n=0; n<16384; ++n)
        if (scratch[n] != ((n * 0x9e3779b9) ^ 0x55aa55aa))
            return 23;
    return 1;
}

unsigned h2_ddr_initialize(void)
{
    CPM(0x20) &= ~((1u<<31)|(1u<<20));
    OST(0x00) = (OST(0x00) & ~12u) | 4;
    OST(0x08) = 2;
    OST(0x04) |= 2;
    CPM(0x14) &= ~(1u<<7);
    if (!wait_bits(&CPM(0x14),1,0))
        return 10;
    CPM(0x14) = 0x98000080u;
    if (!wait_bits(&CPM(0x14),1,1))
        return 11;
    CPM(0x2c) = 0xa0000002;
    if (!wait_bits(&CPM(0xd4),1u<<27,1u<<27) ||
        !wait_bits(&CPM(0x2c),1u<<28,0))
        return 12;
    CPM(0x2c) &= ~(1u<<29);

    CPM(0xd0) = 0x73; delay_3ms();
    CPM(0xd0) = 0x71; delay_3ms();
    APB(0x80) = 0x1a00001; delay_3ms();
    APB(0x80) = 0; delay_3ms();
    DDR(0x08) = 0xf00000; delay_3ms();
    DDR(0x08) = 0; delay_3ms();

    DDR(0x04) = 0x0a46896c;
    DDR(0x08) = 2;
    PHY(0x54) = 0x150000; /* training address */
    PHY(0x30) = 0;
    PHY(0x40) = 0x42;
    PHY(0x48) = 0x98;
    PHY(0x18) = 0x21000a;
    PHY(0x1c) = 0xa09c40;
    PHY(0x20) = 0x280014;
    PHY(0x34) = 0x1a69444a;
    PHY(0x38) = 0x180090;
    PHY(0x3c) = 0x1ff99428;
    for (unsigned lane=0; lane<4; ++lane)
        PHY(0x1c0+lane*0x40) = lane<2 ? 0x90881 : 0x90e80;
    PHY(0x08) = 0x1042e03;
    PHY(0x24) = 0x30c00813;
    PHY(0x28) = 0x4912;
    if (!wait_bits(&PHY(0x0c),7,7))
        return 13;

    PHY(0x14) = 0x80000000;
    PHY(0x2c) &= ~0x10u;
    PHY(0x10) |= 0x800000;
    PHY(0x04) = 0x20020041;
    if (!wait_bits(&PHY(0x0c),15,15))
        return 14;
    APB(0x80) = 0x400000; delay_3ms();
    APB(0x80) = 0; delay_3ms();

    DDR(0x04) = 0x0a4689ec;
    DDR(0x08) = 2;
    PHY(0x04) = 0x20020081;
    if (!wait_bits(&PHY(0x0c),0x7f,0x1f))
        return 15;

    static const uint32_t timing[] = {0x2050501,0x4090404,0x2704030d,0xb7a0251,0xff090200,0xa0a0202};
    static const uint32_t mapping[] = {0x03020b0a,0x07060504,0x01000908,0x0f0e0d0c,0x13121110};
    DDR(0x08) = 0;
    DDR(0x08) = 10;
    DDR(0x08) = 0;
    DDR(0x04) = 0x0a46896c;
    for (unsigned i=0; i<sizeof timing/sizeof *timing; ++i)
        DDR(0x60+4*i) = timing[i];
    DDR(0x24) = 0x20fe;
    DDR(0x28) = 0x2200;
    DDR(0x08) = 10;
    DDR(0x18) = 0x2f0003;
    DDR(0x08) = 0xc91e;
    for (unsigned i=0; i<sizeof mapping/sizeof *mapping; ++i)
        DDR(0x9c+4*i) = mapping[i];
    DDR(0x00) &= ~0x40u;
    CPM(0x2c) |= 1u<<26;
    APB(0x68) = 0x9000000f;
    DDR(0x304) = 1;
    return verify_memory();
}
