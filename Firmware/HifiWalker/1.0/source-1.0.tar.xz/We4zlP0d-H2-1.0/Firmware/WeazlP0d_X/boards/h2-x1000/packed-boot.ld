OUTPUT_ARCH(mips)
ENTRY(start_packed)
SECTIONS {
    . = 0xa0600000;
    .entry : SUBALIGN(4) { KEEP(*(.entry)) }
    . = ALIGN(16) - 0x20000000;
    .text : AT(ADDR(.text)+0x20000000) SUBALIGN(4) { *(.text*) }
    .rodata : AT(ADDR(.rodata)+0x20000000) { *(.rodata*) }
    .data : AT(ADDR(.data)+0x20000000) { *(.data*) BYTE(0); . = ALIGN(4); }
    .bss (NOLOAD) : { *(.bss*) *(.sbss*) }
    /DISCARD/ : { *(.MIPS.abiflags .reginfo .pdr .got .comment .note.*) }
    ASSERT(start_packed == 0xa0600000, "Packed player entry must match NAND manifest")
    ASSERT(SIZEOF(.bss) == 0, "Packed loader has no BSS initialization")
    ASSERT(LOADADDR(.data) + SIZEOF(.data) <= 0xa0638000, "Packed player exceeds NAND image limit")
}
