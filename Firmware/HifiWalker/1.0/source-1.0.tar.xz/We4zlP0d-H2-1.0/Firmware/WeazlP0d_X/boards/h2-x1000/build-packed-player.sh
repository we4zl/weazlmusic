#!/usr/bin/env bash
set -euo pipefail
board=$(cd "$(dirname "$0")" && pwd -P)
root=$(git -C "$board" rev-parse --show-toplevel)
work=${1:?Expected player build directory}
minor=${2:?Expected player revision}
sdk="$root/third_party/lzma_sdk"

python - "$work" <<'PY'
import lzma
from pathlib import Path
import struct
import sys

work = Path(sys.argv[1])
image = (work / "player.tmp").read_bytes()
if not 0 < len(image) <= 0x80000:
    raise SystemExit("Expanded player does not fit its DDR reservation")
filters = [dict(id=lzma.FILTER_LZMA1, preset=9, dict_size=1 << 19, lc=1, lp=2, pb=2)]
packed = lzma.compress(image, format=lzma.FORMAT_RAW, filters=filters)
if lzma.decompress(packed, format=lzma.FORMAT_RAW, filters=filters) != image:
    raise SystemExit("Packed player verification failed")
path = work / "player.lzma"
path.write_bytes(struct.pack("<BI", (2 * 5 + 2) * 9 + 1, 1 << 19) + packed)
(work / "packed-payload.S").write_text(
    '.section .rodata.payload,"a",@progbits\n.balign 4\n'
    '.globl h2_expanded_size,h2_payload,h2_payload_end\n'
    f'h2_expanded_size: .word {len(image)}\nh2_payload:\n.incbin "{path}"\nh2_payload_end:\n')
print(f"Player payload {len(image):,} bytes expanded, {path.stat().st_size:,} bytes packed")
PY

flags=(--target=mipsel-none-elf -march=mips32r2 -msoft-float -mno-abicalls -fno-pic -G0 -Oz -ffreestanding -fno-builtin -fno-stack-protector -ffunction-sections -fdata-sections)
flags+=(-I"$sdk" -I"$work/codec-headers" -DBUILD_MINOR="$minor")
objects=()
for source in "$board/packed-boot.S" "$board/packed-boot.c" "$sdk/LzmaDec.c" "$work/packed-payload.S"; do
    obj="$work/${source##*/}.o"
    clang "${flags[@]}" -DZ7_LZMA_SIZE_OPT -Wall -Wextra -Werror -c "$source" -o "$obj"
    objects+=("$obj")
done
ld.lld -m elf32ltsmip --gc-sections -T "$board/packed-boot.ld" "${objects[@]}" "$work/player_clock.o" "$work/codecs.a" -o "$work/packed.elf"
llvm-objcopy -O binary "$work/packed.elf" "$work/player.tmp"
