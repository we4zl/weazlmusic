/* One A2DP Audio Source service record. Its transport is AVDTP over L2CAP. */
#include "sdp_source.h"

enum { HANDLE=0x10001 };

static const uint8_t attributes[]={
    0x09,0x00,0x00, 0x0a,0,1,0,1,
    0x09,0x00,0x01, 0x35,0x03,0x19,0x11,0x0a,
    0x09,0x00,0x04, 0x35,0x10,
        0x35,0x06,0x19,0x01,0x00,0x09,0,0x19,
        0x35,0x06,0x19,0x00,0x19,0x09,0x01,0x03,
    0x09,0x00,0x05, 0x35,0x03,0x19,0x10,0x02,
    0x09,0x00,0x09, 0x35,0x08,0x35,0x06,0x19,0x11,0x0d,0x09,0x01,0x03,
    0x09,0x03,0x11, 0x09,0,1
};

static unsigned be16(const uint8_t *p)
{
    return ((unsigned)p[0]<<8)|p[1];
}
static unsigned known_pattern(const uint8_t *p,unsigned len)
{
    int relevant=0;
    if (len<2 || p[0]!=0x35 || p[1]+2u>len)
        return 0;
    for (unsigned i=2;i+3<=p[1]+2u;i+=3) {
        if (p[i]!=0x19)
            return 0;
        unsigned uuid=be16(p+i+1);
        if (uuid!=0x0100 && uuid!=0x1002 && uuid!=0x110a && uuid!=0x110d && uuid!=0x0019)
            return 0;
        relevant=1;
    }
    return relevant;
}

unsigned h2_sdp_reply(const uint8_t *in,unsigned size,uint8_t *out,unsigned capacity)
{
    if (size<7 || capacity<sizeof attributes+12 || be16(in+3)!=size-5)
        return 0;
    unsigned offset=5;
    out[1]=in[1]; out[2]=in[2]; out[3]=0;
    if (in[0]==2) {
        int known=known_pattern(in+5,size-5);
        out[0]=3;
        out[offset++]=0; out[offset++]=known;
        out[offset++]=0; out[offset++]=known;
        if (known) {
            out[offset++]=0; out[offset++]=HANDLE>>16;
            out[offset++]=0; out[offset++]=(uint8_t)HANDLE;
        }
    } else if (in[0]==4 || in[0]==6) {
        int search=in[0]==6;
        int known=search ? known_pattern(in+5,size-5) :
            size>=13 && be16(in+5)==1 && be16(in+7)==1;
        unsigned bytes=known ? sizeof attributes+2+2*search : 2;
        out[0]=search ? 7 : 5;
        out[offset++]=0; out[offset++]=bytes;
        if (search || !known) {
            out[offset++]=0x35;
            out[offset++]=known ? sizeof attributes+2 : 0;
        }
        if (known) {
            out[offset++]=0x35;
            out[offset++]=sizeof attributes;
            for (unsigned i=0;i<sizeof attributes;++i)
                out[offset++]=attributes[i];
        }
    } else {
        out[0]=1; out[4]=2; out[5]=0; out[6]=3;
        return 7;
    }
    out[offset++]=0; /* no continuation */
    out[4]=offset-5;
    return offset;
}
