#ifndef H2_PCM_TAP_H
#define H2_PCM_TAP_H

#include <stdint.h>

enum { H2_PCM_TAP_FRAMES=4096 };
typedef struct {
    unsigned limit,count,volume;
    uint32_t position;
    int16_t samples[2*H2_PCM_TAP_FRAMES];
} h2_pcm_tap;

static inline void h2_pcm_tap_reset(h2_pcm_tap *tap)
{
    tap->limit=tap->count=0;
}

static inline int h2_pcm_tap_arm(h2_pcm_tap *tap,unsigned frames,uint32_t position,unsigned volume)
{
    if (!frames || frames>H2_PCM_TAP_FRAMES)
        return 0;
    tap->limit=frames;
    tap->count=0;
    tap->position=position;
    tap->volume=volume;
    return 1;
}

static inline void h2_pcm_tap_push(h2_pcm_tap *tap,const int16_t *pcm,unsigned frames,
                                   uint32_t position,unsigned volume)
{
    if (tap->count==tap->limit)
        return;
    if (position!=tap->position+tap->count || volume!=tap->volume) {
        h2_pcm_tap_reset(tap);
        return;
    }
    unsigned available=tap->limit-tap->count;
    if (frames>available)
        frames=available;
    for (unsigned i=0;i<2*frames;++i)
        tap->samples[2*tap->count+i]=pcm[i];
    tap->count+=frames;
}

static inline int h2_pcm_tap_read(const h2_pcm_tap *tap,unsigned offset,unsigned length,uint8_t *out)
{
    if (!tap->limit || tap->count!=tap->limit || !length ||
        length>64 || (length&3) || offset>tap->count || length/4>tap->count-offset)
        return 0;
    for (unsigned i=0;i<length/2;++i) {
        uint16_t sample=(uint16_t)tap->samples[2*offset+i];
        out[2*i]=sample;
        out[2*i+1]=sample>>8;
    }
    return 1;
}

#endif
