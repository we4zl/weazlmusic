#!/usr/bin/env bash
set -euo pipefail
board=$(cd "$(dirname "$0")" && pwd -P)
root=$(git -C "$board" rev-parse --show-toplevel)
work="$root/build/hifih2/H04"
out="$root/Firmware/HifiWalker/H04"
mkdir -p "$work" "$out"
flags=(--target=mipsel-none-elf -march=mips32r2 -msoft-float -mno-abicalls -fno-pic -G0 -Os -ffreestanding -fno-builtin -fno-stack-protector -Wall -Wextra -Werror)
sed 's/0xa0200000/0xa0600000/' "$board/ddr.ld" >"$work/ddr.ld"
sed 's/0xf4000818/0xa0500018/;s/\.text : {/\.text : SUBALIGN(4) {/' "$board/bridge.ld" >"$work/bridge.ld"
for f in ddr-entry.S boot_usb.c ram_service.c; do
    clang "${flags[@]}" -DBUILD_MINOR=4 -DH2_SERVICE -DH2_DDR_SERVICE -DH2_STACK_TOP=0xa064 -c "$board/$f" -o "$work/${f%.*}.o"
done
ld.lld -m elf32ltsmip -T "$work/ddr.ld" "$work/ddr-entry.o" "$work/boot_usb.o" "$work/ram_service.o" -o "$work/H04.elf"
llvm-objcopy -O binary "$work/H04.elf" "$work/H04.bin"
clang "${flags[@]}" -DH2_BRIDGE_DEST=0xa0600000 -c "$board/bridge.c" -o "$work/bridge.o"
ld.lld -m elf32ltsmip -T "$work/bridge.ld" "$work/bridge.o" -o "$work/bridge.elf"
llvm-objcopy -O binary "$work/bridge.elf" "$work/bridge.bin"
for item in H04.bin bridge.bin; do
    if [[ -f "$out/$item" ]] && ! cmp -s "$out/$item" "$work/$item"; then
        echo "The published H04 $item differs. Give your build a new ID." >&2
        exit 1
    fi
    install -m 644 "$work/$item" "$out/$item"
done
(cd "$out" && sha256sum H04.bin bridge.bin > SHA256SUMS)
