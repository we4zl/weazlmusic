#ifndef H2_A2DP_H
#define H2_A2DP_H
#include <stdint.h>
#include "media_probe.h"
#include "sbc_source.h"
#ifdef H2_PCM_TAP
#include "pcm_tap.h"
#endif

typedef struct { unsigned here, there, peer_mtu; } h2_channel;

typedef struct {
    unsigned handle, request, sdp_there;
    const uint8_t *peer;
    uint8_t key[16], key_valid;
    uint8_t events[24];
    unsigned event_count, auth_result, encrypt_result;
    h2_channel signalling, media;
    unsigned bitpool, seid, transaction, configured, playing, stream_error;
    unsigned volume, selected, packet_count, submitted_pcm, credit;
#ifdef H2_ORIGINAL_AUDIO
    unsigned source_checked;
#endif
    uint32_t due, stamp, read_ticks, encode_ticks, uart_ticks, receive_ticks;
    uint16_t peak[2];
    unsigned sequence, missed_deadlines;
    h2_library library;
    h2_sbc encoder;
#ifdef H2_PCM_TAP
    h2_pcm_tap tap;
#endif
} h2_a2dp;

void h2_avdtp_setup(h2_a2dp *link,unsigned handle,const uint8_t peer[6],uint32_t report[16]);
void h2_avdtp_setup_paired(h2_a2dp *link,unsigned handle,const uint8_t peer[6],const uint8_t *key,
                          uint32_t report[16]);
unsigned h2_a2dp_select(h2_a2dp *link,unsigned row);
unsigned h2_a2dp_select_frame(h2_a2dp *link,unsigned row,uint32_t frame);
unsigned h2_a2dp_play(h2_a2dp *link,unsigned on);
void h2_a2dp_tick(h2_a2dp *link);
void h2_a2dp_status(h2_a2dp *link,uint32_t report[16]);
#endif
