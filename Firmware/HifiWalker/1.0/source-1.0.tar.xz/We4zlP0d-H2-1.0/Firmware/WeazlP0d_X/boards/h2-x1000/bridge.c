/* An H02 cooperative trial that hands off to a checked supervisor in DRAM.
 * Endpoint zero retains its configured address during the bounded transfer. */
#include <stdint.h>
#if defined(H2_BOOT_RAM_TRIAL) || defined(H2_RTC_PROBE)
#include "boot_health.h"
#endif
#define USB(offset) (*(volatile uint32_t *)(0xb3500000u + (offset)))
#ifdef H2_TIMED_RAM_TRIAL
#define TCU(offset) (*(volatile uint32_t *)(0xb0002000u + (offset)))
static void arm_return(void)
{
    TCU(0x3c)=1u<<16;
    TCU(0x04)=0;
    TCU(0x0c)=0x2c;
    TCU(0x08)=0;
    TCU(0x00)=60000;
    TCU(0x04)=1;
}

static void sync_sram_code(void)
{
    __asm__ volatile("mtc0 $zero,$28; mtc0 $zero,$29; ehb" ::: "memory");
    for (uintptr_t line=0x80000000u;line<0x80004000u;line+=32)
        __asm__ volatile("cache 8,0(%0)" :: "r"(line) : "memory");
    __asm__ volatile("sync; ehb" ::: "memory");
}
#endif
#ifndef H2_BRIDGE_DEST
#define H2_BRIDGE_DEST 0xa0200000u
#endif
#ifndef H2_BRIDGE_LIMIT
#define H2_BRIDGE_LIMIT 32768
#endif
enum { DEST=H2_BRIDGE_DEST, LIMIT=H2_BRIDGE_LIMIT, BUILD=0x4830324cu };
static void arm(void)
{
    USB(0xb10) = 0x60080040;
    USB(0xb00) |= 0x84000000;
}
static void reply(unsigned data, unsigned length)
{
    USB(0x910) = (1u<<19) | length;
    USB(0x900) |= 0x84000000;
    if (length)
        USB(0x1000) = data;
}

__attribute__((section(".entry")))
uint32_t bridge(uint32_t cookie)
{
    volatile uint32_t *dest = (volatile uint32_t *)DEST;
    unsigned expected = 0, received = 0, sum = 0, good = 0, quit = 0;
    uint32_t setup[2] = {0,0};
    int got = 0;
    for (;;) {
        uint32_t in = USB(0x908);
        if (in & 1) {
            USB(0x908) = in;
            if (quit == 1)
                break;
#ifdef H2_RTC_PROBE
            if (quit == 3) {
                h2_health_arm();
                for (;;) {}
            }
#endif
            if (quit == 2) {
                __asm__ volatile("sync" ::: "memory");
#ifdef H2_TIMED_RAM_TRIAL
                arm_return();
                sync_sram_code();
#endif
#ifdef H2_BOOT_RAM_TRIAL
                ((void (*)(uint32_t))DEST)(H2_HEALTH_TRIAL_ENTRY);
#else
                ((void (*)(void))DEST)();
#endif
                break;
            }
        }
        if (USB(0x14) & (1u<<12))
            break;
        while (USB(0x14) & (1u<<4)) {
            uint32_t status = USB(0x20);
            unsigned size = (status >> 4) & 2047;
            unsigned is_setup = (status & 0x1e000f) == 0xc0000 && size == 8;
            for (unsigned i=0; i<(size+3)/4; ++i) {
                uint32_t data = USB(0x1000);
                if (is_setup)
                    setup[i] = data;
            }
            got |= is_setup;
        }
        uint32_t out = USB(0xb08);
        if (!out)
            continue;
        USB(0xb08) = out;
        if ((out&8) && got) {
            unsigned req = setup[0]&65535, val = setup[0]>>16, len = setup[1]>>16;
            uint32_t arg = val | (setup[1]<<16);
            got = 0;
            if (req == 0x60c0 && len == 4)
                reply(0x4c323048u, 4); /* H02L */
            else if (req == 0x6140 && !len && arg && arg <= LIMIT && !(arg&3)) {
                expected = arg;
                received = 0;
                sum = ~0u;
                good = 0;
                reply(0,0);
            } else if (req == 0x6240 && !len && received < expected) {
                dest[received/4] = arg;
                received += 4;
                for (unsigned byte=0; byte<4; ++byte) {
                    sum ^= (arg>>(8*byte))&255;
                    for (unsigned bit=0; bit<8; ++bit)
                        sum = (sum>>1) ^ (0xedb88320u & -(sum&1));
                }
                reply(0,0);
            } else if (req == 0x6340 && !len && expected && received == expected) {
                /* Also check bytes read back from the final destination. */
                uint32_t crc = ~0u;
                for (unsigned word=0; word<expected/4; ++word) {
                    uint32_t data = dest[word];
                    for (unsigned byte=0; byte<4; ++byte) {
                        crc ^= (data>>(8*byte))&255;
                        for (unsigned bit=0; bit<8; ++bit)
                            crc = (crc>>1) ^ (0xedb88320u & -(crc&1));
                    }
                }
                good = ~sum==arg && ~crc==arg;
                reply(0,0);
            } else if (req == 0x64c0 && len == 4)
                reply(good,4);
            else if (req == 0x6540 && !len && !arg && good) {
                quit = 2;
                reply(0,0);
            } else if (req == 0x6640 && !len && !arg) {
                quit = 1;
                reply(0,0);
#ifdef H2_RTC_PROBE
            } else if (req == 0x67c0 && len==4 && !arg) {
                reply(h2_health_read(),4);
            } else if (req == 0x6740 && !len && h2_health_write(arg)) {
                reply(0,0);
            } else if (req == 0x6840 && !len && arg==H2_HEALTH_TRIAL_ENTRY) {
                quit=3;
                reply(0,0);
#endif
            } else {
                USB(0x900) |= 1u<<21;
                USB(0xb00) |= 1u<<21;
            }
        }
        arm();
    }
#ifdef H2_RTC_PROBE
    /* Retire the diagnostic slot and leave the live player available. */
    return cookie;
#else
    return BUILD ^ cookie;
#endif
}
