OUTPUT_ARCH(mips)
ENTRY(panel_trial)
SECTIONS {
    . = 0xa0500018;
    .text : SUBALIGN(4) { KEEP(*(.entry)) *(.text*) }
    .rodata : { *(.rodata*) }
    .data : { *(.data*) BYTE(0); . = ALIGN(4); }
    /DISCARD/ : { *(.MIPS.abiflags .reginfo .pdr .got .comment .note.*) }
    ASSERT(panel_trial == 0xa0500018, "Panel trial entry must match USB slot")
    ASSERT(SIZEOF(.bss) == 0, "Panel trial has no BSS init")
    ASSERT(. < 0xa0600000, "Panel trial must fit the slot")
}
