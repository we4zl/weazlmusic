"""Pack an X1000 mask-ROM NAND stage or an H2 application image for test."""
from argparse import ArgumentParser
from pathlib import Path
import struct
import zlib

ROM_MAGIC = bytes.fromhex("060504030255aa5500")
ROM_HEADER = 2048
SRAM_LIMIT = 0x2400
MAX_IMAGE = 0x38000
FORMAT = 0x10001
FORMAT_GUARDED = 0x10002
BOARD = 0x48325734
BASE = 0xa0600000


def crc7(blob):
    crc = 0
    for byte in blob:
        for bit in range(7, -1, -1):
            feedback = ((crc >> 6) ^ (byte >> bit)) & 1
            crc = ((crc << 1) & 127) ^ (9 if feedback else 0)
    return crc


def rom_stage(image):
    if not image or len(image) > SRAM_LIMIT or len(image) % 4:
        raise ValueError("SPL exceeds the bounded SRAM code area or is unaligned")
    header = ROM_MAGIC + bytes((crc7(image), 2, 2)) + struct.pack("<I", ROM_HEADER + len(image))
    return header.ljust(ROM_HEADER, b"\0") + image


def application(image, generation, build_id, guarded=False):
    if not image or len(image) > MAX_IMAGE or len(image) % 4:
        raise ValueError("Application exceeds its image region or is unaligned")
    if generation <= 0 or build_id <= 0:
        raise ValueError("Generation and build ID must be positive")
    if guarded and generation > 0xfffff:
        raise ValueError("Generation does not fit the X1000 boot health register")
    fields = struct.pack("<7I", BOARD, FORMAT_GUARDED if guarded else FORMAT,
                         generation, len(image), zlib.crc32(image), BASE, build_id)
    header = fields + struct.pack("<I", zlib.crc32(fields))
    return header.ljust(2048, b"\xff") + image + b"\xff" * (-len(image) % 2048)


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("kind", choices=("rom", "app"))
    cli.add_argument("binary", type=Path)
    cli.add_argument("output", type=Path)
    cli.add_argument("--generation", type=lambda x: int(x, 0), default=1)
    cli.add_argument("--build-id", type=lambda x: int(x, 0), default=0x483034)
    cli.add_argument("--guarded", action="store_true")
    args = cli.parse_args()
    image = args.binary.read_bytes()
    packaged = rom_stage(image) if args.kind == "rom" else application(image, args.generation,
                                                                        args.build_id, args.guarded)
    with args.output.open("xb") as target:
        target.write(packaged)


if __name__ == "__main__":
    main()
