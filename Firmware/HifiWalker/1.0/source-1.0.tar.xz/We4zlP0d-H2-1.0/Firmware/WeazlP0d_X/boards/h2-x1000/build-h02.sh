#!/usr/bin/env bash
set -euo pipefail
board=$(cd "$(dirname "$0")" && pwd -P)
root=$(git -C "$board" rev-parse --show-toplevel)
out="$root/Firmware/HifiWalker/H02"
work="$root/build/hifih2/H02"
mkdir -p "$work" "$out"
flags=(--target=mipsel-none-elf -march=mips32r2 -msoft-float -mno-abicalls -fno-pic -G0 -Os -ffreestanding -fno-builtin -fno-stack-protector -Wall -Wextra -Werror)
objects=()
for src in start.S boot_usb.c ram_service.c ddr.c; do
    obj="$work/${src%.*}.o"
    clang "${flags[@]}" -DH2_SERVICE -c "$board/$src" -o "$obj"
    objects+=("$obj")
done
ld.lld -m elf32ltsmip -T "$board/sram.ld" "${objects[@]}" -o "$work/H02.elf"
llvm-objcopy -O binary "$work/H02.elf" "$work/H02.bin"
if [[ -f "$out/H02.bin" ]] && ! cmp -s "$out/H02.bin" "$work/H02.bin"; then
    echo 'The published H02 differs. Give your build a new ID.' >&2
    exit 1
fi
install -m 644 "$work/H02.bin" "$out/H02.bin"
(cd "$out" && sha256sum H02.bin > SHA256SUMS)
