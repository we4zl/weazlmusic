#!/usr/bin/env bash
set -euo pipefail
board=$(cd "$(dirname "$0")" && pwd -P)
root=$(git -C "$board" rev-parse --show-toplevel)
minor=${1:-5}
case "$minor" in 5|13|15) ;; *) exit 2 ;; esac
printf -v build 'h%02d' "$minor"
work="$root/build/hifih2/boot/$build"
backup="$root/Firmware/HifiWalker/H03/flash-first-192-pages.bin"
crc=$(python - "$backup" <<'PY'
import hashlib, sys, zlib
from pathlib import Path
data = Path(sys.argv[1]).read_bytes()
if len(data)!=192*2112 or hashlib.sha256(data).hexdigest()!="4d95a30f60e243e40741f263f1e2ea06961ffd7854b99abad8ecefd4fc4a6d06":
    raise SystemExit("Factory NAND backup checksum differs")
print(hex(zlib.crc32(data[:64*2112])))
PY
)
defines=(-DH2_FACTORY_BOOT_BLOCK_CRC="$crc")
if [[ "$minor" != 5 ]]; then
    h05="$root/Firmware/HifiWalker/H05"
    (cd "$h05" && sha256sum -c SHA256SUMS >/dev/null)
    crc=$(python - "$h05/nand-boot.jsonl" <<'PY'
import json, sys
from pathlib import Path
events = [json.loads(line) for line in Path(sys.argv[1]).read_text().splitlines()]
state = next(event for event in events if event["event"] == "preflight")
if not state["primary_matches"] or not state["copy_matches"] or state["primary_crc"] != state["copy_crc"]:
    raise SystemExit("The previous recovery copies did not verify")
print(hex(state["primary_crc"]))
PY
)
    installer_id=$((0x48000000+(0x30+minor/10)*65536+(0x30+minor%10)*256+0x46))
    defines+=(-DH2_RECOVERY_UPGRADE -DH2_RECOVERY_INSTALLER_ID="$installer_id"
              -DH2_PREVIOUS_BOOT_BLOCK_CRC="$crc")
fi
cat >"$work/rom-image.S" <<EOF
.section .rodata,"a",@progbits
.balign 4
.globl h2_rom_image
h2_rom_image:
.incbin "$work/$build-spl.img"
.globl h2_rom_length
h2_rom_length:
.word . - h2_rom_image
EOF
flags=(--target=mipsel-none-elf -march=mips32r2 -msoft-float -mno-abicalls -fno-pic -G0 -Os -ffreestanding -fno-builtin -fno-stack-protector -Wall -Wextra -Werror)
clang "${flags[@]}" "${defines[@]}" -c "$board/flash_trial.c" -o "$work/flash_trial.o"
clang "${flags[@]}" -DH2_NAND_INSTALLER -c "$board/nand_read.c" -o "$work/nand_install.o"
clang "${flags[@]}" -c "$work/rom-image.S" -o "$work/rom-image.o"
clang "${flags[@]}" -c "$board/flash-entry.S" -o "$work/flash-entry.o"
ld.lld -m elf32ltsmip -T "$board/flash-trial.ld" "$work/flash-entry.o" "$work/flash_trial.o" "$work/nand_install.o" "$work/rom-image.o" -o "$work/flash.elf"
llvm-objcopy -O binary "$work/flash.elf" "$work/flash.bin"
llvm-readelf -h "$work/flash.elf" | awk '/Entry point address/ {e=tolower($NF)} END {exit e!="0xa0400018"}'
