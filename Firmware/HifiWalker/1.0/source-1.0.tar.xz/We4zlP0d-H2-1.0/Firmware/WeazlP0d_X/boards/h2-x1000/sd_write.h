#ifndef H2_SD_WRITE_H
#define H2_SD_WRITE_H

#include <stdint.h>

enum { H2_SD_WRITE_MAX_SECTORS = BUILD_MINOR >= 32 ? 240 : 32 };

uint32_t h2_sd_capacity(void);
int h2_sd_write_blocks(uint32_t lba, const uint8_t *data, unsigned count);
#if BUILD_MINOR >= 30
void h2_sd_write_report(uint32_t out[8]);
#endif
#if BUILD_MINOR >= 35
void h2_sd_write_timing(uint32_t out[8]);
#endif
#if BUILD_MINOR >= 36
int h2_sd_read_blocks(uint32_t lba, uint32_t *data, unsigned count);
#if BUILD_MINOR >= 62
int h2_sd_export_speed(void);
#endif
#endif
#if defined(H2_WRITE_PIPELINE)
int h2_sd_begin_write(uint32_t lba, const uint8_t *data, unsigned count);
/* Zero means busy, positive means durable, negative means failed. */
int h2_sd_poll_write(void);
#endif
#endif
