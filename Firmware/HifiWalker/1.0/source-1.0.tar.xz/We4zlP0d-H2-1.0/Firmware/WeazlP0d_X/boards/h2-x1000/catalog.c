/* Initial Ingenic Linux port. Run "views" to inspect a docked index or
 * "pcm ROW" to render exactly one occurrence to stdout as 48 kHz S16LE. */
#define _FILE_OFFSET_BITS 64
#define _POSIX_C_SOURCE 200809L
#include "trip.h"
#include "file_library.h"
#include <stdlib.h>
#include <sys/stat.h>

static int render_row(trip_player *player, const char *number)
{
    char *end;
    unsigned long row = strtoul(number, &end, 10);
    if (number[0] < '0' || number[0] > '9' || *end || row >= (uint64_t)player->count + player->stations ||
        !trip_select(player, (uint32_t)row, 0))
        return 1;
    fprintf(stderr, "%s — %s (%u frames)\n", player->title, player->artist, player->frames);
    while (player->position < player->frames) {
        int16_t pcm[256];
        int n = trip_pull(player, pcm, 128);
        if (n <= 0 || fwrite(pcm, 4, (size_t)n, stdout) != (size_t)n)
            return 1;
    }
    return fflush(stdout) != 0;
}

int main(int argc, char **argv)
{
    int list = argc == 3 && !strcmp(argv[2], "views");
    if (!list && !(argc == 4 && !strcmp(argv[2], "pcm"))) {
        fprintf(stderr, "Usage: %s WXP.TRIP views | WXP.TRIP pcm ROW\n", argv[0]);
        return 2;
    }
    file_library files = {.index = fopen(argv[1], "rb"), .path = argv[1]};
    trip_player player = {0};
    struct stat st;
    int result = 1;
    if (!files.index || fstat(fileno(files.index), &st) || st.st_size < 0 ||
        (uint64_t)st.st_size > UINT32_MAX || !trip_open(&player, file_read, &files, st.st_size)) {
        fprintf(stderr, "Could not open catalog %s\n", argv[1]);
    } else if (list) {
        result = 0;
        for (unsigned i = 0; i < player.views; ++i) {
            trip_view v;
            if (!trip_view_at(&player, i, &v) || printf("%u\t%u\t%u\t%s\n", v.kind, v.first, v.count, v.title) < 0) {
                result = 1;
                break;
            }
        }
        if (fflush(stdout)) result = 1;
    } else {
        result = render_row(&player, argv[3]);
    }
    if (files.clip) fclose(files.clip);
    if (files.index) fclose(files.index);
    return result;
}
