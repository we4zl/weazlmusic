/* One last receiver stored in an append-only NAND block outside both app slots. */
#include "bond_store.h"
#include "boot_slot.h"

enum { BOND_FIRST=1024, BOND_PAGES=64, MAGIC=0x4b423248, VERSION=1 };
unsigned h2_nand_info(uint32_t info[4]);
unsigned h2_nand_page(unsigned page,uint32_t words[528],unsigned *status);
unsigned h2_nand_program_install_page(unsigned page,const uint32_t data[512],uint32_t *scratch);

static uint32_t checksum(const uint32_t *data,unsigned count)
{
    uint32_t crc=~0u;
    for (unsigned i=0;i<count;++i) {
        crc^=((const uint8_t *)data)[i];
        for (unsigned bit=0;bit<8;++bit)
            crc=(crc>>1)^(0xedb88320u&-(crc&1));
    }
    return ~crc;
}

static int scan(h2_bond *bond,unsigned *blank,uint32_t *scratch
#if BUILD_MINOR >= 26
                ,unsigned capacity
#endif
                )
{
    typedef unsigned (*identify)(uint32_t *);
    typedef unsigned (*read)(unsigned,uint32_t *,unsigned *);
    identify inspect=(identify)((uintptr_t)h2_nand_info|0x20000000u);
    read page=(read)((uintptr_t)h2_nand_page|0x20000000u);
    uint32_t info[4];
    *blank=0;
    if (inspect(info) || (info[0]&0xffffff)!=0x21aaef || (info[1]&0xffffff)!=0x21aaef ||
        info[2]!=0x18 || info[3]!=0x7c)
        return -1;
    int found=0;
    for (unsigned i=BOND_FIRST;i<BOND_FIRST+BOND_PAGES;++i) {
        unsigned flags;
        if (page(i,scratch,&flags) || (scratch[512]&255)!=255)
            return -1;
        if ((flags&0x30)==0x20)
            continue;
        if (scratch[0]==0xffffffff) {
            int erased=1;
            for (unsigned k=1;k<528;++k)
                erased &= scratch[k]==0xffffffff;
            if (erased) {
                *blank=i;
                break;
            }
        }
        if (scratch[0]==MAGIC && scratch[1]==VERSION && scratch[8]==checksum(scratch,32)) {
            const uint8_t *payload=(const uint8_t *)(scratch+2);
#if BUILD_MINOR >= 26
            unsigned pos=0;
            while (pos<(unsigned)found) {
                unsigned k=0;
                while (k<6 && bond[pos].peer[k]==payload[k]) ++k;
                if (k==6) break;
                ++pos;
            }
            if (pos==(unsigned)found && pos<capacity) ++found;
            if (pos==capacity) --pos;
            for (;pos>0;--pos)
                for (unsigned k=0;k<sizeof *bond;++k)
                    ((uint8_t *)&bond[pos])[k]=((uint8_t *)&bond[pos-1])[k];
            for (unsigned k=0;k<22;++k) ((uint8_t *)bond)[k]=payload[k];
            for (unsigned k=0;k<sizeof bond->name;++k) bond->name[k]=0;
            if (scratch[9]==0x454d414e && scratch[18]==checksum(scratch,72)) {
                for (unsigned k=0;k+1<sizeof bond->name;++k)
                    bond->name[k]=((const char *)(scratch+10))[k];
            }
#else
            for (unsigned k=0;k<sizeof *bond;++k)
                ((uint8_t *)bond)[k]=payload[k];
            found=1;
#endif
        }
    }
    return found;
}

int h2_bond_load(h2_bond *bond)
{
    unsigned empty;
    uint32_t scratch[528];
#if BUILD_MINOR >= 26
    return scan(bond,&empty,scratch,1);
#else
    return scan(bond,&empty,scratch);
#endif
}

#if BUILD_MINOR >= 26
int h2_bonds_load(h2_bond bonds[H2_SAVED])
{
    unsigned empty;
    uint32_t scratch[528];
    return scan(bonds,&empty,scratch,H2_SAVED);
}
#endif

int h2_bond_save(const h2_bond *bond)
{
    uint32_t scratch[528], data[512];
    unsigned blank;
    h2_bond last;
#if BUILD_MINOR >= 26
    int found=scan(&last,&blank,scratch,1);
#else
    int found=scan(&last,&blank,scratch);
#endif
    if (found<0)
        return 0;
    if (found) {
        unsigned difference=0;
        for (unsigned k=0;k<sizeof last;++k)
            difference|=((const uint8_t *)bond)[k]^((const uint8_t *)&last)[k];
        if (!difference)
            return 1;
    }
    if (!blank)
        return 0;
    for (unsigned i=0;i<512;++i)
        ((volatile uint32_t *)data)[i]=0xffffffff;
    data[0]=MAGIC;
    data[1]=VERSION;
    uint8_t *payload=(uint8_t *)(data+2);
    for (unsigned k=0;k<22;++k)
        payload[k]=((const uint8_t *)bond)[k];
    data[8]=checksum(data,32);
#if BUILD_MINOR >= 26
    data[9]=0x454d414e;
    for (unsigned k=0;k<sizeof bond->name;++k)
        ((char *)(data+10))[k]=bond->name[k];
    data[18]=checksum(data,72);
#endif
    typedef unsigned (*program)(unsigned,const uint32_t *,uint32_t *);
    program commit=(program)((uintptr_t)h2_nand_program_install_page|0x20000000u);
    return commit(blank,data,scratch)==0;
}
