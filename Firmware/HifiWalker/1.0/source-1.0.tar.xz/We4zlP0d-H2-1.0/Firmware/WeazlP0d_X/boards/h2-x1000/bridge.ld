OUTPUT_ARCH(mips)
ENTRY(bridge)
SECTIONS {
    . = 0xf4000818;
    .text : { KEEP(*(.entry)) *(.text*) } 
    /DISCARD/ : { *(.MIPS.abiflags .reginfo .pdr .got .comment .note.*) }
    ASSERT(SIZEOF(.text) <= 2024, "H02 bridge exceeds SRAM slot")
}
