# HiFi Walker H2, USB-C, factory V2.0 hardware

The CPU reported X1000_v1 over the Ingenic USB interface. This earlier experiment targeted the factory Linux kernel. The ground-up H2 firmware has its own build directory. [H2 firmware](../../../HifiWalker/README.md) Factory V2.2 now cold-boots directly on the physical H2. [Restoration record](../../../H2/stock/README.md) The first build exercises the existing X catalog and stereo decoder. It is a command-line bring-up tool. It has no dependency on Rockbox.

HiFi Walker's H2 compatibility table selects V2.2 for an installed V2.0. The repository's V1.4 image belongs to a different update branch. The downloaded V2.2 ISO has SHA-256 `5e28f9d56bff9cbb8b4e03a97c9fbe230d88ed570488aab31fdf01d5ade7ae0f`. Its manifest checksums match its kernel and root filesystem. REA with llvm-objdump identified the factory player as little-endian MIPS ELF with entry point 0x0041b990. Its SHA-256 is `9e7957c1ee2bf50480b0e0e943f7b732a2dde35618e9a5ed4ad72531ea970ea8`. [Manufacturer firmware selector](https://hifiwalker.com/pages/download) · [Factory update procedure](https://hifiwalker.com/blogs/hifi-walker-h2/h2-firmware-update-guide)

## Reproduce the first build

From the repository root, with Zig 0.13 and qemu-user installed, run the following commands. Give the program the path to a WXP.TRIP with its WXPCLIPS directory alongside.

```sh
x=Firmware/WeazlP0d_X
zig cc -target mipsel-linux-musl -mcpu=mips32r2 -O2 -Wall -Wextra -Werror -static \
    -I"$x" "$x/boards/h2-x1000/catalog.c" "$x/trip.c" -o h2-catalog
qemu-mipsel-static ./h2-catalog /path/to/WXP.TRIP views
qemu-mipsel-static ./h2-catalog /path/to/WXP.TRIP pcm 0 > row0.s16le
```

The physical card's captured index returned Continue, two recent albums, albums, artists, genre, and Drop the Needle. Its first row, Left Right Both, rendered 720,000 frames of 48 kHz stereo in QEMU. All 2,880,000 PCM bytes matched the X simulator. The right channel was silent during the left-only passage and the left channel was silent during the right-only passage. SHA-256 was `520545be8c77e7665c793d3ffa64b6d98e8f6a3a361eb5c2e7b022ac0728dc78`.

The V2.2 factory `aplay` and ALSA library also ran under QEMU. Their file output preserved every PCM byte and added 6,000 silent stereo frames at end-of-stream. This exercised the vendor playback software up to the output device.

Hardware acceptance still requires running X on the H2 itself, checking display and physical inputs, low-level wired output, identifiable Bluetooth stereo, artwork, time-synchronized radio, and saved playback position. An autonomous update requires two distinguishable X builds applied over normal USB and a tested rollback. The manual SD updater was verified for the factory restoration.
