#!/usr/bin/env bash
set -euo pipefail
board=$(cd "$(dirname "$0")" && pwd -P)
root=$(git -C "$board" rev-parse --show-toplevel)
cd "$root"
out="$root/build/hifih2/panel"
art=Firmware/HifiWalker/art
(cd "$art" && sha256sum -c SHA256SUMS)
flags=(--target=mipsel-none-elf -march=mips32r2 -msoft-float -mno-abicalls -fno-pic -G0 -Os -ffreestanding -fno-builtin -fno-stack-protector -Wall -Wextra -Werror)
linker=panel-trial.ld
entry=()
sources=(panel panel_trial)
art_object=()
case "${1:-}" in
    '') ;;
    --live|--live-slcd|--live-slcd-rails)
        out+=/live
        flags+=(-DH2_PANEL_LIVE)
        if [[ "$1" == --live-slcd* ]]; then
            out+=-slcd
            flags+=(-DH2_PANEL_SLCD)
            sources+=(slcd_trial)
        fi
        if [[ "$1" == --live-slcd-rails ]]; then
            out+=-rails
            flags+=(-DH2_PANEL_LCD_RAILS)
            sources+=(pmic)
        fi
        linker=flash-trial.ld
        mkdir -p "$out"
        clang "${flags[@]}" -c "$board/flash-entry.S" -o "$out/entry.o"
        entry=("$out/entry.o")
        ;;
    *) echo "Expected --live, --live-slcd or --live-slcd-rails" >&2; exit 2 ;;
esac
mkdir -p "$out"
objects=()
for f in "${sources[@]}"; do
    clang "${flags[@]}" -c "$board/$f.c" -o "$out/$f.o"
    objects+=("$out/$f.o")
done
if [[ "${1:-}" != --live-slcd* ]]; then
    clang "${flags[@]}" -DH2_TRIAL_ART='"Firmware/HifiWalker/art/night-tunnel.rgb565le"' -c "$board/panel-trial-art.S" -o "$out/art.o"
    art_object=("$out/art.o")
fi
ld.lld -m elf32ltsmip -T "$board/$linker" "${entry[@]}" "${objects[@]}" "${art_object[@]}" -o "$out/trial.elf"
llvm-objcopy -O binary "$out/trial.elf" "$out/trial.bin"
