/* Fixed 48 kHz stereo SBC profile for the first H2 A2DP Audio Source.
 * A2DP v1.4.1 Appendix B defines filtering, loudness allocation and coding. */
#include "sbc_source.h"
#include "sbc_tables.h"

static unsigned magnitude(int32_t n)
{
    return n<0 ? (unsigned)-n : (unsigned)n;
}
static void analyze(h2_sbc *s,const int16_t *pcm,int16_t bands[2][8])
{
    s->offset=s->offset>=8 ? s->offset-8 : 72;
    for (unsigned ch=0;ch<2;++ch) {
        int16_t *history=s->delay[ch];
        for (unsigned i=0;i<8;++i)
            history[s->offset+i]=pcm[2*(7-i)+ch];

        int32_t phase[16];
        for (unsigned j=0;j<16;++j) {
            unsigned pos=s->offset+j;
            if (pos>=80)
                pos-=80;
            int32_t sum=0;
            for (unsigned i=j;i<80;i+=16) {
                sum+=(int32_t)history[pos]*prototype[i];
                pos+=16;
                if (pos>=80)
                    pos-=80;
            }
            phase[j]=sum>>15;
        }
        for (unsigned sb=0;sb<8;++sb) {
            int32_t sum=0;
            for (unsigned i=0;i<16;++i)
                sum+=phase[i]*cosine[sb][i];
            bands[ch][sb]=sum>>15;
        }
    }
}

static void allocate(const uint8_t scale[16],uint8_t slots[16],unsigned pool)
{
    static const int bias[]={-4,0,0,0,0,0,1,2};
    int need[16], slice=0;
    for (unsigned i=0;i<16;++i) {
        int value=scale[i]-bias[i%8];
        need[i]=scale[i]==0 ? -5 : value>0 ? value/2 : value;
        if (need[i]>slice)
            slice=need[i];
    }
    unsigned spent=0,next=0;
    ++slice;
    do {
        --slice;
        spent+=next;
        next=0;
        for (unsigned i=0;i<16;++i) {
            int width=need[i]-slice;
            next+=width==1 ? 2 : width>1 && width<16 ? 1 : 0;
        }
    } while (spent+next<pool);
    if (spent+next==pool) {
        spent+=next;
        --slice;
    }
    for (unsigned i=0;i<16;++i) {
        int width=need[i]-slice;
        slots[i]=width<2 ? 0 : width>16 ? 16 : width;
    }
    for (unsigned i=0;i<16 && spent<pool;++i) {
        unsigned j=(i/2)+(i%2)*8;
        if (slots[j]>=2 && slots[j]<16) {
            ++slots[j]; ++spent;
        } else if (need[j]==slice+1 && spent+1<pool) {
            slots[j]=2; spent+=2;
        }
    }
    for (unsigned i=0;i<16 && spent<pool;++i) {
        unsigned j=(i/2)+(i%2)*8;
        if (slots[j]<16) {
            ++slots[j]; ++spent;
        }
    }
}

static uint8_t crc_byte(uint8_t crc,uint8_t byte)
{
    crc^=byte;
    for (unsigned i=0;i<8;++i)
        crc=(uint8_t)((crc<<1)^((crc&128) ? 0x1d : 0));
    return crc;
}

void h2_sbc_encode_pool(h2_sbc *state,const int16_t pcm[256],uint8_t *out,unsigned pool)
{
    if (pool<2 || pool>H2_SBC_MAX_POOL) return;
    int16_t samples[16][2][8];
    for (unsigned n=0;n<16;++n)
        analyze(state,pcm+16*n,samples[n]);
    uint8_t scale[16],bits[16];
    for (unsigned i=0;i<16;++i) {
        unsigned peak=0, sf=0;
        for (unsigned n=0;n<16;++n) {
            unsigned absolute=magnitude(samples[n][i/8][i%8]);
            if (absolute>peak)
                peak=absolute;
        }
        while (sf<15 && peak>=(2u<<sf))
            ++sf;
        scale[i]=sf;
    }
    out[0]=0x9c;
    out[1]=0xf9; /* 48 kHz, 16 blocks, stereo, loudness, 8 subbands */
    out[2]=pool;
    uint8_t crc=crc_byte(crc_byte(0x0f,out[1]),out[2]);
    for (unsigned i=0;i<8;++i) {
        out[4+i]=(scale[2*i]<<4)|scale[2*i+1];
        crc=crc_byte(crc,out[4+i]);
    }
    out[3]=crc;
    allocate(scale,bits,pool);
    unsigned position=12*8;
    for (unsigned i=12;i<H2_SBC_FRAME_BYTES(pool);++i)
        out[i]=0;
    for (unsigned n=0;n<16;++n)
        for (unsigned i=0;i<16;++i) {
            unsigned width=bits[i];
            if (!width)
                continue;
            unsigned limit=2u<<scale[i];
            int32_t centered=samples[n][i/8][i%8]+(int32_t)limit;
            unsigned levels=(1u<<width)-1;
            unsigned value=((unsigned)centered*levels)>>(scale[i]+2);
            for (unsigned bit=width;bit;--bit,++position)
                if (value&(1u<<(bit-1)))
                    out[position/8]|=0x80>>(position%8);
        }
}

void h2_sbc_encode(h2_sbc *state,const int16_t pcm[256],uint8_t *out)
{
    h2_sbc_encode_pool(state,pcm,out,26);
}
