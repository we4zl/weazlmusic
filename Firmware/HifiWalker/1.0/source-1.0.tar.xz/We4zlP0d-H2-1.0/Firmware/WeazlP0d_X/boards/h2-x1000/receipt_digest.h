/* SHA-256 for one 32-byte sync revision. The SCSI request is read-only and
 * serialized with normal card I/O. Never use the playback FAT cache here. */
#include "fs.h"

#include "receipt_sha256.h"

static int card_receipt(unsigned page,unsigned cap,uint8_t *out)
{
    static const char *const paths[]={"/WXP.RAD","/WXP.MUS","/WXP.ART"};
    uint8_t sector[512],token[32];
    fs volume;fs_file file;size_t n;
    if (!h2_sd_read(0,0,sector) || sector[510]!=0x55 || sector[511]!=0xaa) return -1;
    if (fs_mount(&volume,h2_sd_read,0,cap,little(sector+454))!=FS_OK) return -1;
    fs_status result=fs_open(&volume,paths[page-0xc0],&file);
    if (result==FS_NOT_FOUND) return 0;
    if (result!=FS_OK || file.size!=32 || fs_read(&file,token,32,&n)!=FS_OK || n!=32) return -1;
    receipt_sha256(token,out);
    return 32;
}
