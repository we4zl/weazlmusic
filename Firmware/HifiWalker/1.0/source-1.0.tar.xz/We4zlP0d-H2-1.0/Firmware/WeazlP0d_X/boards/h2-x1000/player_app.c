/* Native 320 x 240 H2 surface. Media stays under the shared X catalog and decoder. */
#include "a2dp.h"
#include "bond_store.h"
#ifdef H2_BOOT_GUARD
#include "boot_health.h"
#endif
#include "input.h"
#include "panel.h"
#include "player_app.h"
#include "ui.h"
#include <stdbool.h>
#ifdef H2_ORIGINAL_AUDIO
#include "original_audio.h"
#endif

#ifndef BUILD_MINOR
#define BUILD_MINOR 6
#endif
#if BUILD_MINOR >= 63
#define SMALL_UI __attribute__((minsize))
#else
#define SMALL_UI
#endif
#if BUILD_MINOR >= 30
#include "sd_write.h"
#endif
#define OST (*(volatile uint32_t *)0xb2000020u)
#define CPM(off) (*(volatile uint32_t *)(0xb0000000u+(off)))
#define TCU(off) (*(volatile uint32_t *)(0xb0002000u+(off)))
enum { W=320, H=240, VISIBLE=(BUILD_MINOR>=43 ? 4 : 5), CAP=(BUILD_MINOR>=54 ? 100 : 40), PANEL_SETTLE_MS=450 };
enum screen { HOME, SHELVES, TRACKS, PLAYING, RADIO, SETTINGS, STATIONS, DOCK
#if BUILD_MINOR >= 58
    , MUSIC
#endif
#if BUILD_MINOR >= 55
    , RESTART_RECORDING
#endif
};
enum action { PREV, NEXT, SELECT, BACK, MENU, LOUDER, QUIETER };
enum { BACKGROUND=0x0883, INK=0xf7bf, MUTED=0xa59b, ACCENT=0xfef9, FOCUS=0x3850 };
static const char *const home[]={"Continue","Drop the Needle","New in the Crates","Music",
                                "Flight Recorder","Bluetooth","Settings","USB Dock"
#if BUILD_MINOR >= 58
                                ,"My WAR3Z","Playlists"
#endif
};
#if BUILD_MINOR >= 58
static const char *const music[]={"Songs","Artists","Albums"};
static const unsigned music_kinds[]={TRIP_SONGS,TRIP_ARTISTS,TRIP_ALBUMS};
static unsigned music_cursor;
#endif
static const char *shelf_title(void);
#if BUILD_MINOR >= 43
static const unsigned home_order[]={1,2,4,0,
#if BUILD_MINOR >= 58
    8,9,
#endif
    3,5,6,7};
#define HOME_ACTION(row) home_order[row]
#else
#define HOME_ACTION(row) (row)
#endif
static const char version[]={'H','0'+BUILD_MINOR/10,'0'+BUILD_MINOR%10,0};
void h2_hci_probe(uint32_t report[9],unsigned rails,unsigned keep);
void h2_hci_link(const uint8_t peer[6],uint32_t report[8],int keep);
void h2_hci_stop(void);
int h2_pmic_poweroff(void);
unsigned h2_player_clock(void);
extern const uint8_t h2_art[], h2_art_end[],h2_dock_art[],h2_dock_art_end[];
int h2_decode_art(const uint8_t *,size_t,uint8_t *,size_t);

static h2_library library;
static h2_a2dp audio;
static h2_input keys;
static enum screen page;
static unsigned cursor,home_cursor,shelf_cursor,shelf_kind,track;
#if BUILD_MINOR >= 63
enum { STRIP=8, BROWSE_TOP=43, BROWSE_ROW=29, BROWSE_COUNT=6, LIST_TOP=118, LIST_ROW=25 };
static uint32_t damage;
static unsigned browse_list(void) { return page==SHELVES || page==TRACKS; }
static void repaint(unsigned top,unsigned bottom)
{
    damage|=((1u<<((bottom+STRIP-1)/STRIP))-1) & ~((1u<<(top/STRIP))-1);
}
static unsigned paint_idle(void) { return !damage; }
#else
static unsigned visible_y;
static unsigned paint_idle(void) { return visible_y>=H; }
#endif
static const char *shelf_title(void)
{
    switch(shelf_kind) {
    case TRIP_RECENT: return "New in the Crates";
    case TRIP_WAREZ: return "My WAR3Z";
    case TRIP_PLAYLISTS: return "Playlists";
    case TRIP_ARTISTS: return "Artists";
    case TRIP_SONGS: return "Songs";
    case TRIP_ALBUMS: return "Albums";
    default: return "Music";
    }
}
static unsigned storage_error,volume,panel,peer_set,connect_pending,radio_error;
static h2_panel_startup panel_startup;
static unsigned mount_attempts;
static unsigned clock_status;
static uint32_t now,last_tick,last_render,last_mount;
#if BUILD_MINOR >= 52
int h2_pmic_read(uint8_t reg,uint8_t *value);
static int battery_percent=-1;
static uint32_t battery_due;
#endif
static uint32_t volume_until, draw_seed;
#if BUILD_MINOR >= 64
static uint32_t title_since;
#endif
static uint32_t parked_frame,music_frame,station_frame;
static unsigned music_row,draw_slot,drawing,frame_rows;
static uint32_t key_counts[8], wheel_forward, wheel_back;
static uint32_t power_pressed;
static unsigned screen_dark;
#if BUILD_MINOR >= 59
static unsigned screen_timed_out;
static uint32_t last_input;

static int wake_after_timeout(void)
{
    last_input=now;
    if (!screen_timed_out) return 0;
    screen_dark=screen_timed_out=0;
    h2_panel_light();
    return 1;
}
#endif
static uint32_t radio_status[16];
#if BUILD_MINOR >= 41
static uint32_t radio_probe_status[9], radio_link_status[8];
#endif
static uint8_t peer[6], cover[80*80*2];
static h2_bond saved_bond;
static int bond_available, bond_result;
static unsigned save_pending,restart_pending;
static uint8_t *const wallpaper=(uint8_t *)0x80800000u;
static uint8_t *const framebuffer=(uint8_t *)0x80840000u;
static uint8_t *const dock_art=(uint8_t *)0x80880000u;
static int cover_ready, alternate_home;
#if BUILD_MINOR < 63
static int wallpaper_ready, dock_art_ready;
#endif
static trip_view view;
enum { RECENT_ROWS=9 };
static char labels[BUILD_MINOR>=45 ? RECENT_ROWS : VISIBLE][TRIP_LABEL_BYTES+1];
static unsigned first,count;

static void copy_text(char *out,const char *in,unsigned capacity)
{
    unsigned i=0;
    while (i+1<capacity && in[i]) {
        out[i]=in[i];
        ++i;
    }
    out[i]=0;
}

#if BUILD_MINOR < 26
static void start_saved(void)
{
    if (bond_available!=1 || audio.configured)
        return;
    for (unsigned i=0;i<sizeof peer;++i)
        peer[i]=saved_bond.peer[i];
    peer_set=1;
    connect_pending=1;
}

#endif

static void put32(uint8_t *out,uint32_t value)
{
    for (unsigned i=0;i<4;++i)
        out[i]=value>>(8*i);
}

#if BUILD_MINOR >= 55
#include "player_bookmark.h"
static unsigned station_cursor, radio_busy, radio_cancel, poweroff_pending, mount_pending;
#if BUILD_MINOR == 55
static unsigned waiting_to_undock;
#endif
static uint32_t next_checkpoint, first_frame_at, mount_ticks;
#if BUILD_MINOR >= 57
static unsigned automatic_receiver;
static uint32_t radio_deadline;
void h2_usb_poll_radio(void);
#endif
#endif

static int set_track(unsigned row,uint32_t frame)
{
    trip_player *p=&library.player;
    if (storage_error || !trip_select(p,row,0))
        return 0;
    track=row;
    p->position=parked_frame=frame<p->frames ? frame : p->frames;
    cover_ready=0;
    if (p->cover)
        cover_ready=p->read(p->context,0,p->cover,cover,sizeof cover);
    return 1;
}

#if BUILD_MINOR >= 23
static void invalidate_tiles(void);
#endif

#if BUILD_MINOR >= 45
static void invalidate_recent(void);
#endif

static void mount_library(void)
{
#ifdef H2_ORIGINAL_AUDIO
    h2_original_close();
#endif
#if BUILD_MINOR >= 23
    invalidate_tiles();
#if BUILD_MINOR >= 45
    invalidate_recent();
#endif
#endif
    storage_error=h2_media_mount(&library);
    audio.selected=0;
    parked_frame=0;
    if (storage_error)
        return;

    const trip_player *p=&library.player;
    music_row=p->count ? p->index : 0;
    music_frame=p->count ? p->position : 0;
#if BUILD_MINOR >= 55
    restore_station();
#else
    station_frame=p->count ? 0 : p->position;
#endif
    drawing=0;
#if BUILD_MINOR >= 55
    if (!p->count && p->stations)
        set_track(station_row,station_frame);
    else
#endif
        set_track(p->index,p->position);
}

static uint32_t active_position(void)
{
    return audio.selected==track+1 ? audio.library.player.position : parked_frame;
}

static int on_station(void)
{
    return track>=library.player.count && track-library.player.count<library.player.stations;
}

#if BUILD_MINOR >= 55
static void checkpoint_station(void)
{
    if (!storage_error && on_station()) {
        station_row=track-library.player.count;
        station_frame=active_position();
        save_station();
    }
    next_checkpoint=now+10000;
}
#endif

#if BUILD_MINOR >= 26
static void refresh(void);
#include "player_receivers.h"
#endif

static unsigned choices(void)
{
    switch (page) {
#if BUILD_MINOR >= 26
    case RADIO: return receiver_rows();
#endif
    case HOME: return sizeof home/sizeof home[0];
#if BUILD_MINOR >= 58
    case MUSIC: return sizeof music/sizeof music[0];
#endif
    case SHELVES: return storage_error ? 0 : trip_view_count(&library.player,shelf_kind);
    case TRACKS: return view.count;
#if BUILD_MINOR >= 55
    case STATIONS: return storage_error || !library.player.stations ? 0 : library.player.stations+1;
    case RESTART_RECORDING: return 2;
#else
    case STATIONS: return storage_error ? 0 : library.player.stations;
#endif
    case SETTINGS: return 2;
    default: return 0;
    }
}

#if BUILD_MINOR >= 23
#include "player_art.h"
#if BUILD_MINOR >= 45
#include "recent_shelf.h"
#endif
#endif

static SMALL_UI void refresh_labels(void)
{
    count=choices();
#if BUILD_MINOR >= 26
    if (count && cursor>=count) cursor=count-1;
#endif
#if BUILD_MINOR >= 45
    if (recent_page()) {
        recent_titles();
        return;
    }
#endif
#if BUILD_MINOR >= 63
    static enum screen labeled=DOCK;
    unsigned shown=browse_list() ? BROWSE_COUNT : VISIBLE;
    if (page!=labeled) first=0;
    labeled=page;
    if (cursor<first) first=cursor;
    if (cursor>=first+shown) first=cursor-shown+1;
    if (count<=shown) first=0;
    else if (first>count-shown) first=count-shown;
#else
    first=cursor>=VISIBLE ? cursor-VISIBLE+1 : 0;
    unsigned shown=VISIBLE;
#if BUILD_MINOR >= 23
    if (page==SHELVES) {
        shown=TILE_COUNT;
        first=cursor/TILE_COUNT*TILE_COUNT;
    }
#endif
#endif
    for (unsigned i=0;i<shown;++i) {
        unsigned row=first+i;
        labels[i][0]=0;
        if (row>=count)
            continue;
        if (page==HOME) {
            copy_text(labels[i],home[HOME_ACTION(row)],sizeof labels[i]);
#if BUILD_MINOR >= 26
        } else if (page==RADIO) {
            receiver_row(row,labels[i],sizeof labels[i]);
#endif
#if BUILD_MINOR >= 58
        } else if (page==MUSIC) {
            copy_text(labels[i],music[row],sizeof labels[i]);
#endif
        } else if (page==SETTINGS) {
            copy_text(labels[i],row==0 ? "Wallpaper" : "Reload SD library",sizeof labels[i]);
#if BUILD_MINOR >= 55
        } else if (page==RESTART_RECORDING) {
            copy_text(labels[i],row==0 ? "Keep position" : "Restart at 00:00:00",sizeof labels[i]);
        } else if (page==STATIONS && row==library.player.stations) {
            copy_text(labels[i],"Restart recording...",sizeof labels[i]);
#endif
        } else if (page==SHELVES) {
            trip_view item;
            if (trip_view_by_kind(&library.player,shelf_kind,row,&item)) {
                copy_text(labels[i],item.title,sizeof labels[i]);
#if BUILD_MINOR >= 23
                trip_player entry=library.player;
                uint32_t offset=trip_select(&entry,item.first,0) ? entry.cover : 0;
                if (TILE(i).offset!=offset) {
                    TILE(i).offset=offset;
                    TILE(i).received=0;
                }
#endif
            }
        } else if (page==TRACKS || page==STATIONS) {
            trip_player item=library.player;
            unsigned start=page==TRACKS ? view.first : item.count;
            if (trip_select(&item,start+row,0))
                copy_text(labels[i],item.title,sizeof labels[i]);
        }
    }
}

static void refresh(void)
{
    refresh_labels();
#if BUILD_MINOR >= 63
    repaint(0,H);
#else
    visible_y=0;
#endif
}

static void draw_text(unsigned y,int x,int top,int width,unsigned font,const char *s,
                      uint16_t color,uint8_t *line)
{
    ui_text_row(y,x,top,width,font,s,color,line);
}

#if BUILD_MINOR >= 64
static SMALL_UI void focused_text(unsigned y,int x,int top,int width,unsigned font,const char *text,
                                  uint16_t color,uint8_t *line)
{
    unsigned age=now-title_since;
    if (age<1100)
        draw_text(y,x,top,width,font,text,color,line);
    else
        ui_marquee_row(y,x,top,width,font,text,color,age,line);
}
#endif

#if BUILD_MINOR >= 43
#include "record_shop.h"
#endif

#if BUILD_MINOR >= 46
static uint32_t scroll_started, scroll_feedback, scroll_row, scroll_sequence, scroll_top;
#if BUILD_MINOR < 63
static int measuring_scroll;
#endif
#endif
#if BUILD_MINOR >= 47
static uint32_t scroll_viewport;
#if BUILD_MINOR >= 50
static uint32_t scroll_transfer_ticks;
#endif
#if BUILD_MINOR >= 49
static void transmit_scroll_patch(unsigned left,unsigned right,unsigned top,unsigned bottom)
{
    if (left==W) return;
#if BUILD_MINOR >= 50
    uint32_t start_ticks=OST;
#endif
    const unsigned width=right-left;
    const uint8_t *pixels=framebuffer+top*W*2;
    if (width!=W) {
        uint32_t *packed=(uint32_t *)dock_art;
        for (unsigned sy=top;sy<bottom;++sy) {
            const uint32_t *src=(const uint32_t *)(framebuffer+(sy*W+left)*2);
            for (unsigned j=0;j<width/2;++j) *packed++=src[j];
        }
        pixels=dock_art;
    }
    if (!h2_panel_scroll_rect(left,top,width,bottom-top,pixels)) {
        for (unsigned sy=top;sy<bottom;++sy)
            if (!h2_panel_scroll_span(sy,left,right,framebuffer+sy*W*2))
                h2_panel_row(sy,framebuffer+sy*W*2);
    }
#if BUILD_MINOR >= 50
    scroll_transfer_ticks+=OST-start_ticks;
#endif
}
#endif
static void scroll_commit(unsigned y,unsigned rows)
{
#if BUILD_MINOR >= 48
    uint32_t words[W/2];
#if BUILD_MINOR >= 49
    /* Separate the thumbnails from the glyphs: their dirty regions have
     * different heights. Four-line bands also skip interline space. */
    struct dirty { unsigned left,right,top,bottom; } patches[6][2];
    for (unsigned band=0;band<6;++band) for (unsigned part=0;part<2;++part)
        patches[band][part]=(struct dirty){W,0,H,0};
    for (unsigned sy=y;sy<y+rows;++sy) {
        recent_row(sy,(uint8_t *)words);
        uint32_t *dest=(uint32_t *)(framebuffer+sy*W*2);
        for (unsigned part=0;part<2;++part) {
            unsigned start=part ? 16 : 0, end=part ? W/2 : 16;
            unsigned l=W,r=0;
            for (unsigned j=start;j<end;++j) {
                uint32_t native;
#ifdef __mips__
                __asm__("wsbh %0,%1":"=r"(native):"r"(words[j]));
#else
                native=((words[j]&0x00ff00ffu)<<8)|((words[j]&0xff00ff00u)>>8);
#endif
                if (dest[j]==native) continue;
                dest[j]=native;
                if (l==W) l=2*j;
                r=2*j+2;
            }
            if (!r) continue;
            struct dirty *patch=&patches[(sy-y)/4][part];
            if (patch->left>l) patch->left=l;
            if (patch->right<r) patch->right=r;
            if (patch->top>sy) patch->top=sy;
            patch->bottom=sy+1;
        }
    }
    for (unsigned band=0;band<6;++band) for (unsigned part=0;part<2;++part) {
        struct dirty *p=&patches[band][part];
        if (p->right) transmit_scroll_patch(p->left,p->right,p->top,p->bottom);
    }
#else
    unsigned left=W,right=0,top=y+rows,bottom=y;
    for (unsigned sy=y;sy<y+rows;++sy) {
        recent_row(sy,(uint8_t *)words);
        uint32_t *dest=(uint32_t *)(framebuffer+sy*W*2);
        unsigned row_left=W,row_right=0;
        for (unsigned j=0;j<W/2;++j) {
            uint32_t native;
            __asm__("wsbh %0,%1":"=r"(native):"r"(words[j]));
            if (dest[j]==native) continue;
            dest[j]=native;
            if (row_left==W) row_left=2*j;
            row_right=2*j+2;
        }
        if (!row_right) continue;
        if (top>sy) top=sy;
        bottom=sy+1;
        if (left>row_left) left=row_left;
        if (right<row_right) right=row_right;
    }
    if (left==W) return;
    const unsigned width=right-left;
    const uint8_t *pixels=framebuffer+top*W*2;
    if (width!=W) {
        uint32_t *packed=(uint32_t *)dock_art;
        for (unsigned sy=top;sy<bottom;++sy) {
            const uint32_t *src=(const uint32_t *)(framebuffer+(sy*W+left)*2);
            for (unsigned j=0;j<width/2;++j) *packed++=src[j];
        }
        pixels=dock_art;
    }
    if (!h2_panel_scroll_rect(left,top,width,bottom-top,pixels)) {
        for (unsigned sy=top;sy<bottom;++sy)
            if (!h2_panel_scroll_span(sy,left,right,framebuffer+sy*W*2))
                h2_panel_row(sy,framebuffer+sy*W*2);
    }
#endif
#else
    uint8_t line[W*2];
    for (unsigned sy=y;sy<y+rows;++sy) {
        recent_row(sy,line);
        uint8_t *dest=framebuffer+sy*W*2;
        for (unsigned j=0;j<W*2;j+=2) {dest[j]=line[j+1];dest[j+1]=line[j];}
    }
    if (!h2_panel_scroll_rect(0,y,W,rows,framebuffer+y*W*2)) {
        for (unsigned sy=y;sy<y+rows;++sy)
            if (!h2_panel_scroll_span(sy,0,W,framebuffer+sy*W*2))
                h2_panel_row(sy,framebuffer+sy*W*2);
    }
#endif
}
#endif
static void draw(unsigned y)
{
#if BUILD_MINOR >= 63
    uint32_t line[W/2];
    unsigned left=W, right=0, top=y+STRIP, bottom=y;
    for (unsigned sy=y;sy<y+STRIP;++sy) {
        shop_row(sy,(uint8_t *)line);
        uint32_t *dest=(uint32_t *)(framebuffer+sy*W*2);
        for (unsigned x=0;x<W/2;++x) {
            uint32_t pixel;
#ifdef __mips__
            __asm__("wsbh %0,%1":"=r"(pixel):"r"(line[x]));
#else
            pixel=((line[x]&0x00ff00ffu)<<8)|((line[x]&0xff00ff00u)>>8);
#endif
            if (frame_rows==H && dest[x]==pixel) continue;
            dest[x]=pixel;
            if (left>2*x) left=2*x;
            if (right<2*x+2) right=2*x+2;
            if (top>sy) top=sy;
            bottom=sy+1;
        }
    }
    transmit_scroll_patch(left,right,top,bottom);
    if (frame_rows<y+STRIP) frame_rows=y+STRIP;
#else
    uint8_t line[UI_WIDTH*2] __attribute__((aligned(4)));
#if BUILD_MINOR >= 43
    shop_row(y,line);
    goto publish_row;
#endif
    const uint8_t *art=0;
    if (page==HOME)
        art=alternate_home&&dock_art_ready ? dock_art : wallpaper_ready ? wallpaper : 0;
    else if (page==DOCK && dock_art_ready)
        art=dock_art;
    for (unsigned x=0;x<W;++x) {
        unsigned color=BACKGROUND;
        if (art) {
            unsigned i=(y*W+x)*2;
            color=art[i]|((unsigned)art[i+1]<<8);
            color=(color&0xf7de)>>1;
        }
#if BUILD_MINOR >= 26
        if (page==PLAYING && cover_ready && y>=54 && y<166 && x>=16 && x<128) {
            unsigned i=2*((y-54)*80/112*80+(x-16)*80/112);
#else
        if (page==PLAYING && cover_ready && y>=60 && y<140 && x>=20 && x<100) {
            unsigned i=((y-60)*80+x-20)*2;
#endif
            color=((unsigned)cover[i]<<8)|cover[i+1];
        }
        if (
#if BUILD_MINOR >= 23
            page!=SHELVES &&
#endif
            count && y>=75 && y<210 && (y-75)/27+first==cursor && x>=12 && x<W-12)
            color=FOCUS;
        line[x*2]=color>>8;
        line[x*2+1]=color;
    }

    if (page==HOME) {
        draw_text(y,20,25,280,2,"We4zlP0d X",INK,line);
    } else if (page==SHELVES || page==TRACKS || page==STATIONS) {
        const char *title=page==TRACKS ? view.title : page==STATIONS ? "Flight Recorder" :
                          shelf_title();
        draw_text(y,20,24,280,2,title,INK,line);
        if (!count)
            draw_text(y,20,90,280,1,storage_error ? "Insert the library card" :
                      page==STATIONS ? "No flight recordings" : "Nothing on this shelf",MUTED,line);
    } else if (page==PLAYING) {
        draw_text(y,20,24,280,2,"Now Playing",INK,line);
#if BUILD_MINOR >= 23
        if (!cover_ready)
            cassette(y,20,74,80,line);
#if BUILD_MINOR >= 26
        unsigned x=cover_ready ? 138 : 114;
#else
        unsigned x=114;
#endif
        playback_progress(y,line);
#else
        unsigned x=cover_ready ? 114 : 20;
#endif
        ui_marquee_row(y,x,68,W-x-14,1,library.player.title,INK,now,line);
        ui_marquee_row(y,x,96,W-x-14,0,library.player.artist,MUTED,now,line);
        const char *status=audio.playing ? "Playing" : audio.configured ? "Paused" : "Connect Bluetooth to listen";
#if BUILD_MINOR >= 26
        draw_text(y,x,132,W-x-10,0,status,ACCENT,line);
#else
        draw_text(y,20,160,280,1,status,ACCENT,line);
#endif
        char level[]={'V','o','l','u','m','e',' ', '0'+volume/10,'0'+volume%10,'%',0};
#if BUILD_MINOR >= 23
        draw_text(y,116,190,100,0,volume==100 ? "Volume 100%" : level,MUTED,line);
#else
        draw_text(y,20,191,280,0,volume==100 ? "Volume 100%" : level,MUTED,line);
#endif
    } else if (page==RADIO) {
        draw_text(y,20,24,280,2,"Bluetooth",INK,line);
#if BUILD_MINOR >= 26
        char status[48];
        if (audio.configured)
            receiver_label(status,sizeof status,"Connected: ",peer_name,peer);
        else copy_text(status,connecting ? "Connecting..." : radio_error ? "Try pairing mode and scan again" :
                       nearby.phase || scan_pending ? "Looking for headphones..." :
                       scanned && !nearby.count ? "No nearby devices found" :
                       save_pending ? "Saving receiver..." : "Select a receiver",sizeof status);
        draw_text(y,20,49,280,0,status,ACCENT,line);
#else
        const char *status=audio.configured ? "Receiver connected" : radio_error ? "Connection failed" :
                           (peer_set || bond_available==1) ? "Play to connect receiver" :
#if BUILD_MINOR >= 23
                           "Choose receiver on dock";
#else
                           "Choose receiver from the dock";
#endif
        draw_text(y,20,85,280,1,status,INK,line);
        if (audio.configured && audio.key_valid)
            draw_text(y,20,121,280,0,bond_result==1 ? "Receiver saved" : "Play to save receiver",MUTED,line);
#endif
    } else if (page==SETTINGS) {
        draw_text(y,20,24,280,2,"Settings",INK,line);
#if BUILD_MINOR >= 42
        if (library.pod_name[0]) draw_text(y,20,128,280,0,library.pod_name,ACCENT,line);
#endif
        draw_text(y,20,150,280,1,storage_error ? "SD library unavailable" : "SD library ready",INK,line);
        draw_text(y,20,185,280,1,"Firmware",INK,line);
        draw_text(y,218,185,80,1,version,ACCENT,line);
    } else if (page==DOCK) {
        draw_text(y,20,24,280,2,"USB Dock",INK,line);
        #if BUILD_MINOR >= 27
        draw_text(y,20,83,280,1,"SD card on USB",INK,line);
        draw_text(y,20,122,280,0,"Eject the card to resume playback",MUTED,line);
#else
        draw_text(y,20,83,280,1,"Control and firmware updates",INK,line);
#endif
    }
#if BUILD_MINOR >= 23
    if (page==SHELVES)
        album_tiles(y,line);
    else
#endif
    for (unsigned i=0;i<VISIBLE && first+i<count;++i)
        draw_text(y,23,78+27*i,273,1,labels[i],first+i==cursor ? INK : MUTED,line);
    if ((int32_t)(volume_until-now)>0 && page!=PLAYING) {
        char level[]={'V','o','l','u','m','e',' ', '0'+volume/10,'0'+volume%10,'%',0};
        draw_text(y,22,213,280,0,volume==100 ? "Volume 100%" : level,INK,line);
    }

#if BUILD_MINOR >= 43
publish_row:
#endif
#if BUILD_MINOR >= 45
    if (recent_page() && frame_rows==H) {
        const uint8_t *last=framebuffer+y*W*2;
        unsigned i=0;
        while (i<2*W && last[i]==line[i+1] && last[i+1]==line[i]) i+=2;
        if (i==2*W) return;
    }
#endif
#if BUILD_MINOR >= 46
    unsigned left=0,end=W;
    if (recent_page() && frame_rows==H) {
        const uint8_t *last=framebuffer+y*W*2;
        while (left<end && line[2*left]==last[2*left+1] && line[2*left+1]==last[2*left]) ++left;
        while (end>left && line[2*end-2]==last[2*end-1] && line[2*end-1]==last[2*end-2]) --end;
    }
#endif
    for (unsigned x=0;x<W*2;x+=2) {
        uint8_t swap=line[x];
        line[x]=line[x+1];
        line[x+1]=swap;
        framebuffer[(y*W*2)+x]=line[x];
        framebuffer[(y*W*2)+x+1]=swap;
    }
#if BUILD_MINOR >= 46
    if (!recent_page() || !h2_panel_scroll_span(y,left,end,line))
#endif
    h2_panel_row(y,line);
#if BUILD_MINOR >= 46
    if (measuring_scroll && !scroll_feedback) scroll_feedback=OST-scroll_started;
#endif
    if (frame_rows<y+1)
        frame_rows=y+1;
#endif
}

static void paint_next(void)
{
#if BUILD_MINOR >= 63
    unsigned strip=__builtin_ctz(damage);
    damage&=damage-1;
    draw(strip*STRIP);
#else
    draw(visible_y++);
#endif
}

static void choose_frame(unsigned row,uint32_t frame,int start)
{
    if (audio.playing && h2_a2dp_play(&audio,0))
        return;
    if (on_station()) {
#if BUILD_MINOR >= 55
        checkpoint_station();
#else
        station_frame=active_position();
#endif
    } else {
        music_row=track;
        music_frame=active_position();
    }
    if (!set_track(row,frame))
        return;
#if BUILD_MINOR >= 64
    title_since=now;
#endif
    page=PLAYING;
#if BUILD_MINOR >= 55
    audio.selected=0;
    checkpoint_station();
#endif
    if (audio.configured && !h2_a2dp_select_frame(&audio,row,parked_frame) && start)
        h2_a2dp_play(&audio,1);
}

static void choose_track(unsigned row,int start)
{
    choose_frame(row,0,start);
}

static void needle(int forward,int start)
{
    trip_player *p=&library.player;
    trip_view shelf;
    int live_draw=trip_view_by_kind(p,TRIP_SONGS,0,&shelf);
    if (!live_draw && !trip_view_by_kind(p,TRIP_NEEDLE,0,&shelf))
        return;
    unsigned limit=shelf.count<TRIP_NEEDLE_LIMIT ? shelf.count : TRIP_NEEDLE_LIMIT;
    if (!limit)
        return;
    if (drawing) {
        draw_slot=(draw_slot+limit+(forward ? 1 : limit-1))%limit;
    } else {
        draw_seed=OST|1;
        draw_slot=0;
    }
    if (!live_draw || trip_draw(p,draw_seed,draw_slot,0)) {
        drawing=1;
        choose_track(live_draw ? p->index : shelf.first+draw_slot,start);
    }
}

static SMALL_UI void press(enum action key)
{
#if BUILD_MINOR >= 59
    if (wake_after_timeout()) return;
#endif
#if BUILD_MINOR >= 46
    int wheel_step=(key==NEXT || key==PREV) && recent_page() && count && !screen_dark && panel;
    if (wheel_step) scroll_started=OST;
#if BUILD_MINOR >= 47
    unsigned old_cursor=cursor, old_first=first;
#if BUILD_MINOR >= 63
    enum screen old_page=page;
    uint32_t pending_damage=damage;
#elif BUILD_MINOR >= 48
    unsigned pending_row=visible_y;
#endif
#endif
#endif
    if (key==LOUDER || key==QUIETER) {
#if BUILD_MINOR >= 26
        if (key==LOUDER) volume=volume+4<CAP ? volume+4 : CAP;
        else volume=volume>4 ? volume-4 : 0;
#else
        if (key==LOUDER && volume<CAP)
            ++volume;
        else if (key==QUIETER && volume)
            --volume;
#endif
        audio.volume=volume;
        volume_until=now+1600;
    }
#if BUILD_MINOR >= 55
    else if (page==RESTART_RECORDING) {
        if (key==PREV || key==NEXT) {
            cursor^=1;
        } else if (key==SELECT && cursor==1) {
            choose_frame(library.player.count+station_row,0,1);
        } else {
            page=STATIONS;
            cursor=station_cursor;
        }
    }
#endif
    else if (key==MENU) {
#if BUILD_MINOR >= 55
        checkpoint_station();
#endif
        page=HOME;
        cursor=home_cursor;
    } else if (key==BACK) {
#if BUILD_MINOR >= 55
        checkpoint_station();
#endif
        if (page==TRACKS
#if BUILD_MINOR >= 58
            && shelf_kind!=TRIP_SONGS
#endif
        ) {
            page=SHELVES;
            cursor=shelf_cursor;
#if BUILD_MINOR >= 58
        } else if ((page==SHELVES && (shelf_kind==TRIP_ALBUMS || shelf_kind==TRIP_ARTISTS)) ||
                   (page==TRACKS && shelf_kind==TRIP_SONGS)) {
            page=MUSIC;
            cursor=music_cursor;
#endif
        } else {
            page=HOME;
            cursor=home_cursor;
        }
    } else if (key==PREV || key==NEXT) {
        if (page==PLAYING && !storage_error && (library.player.count || library.player.stations)) {
            unsigned rows=library.player.count;
            if (on_station()) {
                unsigned n=library.player.stations;
                unsigned station=(track-rows+n+(key==NEXT ? 1 : n-1))%n;
                choose_frame(rows+station,active_position(),audio.playing);
            } else if (drawing) {
                needle(key==NEXT,audio.playing);
            } else {
                unsigned row=(track+rows+(key==NEXT ? 1 : rows-1))%rows;
                choose_track(row,audio.playing);
            }
        } else if (count) {
            cursor=(cursor+count+(key==NEXT ? 1 : count-1))%count;
        }
    } else if (page==HOME) {
        home_cursor=cursor;
        if (!HOME_ACTION(cursor) && !storage_error && library.player.count) {
            if (on_station())
                choose_frame(music_row,music_frame,audio.playing);
            else
                page=PLAYING;
        } else if (HOME_ACTION(cursor)==1 && !storage_error) {
            drawing=0;
            needle(1,1);
#if BUILD_MINOR >= 58
        } else if (HOME_ACTION(cursor)==3) {
            page=MUSIC; cursor=0;
        } else if (HOME_ACTION(cursor)==8 || HOME_ACTION(cursor)==9) {
            page=SHELVES;
            shelf_kind=HOME_ACTION(cursor)==8 ? TRIP_WAREZ : TRIP_PLAYLISTS;
            cursor=0;
#endif
        } else if (HOME_ACTION(cursor)==2 || HOME_ACTION(cursor)==3) {
            page=SHELVES;
            shelf_kind=HOME_ACTION(cursor)==2 ? TRIP_RECENT : TRIP_ALBUMS;
            cursor=0;
        } else if (HOME_ACTION(cursor)==4) {
            page=STATIONS;
#if BUILD_MINOR >= 55
            cursor=on_station() ? track-library.player.count : station_row;
#else
            cursor=0;
#endif
        } else if (HOME_ACTION(cursor)==5) {
            page=RADIO;
#if BUILD_MINOR >= 26
            cursor=0;
#endif
        } else if (HOME_ACTION(cursor)==6) {
            page=SETTINGS;
            cursor=0;
        } else if (HOME_ACTION(cursor)==7)
            page=DOCK;
#if BUILD_MINOR >= 58
    } else if (page==MUSIC && count) {
        music_cursor=cursor;
        shelf_kind=music_kinds[cursor];
        cursor=0;
        if (shelf_kind==TRIP_SONGS) {
            view=(trip_view){0};
            trip_view_by_kind(&library.player,TRIP_SONGS,0,&view);
            page=TRACKS;
        } else page=SHELVES;
#endif
    } else if (page==SHELVES && count) {
        if (trip_view_by_kind(&library.player,shelf_kind,cursor,&view)) {
            shelf_cursor=cursor;
            page=TRACKS;
            cursor=0;
        }
    } else if (page==TRACKS && count) {
        drawing=0;
        choose_track(view.first+cursor,1);
    } else if (page==STATIONS && count) {
#if BUILD_MINOR >= 55
        if (cursor==library.player.stations) {
            station_cursor=cursor;
            page=RESTART_RECORDING;
            cursor=0;
        } else
#endif
        choose_frame(library.player.count+cursor,on_station() ? active_position() : station_frame,1);
    } else if (page==PLAYING && audio.configured) {
        if (audio.selected==track+1 || !h2_a2dp_select_frame(&audio,track,parked_frame))
            h2_a2dp_play(&audio,!audio.playing);
#if BUILD_MINOR >= 55
        if (!audio.playing) checkpoint_station();
#endif
    } else if (page==RADIO) {
#if BUILD_MINOR >= 26
#if BUILD_MINOR >= 55
        if (radio_busy
#if BUILD_MINOR >= 56
            || connecting
#endif
        ) {
            radio_cancel=1;
            auto_enabled=0;
#if BUILD_MINOR >= 56
            if (!radio_busy) connect_pending=connecting=0;
#endif
        } else
#endif
        select_receiver(cursor);
#else
        if (audio.configured && audio.key_valid && !audio.playing)
            save_pending=1;
        else if (bond_available==1)
            start_saved();
        else if (peer_set && !audio.configured)
            connect_pending=1;
#endif
    } else if (page==SETTINGS) {
        if (!cursor)
            #if BUILD_MINOR >= 43
            alternate_home=(alternate_home+1)%4;
#else
            alternate_home^=1;
#endif
        else if (!audio.playing)
            mount_library();
    }
#if BUILD_MINOR >= 64
    if (page!=old_page || cursor!=old_cursor)
        title_since=now;
#endif
#if BUILD_MINOR >= 63
    if (key==LOUDER || key==QUIETER) {
        if (recent_page()) repaint(0,24);
        else repaint(218,H);
        return;
    }
    if ((key==PREV || key==NEXT) && page==old_page && page!=PLAYING && !recent_page() && count) {
        if (page==RESTART_RECORDING) repaint(119,184);
        else {
            unsigned height=browse_list() ? BROWSE_ROW : LIST_ROW;
            unsigned top=browse_list() ? BROWSE_TOP : LIST_TOP;
            unsigned shown=browse_list() ? BROWSE_COUNT : VISIBLE;
            if (cursor<first || cursor>=first+shown) {
                refresh_labels();
                repaint(top,top+height*shown);
            } else if (cursor!=old_cursor) {
                repaint(top+(old_cursor-first)*height,top+(old_cursor-first+1)*height);
                repaint(top+(cursor-first)*height,top+(cursor-first+1)*height);
            }
        }
        return;
    }
#endif
    refresh();
#if BUILD_MINOR >= 46
    if (wheel_step) {
        scroll_feedback=scroll_row=0;
#if BUILD_MINOR >= 50
        scroll_transfer_ticks=0;
#endif
        scroll_top=24+(cursor-first)*24;
#if BUILD_MINOR >= 47
        scroll_commit(scroll_top,24);
        scroll_row=scroll_feedback=OST-scroll_started;
        if (old_first!=first) {
#if BUILD_MINOR >= 48
            for (unsigned top=24;top<H;top+=24)
                if (top!=scroll_top) scroll_commit(top,24);
#else
            if (scroll_top>24) scroll_commit(24,scroll_top-24);
            if (scroll_top+24<H) scroll_commit(scroll_top+24,H-scroll_top-24);
#endif
        } else if (old_cursor!=cursor) scroll_commit(24+(old_cursor-first)*24,24);
        scroll_viewport=OST-scroll_started;
#if BUILD_MINOR >= 63
        damage=pending_damage;
#elif BUILD_MINOR >= 48
        visible_y=pending_row;
#else
        visible_y=H;
#endif
#else
        measuring_scroll=1;
        for (unsigned y=scroll_top;y<scroll_top+24;++y) draw(y);
        scroll_row=OST-scroll_started;
        measuring_scroll=0;
#endif
        ++scroll_sequence;
    }
#endif
}

#if BUILD_MINOR >= 24
static void turn_wheel(int direction)
{
#if BUILD_MINOR == 24
    if (page==PLAYING || (screen_dark && audio.playing))
        press(direction>0 ? LOUDER : QUIETER);
    else
        press(direction>0 ? NEXT : PREV);
#else
    press(direction>0 ? NEXT : PREV);
#endif
}
#endif

void h2_player_begin(void)
{
    clock_status=h2_player_clock();
    last_tick=OST;
    h2_input_begin(&keys);
#if BUILD_MINOR >= 26
#if BUILD_MINOR < 55
    reload_bonds();
#endif
    auto_enabled=1;
    retry_at=5000;
#else
    bond_available=h2_bond_load(&saved_bond);
#endif
#if BUILD_MINOR < 63
    if (BUILD_MINOR<43) {
        wallpaper_ready=h2_decode_art(h2_art,h2_art_end-h2_art,wallpaper,2*W*H);
        dock_art_ready=h2_decode_art(h2_dock_art,h2_dock_art_end-h2_dock_art,dock_art,2*W*H);
    }
#endif
#if BUILD_MINOR >= 55 && BUILD_MINOR < 59
    h2_decode_art(shop_packed,shop_packed_end-shop_packed,(uint8_t *)shop_banners,sizeof shop_banners);
#endif
#if BUILD_MINOR >= 55
    storage_error=0x101;
    mount_pending=1;
#else
    mount_library();
    mount_attempts=1;
#endif
    refresh();
}

static void connect_receiver(void)
{
#if BUILD_MINOR >= 41
    uint32_t *radio=radio_probe_status, *link=radio_link_status;
    for (unsigned i=0;i<9;++i)
        ((volatile uint32_t *)radio)[i]=0;
#else
    uint32_t radio[9], link[8];
#endif
    for (unsigned i=0;i<8;++i)
        ((volatile uint32_t *)link)[i]=0;
    h2_hci_probe(radio,4,1);
    radio_error=radio[0];
    if (!radio_error) {
        h2_hci_link(peer,link,1);
        radio_error=link[0];
        if (!radio_error && link[3]) {
            unsigned different=0;
            for (unsigned i=0;i<sizeof peer;++i)
                different|=saved_bond.peer[i]^peer[i];
            parked_frame=active_position();
            h2_avdtp_setup_paired(&audio,link[3],peer,
                                  bond_available==1 && !different
#if BUILD_MINOR >= 26
                                  && !skip_key
#endif
                                  ? saved_bond.key : 0,radio_status);
            radio_error=radio_status[0];
            audio.volume=volume;
        }
    }
    refresh();
}

#if BUILD_MINOR >= 26
void h2_player_usb_staging(void)
{
    retry_at=now+30000;
}
#endif

#if BUILD_MINOR >= 27
static unsigned card_host_owned;
int h2_card_busy(void) { return card_host_owned; }
int h2_card_claim(void)
{
    if (card_host_owned) return 1;
    if (frame_rows!=H || audio.playing) return 0;
#if BUILD_MINOR >= 55
#if BUILD_MINOR >= 57
    if (radio_busy) radio_cancel=1;
#endif
    if (mount_pending || radio_busy) return 0;
    checkpoint_station();
#if BUILD_MINOR == 55
    waiting_to_undock=1;
#endif
#endif
#ifdef H2_ORIGINAL_AUDIO
    h2_original_close();
#endif
#if BUILD_MINOR >= 62
    if (!h2_sd_export_speed()) return 0;
#endif
#if BUILD_MINOR >= 59
    wake_after_timeout();
#endif
    card_host_owned=1;
    page=DOCK; cursor=0; refresh();
    return 1;
}
void h2_card_release(void)
{
    if (!card_host_owned) return;
    card_host_owned=0;
#if BUILD_MINOR >= 59
    last_input=now;
#endif
    mount_library();
#if BUILD_MINOR >= 56
    auto_enabled=1;
    next_saved=0;
    /* Give a USB updater time to begin staging after a safe eject. */
    retry_at=now+1250;
#endif
    page=HOME; cursor=0; refresh();
}
#endif

#if BUILD_MINOR >= 55
static void update_time(void)
{
    uint32_t elapsed=OST-last_tick;
    now+=elapsed/6000;
    last_tick+=elapsed-elapsed%6000;
}

static void interface_tick(void);

int h2_player_radio_yield(void)
{
    if (!radio_busy) return 0;
    if (OST-last_tick>=6000) {
        update_time();
#if BUILD_MINOR >= 57
        h2_usb_poll_radio();
        if (radio_deadline && (int32_t)(now-radio_deadline)>=0)
            radio_cancel=1;
#endif
        interface_tick();
    }
    return radio_cancel;
}
#endif

void h2_player_tick(void)
{
#if BUILD_MINOR >= 55
    update_time();
#else
    uint32_t elapsed=OST-last_tick;
    now+=elapsed/6000;
    last_tick+=elapsed-elapsed%6000;
#endif
#if BUILD_MINOR >= 52
    if (panel && (int32_t)(now-battery_due)>=0) {
        uint8_t level;
        int value=h2_pmic_read(0xa4,&level) && level<=100 ? level : -1;
        battery_due=now+15000;
        if (value!=battery_percent) {
            battery_percent=value;
#if BUILD_MINOR >= 63
            repaint(0,18);
#else
            visible_y=0;
#endif
        }
    }
#endif
#if BUILD_MINOR >= 27
    if (card_host_owned) {
        if (!(*(volatile uint32_t *)0xb0010300u & (1u<<3))) h2_card_release();
        else {
            if (!paint_idle()) paint_next();
            return;
        }
    }
#endif
#if BUILD_MINOR >= 55
#if BUILD_MINOR == 55
    if (waiting_to_undock && !(*(volatile uint32_t *)0xb0010300u & (1u<<3))) {
        waiting_to_undock=0;
        auto_enabled=1;
        next_saved=0;
        retry_at=now+250;
    }
#endif
    if (poweroff_pending) {
        poweroff_pending=0;
        audio.volume=volume=0;
        if (audio.playing) h2_a2dp_play(&audio,0);
        checkpoint_station();
        h2_hci_stop();
        audio.configured=audio.playing=0;
        if (panel) h2_panel_blank();
        if (!h2_pmic_poweroff() && panel) h2_panel_light();
    }
    if (mount_pending && frame_rows==H) {
        uint32_t start=OST;
        mount_pending=0;
        mount_attempts=1;
        mount_library();
        mount_ticks=OST-start;
        reload_bonds();
        retry_at=now+1500;
        refresh();
    }
#endif
    if (restart_pending && now-restart_pending>=50) {
#if BUILD_MINOR >= 55
        checkpoint_station();
#endif
        h2_hci_stop();
        TCU(0x3c)=1u<<16;
        TCU(0x0c)=0x0c;
        TCU(0x08)=0;
        TCU(0x00)=60000;
        TCU(0x04)=1;
        for (;;) {}
    }
    if (storage_error && mount_attempts && mount_attempts<3 && now-last_mount>=250) {
        ++mount_attempts;
        last_mount=now;
        mount_library();
        refresh();
    }
#if BUILD_MINOR >= 26
    receiver_tick();
#endif
    if (connect_pending
#if BUILD_MINOR >= 26
        && (page!=RADIO || screen_dark || paint_idle())
#endif
    ) {
        connect_pending=0;
#if BUILD_MINOR >= 55
        radio_cancel=0;
        radio_busy=1;
#if BUILD_MINOR >= 57
        radio_deadline=automatic_receiver ? now+10000 : 0;
        automatic_receiver=0;
#endif
#endif
        connect_receiver();
#if BUILD_MINOR >= 55
        radio_busy=0;
#if BUILD_MINOR >= 57
        radio_deadline=0;
#endif
        if (radio_cancel || !audio.configured) {
            h2_hci_stop();
            if (radio_cancel) audio.configured=0;
        }
#endif
#if BUILD_MINOR >= 26
        connecting=0;
        if (audio.configured && audio.key_valid) {
            save_pending=1;
            next_saved=0;
        } else if (replace_key && radio_error==0x10 && bond_available==1 &&
                   same_receiver(saved_bond.peer,peer)) {
            /* An explicitly rediscovered headset may have forgotten our old key. */
            skip_key=1;
            replace_key=0;
            connecting=connect_pending=1;
        }
#if BUILD_MINOR >= 55
        retry_at=now+3000;
#else
        retry_at=now+30000;
#endif
        refresh();
#endif
    }
    if (save_pending) {
        h2_bond candidate;
#if BUILD_MINOR >= 26
        for (unsigned i=0;i<sizeof candidate.name;++i) candidate.name[i]=0;
        copy_text(candidate.name,peer_name,sizeof candidate.name);
#endif
        save_pending=0;
        for (unsigned i=0;i<sizeof candidate.peer;++i)
            candidate.peer[i]=peer[i];
        for (unsigned i=0;i<sizeof candidate.key;++i)
            candidate.key[i]=audio.key[i];
        bond_result=h2_bond_save(&candidate);
        if (bond_result) {
            saved_bond=candidate;
            bond_available=1;
        }
#if BUILD_MINOR >= 26
        reload_bonds();
#endif
        refresh();
    }
    unsigned was_playing=audio.playing;
#if BUILD_MINOR >= 26
    unsigned was_connected=audio.configured;
#endif
    h2_a2dp_tick(&audio);
#if BUILD_MINOR >= 55
    if ((was_playing && !audio.playing) ||
        (audio.playing && (int32_t)(now-next_checkpoint)>=0))
        checkpoint_station();
#endif
#if BUILD_MINOR >= 26
    if (was_connected && !audio.configured) {
        release_receiver();
        next_saved=0;
        retry_at=now+2500;
        refresh();
    }
#endif
    if (was_playing && !audio.playing
#if BUILD_MINOR >= 26
        && audio.configured
#endif
        && drawing && !on_station() && !audio.stream_error)
        needle(1,1);
#if BUILD_MINOR >= 55
    interface_tick();
}

static void interface_tick(void)
{
#endif
    h2_input_event event=h2_input_poll(&keys,now);
    for (unsigned i=0;i<8;++i)
        if (event.pressed&(1u<<i)) ++key_counts[i];
    wheel_forward+=event.wheel>0;
    wheel_back+=event.wheel<0;
#if BUILD_MINOR >= 59
    if (((event.pressed & ~H2_POWER) || event.wheel) && wake_after_timeout()) {
        event.pressed &= H2_POWER;
        event.wheel=0;
    }
#endif
#if BUILD_MINOR >= 24
    if (event.wheel)
        turn_wheel(event.wheel);
    if (event.pressed&(H2_PREVIOUS|H2_NEXT))
        press(event.pressed&H2_NEXT ? NEXT : PREV);
#else
    if (event.wheel || event.pressed&(H2_PREVIOUS|H2_NEXT))
        press(event.wheel>0 || event.pressed&H2_NEXT ? NEXT : PREV);
#endif
    if (event.pressed&H2_PLAY) press(SELECT);
    if (event.pressed&H2_BACK) press(BACK);
    if (event.pressed&H2_MENU) press(MENU);
    if (event.pressed&H2_VOLUME_UP) press(LOUDER);
    if (event.pressed&H2_VOLUME_DOWN) press(QUIETER);
    if (event.pressed&H2_POWER)
        power_pressed=now;
    if (event.released&H2_POWER) {
        if (now-power_pressed>=1100) {
#if BUILD_MINOR >= 55
            radio_cancel=poweroff_pending=1;
#else
            audio.volume=volume=0;
            if (audio.playing)
                h2_a2dp_play(&audio,0);
            h2_hci_stop();
            audio.configured=audio.playing=0;
            if (panel)
                h2_panel_blank();
            if (!h2_pmic_poweroff() && panel)
                h2_panel_light();
#endif
        } else if (frame_rows==H) {
#if BUILD_MINOR >= 59
            screen_timed_out=0;
            last_input=now;
#endif
            screen_dark^=1;
            if (screen_dark)
                h2_panel_blank();
            else
                h2_panel_light();
        }
    }
#if BUILD_MINOR >= 59
    if (panel && frame_rows==H && !screen_dark && !power_pressed && now-last_input>=30000) {
        screen_dark=screen_timed_out=1;
        h2_panel_blank();
    }
    if (event.released&H2_POWER)
        power_pressed=0;
#endif
#if BUILD_MINOR >= 23
#if BUILD_MINOR >= 45
    if (recent_page()) recent_load_thumbnail();
    else
#endif
    load_tile_chunk();
    if (paint_idle() && now-last_render>110 &&
        (page==PLAYING ||
#if BUILD_MINOR >= 63
         (page==TRACKS && ui_text_width(1,view.title)>300) ||
         (browse_list() && count && ui_text_width(1,labels[cursor-first])>
             (recent_page() ? 281 : page==SHELVES ? 278 : 301))
#else
         (page==SHELVES && count && ui_text_width(1,labels[cursor-first])>W-32)
#endif
        )) {
#else
    if (page==PLAYING && visible_y==H && now-last_render>110) {
#endif
#if BUILD_MINOR >= 63
        if (page==PLAYING) {
            repaint(125,173);
            repaint(207,H);
        } else if (recent_page()) {
            unsigned top=24+(cursor-first)*24;
            repaint(top,top+24);
        } else {
            if (page==TRACKS) repaint(18,BROWSE_TOP);
            if (count) {
                unsigned top=BROWSE_TOP+(cursor-first)*BROWSE_ROW;
                repaint(top,top+BROWSE_ROW);
            }
        }
#else
        visible_y=0;
#endif
        last_render=now;
    }
    if (volume_until && (int32_t)(now-volume_until)>=0) {
        volume_until=0;
#if BUILD_MINOR >= 63
        if (recent_page()) repaint(0,24);
        else repaint(218,H);
#else
        visible_y=0;
#endif
    }
    if (!panel && now>=PANEL_SETTLE_MS)
        panel=h2_panel_step(&panel_startup);
    if (panel && !screen_dark && !paint_idle()) {
        bool first_frame=frame_rows<H;
        paint_next();
        if (first_frame && frame_rows==H) {
#if BUILD_MINOR >= 55
            first_frame_at=now;
#endif
            last_render=now;
            h2_panel_light();
        }
    }
#ifdef H2_BOOT_GUARD
    static unsigned reported;
    if (!reported && frame_rows==H)
        reported=h2_health_confirm();
#endif
}

SMALL_UI int h2_player_usb(unsigned request,unsigned value,unsigned index,unsigned length,uint8_t *out)
{
#ifdef H2_ORIGINAL_AUDIO
    if (request==0xbdc0 && !value && !index && length==24) {
        uint32_t report[6];
        h2_original_status(report);
        for (unsigned i=0;i<6;++i) put32(out+4*i,report[i]);
        return 1;
    }
#endif
#if BUILD_MINOR >= 59
    if (request==0xbec0 && !value && !index && length==8) {
        put32(out,screen_dark); put32(out+4,screen_timed_out);
        return 1;
    }
#endif
#if BUILD_MINOR >= 57
    if (radio_busy && !(request&0x80) && request!=0x5040) return 0;
#endif
#if BUILD_MINOR >= 55
    if (request==0xacc0 && !value && !index && length==24) {
        put32(out,first_frame_at); put32(out+4,mount_ticks/6000);
        put32(out+8,station_row); put32(out+12,station_frame);
        put32(out+16,bookmark_sequence); put32(out+20,bookmark_ready);
        return 1;
    }
#endif
#if BUILD_MINOR >= 41
    if (request==0xbbc0 && !index && ((value==0 && length==36) || (value==1 && length==32))) {
        const uint32_t *report=value ? radio_link_status : radio_probe_status;
        for (unsigned i=0;i<length/4;++i)
            put32(out+i*4,report[i]);
        return 1;
    }
#endif
#if BUILD_MINOR >= 35
    if (request==0xb9c0 && !value && !index && length==32) {
        uint32_t timing[8];
        h2_sd_write_timing(timing);
        for (unsigned i=0;i<8;++i)
            put32(out+i*4,timing[i]);
        return 1;
    }
#endif
#if BUILD_MINOR >= 30
    if (request==0xb8c0 && !value && !index && length==32) {
        uint32_t report[8];
        h2_sd_write_report(report);
        for (unsigned i=0;i<8;++i)
            put32(out+i*4,report[i]);
        return 1;
    }
#endif
#if BUILD_MINOR >= 27
    if (card_host_owned && request!=0x51c0 && request!=0x52c0 && request!=0x53c0) return 0;
#endif
#if BUILD_MINOR >= 46
#if BUILD_MINOR >= 47
#if BUILD_MINOR >= 50
    if (request==0xa9c0 && !index && !value && length==4) {put32(out,scroll_transfer_ticks);return 1;}
#endif
    if (request==0xa8c0 && !value && !index && length==4) {
        put32(out,scroll_viewport);return 1;
    }
#endif
    if (request==0xa7c0 && !value && !index && length==16) {
        put32(out,scroll_sequence); put32(out+4,scroll_feedback);
        put32(out+8,scroll_row); put32(out+12,h2_panel_scroll_faults());
        return 1;
    }
#endif
    if (request==0x5040 && !index && !length && value<=QUIETER) {
        press(value);
        return 1;
    }
    if (request==0x51c0 && !value && !index && length==64) {
        put32(out,page); put32(out+4,cursor); put32(out+8,storage_error ? 0 : library.player.count);
        put32(out+12,storage_error); put32(out+16,volume); put32(out+20,audio.playing);
        put32(out+24,active_position());
        put32(out+28,audio.configured);
        const char *label=page==PLAYING ? library.player.title : count ? labels[cursor-first] : "";
        copy_text((char *)out+32,label,32);
        return 1;
    }
    if (request==0x52c0 && value<frame_rows && index<10 && length==64) {
        const uint8_t *pixels=framebuffer+value*W*2+index*64;
        for (unsigned i=0;i<64;++i)
            out[i]=pixels[i];
        return 1;
    }
    if (request==0x53c0 && !value && !index && length==48) {
        for (unsigned i=0;i<8;++i)
            put32(out+4*i,key_counts[i]);
        put32(out+32,wheel_forward); put32(out+36,wheel_back);
        put32(out+40,frame_rows); put32(out+44,now);
        return 1;
    }
    if (request==0x88c0 && !value && !index && length==16) {
        put32(out,clock_status); put32(out+4,CPM(0));
        put32(out+8,CPM(0x10)); put32(out+12,CPM(0x14));
        return 1;
    }
#if BUILD_MINOR >= 26
    if (request==0xa0c0 && !index && !value && length==32) {
        put32(out,scan_pending || nearby.phase); put32(out+4,nearby.count);
        put32(out+8,saved_count); put32(out+12,radio_error);
        put32(out+16,connecting); put32(out+20,bond_result);
        put32(out+24,radio_status[1]); put32(out+28,cover_ready);
        return 1;
    }
#endif
    if (request==0x99c0 && !value && !index && length==16) {
        put32(out,bond_available); put32(out+4,bond_result);
        put32(out+8,audio.key_valid); put32(out+12,radio_error);
        return 1;
    }
    if (request==0x9940 && !value && !index && !length && audio.configured &&
            audio.key_valid && !audio.playing) {
        save_pending=1;
        return 1;
    }
    if (request==0x9a40 && !value && !index && !length && bond_available==1 && !audio.configured) {
#if BUILD_MINOR >= 26
        if (!saved_count) return 0;
        release_receiver();
        queue_receiver(bonds[0].peer,bonds[0].name,0);
#else
        start_saved();
#endif
        return 1;
    }
    if (request==0x9b40 && !value && index==0x5732 && !length && !audio.playing && !volume) {
        restart_pending=now ? now : 1;
        return 1;
    }
    if (request==0x9c40 && !length && audio.configured && audio.selected) {
        unsigned offset=value|((uint32_t)index<<16);
#if BUILD_MINOR >= 55
        if (on_station() && !offset) return 0;
#endif
        if (offset>=audio.library.player.frames/48)
            return 0;
        choose_frame(track,offset*48,audio.playing);
        return 1;
    }
    if (request==0x9dc0 && !index && length==64 && !storage_error &&
            value<library.player.count+library.player.stations) {
        trip_player item=library.player;
        if (!trip_select(&item,value,0))
            return 0;
        copy_text((char *)out,item.title,32);
        copy_text((char *)out+32,item.artist,32);
        return 1;
    }
#ifdef H2_PCM_TAP
    if (request==0x9e40 && !index && !length && audio.selected && !audio.playing) {
        const trip_player *p=&audio.library.player;
        return value<=p->frames-p->position &&
               h2_pcm_tap_arm(&audio.tap,value,p->position,audio.volume);
    }
    if (request==0x9ec0 && !value && !index && length==20) {
        put32(out,audio.tap.limit); put32(out+4,audio.tap.count);
        put32(out+8,audio.tap.position); put32(out+12,audio.tap.volume);
        put32(out+16,audio.selected);
        return 1;
    }
    if (request==0x9fc0 && !index && !audio.playing)
        return h2_pcm_tap_read(&audio.tap,value,length,out);
#endif
    if (request==0x7e40 && !length && !audio.configured) {
#if BUILD_MINOR >= 26
        release_receiver();
        auto_enabled=0;
        peer_name[0]=0;
#endif
        peer[0]=value; peer[1]=value>>8; peer[2]=index; peer[3]=index>>8;
        peer_set=1;
        return 1;
    }
    if (request==0x7f40 && !length && !index && peer_set && !audio.configured) {
        peer[4]=value; peer[5]=value>>8;
#if BUILD_MINOR >= 26
        for (unsigned i=0;i<saved_count;++i)
            if (same_receiver(peer,bonds[i].peer)) {
                saved_bond=bonds[i];
                copy_text(peer_name,bonds[i].name,sizeof peer_name);
                break;
            }
        auto_enabled=1;
        replace_key=skip_key=0;
#endif
        connect_pending=1;
        return 1;
    }
    if (request==0x82c0 && !index && !value && length==64 && audio.configured) {
        for (unsigned i=0;i<16;++i)
            put32(out+4*i,radio_status[i]);
        return 1;
    }
    if (request==0x8340 && !index && !length && audio.configured &&
            !audio.playing && !storage_error && value<library.player.count) {
        choose_track(value,0);
        drawing=0;
        refresh();
        return 1;
    }
    if (request==0x8440 && !index && !length && value<=1 && audio.configured && audio.selected) {
        audio.stream_error=h2_a2dp_play(&audio,value);
#if BUILD_MINOR >= 55
        if (!audio.playing) checkpoint_station();
#endif
        return 1;
    }
    if (request==0x85c0 && !index && !value && length==64 && audio.configured) {
        uint32_t status[16]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
        h2_a2dp_status(&audio,status);
        for (unsigned i=0;i<16;++i)
            put32(out+4*i,status[i]);
        return 1;
    }
    if (request==0x8640 && !index && !length && value<=CAP) {
        audio.volume=volume=value;
        return 1;
    }
    return 0;
}
