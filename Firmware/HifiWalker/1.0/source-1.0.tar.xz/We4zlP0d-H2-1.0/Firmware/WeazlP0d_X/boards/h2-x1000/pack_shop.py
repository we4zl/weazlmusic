"""Pack each 320x100 approved banner as an indexed 256x80 RGB565 illustration."""
from pathlib import Path
import struct
import sys
from ctypes import CDLL, create_string_buffer
from PIL import Image

source, work = map(Path, sys.argv[1:3])
packed = bytearray()
for scene in ("counter", "bins", "booth", "bench"):
    with Image.open(source / f"shop-{scene}.webp") as image:
        if image.size != (320, 100):
            raise ValueError(f"Unexpected dimensions for {scene}")
        picture = image.convert("RGB").resize((256, 80), Image.Resampling.LANCZOS)
    shade = Image.new("L", picture.size)
    shade.putdata([min(235, max(0, (165-x)*2)) for y in range(80) for x in range(256)])
    picture.paste((22, 12, 16), mask=shade)
    indexed = picture.quantize(colors=256)
    palette = bytes(indexed.getpalette()).ljust(768, b"\0")
    for r,g,b in zip(palette[::3],palette[1::3],palette[2::3]):
        packed.extend(struct.pack("<H", (r>>3)<<11 | (g>>2)<<5 | (b>>3)))
    packed.extend(indexed.tobytes())
path = work / "shop.bin"
if sys.argv[3:] == ["--compress"]:
    lz4 = CDLL("liblz4.so.1")
    output = create_string_buffer(lz4.LZ4_compressBound(len(packed)))
    size = lz4.LZ4_compress_HC(bytes(packed), output, len(packed), len(output), 12)
    if not 0 < size < len(packed):
        raise SystemExit("Could not compress the record shop banners")
    path.write_bytes(output.raw[:size])
    (work / "wallpaper.S").write_text(
        '.section .rodata.shop,"a",@progbits\n.balign 4\n.globl shop_packed,shop_packed_end\n'
        f'shop_packed:\n.incbin "{path}"\nshop_packed_end:\n')
    sys.exit(0)
path.write_bytes(packed)
(work / "wallpaper.S").write_text(
    '.section .rodata.shop,"a",@progbits\n.balign 4\n.globl shop_banners\n'
    f'shop_banners:\n.incbin "{path}"\n')
