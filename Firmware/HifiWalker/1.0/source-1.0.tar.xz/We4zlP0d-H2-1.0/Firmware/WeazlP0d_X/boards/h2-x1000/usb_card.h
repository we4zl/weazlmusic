/* USB Bulk-Only Transport. Interface 0 retains the X controls. */
#include "sd_write.h"

int h2_sd_read(void *,uint32_t,uint8_t *);
int h2_card_busy(void);
int h2_card_claim(void);
void h2_card_release(void);
enum { CBW, DATA_IN, DATA_OUT, STATUS_IN, BAD_CBW };
static unsigned bot_phase,tag,residue,failed,lba,blocks,at,reply_size,sector_read,ejected;
static unsigned sense,asc,high_speed_capable;
static unsigned packet_size=64;
#if BUILD_MINOR == 37
static unsigned ram_sink,ram_digest=2166136261u,ram_bytes;
#endif
/* A 120 KiB batch matches the typical Linux usb-storage WRITE(10). */
#if defined(H2_WRITE_PIPELINE)
/* Split the host's usual 120 KiB WRITE(10) into two alternating buffers. */
static uint32_t write_bank[2][120*128];
static unsigned write_bank_index,write_dma_busy,out_complete;
#define write_words (write_bank[write_bank_index])
#define write_buffer ((const uint8_t *)write_words)
#define WRITE_BUFFER_SIZE sizeof write_bank[0]
static unsigned out_batch;
#elif BUILD_MINOR >= 34
static uint32_t write_words[512 * H2_SD_WRITE_MAX_SECTORS / sizeof(uint32_t)];
#define write_buffer ((const uint8_t *)write_words)
#define WRITE_BUFFER_SIZE sizeof write_words
static unsigned out_batch;
#else
static uint8_t write_buffer[512 * (BUILD_MINOR >= 28 ? H2_SD_WRITE_MAX_SECTORS : 1)];
#define WRITE_BUFFER_SIZE sizeof write_buffer
#endif
#if BUILD_MINOR >= 36
static unsigned read_bytes;
#else
static uint8_t sector[512];
#endif
static uint8_t reply[64];
#define IN1(off) REG(0x920+(off))
#define OUT1(off) REG(0xb20+(off))
static unsigned little(const uint8_t *p)
{
    return p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);
}
static unsigned big(const uint8_t *p)
{
    return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((unsigned)p[2]<<8)|p[3];
}
static void be(uint8_t *p,uint32_t v)
{
    for (unsigned i=0;i<4;++i) p[i]=v>>(24-8*i);
}
#if BUILD_MINOR >= 51
#include "receipt_digest.h"
#endif
static void bulk_arm(void)
{
#if defined(H2_WRITE_PIPELINE)
    out_complete=0;
#endif
#if BUILD_MINOR >= 34
    unsigned bytes=packet_size;
    if (bot_phase==DATA_OUT) {
        bytes=WRITE_BUFFER_SIZE-at;
        if (bytes>residue) bytes=residue;
        if (bytes>128*packet_size) bytes=128*packet_size;
    }
    out_batch=bytes;
    OUT1(0x10)=((bytes+packet_size-1)/packet_size<<19)|bytes;
#else
    OUT1(0x10)=(1u<<19)|packet_size;
#endif
    OUT1(0)|=(1u<<31)|(1u<<26);
}
static void bulk_send(const uint8_t *p,unsigned n)
{
    IN1(0x10)=(1u<<19)|n;
    IN1(0)|=(1u<<31)|(1u<<26);
    for (unsigned i=0;i<n;i+=4) {
        uint32_t v=0;
        for (unsigned k=0;k<4 && i+k<n;++k) v|=(uint32_t)p[i+k]<<(k*8);
        REG(0x2000)=v;
    }
}
#if defined(H2_WRITE_PIPELINE)
static void bulk_abort_write(void)
{
    if (write_dma_busy)
        while (!h2_sd_poll_write()) {}
    write_dma_busy=0;
    write_bank_index=out_complete=0;
}
#endif
static void bulk_init(void)
{
#if defined(H2_WRITE_PIPELINE)
    bulk_abort_write();
#endif
    bot_phase=CBW;
    IN1(0)=(1u<<28)|(1u<<22)|(2u<<18)|(1u<<15)|packet_size;
    OUT1(0)=(1u<<28)|(2u<<18)|(1u<<15)|packet_size;
    IN1(8)=OUT1(8)=0xffff;
    bulk_arm();
}
static void csw(void)
{
    uint8_t p[13]={'U','S','B','S'};
    for (unsigned i=0;i<4;++i) { p[4+i]=tag>>(8*i); p[8+i]=residue>>(8*i); }
    p[12]=failed;
    bot_phase=STATUS_IN;
    bulk_send(p,13);
}
static void fail(unsigned key,unsigned code)
{
    failed=1; sense=key; asc=code;
}
#if defined(H2_WRITE_PIPELINE)
static void bulk_drain_write(unsigned out_interrupt)
{
    if (bot_phase!=DATA_OUT) return;
    if (out_interrupt&1) out_complete=1;
    if (write_dma_busy) {
        int result=h2_sd_poll_write();
        if (result<0) fail(3,0x0c);
        if (result) write_dma_busy=0;
    }
    if (at && (at==WRITE_BUFFER_SIZE || !residue)) {
        if (write_dma_busy) return;
        if (at&511) fail(5,0x24);
        if (!failed) {
            write_dma_busy=h2_sd_begin_write(lba,write_buffer,at/512);
            if (!write_dma_busy) fail(3,0x0c);
        }
        lba+=at/512;
        at=0;
        write_bank_index^=1u;
    }
    if (!residue && !write_dma_busy) csw();
    else if (residue && !out_batch && out_complete) bulk_arm();
}
#endif
static void bulk_next(void)
{
    if (bot_phase==STATUS_IN) { bot_phase=CBW; bulk_arm(); return; }
    if (bot_phase!=DATA_IN) return;
#if BUILD_MINOR >= 36
    if (sector_read && (blocks || at) && residue) {
#else
    if (sector_read && blocks && residue) {
#endif
#if BUILD_MINOR >= 36
        if (!at) {
            unsigned count=blocks>32 ? 32 : blocks;
            if (!h2_sd_read_blocks(lba,write_words,count)) {
                fail(3,0x11); blocks=0; bulk_send(0,0); return;
            }
            read_bytes=count*512;
            blocks-=count;
            lba+=count;
        }
        bulk_send(write_buffer+at,packet_size); residue-=packet_size; at+=packet_size;
        if (at==read_bytes) at=0;
#else
        if (!at && !h2_sd_read(0,lba,sector)) {
            fail(3,0x11); blocks=0; bulk_send(0,0); return;
        }
        bulk_send(sector+at,packet_size); residue-=packet_size; at+=packet_size;
        if (at==512) { at=0; ++lba; --blocks; }
#endif
    } else csw();
}
static void cbw(const uint8_t *p,unsigned n)
{
    if (n!=31 || little(p)!=0x43425355 || p[13] || !p[14] || p[14]>16) {
        bot_phase=BAD_CBW; IN1(0)|=1u<<21; OUT1(0)|=1u<<21; return;
    }
    tag=little(p+4); residue=little(p+8);
    const uint8_t *c=p+15;
    failed=reply_size=sector_read=at=blocks=0;
#if BUILD_MINOR == 37
    ram_sink=0;
#endif
    for (unsigned i=0;i<sizeof reply;++i) reply[i]=0;
    unsigned cmd=c[0],cap=h2_sd_capacity();
#if BUILD_MINOR >= 51
    if (cmd==0x12 && (c[1]&1) && c[2]>=0xc0 && c[2]<=0xc2) {
        if (ejected || !cap || !h2_card_claim()) fail(2,0x3a);
        else {
            int size=card_receipt(c[2],cap,reply+4);
            if (size<0) fail(3,0x11);
            else {reply[1]=c[2];reply[3]=size;reply_size=4+size;}
        }
    } else
#endif
    if (cmd==0x12) {
        const char id[]="Weazl   H2 SD Card      0027";
        reply[1]=0x80; reply[2]=4; reply[3]=2; reply[4]=31;
        for (unsigned i=0;i<28;++i) reply[8+i]=id[i];
        reply_size=c[4]<36 ? c[4] : 36;
    } else if (cmd==3) {
        reply[0]=0x70; reply[2]=sense; reply[7]=10; reply[12]=asc;
        sense=asc=0; reply_size=c[4]<18 ? c[4] : 18;
    } else if (cmd==0x1b && (c[4]&3)==2) {
        ejected=1; h2_card_release();
#if BUILD_MINOR == 37
    } else if (cmd==0xf0 && c[1]=='W' && c[2]=='X' && c[3]=='R' && c[4]=='M' &&
               ejected && !h2_card_busy() && residue && !(residue&511) &&
               !(p[12]&128)) {
        ram_sink=1; bot_phase=DATA_OUT; bulk_arm(); return;
#endif
    } else if (!cap || ejected || !h2_card_claim()) {
        fail(2,ejected || !cap ? 0x3a : 0x04);
    } else if (cmd==0x25) {
        be(reply,cap-1); be(reply+4,512); reply_size=8;
    } else if (cmd==0x23) {
        reply[3]=8; be(reply+4,cap); reply[8]=2; reply[10]=2; reply_size=12;
    } else if (cmd==0x1a) {
        reply[0]=3; reply_size=4;
    } else if (cmd==0x28 || cmd==0x2a) {
        lba=big(c+2); blocks=((unsigned)c[7]<<8)|c[8];
        if (lba>=cap || blocks>cap-lba) fail(5,0x21);
        else if (residue!=blocks*512 || !!(p[12]&128)!=(cmd==0x28)) fail(5,0x24);
        else if (blocks && cmd==0x28) {
            sector_read=1; bot_phase=DATA_IN; bulk_next(); return;
        } else if (blocks) { bot_phase=DATA_OUT; bulk_arm(); return; }
    } else if (cmd!=0 && cmd!=0x1b && cmd!=0x1e && cmd!=0x35) fail(5,0x20);
    if (residue && (p[12]&128)) {
        unsigned len=reply_size<residue ? reply_size : residue;
        residue-=len; bot_phase=DATA_IN; blocks=0; bulk_send(reply,len);
    } else if (residue) { failed=1; blocks=0; bot_phase=DATA_OUT; bulk_arm(); }
    else csw();
}
static void bulk_out(const uint8_t *p,unsigned n)
{
    if (bot_phase==CBW) { cbw(p,n); return; }
    if (bot_phase!=DATA_OUT) return;
    if (!n || n>residue || at+n>WRITE_BUFFER_SIZE
#if BUILD_MINOR >= 34
        || n>out_batch || (n&3)
#endif
        ) {
#if defined(H2_WRITE_PIPELINE)
        bulk_abort_write();
#endif
        fail(5,0x24); csw(); return;
    }
#if BUILD_MINOR >= 34
    /* The packet has already been drained directly from the receive FIFO. */
    out_batch-=n;
#else
    for (unsigned i=0;i<n;++i) write_buffer[at+i]=p[i];
#endif
    at+=n; residue-=n;
#if !defined(H2_WRITE_PIPELINE)
    if (at==WRITE_BUFFER_SIZE || !residue) {
#if BUILD_MINOR == 37
        if (ram_sink) {
            for (unsigned i=0;i<at/4;++i)
                ram_digest=(ram_digest^write_words[i])*16777619u;
            ram_bytes+=at;
        } else
#endif
        if (!failed && !h2_sd_write_blocks(lba,write_buffer,at/512)) fail(3,0x0c);
        lba+=at/512; at=0;
    }
#if BUILD_MINOR >= 34
    if (!residue) csw();
#else
    if (residue) bulk_arm(); else csw();
#endif
#endif
}
