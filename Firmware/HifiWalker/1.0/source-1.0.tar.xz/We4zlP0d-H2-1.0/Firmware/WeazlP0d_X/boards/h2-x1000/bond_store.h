#ifndef H2_BOND_STORE_H
#define H2_BOND_STORE_H
#include <stdint.h>

typedef struct {
    uint8_t peer[6], key[16];
#if BUILD_MINOR >= 26
    char name[32];
#endif
} h2_bond;
#if BUILD_MINOR >= 26
enum { H2_SAVED=8 };
int h2_bonds_load(h2_bond bonds[H2_SAVED]);
#endif

int h2_bond_load(h2_bond *bond);
int h2_bond_save(const h2_bond *bond);
#endif
