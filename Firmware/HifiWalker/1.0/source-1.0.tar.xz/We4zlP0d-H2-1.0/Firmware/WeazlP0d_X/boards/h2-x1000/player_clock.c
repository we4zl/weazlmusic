/* Start the application PLL from the X1000 NAND-ROM clock tree.
 * The DDR, SD and SPI clocks use the already locked MPLL. */
#include <stdint.h>

#define CPM(off) (*(volatile uint32_t *)(0xb0000000u+(off)))
#define OST (*(volatile uint32_t *)0xb2000020u)
enum { APLL_ON=1u<<10, DIV_ENABLE=7u<<20, MUX_READY=15u<<28 };

static int wait_bits(volatile uint32_t *reg,uint32_t mask,uint32_t wanted)
{
    uint32_t start=OST;
    for (unsigned tries=0;tries<150000 && OST-start<60000;++tries)
        if ((*reg&mask)==wanted)
            return 1;
    return 0;
}

unsigned h2_player_clock(void)
{
    uint32_t original=CPM(0);
    if ((original&0xff0fffff)==0x95073310 && (CPM(0x10)&0xfffc0500)==0x98000500)
        return 1;
    if ((original&0xff0fffff)!=0x55000000 || (CPM(0x14)&0xfffc0083)!=0x98000083)
        return 2;

    /* SCLK_A still runs from EXTAL while the independent APLL locks at 600 MHz. */
    CPM(0x10)=0x98000100;
    if (!wait_bits(&CPM(0x10),APLL_ON,APLL_ON))
        return 3;

    /* Clock divisors are 1 for CPU, 2 for L2, 4 for AHB and 8 for PCLK. */
    const uint32_t dividers=0x55073310u;
    CPM(0)=dividers|DIV_ENABLE;
    if (!wait_bits(&CPM(0xd4),7,0))
        return 4;
    CPM(0)=dividers;
    CPM(0)=0x95073310u;
    return wait_bits(&CPM(0xd4),MUX_READY,MUX_READY) ? 1 : 5;
}
