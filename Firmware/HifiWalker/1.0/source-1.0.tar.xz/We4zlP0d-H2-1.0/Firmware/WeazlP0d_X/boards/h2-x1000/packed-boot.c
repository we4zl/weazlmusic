#include "LzmaDec.h"

enum { EXPANDED_MAX = 0x80000 };
extern const Byte h2_payload[], h2_payload_end[];
extern const UInt32 h2_expanded_size;
#if BUILD_MINOR >= 60
unsigned h2_player_clock(void);
#endif

static void *allocate(ISzAllocPtr allocator, size_t bytes)
{
    (void)allocator;
    /* Single allocation for the decoder's probabilities. The output buffer
       serves as its dictionary. This scratch is outside both images. */
    return bytes <= 32768 ? (void *)0x80680000u : NULL;
}

static void release(ISzAllocPtr allocator, void *memory)
{
    (void)allocator;
    (void)memory;
}

_Noreturn void h2_unpack_player(void)
{
#if BUILD_MINOR >= 60
    /* NAND recovery enters at the ROM clock. Bring up APLL before spending
       the guarded startup window on decompression. */
    h2_player_clock();
#endif
    static const ISzAlloc allocator = {allocate, release};
    Byte *const destination = (Byte *)0x80a00000u;
    SizeT output = h2_expanded_size;
    SizeT input = h2_payload_end - h2_payload;
    ELzmaStatus status;
    if (output && output <= EXPANDED_MAX && input > LZMA_PROPS_SIZE) {
        input -= LZMA_PROPS_SIZE;
        if (LzmaDecode(destination, &output, h2_payload + LZMA_PROPS_SIZE, &input,
                       h2_payload, LZMA_PROPS_SIZE, LZMA_FINISH_END, &status, &allocator) == SZ_OK &&
            status == LZMA_STATUS_FINISHED_WITH_MARK && output == h2_expanded_size &&
            input == (SizeT)(h2_payload_end - h2_payload) - LZMA_PROPS_SIZE) {
            for (size_t offset = 0; offset < output; offset += 32)
                __asm__ volatile("cache 0x15, 0(%0)" :: "r"(destination + offset) : "memory");
            __asm__ volatile("sync" ::: "memory");
            ((void (*)(void))0xa0a00000u)();
        }
    }
    /* The installed recovery watchdog retries the previous guarded slot. */
    for (;;) {}
}
