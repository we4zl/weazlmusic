#ifndef H2_BOOT_HEALTH_H
#define H2_BOOT_HEALTH_H

#include <stdint.h>

#define H2_HEALTH_MARK 0x58000000u
#define H2_HEALTH_GENERATION_MAX 0xfffffu
#define H2_HEALTH_TRIAL_ENTRY 0x58325241u

/* Two bits record failed slots, and two indicate the outstanding attempt.
 * The newest manifest generation identifies the pair of slots. */
static inline uint32_t h2_health_resume(uint32_t previous,uint32_t generation)
{
    uint32_t base=H2_HEALTH_MARK|(generation<<4);
    if ((previous&~15u)!=base)
        return base;
    return base|((previous|(previous>>2))&3u);
}

static inline uint32_t h2_health_attempt(uint32_t state,unsigned slot)
{
    return state|(4u<<slot);
}

static inline uint32_t h2_health_confirmed(uint32_t state)
{
    return state&~12u;
}

uint32_t h2_health_read(void);
int h2_health_write(uint32_t value);
void h2_health_arm(void);
int h2_health_confirm(void);

#endif
