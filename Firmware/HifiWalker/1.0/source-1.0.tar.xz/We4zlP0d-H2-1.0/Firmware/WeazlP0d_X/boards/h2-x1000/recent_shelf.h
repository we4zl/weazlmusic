/* Recent album metadata survives selection changes until the card is remounted. */
enum { RECENT_CACHE=16, RECENT_THUMB=20 };
static struct recent_album {
    unsigned tag, first_track, cover_offset, received;
    int checked_cover;
#if BUILD_MINOR >= 50
    /* Nonzero glyph runs per scanline, so moving a cached title needs no
     * font decode or repeated measurements. Long selected titles still scroll. */
    uint8_t glyphs[24][(282+7)/8];
    unsigned width;
#endif
    char title[TRIP_LABEL_BYTES+1];
    uint8_t thumb[RECENT_THUMB*RECENT_THUMB*2];
} recent_albums[RECENT_CACHE];
static unsigned recent_top, recent_quiet_since;
static int recent_page(void) { return page==SHELVES && shelf_kind==TRIP_RECENT; }

static void invalidate_recent(void)
{
    for (unsigned i=0;i<RECENT_CACHE;++i) recent_albums[i].tag=0;
    recent_top=0;
}

#if BUILD_MINOR >= 50
static void cache_recent_title(struct recent_album *album)
{
    uint8_t row[UI_WIDTH*2];
    album->width=ui_text_width(1,album->title);
    for (unsigned y=0;y<24;++y) {
        for (unsigned j=0;j<282*2;++j) row[j]=0;
        ui_text_row(y,0,1,281,1,album->title,0xffff,row);
        for (unsigned j=0;j<sizeof album->glyphs[y];++j) {
            unsigned bits=0;
            for (unsigned k=0;k<8 && 8*j+k<281;++k)
                if (row[2*(8*j+k)]) bits|=1u<<k;
            album->glyphs[y][j]=bits;
        }
    }
}
#endif

static void recent_titles(void)
{
    if (cursor<recent_top) recent_top=cursor;
    if (cursor>=recent_top+RECENT_ROWS) recent_top=cursor-RECENT_ROWS+1;
    if (count<=RECENT_ROWS) recent_top=0;
    else if (recent_top>count-RECENT_ROWS) recent_top=count-RECENT_ROWS;
    first=recent_top;
    unsigned fetch=RECENT_ROWS;
#if BUILD_MINOR >= 47
    if (count<=RECENT_CACHE && !first) fetch=count;
#endif
    for (unsigned i=0;i<fetch && first+i<count;++i) {
        unsigned row=first+i;
        struct recent_album *album=&recent_albums[row%RECENT_CACHE];
        if (album->tag!=row+1) {
            trip_view entry;
            album->tag=album->received=album->checked_cover=album->cover_offset=0;
            if (i<RECENT_ROWS) labels[i][0]=0;
            if (!trip_view_by_kind(&library.player,TRIP_RECENT,row,&entry)) continue;
            album->first_track=entry.first;
            copy_text(album->title,entry.title,sizeof album->title);
#if BUILD_MINOR >= 50
            cache_recent_title(album);
#endif
            album->tag=row+1;
        }
        if (i<RECENT_ROWS) copy_text(labels[i],album->title,sizeof labels[i]);
    }
    recent_quiet_since=now;
}

/* The wheel takes priority over thumbnail reads. Retain only the displayed pixels. */
static void recent_load_thumbnail(void)
{
    if (now-recent_quiet_since<160 || !paint_idle()) return;
    for (unsigned row=first;row<first+RECENT_ROWS && row<count;++row) {
        struct recent_album *album=&recent_albums[row%RECENT_CACHE];
        if (album->tag!=row+1) continue;
        if (!album->checked_cover) {
            trip_player p=library.player;
            album->cover_offset=trip_select(&p,album->first_track,0) ? p.cover : 0;
            album->checked_cover=1;
            return;
        }
        if (!album->cover_offset || album->received==COVER_BYTES) continue;
        uint8_t data[512];
        unsigned at=album->received;
        trip_player *p=&library.player;
        if (!p->read(p->context,0,album->cover_offset+at,data,sizeof data)) {
            album->cover_offset=0;
            return;
        }
        for (unsigned j=0;j<512;j+=8) {
            unsigned pixel=(at+j)/2, sy=pixel/COVER_SIDE;
            if (sy%4) continue;
            unsigned dest=2*((sy/4)*RECENT_THUMB+(pixel%COVER_SIDE)/4);
            album->thumb[dest]=data[j]; album->thumb[dest+1]=data[j+1];
        }
        album->received+=sizeof data;
        if (album->received==COVER_BYTES) {
            unsigned top=24+(row-first)*24;
#if BUILD_MINOR >= 63
            repaint(top,top+24);
#else
            visible_y=top;
#endif
        }
        return;
    }
}
