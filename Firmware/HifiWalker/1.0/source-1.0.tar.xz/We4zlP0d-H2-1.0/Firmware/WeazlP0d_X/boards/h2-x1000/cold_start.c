/* X1000 ROM second entry. Recover without SDRAM or a readable NAND slot. */
#include "boot_slot.h"
#ifdef H2_BOOT_GUARD
#include "boot_launch.h"
#endif
#include <stdint.h>
#define REG(addr) (*(volatile uint32_t *)(uintptr_t)(addr))
#define CPM(off) REG(0xb0000000u+(off))
#define OST(off) REG(0xb2000000u+(off))
#define GPIO(bank,off) REG(0xb0010000u+(bank)*0x100+(off))
#define DDR_CONTROL REG(0xb34f0008u)

enum { USB_MUX_CFG0=1u<<5, USB_MUX_CFG1=1u<<30, USB_HOST_VBUS=1u<<25, MENU=1u<<28 };
unsigned h2_ddr_initialize(void);
unsigned h2_nand_info(uint32_t info[4]);
unsigned h2_nand_page(unsigned page,uint32_t words[528],unsigned *status);
void h2_main(void);
void h2_set_ddr_status(unsigned state);

static void delay_ticks(unsigned duration)
{
    uint32_t start=OST(0x20);
    for (unsigned i=0; i<1800000 && OST(0x20)-start<duration; ++i) {}
}

static void low(unsigned bank,unsigned bits)
{
    GPIO(bank,0x18)=bits;
    GPIO(bank,0x48)=bits;
    GPIO(bank,0x38)=bits;
    GPIO(bank,0x24)=bits;
}

static int usb_phy(void)
{
    low(1,USB_MUX_CFG1|USB_HOST_VBUS);
    low(3,USB_MUX_CFG0);
    CPM(0x20)&=~(1u<<3);           /* DWC2 clock */
    CPM(0x50)=1u<<29;             /* external reference, divider zero */
    for (unsigned n=0;n<120000 && (CPM(0x50)&(1u<<28));++n) {}
    if (CPM(0x50)&(1u<<28))
        return 0;
    CPM(0x50)&=~(1u<<29);
    CPM(0xc4)|=1u<<12;
    delay_ticks(90);
    CPM(0xc4)&=~(1u<<12);
    CPM(0x24)=(CPM(0x24)&~(1u<<23))|(1u<<7);
    delay_ticks(320);
    CPM(0x44)=0;
    CPM(0x40)=(1u<<25)|0x96;
    CPM(0x48)=(1u<<31)|(2u<<26)|(1u<<24)|(1u<<19);
    const uint32_t analog=(1u<<25)|(1u<<24)|(1u<<23)|(1u<<20)|(7u<<11)|(1u<<6)|(1u<<4)|7u;
    CPM(0x3c)=analog|(1u<<22);
    delay_ticks(8000);
    CPM(0x3c)=analog;
    delay_ticks(8000);
    return 1;
}

static int menu_held(void)
{
    GPIO(1,0x18)=MENU;
    GPIO(1,0x34)=MENU;
    GPIO(1,0x24)=MENU;
    return !(GPIO(1,0)&MENU);
}

static int read_flash(void *context,unsigned page,uint32_t data[H2_NAND_PAGE/4])
{
    uint32_t *physical=context;
    unsigned status=0;
    if (h2_nand_page(page,physical,&status) || (status&0x30)==0x20)
        return 0; /* W25N01GV uncorrectable ECC */
    for (unsigned i=0;i<H2_NAND_PAGE/4;++i)
        data[i]=physical[i];
    return 1;
}

#ifdef H2_BOOT_GUARD
static unsigned load_app(unsigned avoid,h2_image *chosen)
{
    return h2_load_best(read_flash,(void *)0xa0010000u,avoid,(void *)0xa0011000u,
                        (void *)H2_BOOT_BASE,chosen);
}

#endif

#ifdef H2_BOOT_RAM_TRIAL
void h2_cold_main(uint32_t entry)
#else
void h2_cold_main(void)
#endif
{
    CPM(0x20)&=~(1u<<20);
    OST(0x00)=(OST(0x00)&~12u)|4u;
    OST(0x34)=2;
    /* A live handoff can inherit initialized DDR. Do not drop the PLL
       feeding its controller while returning from a RAM service. */
#ifdef H2_INHERIT_USB_PHY
    int ram_trial=entry==H2_HEALTH_TRIAL_ENTRY;
    unsigned ddr=ram_trial || (CPM(0x2c)==0x84000002u && DDR_CONTROL==0xc91eu) ? 1 : h2_ddr_initialize();
    h2_set_ddr_status(ddr);
    int usb_ready=ram_trial || usb_phy();
#else
    unsigned ddr=CPM(0x2c)==0x84000002u && DDR_CONTROL==0xc91eu ? 1 : h2_ddr_initialize();
    h2_set_ddr_status(ddr);
    int usb_ready=usb_phy();
#endif
    if (ddr==1 && usb_ready &&
#ifdef H2_BOOT_RAM_TRIAL
        entry!=H2_HEALTH_TRIAL_ENTRY &&
#endif
        !menu_held()) {
        uint32_t info[4];
        if (!h2_nand_info(info) && (info[0]&0xffffff)==0x21aaef && (info[2]&0x10)) {
            h2_image chosen;
#ifdef H2_BOOT_GUARD
            unsigned result=load_app(0,&chosen);
            if (result && !h2_boot_launchable(result,&chosen,load_app))
                result=0;
#else
            unsigned result=h2_load_best(read_flash,(void *)0xa0010000u,0,(void *)0xa0011000u,(void *)H2_BOOT_BASE,&chosen);
#endif
            if (result) {
                __asm__ volatile("sync" ::: "memory");
                ((void (*)(void))H2_BOOT_BASE)();
            }
        }
    }
    if (usb_ready)
        h2_main();
    for (;;) {}
}
