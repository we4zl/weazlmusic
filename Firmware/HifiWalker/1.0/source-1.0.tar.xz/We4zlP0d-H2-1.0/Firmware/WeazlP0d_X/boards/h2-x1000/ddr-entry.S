#ifndef H2_STACK_TOP
#define H2_STACK_TOP 0xa024
#endif
.set noreorder
.set noat
.section .start,"ax",@progbits
.globl _start
_start:
    di
    ehb
    lui $sp, H2_STACK_TOP
    addiu $sp, $sp, -16
    lui $t0, %hi(__bss_start)
    addiu $t0, $t0, %lo(__bss_start)
    lui $t1, %hi(__bss_end)
    addiu $t1, $t1, %lo(__bss_end)
1:  beq $t0, $t1, 2f
    nop
    sw $zero, 0($t0)
    b 1b
    addiu $t0, $t0, 4
2:  jal h2_main
    nop
3:  b 3b
    nop
