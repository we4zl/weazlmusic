#!/usr/bin/env bash
set -euo pipefail
board=$(cd "$(dirname "$0")" && pwd -P)
root=$(git -C "$board" rev-parse --show-toplevel)
minor=${1:-6}
defines=()
case "$minor" in
    6|7|8|9|10) ;;
    12) defines+=(-DH2_BOOT_GUARD) ;;
    14|16|18|19|20|21) defines+=(-DH2_BOOT_GUARD -DH2_PCM_TAP) ;;
    22|23|24|25|26|27|28|29|30|31|32|33|34|35|36|37|40|41|42|43|44|45|46|47|48|49|50|51|52|53|54|55|56|57|58) defines+=(-DH2_BOOT_GUARD -DH2_PCM_TAP -DH2_PANEL_POWER) ;;
    59|60|61|62|63|64) defines+=(-DH2_BOOT_GUARD -DH2_PCM_TAP -DH2_PANEL_POWER -DH2_ORIGINAL_AUDIO) ;;
    38|39) defines+=(-DH2_BOOT_GUARD -DH2_PCM_TAP -DH2_PANEL_POWER -DH2_WRITE_PIPELINE) ;;
    *) exit 2 ;;
esac
printf -v build 'H%02d' "$minor"
work="$root/build/hifih2/player/$build"
mkdir -p "$work"
art="$root/Firmware/HifiWalker/art"
patch="$root/build/hifih2/v22-root/lib/firmware/BCM4343A1_001.002.009.0122.0538.hcd"
printf '%s  %s\n' '9873217acdeaee78bd502a31fa876dc1b120c9d07ca8c16420853bc44ba64972' "$patch" | sha256sum -c >&2
if (( minor >= 43 )); then
    shop_flags=()
    if (( minor >= 55 && minor < 59 )); then shop_flags+=(--compress); fi
    python "$board/pack_shop.py" "$root/Firmware/HifiWalker/menu-preview/art" "$work" "${shop_flags[@]}"
else
python - "$art" "$work" <<'PY'
from ctypes import CDLL, create_string_buffer
from pathlib import Path
import sys
art, work = map(Path, sys.argv[1:])
lz4 = CDLL("liblz4.so.1")
assembly = ['.section .rodata.wallpaper,"a",@progbits']
for symbol, source in (("h2_art", "night-tunnel"), ("h2_dock_art", "weazl-dock")):
    data = (art / f"{source}.rgb565le").read_bytes()
    if len(data) != 320 * 240 * 2:
        raise SystemExit(f"Wrong dimensions in {source}")
    output = create_string_buffer(lz4.LZ4_compressBound(len(data)))
    compressed = lz4.LZ4_compress_HC(data, output, len(data), len(output), 12)
    if compressed <= 0:
        raise SystemExit(f"Could not pack {source}")
    path = work / f"{source}.lz4"
    path.write_bytes(output.raw[:compressed])
    assembly.extend((f".globl {symbol}", f".globl {symbol}_end", f"{symbol}:",
                     f'.incbin "{path}"', f"{symbol}_end:"))
(work / "wallpaper.S").write_text("\n".join(assembly) + "\n")
PY
fi
flags=(--target=mipsel-none-elf -march=mips32r2 -msoft-float -mno-abicalls -fno-pic -G0 -Os -ffreestanding -fno-builtin -fno-stack-protector -Wall -Wextra -Werror -ffunction-sections -fdata-sections)
flags+=(-I"$root/include" -I"$root/build/ui" -I"$board/../..")
objects=()
extra_sources=()
extra_link=()
link_symbols=()
if (( minor >= 59 )); then
    python "$board/build_codecs.py" "$work" "${flags[@]}"
    python "$board/build_resampler.py" "$work/resample_coefficients.h"
    flags+=(-I"$work/codec-headers" -I"$work")
    extra_sources+=(original_audio.c codec-guard.S)
    extra_link+=("$work/codecs.a")
    link_symbols+=(--defsym=h2_expanded=1)
fi
for name in player-entry.S player_app.c player_clock.c lcd_art.c boot_usb.c ram_service.c panel.c input.c sd_read.c media_probe.c hci_probe.c pmic.c avdtp_probe.c sdp_source.c sbc_source.c nand_read.c bond_store.c boot_health.c "${extra_sources[@]}"; do
    out="$work/${name%.*}.o"
    render_flags=()
    if (( minor >= 52 )) && [[ "$name" == pmic.c || "$name" == sdp_source.c ]]; then render_flags+=(-Oz); fi
    if (( minor >= 53 )) && [[ "$name" == bond_store.c || "$name" == hci_probe.c || "$name" == nand_read.c ]]; then render_flags+=(-Oz); fi
    if (( minor >= 50 )) && [[ "$name" == player_app.c ]]; then render_flags+=(-O2); fi
    if [[ "$name" == original_audio.c ]]; then render_flags+=(-O2 -fno-optimize-sibling-calls); fi
    clang "${flags[@]}" "${render_flags[@]}" "${defines[@]}" -DBUILD_MINOR="$minor" -DH2_PLAYER -DH2_SERVICE -DH2_DDR_SERVICE -DH2_NAND_INSTALLER -DH2_BOND_STORAGE -c "$board/$name" -o "$out"
    objects+=("$out")
done
clang "${flags[@]}" -DH2_RADIO_PATCH='"'"$patch"'"' -c "$board/radio-patch.S" -o "$work/radio-patch.o"
clang "${flags[@]}" -c "$work/wallpaper.S" -o "$work/wallpaper.o"
ui_flags=()
if (( minor >= 44 )); then ui_flags+=(-DUI_HEIGHT=240); fi
if (( minor >= 50 )); then ui_flags+=(-O2); fi
clang "${flags[@]}" "${ui_flags[@]}" -c "$root/src/ui.c" -o "$work/ui.o"
clang "${flags[@]}" -c "$root/src/fs.c" -o "$work/fs.o"
clang "${flags[@]}" -c "$board/../../trip.c" -o "$work/trip.o"
ld.lld -m elf32ltsmip --gc-sections "${link_symbols[@]}" -T "$board/player.ld" "${objects[@]}" "$work/radio-patch.o" "$work/wallpaper.o" "$work/ui.o" "$work/fs.o" "$work/trip.o" "${extra_link[@]}" -o "$work/player.elf"
llvm-objcopy -O binary "$work/player.elf" "$work/player.tmp"
if (( minor >= 59 )); then
    llvm-readelf -h "$work/player.elf" | awk '/Entry point address/ {e=tolower($NF)} END {exit e!="0xa0a00000"}'
    bash "$board/build-packed-player.sh" "$work" "$minor"
    entry="$work/packed.elf"
else
    entry="$work/player.elf"
fi
llvm-readelf -h "$entry" | awk '/Entry point address/ {e=tolower($NF)} END {exit e!="0xa0600000"}'
published="$root/Firmware/HifiWalker/$build/$build.bin"
if [[ -f "$published" ]] && ! cmp -s "$published" "$work/player.tmp"; then
    echo "The published $build differs. Use a new build ID." >&2
    exit 1
fi
mv "$work/player.tmp" "$work/player.bin"
llvm-size "$work/player.elf"
