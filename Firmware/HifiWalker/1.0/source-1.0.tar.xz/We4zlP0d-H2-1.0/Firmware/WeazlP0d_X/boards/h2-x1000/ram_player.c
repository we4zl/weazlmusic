/* Start the verified application bytes from DDR. NAND is never opened. */
#include <stdint.h>
#include "boot_health.h"
#include "boot_slot.h"

extern const uint32_t h2_ram_image[], h2_ram_image_end[];

uint32_t flash_trial(uint32_t cookie)
{
    unsigned words=h2_ram_image_end-h2_ram_image;
    /* Keep a failed RAM boot separate from the installed package generation. */
    if (!words || words>H2_BOOT_IMAGE_LIMIT/4 ||
        !h2_health_write(h2_health_attempt(h2_health_resume(0,H2_HEALTH_GENERATION_MAX),1)))
        return cookie;

    h2_health_arm();
    volatile uint32_t *dest=(volatile uint32_t *)H2_BOOT_BASE;
    for (unsigned i=0;i<words;++i)
        dest[i]=h2_ram_image[i];
    __asm__ volatile("sync" ::: "memory");
    ((void (*)(void))H2_BOOT_BASE)();
    for (;;) {}
}
