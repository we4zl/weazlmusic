#include "input.h"

#define PORT(bank, offset) (*(volatile uint32_t *)(uintptr_t)(0xb0010000u+(bank)*0x100+(offset)))
enum { A, B, C, D };
enum {
    PLAY=1u<<16, UP=1u<<17, BACK=1u<<18, DOWN=1u<<19,
    WHEEL=3u<<23, MENU=1u<<28, POWER=1u<<31, PREVIOUS=1u<<4, NEXT=1u<<24,
};

static void input_pins(unsigned bank,uint32_t pins)
{
    PORT(bank,0x18)=pins;
    PORT(bank,0x24)=pins;
    PORT(bank,0x34)=pins;
}

void h2_input_begin(h2_input *in)
{
    input_pins(A,PLAY|UP|BACK|DOWN);
    input_pins(B,WHEEL|MENU|POWER);
    input_pins(C,NEXT);
    input_pins(D,PREVIOUS);
    in->changed=0;
    in->candidate=in->stable=in->armed=0;
    in->last_wheel=(PORT(B,0)&WHEEL)>>23;
    in->wheel=0;
}

h2_input_event h2_input_poll(h2_input *in,uint32_t now)
{
    uint32_t a=~PORT(A,0), b=PORT(B,0), c=~PORT(C,0), d=~PORT(D,0);
    unsigned raw=((a&PLAY) ? H2_PLAY : 0)|((a&UP) ? H2_VOLUME_UP : 0)|
        ((a&DOWN) ? H2_VOLUME_DOWN : 0)|((a&BACK) ? H2_BACK : 0)|
        ((b&MENU) ? 0 : H2_MENU)|((b&POWER) ? 0 : H2_POWER)|
        ((c&NEXT) ? H2_NEXT : 0)|((d&PREVIOUS) ? H2_PREVIOUS : 0);
    h2_input_event out={0,0,0};
    if (raw!=in->candidate) {
        in->candidate=raw;
        in->changed=now;
    }
    if (now-in->changed>=25) {
        if (in->armed) {
            out.pressed=in->candidate&~in->stable;
            out.released=in->stable&~in->candidate;
        } else if (!in->candidate) {
            in->armed=1;
        }
        in->stable=in->candidate;
    }

    unsigned wheel=(b&WHEEL)>>23;
    if (wheel!=in->last_wheel) {
        static const int8_t step[4][4]={{0,-1,1,0},{1,0,0,-1},{-1,0,0,1},{0,1,-1,0}};
        int delta=step[in->last_wheel][wheel];
        in->last_wheel=wheel;
        in->wheel=delta ? in->wheel+delta : 0;
        if (in->wheel==4 || in->wheel==-4) {
            out.wheel=in->wheel/4;
            in->wheel=0;
        }
    }
    return out;
}
