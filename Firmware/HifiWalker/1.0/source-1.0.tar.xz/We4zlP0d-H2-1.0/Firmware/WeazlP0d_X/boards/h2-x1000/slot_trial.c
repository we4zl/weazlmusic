/* Reusable USB transport for verified application and rollback transactions. */
#include "boot_slot.h"
#include <stdint.h>

#define USB(off) (*(volatile uint32_t *)(0xb3500000u+(off)))
#define TCU(off) (*(volatile uint32_t *)(0xb0002000u+(off)))
#define CPM(off) (*(volatile uint32_t *)(0xb0000000u+(off)))
#define OST (*(volatile uint32_t *)0xb2000020u)
enum { SLOT_TOOL=0x4832534c, TOKEN=0x5732, PAGE_WORDS=H2_NAND_PAGE/4 };
extern const uint32_t h2_package[], h2_package_end[];
unsigned h2_nand_info(uint32_t info[4]);
unsigned h2_nand_page(unsigned page,uint32_t words[528],unsigned *status);
unsigned h2_nand_erase_install_block(unsigned page,uint32_t *scratch);
unsigned h2_nand_program_install_page(unsigned page,const uint32_t data[PAGE_WORDS],uint32_t *scratch);
unsigned h2_player_clock(void);

static int read_page(void *context,unsigned page,uint32_t *data)
{
    uint32_t *scratch=context;
    unsigned flags;
    if (h2_nand_page(page,scratch,&flags) || (flags&0x30)==0x20)
        return 0;
    for (unsigned i=0;i<PAGE_WORDS;++i)
        data[i]=scratch[i];
    return 1;
}

static int read_package(void *context,unsigned page,uint32_t *data)
{
    unsigned first=*(const unsigned *)context;
    unsigned relative=page-first;
    unsigned n=h2_package_end-h2_package;
    unsigned offset=relative==H2_BOOT_SLOT_PAGES-1 ? 0 : (relative+1)*PAGE_WORDS;
    if (page<first || relative>=H2_BOOT_SLOT_PAGES || offset>n || n-offset<PAGE_WORDS)
        return 0;
    for (unsigned i=0;i<PAGE_WORDS;++i)
        data[i]=h2_package[offset+i];
    return 1;
}

static unsigned inspect(unsigned target,uint32_t report[8],uint32_t *scratch,uint32_t *data)
{
    uint32_t info[4];
    if (h2_nand_info(info) || (info[0]&0xffffff)!=0x21aaef ||
        (info[1]&0xffffff)!=0x21aaef || info[2]!=0x18 || info[3]!=0x7c)
        return 1;
    h2_image selected, other, offered;
    uintptr_t image=0xa0900000u;
    unsigned current=h2_load_best(read_page,scratch,0,data,(void *)image,&selected);
    unsigned previous=h2_load_best(read_page,scratch,target,data,(void *)image,&other);
    report[1]=current ? selected.id : 0;
    report[2]=current ? selected.generation : 0;
    report[3]=previous ? other.id : 0;
    report[4]=previous ? other.generation : 0;
    report[5]=current;
    if (!h2_load_best(read_package,&target,0,data,(void *)image,&offered) ||
        h2_package_end-h2_package!=(int)(PAGE_WORDS+((offered.length+H2_NAND_PAGE-1)/H2_NAND_PAGE)*PAGE_WORDS))
        return 2;
    if (offered.generation<=report[2] || (current && !previous) ||
        (current && current==(target==H2_BOOT_SLOT_A ? 1u : 2u)))
        return 3;
    return 0;
}

static unsigned write_slot(unsigned target,uint32_t report[8],uint32_t *scratch,uint32_t *data)
{
    unsigned error=inspect(target,report,scratch,data);
    if (error)
        return error;
    unsigned manifest=target+H2_BOOT_SLOT_PAGES-1;
    /* Discard a stale commit record before touching the data it described. */
    unsigned block=manifest&~(H2_NAND_BLOCK_PAGES-1);
    unsigned flags;
    if (h2_nand_page(manifest,scratch,&flags) || (flags&0x30)==0x20)
        return 4;
    if (scratch[0]!=0xffffffff &&
        (error=h2_nand_erase_install_block(block,scratch)))
        return 0x20+error;
    unsigned pages=(h2_package_end-h2_package)/PAGE_WORDS-1;
    for (unsigned i=0;i<pages;++i) {
        unsigned page=target+i;
        if (!(i%H2_NAND_BLOCK_PAGES)) {
            error=h2_nand_erase_install_block(page,scratch);
            if (error)
                return 0x30+error;
        }
        report[6]=page;
        error=h2_nand_program_install_page(page,h2_package+(i+1)*PAGE_WORDS,scratch);
        if (error)
            return 0x40+error;
    }
    for (unsigned i=0;i<pages;++i) {
        if (!read_page(scratch,target+i,data))
            return 0x51;
        for (unsigned k=0;k<PAGE_WORDS;++k)
            if (data[k]!=h2_package[(i+1)*PAGE_WORDS+k])
                return 0x52;
    }
    report[6]=manifest;
    error=h2_nand_program_install_page(manifest,h2_package,scratch);
    if (error)
        return 0x60+error;
    h2_image chosen;
    int expected=target==H2_BOOT_SLOT_A ? 1 : 2;
    if (h2_load_best(read_page,scratch,0,data,(void *)0xa0900000u,&chosen)!=expected ||
        chosen.id!=h2_package[6] || chosen.generation!=h2_package[2])
        return 0x71;
    return 0;
}

static unsigned rollback(unsigned target,uint32_t *scratch,uint32_t *data)
{
    h2_image chosen;
    void *image=(void *)0xa0900000u;
    int expected=target==H2_BOOT_SLOT_A ? 1 : 2;
    if (h2_load_best(read_page,scratch,0,data,image,&chosen)!=expected)
        return 0x81;
    if (!h2_load_best(read_page,scratch,target,data,image,&chosen))
        return 0x80;
    unsigned manifest=target+H2_BOOT_SLOT_PAGES-1;
    return h2_nand_erase_install_block(manifest&~(H2_NAND_BLOCK_PAGES-1),scratch);
}

#ifndef H2_SLOT_TRANSACTION_ONLY
static void reply(const uint32_t *data,unsigned length)
{
    USB(0x910)=(1u<<19)|length;
    USB(0x900)|=0x84000000;
    for (unsigned i=0;i<length/4;++i)
        USB(0x1000)=data[i];
}
static uint32_t cycle_count(void)
{
    uint32_t count;
    __asm__ volatile("mfc0 %0,$9" : "=r"(count));
    return count;
}

static void clock_report(uint32_t data[8])
{
    uint32_t cause;
    __asm__ volatile("mfc0 %0,$13" : "=r"(cause));
    __asm__ volatile("mtc0 %0,$13; ehb" :: "r"(cause&~(1u<<27)));
    uint32_t start=OST, count=cycle_count();
    for (unsigned i=0;i<2000000 && OST-start<12000;++i) {}
    data[0]=CPM(0); data[1]=CPM(0x10); data[2]=CPM(0x14); data[3]=CPM(0xd4);
    data[4]=CPM(0x2c); data[5]=OST-start; data[6]=cycle_count()-count; data[7]=cause;
    __asm__ volatile("mtc0 %0,$13; ehb" :: "r"(cause));
}
static void restart(void)
{
    TCU(0x3c)=1u<<16;
    TCU(0x0c)=0x0c;
    TCU(0x08)=0;
    TCU(0x00)=60000;
    TCU(0x04)=1;
    for (;;) {}
}

uint32_t flash_trial(uint32_t cookie)
{
    uint32_t scratch[528], data[PAGE_WORDS], report[8], clock[8], setup[2];
    for (unsigned i=0;i<8;++i)
        ((volatile uint32_t *)report)[i]=0;
    report[0]=SLOT_TOOL;
    unsigned got=0, finish=0, pending=0, target=0, clock_trial=0;
    for (;;) {
        uint32_t in=USB(0x908);
        if (in&1) {
            USB(0x908)=in;
            if (finish)
                break;
            if (pending) {
                if (pending==3) {
                    TCU(0x3c)=1u<<16;
                    TCU(0x0c)=0x2c;
                    TCU(0x08)=0;
                    TCU(0x00)=60000;
                    TCU(0x04)=1;
                    report[7]=h2_player_clock();
                    TCU(0x04)=0;
                    clock_trial=1;
                } else {
                    report[7]=pending==1 ? write_slot(target,report,scratch,data) :
                                          rollback(target,scratch,data);
                    if (!report[7])
                        restart();
                }
                pending=0;
            }
        }
        if (USB(0x14)&(1u<<12))
            break;
        while (USB(0x14)&(1u<<4)) {
            uint32_t st=USB(0x20);
            unsigned size=(st>>4)&2047, is_setup=(st&0x1e000f)==0xc0000 && size==8;
            for (unsigned i=0;i<(size+3)/4;++i) {
                uint32_t word=USB(0x1000);
                if (is_setup)
                    setup[i]=word;
            }
            got|=is_setup;
        }
        uint32_t out=USB(0xb08);
        if (!out)
            continue;
        USB(0xb08)=out;
        if ((out&8) && got) {
            unsigned req=setup[0]&65535,val=setup[0]>>16,idx=setup[1]&65535,len=setup[1]>>16;
            got=0;
            if (req==0x90c0 && !idx && !val && len==sizeof report)
                reply(report,sizeof report);
            else if (req==0x96c0 && !idx && !val && len==sizeof clock) {
                clock_report(clock);
                reply(clock,sizeof clock);
            } else if (req==0x9740 && idx==TOKEN && !len && !val && !pending) {
                pending=3;
                reply(0,0);
            }
            else if ((req==0x9440 || req==0x9540) && idx==TOKEN && !len &&
                     (val==H2_BOOT_SLOT_A || val==H2_BOOT_SLOT_B) && !pending) {
                pending=req==0x9440 ? 1 : 2;
                target=val;
                reply(0,0);
            } else if (req==0x7440 && !idx && !val && !len) {
                finish=1;
                reply(0,0);
            } else {
                USB(0x900)|=1u<<21;
                USB(0xb00)|=1u<<21;
            }
        }
        USB(0xb10)=0x60080040;
        USB(0xb00)|=0x84000000;
    }
    return clock_trial ? 0 : SLOT_TOOL^cookie;
}
#endif
