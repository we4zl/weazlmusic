/* One-time X recovery installation. This service can write only the two
 * measured ROM blocks and only with the embedded, previously tested stage. */
#include <stdint.h>

#define USB(off) (*(volatile uint32_t *)(0xb3500000u+(off)))
#define TCU(off) (*(volatile uint32_t *)(0xb0002000u+(off)))
enum { PRIMARY=0, COPY=448, PAGES=64, WORDS=528, MAIN_WORDS=512 };
#ifdef H2_RECOVERY_UPGRADE
enum { BUILD=H2_RECOVERY_INSTALLER_ID, ROM_LIMIT=0x2c00 };
#else
enum { BUILD=0x48303546, ROM_LIMIT=0x2a00 };
#endif
enum { UNTESTED=0xffffffff, ACTION_TOKEN=0x5732 };
extern const uint32_t h2_rom_image[];
extern const uint32_t h2_rom_length;
unsigned h2_nand_info(uint32_t info[4]);
unsigned h2_nand_page(unsigned page,uint32_t words[WORDS],unsigned *status);
unsigned h2_nand_erase_install_block(unsigned page,uint32_t *scratch);
unsigned h2_nand_program_install_page(unsigned page,const uint32_t data[MAIN_WORDS],uint32_t *scratch);

static void reply(const uint32_t *data,unsigned length)
{
    USB(0x910)=(1u<<19)|length;
    USB(0x900)|=0x84000000;
    for (unsigned i=0;i<length/4;++i)
        USB(0x1000)=data[i];
}

static int scan(unsigned first,uint32_t *scratch,uint32_t *crc,int *matches,int *empty)
{
    uint32_t sum=~0u;
    *matches=*empty=1;
    for (unsigned p=0;p<PAGES;++p) {
        unsigned flags;
        if (h2_nand_page(first+p,scratch,&flags) || (flags&0x30)==0x20)
            return 0;
        for (unsigned i=0;i<WORDS;++i) {
            uint32_t word=scratch[i];
            *empty &= word==0xffffffff;
            unsigned src=p*MAIN_WORDS+i;
            if (i<MAIN_WORDS)
                *matches &= word==(src<h2_rom_length/4 ? h2_rom_image[src] : 0xffffffff);
            for (unsigned shift=0;shift<32;shift+=8) {
                sum^=(word>>shift)&255;
                for (unsigned bit=0;bit<8;++bit)
                    sum=(sum>>1)^(0xedb88320u&-(sum&1));
            }
        }
    }
    *crc=~sum;
    return 1;
}

static void inspect(uint32_t report[9],uint32_t *scratch)
{
    uint32_t info[4];
    report[8]=0;
    if (h2_nand_info(info) || (info[0]&0xffffff)!=0x21aaef ||
        (info[1]&0xffffff)!=0x21aaef || info[2]!=0x18 || info[3]!=0x7c) {
        report[8]=1;
        return;
    }
    int image0,image7,empty0,empty7;
    if (!scan(PRIMARY,scratch,report+1,&image0,&empty0) ||
        !scan(COPY,scratch,report+2,&image7,&empty7)) {
        report[8]=2;
        return;
    }
    report[3]=image0; report[4]=image7;
    report[5]=empty7;
}

static unsigned install(unsigned first,uint32_t report[9],uint32_t scratch[WORDS])
{
    inspect(report,scratch);
    if (report[8] || !h2_rom_length || h2_rom_length>ROM_LIMIT || (h2_rom_length&3))
        return 0x10;
#ifdef H2_RECOVERY_UPGRADE
    if (report[1]!=H2_PREVIOUS_BOOT_BLOCK_CRC ||
        (first==COPY && !report[5] && report[2]!=H2_PREVIOUS_BOOT_BLOCK_CRC) ||
        (first==PRIMARY && !report[4]))
        return 0x11;
    if (first==PRIMARY || !report[5]) {
#else
    if ((first==COPY && (!report[5] || report[1]!=H2_FACTORY_BOOT_BLOCK_CRC)) ||
        (first==PRIMARY && (!report[4] || report[1]!=H2_FACTORY_BOOT_BLOCK_CRC)))
        return 0x11;
    if (first==PRIMARY) {
#endif
        unsigned error=h2_nand_erase_install_block(first,scratch);
        if (error)
            return 0x20+error;
    }
    uint32_t data[MAIN_WORDS];
    for (unsigned offset=0;offset<h2_rom_length/4;offset+=MAIN_WORDS) {
        for (unsigned i=0;i<MAIN_WORDS;++i)
            data[i]=offset+i<h2_rom_length/4 ? h2_rom_image[offset+i] : 0xffffffff;
        report[6]=first+offset/MAIN_WORDS;
        unsigned error=h2_nand_program_install_page(report[6],data,scratch);
        if (error)
            return 0x30+error;
    }
    inspect(report,scratch);
    return (report[8] || !report[first==PRIMARY ? 3 : 4]) ? 0x40 : 0;
}

static void reboot(void)
{
    TCU(0x3c)=1u<<16;
    TCU(0x0c)=0x0c;
    TCU(0x08)=0;
    TCU(0x00)=60000;
    TCU(0x04)=1;
    for (;;) {}
}

uint32_t flash_trial(uint32_t cookie)
{
    uint32_t scratch[WORDS], report[9];
    for (unsigned i=0;i<9;++i)
        ((volatile uint32_t *)report)[i]=i>=6 ? UNTESTED : 0;
    report[0]=BUILD;
    uint32_t setup[2];
    unsigned got=0, finish=0;
    inspect(report,scratch);
    for (;;) {
        uint32_t in=USB(0x908);
        if (in&1) {
            USB(0x908)=in;
            if (finish==2)
                reboot();
            if (finish)
                break;
        }
        if (USB(0x14)&(1u<<12))
            break;
        while (USB(0x14)&(1u<<4)) {
            uint32_t st=USB(0x20);
            unsigned size=(st>>4)&2047, is_setup=(st&0x1e000f)==0xc0000 && size==8;
            for (unsigned i=0;i<(size+3)/4;++i) {
                uint32_t data=USB(0x1000);
                if (is_setup)
                    setup[i]=data;
            }
            got|=is_setup;
        }
        uint32_t out=USB(0xb08);
        if (!out)
            continue;
        USB(0xb08)=out;
        if ((out&8) && got) {
            unsigned req=setup[0]&65535,val=setup[0]>>16,idx=setup[1]&65535,len=setup[1]>>16;
            got=0;
            if (req==0x90c0 && !idx && !val && len==sizeof report)
                reply(report,sizeof report);
            else if (req==0x9240 && idx==ACTION_TOKEN && !len && (val==PRIMARY || val==COPY)) {
                reply(0,0);
                report[7]=install(val,report,scratch);
            } else if (req==0x9340 && idx==ACTION_TOKEN && !len && !val && report[3] && report[4] && !report[8]) {
                finish=2;
                reply(0,0);
            } else if (req==0x7440 && !idx && !val && !len) {
                finish=1;
                reply(0,0);
            } else {
                USB(0x900)|=1u<<21;
                USB(0xb00)|=1u<<21;
            }
        }
        USB(0xb10)=0x60080040;
        USB(0xb00)|=0x84000000;
    }
    return BUILD ^ cookie;
}
