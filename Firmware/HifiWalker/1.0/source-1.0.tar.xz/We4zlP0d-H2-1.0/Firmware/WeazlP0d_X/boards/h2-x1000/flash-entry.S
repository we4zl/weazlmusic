.set noreorder
.set noat
.section .entry,"ax",@progbits
.globl start_flash_trial
start_flash_trial:
    addiu $sp, $sp, -24
    sw $ra, 20($sp)
    sw $s0, 16($sp)
    move $s0, $sp
    lui $sp, 0xa050
    jal flash_trial
    addiu $sp, $sp, -16
    move $sp, $s0
    lw $s0, 16($sp)
    lw $ra, 20($sp)
    jr $ra
    addiu $sp, $sp, 24
