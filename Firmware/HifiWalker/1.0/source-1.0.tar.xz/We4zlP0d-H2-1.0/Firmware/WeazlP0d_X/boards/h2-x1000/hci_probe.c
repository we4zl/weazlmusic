/* H2 hw4 Bluetooth controller inquiry using the UART H4 transport. */
#include <stddef.h>
#include <stdint.h>
#define REG(base, off) (*(volatile uint32_t *)((uintptr_t)(base)+(off)))
#define UART(off) REG(0xb0030000u,off)
#define GPIO(off) REG(0xb0010200u,off)
#define OST REG(0xb2000000u,0x20)
void h2_pmic_pins(void);
int h2_pmic_read(uint8_t reg,uint8_t *value);
int h2_pmic_radio_gate(uint8_t gates);
extern const uint8_t h2_radio_patch[], h2_radio_patch_end[];
enum { REG_ON=1u<<18, HOST_WAKE=1u<<19, H4_PINS=15u<<10 };
#if BUILD_MINOR >= 55
int h2_player_radio_yield(void);
#endif

static int until(volatile uint32_t *reg,uint32_t mask,unsigned timeout)
{
    uint32_t start=OST;
    for (unsigned i=0;i<30000000 && OST-start<6000*timeout;++i) {
        if (*reg&mask)
            return 1;
#if BUILD_MINOR >= 55
        if (!(i&127) && h2_player_radio_yield())
            break;
#endif
    }
    return 0;
}
static void delay_ms(unsigned ms)
{
    uint32_t start=OST;
    for (unsigned i=0;i<200000000 && OST-start<6000*ms;++i) {
#if BUILD_MINOR >= 55
        if (!(i&127) && h2_player_radio_yield())
            break;
#endif
    }
}
static uint8_t original_rails;
static int radio_powered;
#if BUILD_MINOR >= 41
static void radio_reference_clock(int enable)
{
    /* The V2.2 radio power driver selects RTC32K on PB26, function 0. */
    volatile uint32_t *port_b=(volatile uint32_t *)0xb0010100u;
    const uint32_t pin=1u<<26;
    port_b[0x18/4]=pin;
    port_b[0x48/4]=pin;
    port_b[(enable ? 0x38 : 0x34)/4]=pin;
    port_b[(enable ? 0x28 : 0x24)/4]=pin;
}
#endif
static void uart_baud(unsigned divisor,unsigned sample_count)
{
    UART(0x0c)=0x83;
    UART(0)=divisor;
    UART(0x04)=0;
    UART(0x0c)=3;
    UART(0x24)=sample_count;
    UART(0x28)=0;
}

void h2_hci_stop(void)
{
    GPIO(0x48)=REG_ON|HOST_WAKE;
    if (radio_powered)
        h2_pmic_radio_gate(original_rails&63);
    radio_powered=0;
#if BUILD_MINOR >= 41
    radio_reference_clock(0);
#endif
}

static int exchange_parameters(uint16_t opcode,const uint8_t *parameters,unsigned length,
                               uint8_t *reply,unsigned expected)
{
    const uint8_t cmd[]={1,(uint8_t)opcode,(uint8_t)(opcode>>8),(uint8_t)length};
    for (unsigned i=0;i<sizeof cmd+length;++i) {
        if (!until(&UART(0x14),1u<<5,100))
            return 1;
        UART(0)=i<sizeof cmd ? cmd[i] : parameters[i-sizeof cmd];
    }
    for (unsigned i=0;i<expected+7;++i) {
        if (!until(&UART(0x14),1,150))
            return 2;
        uint8_t data=(uint8_t)UART(0);
        switch (i) {
        case 0: if (data!=4) return 3; break;
        case 1: if (data!=14) return 4; break;
        case 2: if (data!=expected+4) return 5; break;
        case 3: break;
        case 4: if (data!=(uint8_t)opcode) return 6; break;
        case 5: if (data!=opcode>>8) return 7; break;
        case 6: if (data) return 8; break;
        default: reply[i-7]=data; break;
        }
    }
    return 0;
}

static int exchange(uint16_t opcode,uint8_t *reply,unsigned expected)
{
    return exchange_parameters(opcode,0,0,reply,expected);
}
static int load_patch(unsigned *successful)
{
    const uint8_t *p=h2_radio_patch;
    *successful=0;
    while (p<h2_radio_patch_end) {
        unsigned remaining=(unsigned)(h2_radio_patch_end-p);
        if (remaining<3)
            return 9;
        unsigned opcode=p[0]|((unsigned)p[1]<<8), n=p[2];
        if (remaining<3+n || (opcode!=0xfc4c && opcode!=0xfc4e))
            return 9;
        int rc=exchange_parameters(opcode,p+3,n,0,0);
        if (rc)
            return rc;
        p+=3+n;
        ++*successful;
    }
    return 0;
}

void h2_hci_probe(uint32_t report[9],unsigned rails,unsigned keep)
{
    uint8_t before=0;
    h2_hci_stop();
    /* Keep the wired power amp, DAC and analog output switch muted. */
    volatile uint32_t *port_b=(volatile uint32_t *)0xb0010100u;
    const uint32_t audio=(1u<<6)|(1u<<8)|(1u<<9)|(1u<<12)|(1u<<15);
    port_b[0x18/4]=audio;
    port_b[0x44/4]=1u<<15;
    port_b[0x48/4]=audio&~(1u<<15);
    port_b[0x38/4]=audio;
    port_b[0x24/4]=audio;
    if (rails) {
        h2_pmic_pins();
        if (!h2_pmic_read(0x90,&before) || !h2_pmic_radio_gate((before|rails)&63)) {
            report[0]=0xf001;
            return;
        }
        original_rails=before;
        radio_powered=1;
        delay_ms(40);
    }
#if BUILD_MINOR >= 41
    radio_reference_clock(1);
#endif
    GPIO(0x18)=REG_ON|HOST_WAKE|H4_PINS;
    GPIO(0x38)=REG_ON|HOST_WAKE|H4_PINS;
    GPIO(0x48)=REG_ON|HOST_WAKE|H4_PINS;
    GPIO(0x24)=REG_ON|HOST_WAKE;
    GPIO(0x28)=H4_PINS;
    delay_ms(1000);
    REG(0xb0000000u,0x20)&=~(1u<<14);
    UART(0x0c)=3; UART(0x04)=0;
    UART(0x08)=0;
    uart_baud(13,16);
    UART(0x10)=0xc0; /* CTS/RTS flow control */
    UART(0x08)=0x17;
    GPIO(0x44)=REG_ON;
    delay_ms(250);

    report[1]=UART(0x18);
    GPIO(0x44)=HOST_WAKE;
    uint8_t *records=(uint8_t *)(report+2);
    int rc=exchange(0x0c03,records,0);
    if (rc) {
        delay_ms(50);
        rc=exchange(0x0c03,records,0);
    }
    report[0]=rc;
    if (!rc) {
        delay_ms(125);
        report[1] |= UART(0x18)<<8;
        rc=exchange(0xfc2e,records,0);
        report[0]=rc ? 0x400u+rc : 0;
    }
    if (!rc) {
        delay_ms(50);
        report[1] |= UART(0x18)<<16;
        rc=load_patch(&report[8]);
        report[0]=rc ? 0x500u+rc : 0;
    }
    if (!rc) {
        delay_ms(350);
        rc=exchange(0x0c03,records,0);
        report[0]=rc ? 0x600u+rc : 0;
    }
    if (!rc) {
        delay_ms(60);
        rc=exchange(0x1001,records,8);
        report[0]=rc ? 0x100u+rc : 0;
    }
    if (!rc) {
        rc=exchange(0x1009,records+8,6);
        report[0]=rc ? 0x200u+rc : 0;
    }
    if (!rc) {
        rc=exchange(0x1005,records+14,7);
        report[0]=rc ? 0x300u+rc : 0;
    }
    if (!rc && keep) {
        const uint8_t rate[]={0,0,0xc0,0xc6,0x2d,0};
        rc=exchange_parameters(0xfc18,rate,sizeof rate,0,0);
        if (!rc) {
            uart_baud(1,8);
            delay_ms(40);
            rc=exchange(0x1001,records,8);
        }
        if (!rc) {
            const uint8_t ssp=1;
            rc=exchange_parameters(0x0c56,&ssp,1,0,0);
        }
        if (!rc) {
            /* Turn on SSP, encryption and packet credit events explicitly. */
            const uint8_t events[]={0xbc, 0x60, 0xe4, 0x0c, 0x04, 0x80, 0x3f, 0x0c};
            rc=exchange_parameters(0x0c01,events,sizeof events,0,0);
        }
        if (!rc) {
            static const uint8_t local_name[248]="WeazlP0d X H2";
            rc=exchange_parameters(0x0c13,local_name,sizeof local_name,0,0);
        }

        report[0]=rc ? 0x700u+rc : 0;
    }
    if (!keep || rc)
        h2_hci_stop();
}

int h2_h4_write(uint8_t type,const uint8_t *data,unsigned length)
{
    for (unsigned i=0; i<=length; ++i) {
        if (!until(&UART(0x14),1u<<5,100))
            return 0;
        UART(0)=i ? data[i-1] : type;
    }
    return 1;
}

static int read_event(uint8_t *event,unsigned timeout)
{
    if (!until(&UART(0x14),1,timeout) || (uint8_t)UART(0)!=4)
        return 0;
    for (unsigned i=0,n=2; i<n; ++i) {
        if (!until(&UART(0x14),1,100))
            return 0;
        event[i]=(uint8_t)UART(0);
        if (i==1)
            n+=event[i];
    }
    return 1;
}

void h2_hci_link(const uint8_t peer[6],uint32_t report[8],int keep)
{
    uint8_t command[16], event[257];
    report[0]=1;
    if (!radio_powered)
        return;
#if BUILD_MINOR >= 26
    const uint8_t page_timeout[]={0x00,0x0c}; /* 1.92 seconds per attempt. */
    if (exchange_parameters(0x0c18,page_timeout,2,0,0)) return;
#endif
    command[0]=0x05; command[1]=0x04; command[2]=13;
    for (unsigned i=0;i<6;++i)
        command[3+i]=peer[i];
    command[9]=0x18; command[10]=0xcc;
    command[11]=1; command[12]=command[13]=command[14]=0;
    command[15]=1;
    if (!h2_h4_write(1,command,sizeof command)) {
        report[0]=2;
        return;
    }
    report[0]=3;
    for (unsigned i=0;i<40;++i) {
        if (!read_event(event,200))
            continue;
        if (event[0]==0x0f && event[1]>=4 && event[4]==0x05 && event[5]==0x04) {
            report[1]=event[2];
            if (event[2]) {
                report[0]=4;
                return;
            }
        }
        if (event[0]==0x03 && event[1]==11) {
            report[2]=event[2];
            report[3]=event[3]|((unsigned)event[4]<<8);
            report[4]=event[11];
            report[5]=event[12];
            for (unsigned k=0;k<6;++k)
                ((uint8_t *)(report+6))[k]=event[5+k];
            if (event[2]) {
                report[0]=5;
                return;
            }
            report[0]=0;
            /* First probe only opens the ACL and disconnects cleanly. */
            const uint8_t disconnect[]={6,4,3,event[3],event[4],0x13};
            if (!keep) h2_h4_write(1,disconnect,sizeof disconnect);
            return;
        }
    }
}

unsigned h2_h4_packet(uint8_t *packet,unsigned capacity,unsigned timeout)
{
    if (!(UART(0x14)&1) && !until(&UART(0x14),1,timeout))
        return 0;
    unsigned type=UART(0)&255;
    unsigned header=type==4 ? 2 : type==2 ? 4 : 0;
    if (!header || capacity < header+1)
        return 0;
    packet[0]=type;
    unsigned size=header+1;
    for (unsigned i=1; i<size; ++i) {
        if (!until(&UART(0x14),1,100))
            return 0;
        uint8_t value=UART(0);
        if (i<capacity)
            packet[i]=value;
        if (i==header) {
            unsigned payload=type==4 ? value : (unsigned)packet[3] | ((unsigned)value<<8);
            if (payload>1024)
                return 0;
            size+=payload;
        }
    }
    return size<=capacity ? size : 0;
}

#if BUILD_MINOR >= 26
#include "discovery.h"

int h2_scan_begin(h2_discovery *s,uint32_t now)
{
    uint8_t mode=2;
    /* Add inquiry, remote name and extended inquiry results to the audio mask. */
    const uint8_t events[]={0xff,0x60,0xe4,0x0c,0x06,0xc0,0x3f,0x0c};
    const uint8_t inquiry[]={1,4,5,0x33,0x8b,0x9e,6,0};
    s->count=s->naming=s->phase=s->error=0;
    if (exchange_parameters(0x0c01,events,sizeof events,0,0) ||
        exchange_parameters(0x0c45,&mode,1,0,0) ||
        !h2_h4_write(1,inquiry,sizeof inquiry)) {
        s->error=1;
        return 0;
    }
    s->phase=1;
    s->deadline=now+14000;
    return 1;
}

static h2_receiver *scan_entry(h2_discovery *s,const uint8_t *addr)
{
    for (unsigned i=0;i<s->count;++i) {
        unsigned k=0;
        while (k<6 && s->receivers[i].addr[k]==addr[k]) ++k;
        if (k==6) return &s->receivers[i];
    }
    if (s->count==H2_NEARBY) return 0;
    h2_receiver *r=&s->receivers[s->count++];
    for (unsigned k=0;k<6;++k) r->addr[k]=addr[k];
    r->name[0]=0;
    return r;
}

static void receiver_name(h2_receiver *r,const uint8_t *name,unsigned n)
{
    unsigned i=0;
    for (;i+1<sizeof r->name && i<n && name[i];++i)
        r->name[i]=name[i]>=32 ? (char)name[i] : ' ';
    r->name[i]=0;
}

static void inquiry_result(h2_discovery *s,const uint8_t *p,unsigned len,int extended)
{
    if (!len || !*p) return;
    unsigned count=*p++, stride=(len-1)/count;
    if ((len-1)%count || (extended ? count!=1 || stride!=254 : stride<14 || stride>15)) return;
    for (unsigned i=0;i<count;++i,p+=stride) {
        h2_receiver *r=scan_entry(s,p);
        if (!r) continue;
        r->repetition=p[6];
        if (extended) {
            for (unsigned at=14;at<stride;) {
                unsigned n=p[at++];
                if (!n || n>stride-at) break;
                if (p[at]==9 || (p[at]==8 && !r->name[0]))
                    receiver_name(r,p+at+1,n-1);
                at+=n;
            }
        }
    }
}

/* Resolve legacy receivers without blocking input or the ordinary USB endpoint. */
static void next_name(h2_discovery *s,uint32_t now)
{
    while (s->naming<s->count) {
        h2_receiver *r=&s->receivers[s->naming++];
        if (r->name[0]) continue;
        uint8_t cmd[]={0x19,4,10,0,0,0,0,0,0,0,0,0,0};
        for (unsigned k=0;k<6;++k) cmd[3+k]=r->addr[k];
        cmd[9]=r->repetition;
        if (!h2_h4_write(1,cmd,sizeof cmd)) break;
        s->phase=2;
        s->deadline=now+6500;
        return;
    }
    s->phase=0;
}

int h2_scan_poll(h2_discovery *s,uint32_t now)
{
    if (!s->phase) return 0;
    if ((int32_t)(now-s->deadline)>=0) {
        s->error=s->phase==1;
        s->phase=0;
        return 1;
    }
    uint8_t packet[258];
    unsigned n=h2_h4_packet(packet,sizeof packet,0);
    if (n<4 || packet[0]!=4) return 0;
    unsigned event=packet[1];
    if (s->phase==1 && (event==2 || event==0x22 || event==0x2f)) {
        inquiry_result(s,packet+3,n-3,event==0x2f);
    } else if (event==1 && s->phase==1 && !packet[3]) {
        next_name(s,now);
    } else if (event==7 && s->phase==2 && n>=10) {
        h2_receiver *r=&s->receivers[s->naming-1];
        for (unsigned k=0;k<6;++k)
            if (r->addr[k]!=packet[4+k]) return 0;
        if (!packet[3]) receiver_name(r,packet+10,n-10);
        next_name(s,now);
    } else if (event==0x0f && n==7 && packet[3] && packet[6]==4) {
        if (packet[5]==0x19 && s->phase==2) next_name(s,now);
        else if (packet[5]==1 && s->phase==1) { s->phase=0; s->error=packet[3]; }
    } else return 0;
    return 1;
}
#endif
