/* Probe the H2's power controller over the board's open-drain I2C bus. */
#include <stdint.h>
#define MMIO(addr) (*(volatile uint32_t *)(uintptr_t)(addr))
#define PD(offset) MMIO(0xb0010300u+(offset))
#define OST MMIO(0xb2000020u)
enum { SCL=1, SDA=2, ADDRESS=0x34 };

static void bit_time(void)
{
    uint32_t start=OST;
    for (unsigned i=0; i<3000 && OST-start<30; ++i) {}
}
static void low(unsigned pin)
{
    PD(0x38)=pin;
}
static void release(unsigned pin)
{
    PD(0x34)=pin;
}
static int clock_high(void)
{
    release(SCL);
    for (unsigned i=0; i<10000; ++i) {
        if (PD(0)&SCL) {
            bit_time();
            return 1;
        }
    }
    return 0;
}
static int start(void)
{
    release(SDA);
    bit_time();
    if (!clock_high() || !(PD(0)&SDA))
        return 0;
    low(SDA);
    bit_time();
    low(SCL);
    return 1;
}
static void stop(void)
{
    low(SDA);
    bit_time();
    clock_high();
    release(SDA);
    bit_time();
}
static int send(uint8_t value)
{
    for (unsigned mask=128; mask; mask>>=1) {
        if (value&mask)
            release(SDA);
        else
            low(SDA);
        bit_time();
        if (!clock_high())
            return 0;
        low(SCL);
    }
    release(SDA);
    bit_time();
    if (!clock_high())
        return 0;
    int ack=!(PD(0)&SDA);
    low(SCL);
    return ack;
}
static int receive(uint8_t *value)
{
    uint8_t bits=0;
    release(SDA);
    for (unsigned i=0; i<8; ++i) {
        bit_time();
        if (!clock_high())
            return 0;
        bits=(bits<<1)|!!(PD(0)&SDA);
        low(SCL);
    }
    bit_time();
    int nack=clock_high();
    low(SCL);
    *value=bits;
    return nack;
}

void h2_pmic_pins(void)
{
    PD(0x18)=SCL|SDA;
    PD(0x48)=SCL|SDA;
    release(SCL|SDA);
    PD(0x24)=SCL|SDA;
}
int h2_pmic_read(uint8_t reg,uint8_t *value)
{
    int ok=start() && send(ADDRESS<<1) && send(reg) &&
           start() && send((ADDRESS<<1)|1) && receive(value);
    stop();
    return ok;
}

void h2_pmic_probe(uint32_t report[8])
{
    static const uint8_t registers[]={0x00,0x01,0x03,0x34,0x35,0x80,0x82,0x83,0x84,0x85,0x86,
        0x90,0x91,0x92,0x93,0x94,0x95,0x96,0x97,0x98,0x99,0x9a,0xa4};
    uint8_t *values=(uint8_t *)(report+2);
    h2_pmic_pins();
    report[0]=0;
    report[1]=PD(0)&3;
    for (unsigned i=0; i<sizeof registers; ++i) {
        values[i]=0;
        if (h2_pmic_read(registers[i],&values[i]))
            report[0] |= 1u<<i;
    }
}

/* Only change the six analog LDO gates on the identified H2 PMIC.
 * Leave all voltage settings, digital regulators and charging controls alone. */
int h2_pmic_radio_gate(uint8_t gates)
{
    uint8_t found, before, after;
    if (gates&0xc0 || !h2_pmic_read(3,&found) || found!=0x4a ||
        !h2_pmic_read(0x90,&before))
        return 0;
    gates |= before&0xc0;
    int ok=start() && send(ADDRESS<<1) && send(0x90) && send(gates);
    stop();
    return ok && h2_pmic_read(0x90,&after) && after==gates;
}

int h2_pmic_display_enable(void)
{
    enum { DISPLAY_GATES=0x3a };
    static const uint8_t voltages[]={0x93,0x95,0x96,0x97};
    uint8_t id,gates,value;
    h2_pmic_pins();
    if (!h2_pmic_read(0x03,&id) || id!=0x4a || !h2_pmic_read(0x90,&gates))
        return 0;
    if ((gates&DISPLAY_GATES)==DISPLAY_GATES)
        return 1;
    /* Enabling this group of preset 3.3 V rails restored the hw4 display.
       Preserve ALDO3 (radio), the other gates and every regulator voltage. */
    for (unsigned i=0;i<sizeof voltages;++i)
        if (!h2_pmic_read(voltages[i],&value) || value!=0x1c)
            return 0;
    return h2_pmic_radio_gate((gates|DISPLAY_GATES)&0x3f);
}

int h2_pmic_poweroff(void)
{
    uint8_t id, config;
    h2_pmic_pins();
    if (!h2_pmic_read(3,&id) || id!=0x4a || !h2_pmic_read(0x10,&config))
        return 0;
    int ok=start() && send(ADDRESS<<1) && send(0x10) && send((config&~3u)|1u);
    stop();
    return ok;
}
