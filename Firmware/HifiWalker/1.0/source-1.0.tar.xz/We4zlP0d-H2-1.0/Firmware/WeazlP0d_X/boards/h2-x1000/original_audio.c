#include "original_audio.h"
#include "codec.h"
#include <string.h>
#include "resample_coefficients.h"

enum { OUTPUT_RATE = 48000, BLOCK_BYTES = 4096, DECODE_FRAMES = 1024 };
#if BUILD_MINOR >= 61
enum { INPUT_WINDOWS = 4 };
#else
enum { INPUT_WINDOWS = 2 };
#endif
enum { NO_ORIGINAL, ORIGINAL_READY, ORIGINAL_UNSUPPORTED, ORIGINAL_FALLBACK };

static struct {
    codec decoder;
    _Alignas(8) uint8_t arena[128 * 1024];
    struct {
        fs_file file;
        uint32_t offset;
#if BUILD_MINOR >= 61
        uint32_t used;
#endif
        uint8_t data[BLOCK_BYTES];
    } input[INPUT_WINDOWS];
    unsigned recent, state, kind, rate, decoded, phase, head, padding;
    uint32_t report_frames;
    size_t first, end;
    int16_t samples[DECODE_FRAMES * 2], history[RESAMPLE_TAPS][2];
    int primed;
    codec_status status;
} original;

/* A provider allocation fault must leave the call before its caller can
 * dereference the failed allocation. The arena can then be reused. */
static uint32_t fault_context[11];
int h2_codec_guard(uint32_t context[11]) __attribute__((returns_twice));
_Noreturn void h2_codec_unwind(uint32_t context[11]);

_Noreturn void codec_runtime_fault(unsigned reason)
{
    (void)reason;
    h2_codec_unwind(fault_context);
}

static uint32_t le32(const uint8_t *p)
{
    return p[0] | (uint32_t)p[1] << 8 | (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24;
}

static int read_exact(fs_file *file, uint32_t offset, void *out, size_t bytes)
{
    size_t read;
    return (offset == file->offset || fs_seek(file, offset) == FS_OK) &&
           fs_read(file, out, bytes, &read) == FS_OK && read == bytes;
}

static int locate(fs *volume, uint32_t clip, fs_file *source, unsigned *kind)
{
    fs_file index;
    uint8_t header[8];
    if (fs_open(volume, "/WXP.NAT", &index) != FS_OK ||
        !read_exact(&index, 0, header, sizeof header) || memcmp(header, "XNA1", 4))
        return 0;
    uint32_t first = 0, end = le32(header + 4);
    if (end > (index.size - sizeof header) / 16)
        return 0;
    uint32_t strings = sizeof header + end * 16;
    while (first < end) {
        uint32_t middle = first + (end - first) / 2;
        uint8_t row[16];
        if (!read_exact(&index, sizeof header + middle * sizeof row, row, sizeof row))
            return 0;
        uint32_t key = le32(row);
        if (key < clip) {
            first = middle + 1;
        } else if (key > clip) {
            end = middle;
        } else {
            uint32_t offset = le32(row + 8);
            unsigned length = row[12] | (unsigned)row[13] << 8;
            unsigned format = row[14] | (unsigned)row[15] << 8;
            char path[FS_PATH_BYTES];
            if (format > CODEC_AAC_M4A || !length || length >= sizeof path ||
                offset < strings || offset > index.size || length > index.size - offset ||
                !read_exact(&index, offset, path, length) || path[0] != '/')
                return 0;
            for (unsigned i = 0; i < length; ++i)
                if (!path[i]) return 0;
            path[length] = 0;
            *kind = format;
            return fs_open(volume, path, source) == FS_OK && source->size == le32(row + 4);
        }
    }
    return 0;
}

static int read_original(void *context, size_t offset, uint8_t *out, size_t bytes)
{
    (void)context;
    size_t size = original.input[0].file.size;
    if (offset > size || bytes > size - offset)
        return 0;
    while (bytes) {
        uint32_t block = offset & ~(uint32_t)(BLOCK_BYTES - 1);
#if BUILD_MINOR >= 61
        unsigned slot = 0, forward = INPUT_WINDOWS;
        for (unsigned i = 0; i < INPUT_WINDOWS; ++i) {
            uint32_t cached = original.input[i].offset;
            if (cached == block) {
                slot = i;
                break;
            }
            if (cached != UINT32_MAX && block - cached == BLOCK_BYTES)
                forward = i;
            if (original.input[i].used < original.input[slot].used)
                slot = i;
        }
        if (original.input[slot].offset != block) {
            /* Keep each forward stream on its own FAT cursor. In particular,
               an AAC packet that spans two windows must advance the audio
               window without evicting the sample table near the file end. */
            if (forward < INPUT_WINDOWS)
                slot = forward;
#else
        unsigned slot = original.input[0].offset == block ? 0 : 1;
        if (original.input[slot].offset != block) {
            slot = 1 - original.recent;
#endif
            size_t available = size - block;
            if (!read_exact(&original.input[slot].file, block, original.input[slot].data,
                            available < BLOCK_BYTES ? available : BLOCK_BYTES))
                return 0;
            original.input[slot].offset = block;
        }
#if BUILD_MINOR >= 61
        original.input[slot].used = ++original.recent;
#else
        original.recent = slot;
#endif
        size_t in_block = offset - block, count = BLOCK_BYTES - in_block;
        if (count > bytes)
            count = bytes;
        memcpy(out, original.input[slot].data + in_block, count);
        offset += count;
        out += count;
        bytes -= count;
    }
    return 1;
}

static codec_status open_codec(unsigned kind, const wav_reader *source)
{
    if (!h2_codec_guard(fault_context))
        return codec_open(&original.decoder, kind, source, original.arena, sizeof original.arena);
    codec_abandon(&original.decoder);
    return CODEC_MEMORY;
}

static codec_status read_codec(size_t *frames)
{
    if (!h2_codec_guard(fault_context))
        return codec_read(&original.decoder, original.samples, DECODE_FRAMES, frames);
    *frames = 0;
    codec_abandon(&original.decoder);
    return CODEC_MEMORY;
}

void h2_original_close(void)
{
    if (original.state == ORIGINAL_READY)
        codec_close(&original.decoder);
    original.state = NO_ORIGINAL;
}

void h2_original_open(h2_library *media)
{
    const trip_player *p = &media->player;
    h2_original_close();
    original.kind = original.rate = original.report_frames = original.decoded = 0;
    original.status = CODEC_OK;
    if (p->header != 24 || p->index >= p->count || p->position ||
        !locate(&media->volume, p->offset, &original.input[0].file, &original.kind))
        return;
#if BUILD_MINOR >= 61
    for (unsigned i = 0; i < INPUT_WINDOWS; ++i) {
        original.input[i].file = original.input[0].file;
        original.input[i].offset = UINT32_MAX;
        original.input[i].used = 0;
    }
    original.recent = 0;
#else
    original.input[1].file = original.input[0].file;
    original.input[0].offset = original.input[1].offset = UINT32_MAX;
    original.recent = 1;
#endif
    wav_reader source = {read_original, NULL, original.input[0].file.size};
    original.status = open_codec(original.kind, &source);
    original.rate = original.decoder.info.rate;
    if (original.status == CODEC_OK && (original.rate == 44100 || original.rate == OUTPUT_RATE)) {
        original.state = ORIGINAL_READY;
        original.first = original.end = original.phase = original.head = original.padding = 0;
        original.primed = 0;
        return;
    }
    if (original.status == CODEC_OK)
        original.status = CODEC_UNSUPPORTED;
    codec_close(&original.decoder);
    original.state = ORIGINAL_UNSUPPORTED;
}

static int next_sample(int16_t pcm[2])
{
    unsigned empty = 0;
    while (original.first == original.end) {
        if (original.status != CODEC_OK)
            return 0;
        original.first = 0;
        original.status = read_codec(&original.end);
        original.decoded += original.end;
        if (!original.end && ++empty == 8 && original.status == CODEC_OK)
            original.status = CODEC_INVALID;
    }
    unsigned channels = original.decoder.info.channels;
    size_t offset = original.first++ * channels;
    pcm[0] = original.samples[offset];
    pcm[1] = original.samples[offset + channels - 1];
    return 1;
}

static void advance_window(unsigned slot)
{
    if (next_sample(original.history[slot]))
        return;
    /* Extend the last sample until the output cursor consumes the input. */
    unsigned previous = (slot + RESAMPLE_TAPS - 1) % RESAMPLE_TAPS;
    original.history[slot][0] = original.history[previous][0];
    original.history[slot][1] = original.history[previous][1];
    ++original.padding;
}

static int16_t rounded_pcm(int32_t sample)
{
    sample = (sample + 16384) >> 15;
    return sample > INT16_MAX ? INT16_MAX : sample < INT16_MIN ? INT16_MIN : sample;
}

unsigned h2_original_pull(int16_t *pcm, unsigned frames)
{
    if (original.state != ORIGINAL_READY)
        return 0;
    unsigned used = 0;
    if (original.rate == OUTPUT_RATE) {
        while (used < frames && next_sample(pcm + used * 2))
            ++used;
    } else {
        if (!original.primed) {
            original.primed = next_sample(original.history[0]);
            if (original.primed) {
                for (unsigned i = 1; i < RESAMPLE_TAPS / 2; ++i) {
                    original.history[i][0] = original.history[0][0];
                    original.history[i][1] = original.history[0][1];
                }
                for (unsigned i = RESAMPLE_TAPS / 2; i < RESAMPLE_TAPS; ++i)
                    advance_window(i);
            }
        }
        while (used < frames && original.primed && original.padding <= RESAMPLE_TAPS / 2) {
            const int16_t *weights = resample_coefficients[original.phase];
            int32_t left = 0, right = 0;
            for (unsigned tap = 0; tap < RESAMPLE_TAPS; ++tap) {
                const int16_t *sample = original.history[(original.head + tap) % RESAMPLE_TAPS];
                left += sample[0] * weights[tap];
                right += sample[1] * weights[tap];
            }
            pcm[2 * used] = rounded_pcm(left);
            pcm[2 * used + 1] = rounded_pcm(right);
            ++used;
            original.phase += 147;
            if (original.phase >= RESAMPLE_PHASES) {
                original.phase -= RESAMPLE_PHASES;
                advance_window(original.head);
                original.head = (original.head + 1) % RESAMPLE_TAPS;
            }
        }
    }
    original.report_frames += used;
    if (used < frames) {
        codec_close(&original.decoder);
        original.state = ORIGINAL_FALLBACK;
    }
    return used;
}

void h2_original_status(uint32_t report[6])
{
    report[0] = original.state;
    report[1] = original.kind;
    report[2] = original.rate;
    report[3] = original.report_frames;
    report[4] = original.status;
    report[5] = original.decoded;
}
