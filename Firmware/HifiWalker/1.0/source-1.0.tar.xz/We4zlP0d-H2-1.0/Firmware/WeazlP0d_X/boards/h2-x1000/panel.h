#ifndef H2_PANEL_H
#define H2_PANEL_H

#include <stdbool.h>
#include <stdint.h>

enum h2_panel_phase {
    H2_PANEL_IDLE, H2_PANEL_RESET_LOW, H2_PANEL_RESET_HIGH,
    H2_PANEL_SLEEP_OUT, H2_PANEL_DISPLAY_ON, H2_PANEL_READY, H2_PANEL_FAILED,
};

typedef struct {
    enum h2_panel_phase phase;
    uint32_t deadline;
} h2_panel_startup;

bool h2_panel_step(h2_panel_startup *startup);
bool h2_panel_begin(void);
void h2_panel_row(unsigned y,const uint8_t *line);
bool h2_panel_scroll_rect(unsigned x,unsigned y,unsigned width,unsigned rows,const uint8_t *fb);
bool h2_panel_scroll_span(unsigned y,unsigned left,unsigned end,const uint8_t *line);
unsigned h2_panel_scroll_faults(void);
void h2_panel_light(void);
void h2_panel_blank(void);

#endif
