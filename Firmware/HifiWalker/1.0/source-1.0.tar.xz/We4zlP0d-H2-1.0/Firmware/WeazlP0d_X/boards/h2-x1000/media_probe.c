/* Read the live card through MSC0 and the common X FAT/catalog code. */
#include "media_probe.h"
#include <stdint.h>

unsigned h2_sd_open(uint32_t *sectors);
int h2_sd_read(void *context, uint32_t lba, uint8_t *out);
#if BUILD_MINOR >= 55
#include "sd_write.h"
static uint32_t bookmark_sector[2];

int h2_media_radio_bookmark(h2_library *media)
{
    fs_file file;
    fs *volume=&media->volume;
    bookmark_sector[0]=bookmark_sector[1]=0;
    if (fs_open(volume,"/WXP.RSM",&file)!=FS_OK || file.size!=1024)
        return 0;
    for (unsigned slot=0;slot<2;++slot) {
        if (fs_seek(&file,512*slot)!=FS_OK)
            return 0;
        bookmark_sector[slot]=volume->partition+volume->data_start+
                              (file.cluster-2)*volume->sectors_per_cluster+
                              slot%volume->sectors_per_cluster;
    }
    if (bookmark_sector[0]==bookmark_sector[1])
        bookmark_sector[1]=0;
    return bookmark_sector[1]!=0;
}

int h2_media_radio_read(unsigned slot,uint8_t data[512])
{
    return bookmark_sector[1] && h2_sd_read(0,bookmark_sector[slot],data);
}

int h2_media_radio_write(unsigned slot,const uint8_t data[512])
{
    return bookmark_sector[1] && h2_sd_write_blocks(bookmark_sector[slot],data,1);
}
#endif

static uint32_t le32(const uint8_t *p)
{
    return p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);
}
static int read_exact(fs_file *f, uint32_t offset, void *dst, size_t count)
{
    size_t n;
    return (offset==f->offset || fs_seek(f,offset)==FS_OK) &&
           fs_read(f,dst,count,&n)==FS_OK && n==count;
}
static int catalog_read(void *context,int audio,uint32_t offset,void *dst,size_t count)
{
    h2_library *media=context;
    if (audio<2)
        return read_exact(&media->directory,offset,dst,count);
    if (media->clip_id!=(uint32_t)audio) {
        static const char digits[]="0123456789abcdef";
        char name[]="/WXPCLIPS/00000000.WXA";
        for (unsigned i=0;i<8;++i)
            name[10+i]=digits[((uint32_t)audio>>(28-4*i))&15];
        if (fs_open(&media->volume,name,&media->clip)!=FS_OK)
            return 0;
        media->clip_id=audio;
        media->block_valid=0;
    }
    if (count!=sizeof media->block)
        return read_exact(&media->clip,offset,dst,count);
    if (!media->block_valid || media->block_at!=offset) {
        media->block_valid=read_exact(&media->clip,offset,media->block,sizeof media->block);
        media->block_at=offset;
    }
    if (!media->block_valid)
        return 0;
    for (unsigned i=0;i<count;++i)
        ((uint8_t *)dst)[i]=media->block[i];
    return 1;
}

unsigned h2_media_mount(h2_library *media)
{
    uint8_t mbr[512];
    uint32_t sectors;
#if BUILD_MINOR >= 42
    media->pod_name[0]=0;
#endif
    unsigned error=h2_sd_open(&sectors);
    if (error)
        return 0x100+error;
    if (!h2_sd_read(0,0,mbr) || mbr[510]!=0x55 || mbr[511]!=0xaa ||
        (mbr[450]!=0x0b && mbr[450]!=0x0c))
        return 2;
    uint32_t part=le32(mbr+454), count=le32(mbr+458);
    if (part>=sectors || !part || count>sectors-part)
        return 3;
    media->clip_id=0;
    media->block_valid=0;
    if ((error=fs_mount(&media->volume,h2_sd_read,0,sectors,part))!=FS_OK)
        return 0x200+error;
#if BUILD_MINOR >= 42
    fs_file name;
    if (fs_open(&media->volume,"/WXP.NAME",&name)==FS_OK && name.size>0 && name.size<=32 &&
        read_exact(&name,0,media->pod_name,name.size)) {
        media->pod_name[name.size]=0;
        for (unsigned i=0;i<name.size;i++)
            if ((unsigned char)media->pod_name[i]<32 || (unsigned char)media->pod_name[i]>126)
                media->pod_name[0]=0;
    } else media->pod_name[0]=0;
#endif
    if ((error=fs_open(&media->volume,"/WXP.TRIP",&media->directory))!=FS_OK)
        return 0x300+error;
    if (!trip_open(&media->player,catalog_read,media,media->directory.size))
        return 6;
    return 0;
}

unsigned h2_media_open(h2_library *media,unsigned row,unsigned offset_ms)
{
    unsigned error=h2_media_mount(media);
    return error ? error : trip_select(&media->player,row,offset_ms) ? 0 : 6;
}
unsigned h2_media_probe(uint32_t report[16],unsigned row,unsigned offset_ms)
{
    h2_library media;
    unsigned error=h2_media_open(&media,row,offset_ms);
    if (error)
        return error;
    trip_player *p=&media.player;
    report[1]=p->count;
    report[2]=p->frames;
    report[3]=p->views;
    report[4]=p->stations;
    for (unsigned i=0;i<32;++i)
        ((uint8_t *)report)[32+i]=p->title[i];
    /* 48,000 samples cover the recorded spoken word and its channel isolation. */
    uint32_t hash=2166136261, peaks[2]={0,0}, frames=0;
    while (frames<48000 && frames<p->frames) {
        int16_t pcm[256];
        unsigned limit=48000-frames;
        if (limit>128)
            limit=128;
        int n=trip_pull(p,pcm,limit);
        if (n<=0)
            return 7;
        for (unsigned i=0;i<(unsigned)n*2;++i) {
            int32_t v=pcm[i], magnitude=v<0 ? -v : v;
            if ((uint32_t)magnitude>peaks[i&1])
                peaks[i&1]=magnitude;
            hash=((hash^((uint16_t)v&255))*16777619u ^ ((uint16_t)v>>8))*16777619u;
        }
        frames+=(unsigned)n;
    }
    report[5]=frames;
    report[6]=peaks[0] | (peaks[1]<<16);
    report[7]=hash;
    return 0;
}

/* Compilers can introduce a copy even when linking without libc. */
#ifndef H2_ORIGINAL_AUDIO
void *memcpy(void *dst,const void *src,size_t length)
{
    for (size_t i=0;i<length;++i)
        ((uint8_t *)dst)[i]=((const uint8_t *)src)[i];
    return dst;
}
void *memset(void *dst,int value,size_t length)
{
    for (size_t i=0;i<length;++i)
        ((uint8_t *)dst)[i]=(uint8_t)value;
    return dst;
}
#endif
