#ifndef H2_ORIGINAL_AUDIO_H
#define H2_ORIGINAL_AUDIO_H

#include "media_probe.h"

void h2_original_close(void);
void h2_original_open(h2_library *media);
unsigned h2_original_pull(int16_t *pcm, unsigned frames);
void h2_original_status(uint32_t report[6]);

#endif
