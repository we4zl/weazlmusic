.set noreorder
.set noat
.section .entry,"ax",@progbits
.globl start_player
start_player:
    di
    mfc0 $t0, $16
    addiu $t1, $zero, -8
    and $t0, $t0, $t1
    ori $t0, $t0, 3
    mtc0 $t0, $16
    ehb
    mtc0 $zero, $28
    mtc0 $zero, $29
    ehb
    lui $t0, 0x8000
    ori $t1, $t0, 0x4000
1:  cache 8, 0($t0)
    cache 9, 0($t0)
    addiu $t0, $t0, 32
    bne $t0, $t1, 1b
    nop
    sync
    lui $sp, 0x8070
    addiu $sp, $sp, -16
    lui $t0, %hi(__bss_start)
    addiu $t0, $t0, %lo(__bss_start)
    lui $t1, %hi(__bss_end)
    addiu $t1, $t1, %lo(__bss_end)
2:  beq $t0, $t1, 3f
    nop
    sw $zero, 0($t0)
    b 2b
    addiu $t0, $t0, 4
3:  lui $t0, %hi(h2_main)
    addiu $t0, $t0, %lo(h2_main)
    jr $t0
    nop
