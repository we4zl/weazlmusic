#ifndef H2_DISCOVERY_H
#define H2_DISCOVERY_H
#include <stdint.h>
enum { H2_NEARBY=32, H2_NAME=32 };
typedef struct {
    uint8_t addr[6], repetition;
    char name[H2_NAME];
} h2_receiver;
typedef struct {
    h2_receiver receivers[H2_NEARBY];
    unsigned count, phase, naming, error;
    uint32_t deadline;
} h2_discovery;
int h2_scan_begin(h2_discovery *s,uint32_t now);
int h2_scan_poll(h2_discovery *s,uint32_t now);
#endif
