OUTPUT_ARCH(mips)
ENTRY(_start)
MEMORY { image (rwx) : ORIGIN = 0xa0200000, LENGTH = 0x38000 }
SECTIONS {
    .text : { KEEP(*(.start)) *(.text*) } >image
    .rodata : { *(.rodata*) } >image
    .data : { *(.data* .sdata* .got) } >image
    .bss (NOLOAD) : {
        . = ALIGN(4); __bss_start = .;
        *(.bss* .sbss* COMMON)
        . = ALIGN(4); __bss_end = .;
    } >image
    /DISCARD/ : { *(.MIPS.abiflags .reginfo .pdr .comment .note.* .eh_frame*) }
}
