/* Polling X1000 MSC0 in native SD mode. */
#include <stdbool.h>
#include <stdint.h>
#if BUILD_MINOR >= 27
#include "sd_write.h"
#endif
#if BUILD_MINOR >= 33
#include "boot_health.h"
#endif

#define REG(base, off) (*(volatile uint32_t *)((uintptr_t)(base) + (off)))
#define MSC(off) REG(0xb3450000u, off)
#define CPM(off) REG(0xb0000000u, off)
#define GPIO(port, off) REG(0xb0010000u, 0x100*(port)+(off))
#define TICKS REG(0xb2000000u,0x20)

enum {
    RESPONSE_END = 1u<<2, DATA_END = 1u, RESPONSE_TIMEOUT = 1u<<9,
    RESPONSE_CRC = 1u<<12, DATA_ERROR = (1u<<11)|(1u<<8), RX_EMPTY = 1u<<6,
    INIT = 1u<<7, DATA = 1u<<3, BUSY = 1u<<6, FOUR_DATA_LINES = 2u<<9,
    R1 = 1, R2 = 2, OCR = 3, APP = 55
};
static uint32_t card_sectors, bus_width;

#if BUILD_MINOR >= 30
enum { SD_WRITE_COMMAND = 1, SD_WRITE_FIFO, SD_WRITE_COMPLETION, SD_WRITE_STATUS };
static uint32_t write_fault, write_fault_lba, write_fault_flags, write_fault_status;
static uint32_t sectors_written;

#if BUILD_MINOR >= 35
static uint64_t ticks_writing, ticks_after_data;
static uint32_t operations, data_end_seen;

void h2_sd_write_timing(uint32_t out[8])
{
    out[0]=6000000;
    out[1]=operations;
    out[2]=data_end_seen;
    out[3]=sectors_written;
    out[4]=(uint32_t)ticks_writing;
    out[5]=ticks_writing>>32;
    out[6]=(uint32_t)ticks_after_data;
    out[7]=ticks_after_data>>32;
}
#endif

static int write_failed(uint32_t stage, uint32_t lba)
{
    if (!write_fault) {
        write_fault = stage;
        write_fault_lba = lba;
        write_fault_flags = MSC(0x28);
        write_fault_status = MSC(4);
    }
    return 0;
}

void h2_sd_write_report(uint32_t out[8])
{
    out[0] = bus_width ? 4 : 1;
    out[1] = CPM(0x68);
    out[2] = MSC(0x08);
    out[3] = sectors_written;
    out[4] = write_fault;
    out[5] = write_fault_lba;
    out[6] = write_fault_flags;
    out[7] = write_fault_status;
}
#endif

#if BUILD_MINOR >= 33
/* The final descriptor has ENDI set and LINK clear, as in stock V2.2. */
static volatile struct {
    uint32_t next, source, bytes, control;
} write_descriptor __attribute__((aligned(32), section(".data.sd_dma")));

static void writeback(const volatile void *address, unsigned size)
{
    uintptr_t end=(uintptr_t)address+size;
    for (uintptr_t line=(uintptr_t)address&~31u; line<end; line+=32)
        __asm__ volatile("cache 0x15, 0(%0)" :: "r"(line) : "memory");
    __asm__ volatile("sync" ::: "memory");
}

static void start_write_dma(const uint8_t *sector,unsigned count)
{
    write_descriptor.next=0;
    write_descriptor.source=(uintptr_t)sector&0x1fffffffu;
    write_descriptor.bytes=count*512;
    write_descriptor.control=2;
    writeback(sector,count*512);
    writeback(&write_descriptor,sizeof write_descriptor);
    MSC(0x48)=(uintptr_t)&write_descriptor&0x1fffffffu;
    MSC(0x44)=0x11;
}
#endif

static bool within(uint32_t start, unsigned ms)
{
    return TICKS-start < 6000*ms;
}
static void sleep_ms(unsigned ms)
{
    uint32_t start=TICKS;
    while (within(start,ms)) {}
}
static void pin_mode(unsigned bank, uint32_t mask, unsigned mode)
{
    GPIO(bank,0x18) = mask;
    if (mode==1) {
        GPIO(bank,0x38) = mask;
        GPIO(bank,0x44) = mask;
        GPIO(bank,0x28) = mask;
    } else {
        GPIO(bank,0x24) = mask;
        GPIO(bank,mode==2 ? 0x34 : 0x38) = mask;
        if (mode==0)
            GPIO(bank,0x44) = mask;
    }
}
static uint32_t response_short(void)
{
    uint32_t a = MSC(0x34)&255;
    uint32_t b = MSC(0x34)&65535;
    uint32_t c = MSC(0x34)&255;
    return a<<24 | b<<8 | c;
}
static bool command(unsigned cmd, uint32_t arg, unsigned attrs)
{
    uint32_t start=TICKS;
    MSC(0x28)=~0u;
    MSC(0x2c)=cmd;
    MSC(0x30)=arg;
    MSC(0x0c)=attrs|bus_width;
    MSC(0x00)=4;
    uint32_t flags;
    do {
        flags=MSC(0x28);
    } while (!(flags&(RESPONSE_END|RESPONSE_TIMEOUT)) && within(start,100));
    unsigned errors=RESPONSE_TIMEOUT | ((attrs&3)==OCR ? 0 : RESPONSE_CRC);
    return (flags&RESPONSE_END) && !(flags&errors);
}
static bool read_csd(uint32_t rca, uint32_t *sectors)
{
    if (!command(9,rca,R2))
        return false;
    unsigned a=MSC(0x34)&65535, b=MSC(0x34)&65535, c=MSC(0x34)&65535;
    unsigned d=MSC(0x34)&65535, e=MSC(0x34)&65535;
    uint32_t word0=(a<<24)|(b<<8)|(c>>8);
    uint32_t word1=(c<<24)|(d<<8)|(e>>8);
    unsigned f=MSC(0x34)&65535, g=MSC(0x34)&65535;
    uint32_t word2=(e<<24)|(f<<8)|(g>>8);
    (void)MSC(0x34);
    (void)MSC(0x34);
    if ((word0>>30)!=1)
        return false;
    uint32_t c_size=((word1&63)<<16)|(word2>>16);
    if (c_size==0x3fffff)
        return false; /* Sector count would not fit this board interface. */
    *sectors=(c_size+1)*1024;
    return true;
}

#if BUILD_MINOR >= 31
static bool switch_status(uint32_t argument, uint8_t result[64])
{
    MSC(0x18)=64;
    MSC(0x1c)=1;
    if (!command(6,argument,R1|DATA) || (response_short()&0xfdffe008u))
        return false;
    uint32_t start=TICKS;
    for (unsigned i=0;i<64;i+=4) {
        while (MSC(4)&RX_EMPTY)
            if ((MSC(0x28)&DATA_ERROR) || !within(start,250))
                return false;
        uint32_t word=MSC(0x38);
        for (unsigned byte=0;byte<4;++byte)
            result[i+byte]=(uint8_t)(word>>(8*byte));
    }
    while (!(MSC(0x28)&(DATA_END|DATA_ERROR)) && within(start,250)) {}
    return (MSC(0x28)&(DATA_END|DATA_ERROR))==DATA_END;
}

static bool set_high_speed(void)
{
    uint8_t status[64];
    if (!switch_status(0x00fffff1u,status))
        return false;
    if (!(status[13]&2))
        return true; /* Stay at the verified default-speed clock. */
    if (!switch_status(0x80fffff1u,status) || (status[16]&15)!=1)
        return false;

    uint32_t start=TICKS;
    while ((MSC(4)&(1u<<8)) && within(start,20)) {}
    if (MSC(4)&(1u<<8))
        return false;
#if BUILD_MINOR == 39 || BUILD_MINOR == 40
    /* Comparison with the SD high-speed limit after CMD6 selects it. */
    CPM(0x68)=0xa0000005u; /* 600 MHz / (2*6) = 50 MHz */
#else
    /* Stock hw4 caps MSC0 at 48 MHz. Use the next lower MPLL divider. */
    CPM(0x68)=0xa0000006u; /* 600 MHz / (2*7) = 42.86 MHz */
#endif
    start=TICKS;
    while ((CPM(0x68)&(1u<<28)) && within(start,20)) {}
    if (CPM(0x68)&(1u<<28))
        return false;
    CPM(0x68)&=~(1u<<29);
    MSC(0x08)=0;
    /* Stock jzmmc_set_ios selects these phases above 25 MHz. */
    MSC(0x40)=0xa0000001u;
    return true;
}
#endif

#if BUILD_MINOR >= 62
static unsigned open_card(uint32_t *sectors)
#else
unsigned h2_sd_open(uint32_t *sectors)
#endif
{
    card_sectors=0; bus_width=0;
    pin_mode(1,1u<<11,2); /* card detect */
    if (GPIO(1,0)&(1u<<11))
        return 1;
    pin_mode(1,1u<<10,0); /* card supply enable */
    sleep_ms(15);
    pin_mode(0,0x3fu<<20,1); /* MSC0 pads */
    CPM(0x20)&=~(1u<<4);
    CPM(0x68)=0xa000000bu; /* MPLL 600 MHz / (2*12) = 25 MHz */
    uint32_t start=TICKS;
    while ((CPM(0x68)&(1u<<28)) && within(start,20)) {}
    if (CPM(0x68)&(1u<<28))
        return 2;
    CPM(0x68)&=~(1u<<29);
    MSC(0)=8;
    sleep_ms(1);
    MSC(0)=0;
    start=TICKS;
    while ((MSC(4)&(1u<<15)) && within(start,20)) {}
    if (MSC(4)&(1u<<15))
        return 3;
    MSC(0x08)=6; /* ~390 kHz for initialization */
    MSC(0x24)=~0u;
    MSC(0x44)=0;
    MSC(0x40)=1; /* automatic clock management */
    MSC(0x10)=0xff;
    MSC(0x14)=0xffff;
    if (!command(0,0,INIT) || !command(8,0x1aa,R1) || (response_short()&0xfff)!=0x1aa)
        return 4;
    uint32_t ocr=0;
    for (unsigned attempt=0; attempt<100; ++attempt) {
        if (!command(APP,0,R1))
            return 5;
        (void)response_short();
        if (!command(41,0x40ff8000,OCR))
            return 6;
        ocr=response_short();
        if (ocr&0x80000000)
            break;
        sleep_ms(10);
    }
    if ((ocr&0xc0000000u)!=0xc0000000u)
        return 7;
    if (!command(2,0,R2))
        return 8;
    for (unsigned i=0;i<9;++i)
        (void)MSC(0x34);
    if (!command(3,0,R1))
        return 9;
    uint32_t rca=response_short()&0xffff0000u, size;
    if (!rca || !read_csd(rca,&size))
        return 10;
    if (!command(7,rca,R1|BUSY) || (response_short()&0xfdffe008u))
        return 11;
    sleep_ms(5);
    MSC(0x08)=1; /* 12.5 MHz, conservative single-bit read */
#if BUILD_MINOR == 28
    if (command(APP,rca,R1) && (response_short()&32) &&
        command(6,2,R1) && !(response_short()&0xfdffe008u)) {
        bus_width=FOUR_DATA_LINES;
        MSC(0x08)=0; /* 25 MHz, four data lines */
    }
#elif BUILD_MINOR >= 30
    /* Isolate bus width from the H28 clock change. Keep the H29 12.5 MHz. */
    if (command(APP,rca,R1) && (response_short()&32)) {
        /* A missing or corrupt response leaves the card width ambiguous. */
        if (!command(6,2,R1))
            return 12;
        if (!(response_short()&0xfdffe008u))
            bus_width=FOUR_DATA_LINES;
    }
#endif
#if BUILD_MINOR >= 31 && BUILD_MINOR < 62
    if (bus_width && !set_high_speed())
        return 13;
#endif
    card_sectors=size;
    *sectors=size;
    return 0;
}

#if BUILD_MINOR >= 62
static void cycle_card_power(void)
{
    /* PB10 drives the active-low SD supply. Release the data pads while
       unpowered to avoid keeping the card alive through its inputs. */
    pin_mode(0,0x3fu<<20,2);
    pin_mode(1,1u<<10,0);
    GPIO(1,0x40)=1u<<10;
    sleep_ms(30);
}

unsigned h2_sd_open(uint32_t *sectors)
{
    unsigned error=open_card(sectors);
    if (error>1) {
        cycle_card_power();
        error=open_card(sectors);
    }
    return error;
}

int h2_sd_export_speed(void)
{
    /* Playback uses the default SD clock. Negotiate the faster clock once
       when the workstation claims the card, where bulk throughput matters. */
    if (!bus_width || set_high_speed())
        return 1;
    uint32_t expected=card_sectors, found;
    cycle_card_power();
    return !h2_sd_open(&found) && found==expected;
}
#endif

unsigned h2_sd_read_diagnostic(uint32_t lba, uint8_t *out)
{
    if (lba>=card_sectors || (GPIO(1,0)&(1u<<11)))
        return 0x10000000u;
    MSC(0x18)=512;
    MSC(0x1c)=1;
    if (!command(17,lba,R1|DATA))
        return 0x20000000u | MSC(0x28);
    uint32_t response = response_short();
    if (response & 0xfdffe008u)
        return 0x30000000u | (response&0x0fffffff);
    uint32_t start=TICKS;
    for (unsigned i=0; i<512; i+=4) {
        while ((MSC(4)&RX_EMPTY) && !(MSC(0x28)&DATA_ERROR) && within(start,250)) {}
        if (MSC(4)&RX_EMPTY || MSC(0x28)&DATA_ERROR)
            return 0x40000000u | (i<<16) | (MSC(0x28)&65535u);
        uint32_t data=MSC(0x38);
        for (unsigned j=0; j<4; ++j)
            out[i+j]=(uint8_t)(data>>(8*j));
    }
    while (!(MSC(0x28)&(DATA_END|DATA_ERROR)) && within(start,250)) {}
    uint32_t flags=MSC(0x28);
    return (flags&(DATA_END|DATA_ERROR))==DATA_END ? 0 : 0x50000000u|flags;
}

int h2_sd_read(void *context, uint32_t lba, uint8_t *out)
{
    (void)context;
    if (h2_sd_read_diagnostic(lba,out)==0) return 1;
#if BUILD_MINOR >= 29
    /* Re-select the card after a failed transfer; the controller may still
       be in its data phase. Only retry an idempotent sector read. */
    uint32_t capacity=card_sectors, reopened;
    if (capacity && lba<capacity && !h2_sd_open(&reopened) && reopened==capacity)
        return h2_sd_read_diagnostic(lba,out)==0;
#endif
    return 0;
}

#if BUILD_MINOR >= 36
static bool read_multiple(uint32_t lba,uint32_t *out,unsigned count)
{
    MSC(0x18)=512;
    MSC(0x1c)=count;
    if (!command(18,lba,R1|DATA|(1u<<16)) || (response_short()&0xfdffe008u))
        return false;
    uint32_t start=TICKS;
    for (unsigned i=0;i<count*128;++i) {
        while (MSC(4)&RX_EMPTY)
            if (!within(start,500) || (MSC(0x28)&DATA_ERROR))
                return false;
        out[i]=MSC(0x38);
    }
    unsigned done=DATA_END|(1u<<15), flags;
    do {
        flags=MSC(0x28);
    } while ((flags&done)!=done && !(flags&DATA_ERROR) && within(start,500));
    return (flags&(done|DATA_ERROR))==done;
}

int h2_sd_read_blocks(uint32_t lba,uint32_t *out,unsigned count)
{
    unsigned cap=h2_sd_capacity();
    if (!count || lba>=cap || count>cap-lba || count>H2_SD_WRITE_MAX_SECTORS)
        return 0;
    if (count>1) {
        if (read_multiple(lba,out,count))
            return 1;
        uint32_t reopened;
        if (h2_sd_open(&reopened) || reopened!=cap)
            return 0;
    }
    for (unsigned i=0;i<count;++i)
        if (!h2_sd_read(0,lba+i,(uint8_t *)(out+128*i)))
            return 0;
    return 1;
}
#endif

#if BUILD_MINOR >= 27
uint32_t h2_sd_capacity(void)
{
    return GPIO(1,0)&(1u<<11) ? 0 : card_sectors;
}

#if defined(H2_WRITE_PIPELINE)
static uint32_t dma_lba,dma_count,dma_start,dma_end_tick;

static void finish_write_dma(void)
{
    MSC(0x44)=0;
    (*(volatile uint32_t *)0xb000202cu)=1u<<16;
    ticks_writing+=TICKS-dma_start;
    ++operations;
}

int h2_sd_begin_write(uint32_t lba,const uint8_t *data,unsigned count)
{
    unsigned cap=h2_sd_capacity();
    if (!count || lba>=cap || count>cap-lba || count>H2_SD_WRITE_MAX_SECTORS)
        return 0;
    dma_lba=lba;
    dma_count=count;
    dma_end_tick=0;
    dma_start=TICKS;
    h2_health_arm();
    MSC(0x18)=512;
    MSC(0x1c)=count;
    unsigned multi=count>1;
    if (!command(multi ? 25 : 24,lba,R1|DATA|0x10|(multi<<16)) ||
            (response_short()&0xfdffe008u)) {
        write_failed(SD_WRITE_COMMAND,lba);
        finish_write_dma();
        return 0;
    }
    start_write_dma(data,count);
    return 1;
}

int h2_sd_poll_write(void)
{
    uint32_t flags=MSC(0x28);
    if (!dma_end_tick && (flags&DATA_END))
        dma_end_tick=TICKS-dma_start;
    unsigned done=dma_count>1 ? (1u<<15)|2 : 2;
    if ((flags&0x400) || !within(dma_start,1500)) {
        write_failed(SD_WRITE_COMPLETION,dma_lba);
        finish_write_dma();
        return -1;
    }
    if ((flags&done)!=done) return 0;
    if (MSC(4)&0xc) {
        write_failed(SD_WRITE_STATUS,dma_lba);
        finish_write_dma();
        return -1;
    }
    if (dma_end_tick) {
        ++data_end_seen;
        ticks_after_data+=(TICKS-dma_start)-dma_end_tick;
    }
    sectors_written+=dma_count;
    finish_write_dma();
    return 1;
}
#else
static int write_blocks(uint32_t lba,const uint8_t *sector,unsigned count)
{
    unsigned cap=h2_sd_capacity();
    if (!count || lba>=cap || count>cap-lba || count>H2_SD_WRITE_MAX_SECTORS) return 0;
    MSC(0x18)=512;
    MSC(0x1c)=count;
    unsigned multi=count>1;
    if (!command(multi ? 25 : 24,lba,R1|DATA|0x10|(multi<<16)) || (response_short()&0xfdffe008u))
#if BUILD_MINOR >= 30
        return write_failed(SD_WRITE_COMMAND,lba);
#else
        return 0;
#endif
    uint32_t start=TICKS;
#if BUILD_MINOR >= 33
    start_write_dma(sector,count);
#else
    for (unsigned i=0;i<count*512;i+=4) {
        while (MSC(4)&0x80)
            if (!within(start,500) || (MSC(0x28)&0x400))
#if BUILD_MINOR >= 30
                return write_failed(SD_WRITE_FIFO,lba);
#else
                return 0;
#endif
        MSC(0x3c)=sector[i]|((uint32_t)sector[i+1]<<8)|
                  ((uint32_t)sector[i+2]<<16)|((uint32_t)sector[i+3]<<24);
    }
#endif
    unsigned done=multi ? (1u<<15)|2 : 2;
#if BUILD_MINOR >= 35
    uint32_t data_end_tick=0;
#endif
    while ((MSC(0x28)&done)!=done) {
        if (!within(start,1500) || (MSC(0x28)&0x400))
#if BUILD_MINOR >= 30
            return write_failed(SD_WRITE_COMPLETION,lba);
#else
            return 0;
#endif
#if BUILD_MINOR >= 35
        if (!data_end_tick && (MSC(0x28)&DATA_END))
            data_end_tick=TICKS-start;
#endif
    }
#if BUILD_MINOR >= 35
    if (data_end_tick) {
        ++data_end_seen;
        ticks_after_data+=(TICKS-start)-data_end_tick;
    }
#endif
#if BUILD_MINOR >= 30
    if (MSC(4)&0xc)
        return write_failed(SD_WRITE_STATUS,lba);
    sectors_written+=count;
    return 1;
#else
    return !(MSC(4)&0xc);
#endif
}

int h2_sd_write_blocks(uint32_t lba,const uint8_t *sector,unsigned count)
{
#if BUILD_MINOR >= 33
    /* Recover an unresponsive MSC bus without requiring a physical reset. */
    h2_health_arm();
#if BUILD_MINOR >= 35
    uint32_t start=TICKS;
#endif
    int result=write_blocks(lba,sector,count);
    MSC(0x44)=0;
    (*(volatile uint32_t *)0xb000202cu)=1u<<16;
#if BUILD_MINOR >= 35
    ticks_writing+=TICKS-start;
    ++operations;
#endif
    return result;
#else
    return write_blocks(lba,sector,count);
#endif
}
#endif
#endif
