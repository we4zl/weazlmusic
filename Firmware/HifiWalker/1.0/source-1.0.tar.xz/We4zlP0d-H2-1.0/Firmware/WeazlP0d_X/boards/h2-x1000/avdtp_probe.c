/* BR/EDR L2CAP and AVDTP signalling for the H2 Audio Source bench. */
#include <stdint.h>
#include "sdp_source.h"
#include "a2dp.h"
#include <stddef.h>
#ifdef H2_ORIGINAL_AUDIO
#include "original_audio.h"
#endif

int h2_h4_write(uint8_t type,const uint8_t *data,unsigned length);
unsigned h2_h4_packet(uint8_t *packet,unsigned capacity,unsigned timeout);

#define OST (*(volatile uint32_t *)0xb2000020u)
enum { MEDIA_FRAMES=6, MEDIA_MTU=672 };
static const uint8_t caps[]={1,0,7,6,0,0,0x12,0x15,2,H2_SBC_MAX_POOL};

static unsigned le16(const uint8_t *p)
{
    return p[0]|((unsigned)p[1]<<8);
}
static void put16(uint8_t *p,unsigned word)
{
    p[0]=word;
    p[1]=word>>8;
}

static int acl(h2_a2dp *link,unsigned cid,const uint8_t *payload,unsigned length)
{
    uint8_t packet[680];
    if (length>sizeof packet-8)
        return 0;
    put16(packet,link->handle|0x2000);
    put16(packet+2,length+4);
    put16(packet+4,length);
    put16(packet+6,cid);
    for (unsigned i=0;i<length;++i)
        packet[i+8]=payload[i];
    return h2_h4_write(2,packet,length+8);
}

static int signal(h2_a2dp *link,unsigned code,unsigned id,const uint8_t *data,unsigned length)
{
    uint8_t p[32];
    if (length>sizeof p-4)
        return 0;
    p[0]=code; p[1]=id; put16(p+2,length);
    for (unsigned i=0;i<length;++i)
        p[i+4]=data[i];
    return acl(link,1,p,length+4);
}


static void peer_pairing(h2_a2dp *link,const uint8_t *packet,unsigned size)
{
    if (size<9)
        return;
    for (unsigned i=0;i<6;++i)
        if (packet[3+i]!=link->peer[i])
            return;
    uint8_t cmd[25];
    unsigned opcode=0, length=6;
    switch (packet[1]) {
    case 0x16:
        opcode=0x040e; /* Legacy PIN declined. */
        break;
    case 0x17:
        if (link->key_valid) {
            opcode=0x040b;
            length=22;
            for (unsigned i=0;i<16;++i)
                cmd[9+i]=link->key[i];
        } else {
            opcode=0x040c; /* No existing bond. */
        }
        break;
    case 0x18:
        if (size==26) {
            for (unsigned i=0;i<16;++i)
                link->key[i]=packet[9+i];
            link->key_valid=1;
        }
        return;
    case 0x31:
        opcode=0x042b; /* NoInputNoOutput, no OOB, general bonding. */
        length=9;
        cmd[9]=3; cmd[10]=0; cmd[11]=4;
        break;
    case 0x33:
        opcode=0x042c; /* Just Works, only with the explicit bench peer. */
        break;
    default:
        return;
    }
    put16(cmd,opcode);
    cmd[2]=length;
    for (unsigned i=0;i<6;++i)
        cmd[3+i]=link->peer[i];
    h2_h4_write(1,cmd,length+3);
}


static void incoming_sdp(h2_a2dp *link,const uint8_t *packet,unsigned length)
{
    unsigned cid=le16(packet+7);
    if (cid==1 && length>=13) {
        unsigned code=packet[9], id=packet[10], n=le16(packet+11);
        const uint8_t *p=packet+13;
        uint8_t data[8];
        if (n>length-13)
            return;
        if (code==2 && n==4 && le16(p)==1 && le16(p+2)>=0x40) {
            link->sdp_there=le16(p+2);
            put16(data,0x42); put16(data+2,link->sdp_there);
            put16(data+4,0); put16(data+6,0);
            signal(link,3,id,data,8);
            put16(data,link->sdp_there); put16(data+2,0);
            signal(link,4,++link->request,data,4);
        } else if (code==4 && n>=4 && link->sdp_there && le16(p)==0x42) {
            put16(data,link->sdp_there); put16(data+2,0); put16(data+4,0);
            signal(link,5,id,data,6);
        } else if (code==6 && n==4 && link->sdp_there && le16(p)==0x42) {
            signal(link,7,id,p,4);
            link->sdp_there=0;
        }
    } else if (cid==0x42 && link->sdp_there) {
        uint8_t reply[96];
        unsigned size=h2_sdp_reply(packet+9,length-9,reply,sizeof reply);
        if (size)
            acl(link,link->sdp_there,reply,size);
    }
}


static void incoming_avdtp(h2_a2dp *link,const uint8_t *packet,unsigned length)
{
    if (!link->signalling.there || length<11 || le16(packet+7)!=link->signalling.here || (packet[9]&15))
        return;
    uint8_t response[16];
    response[0]=(packet[9]&0xf0)|2;
    response[1]=packet[10];
    unsigned size=0;
    switch (packet[10]) {
    case 1:
        response[2]=4|(link->configured ? 2 : 0); response[3]=0;
        size=2;
        break;
    case 2: case 12:
        if (length<12 || packet[11]!=4)
            return;
        for (unsigned i=0;i<sizeof caps;++i)
            response[i+2]=caps[i];
        size=sizeof caps;
        break;
    default:
        response[0]|=1;
        response[2]=0x31; /* unsupported command on this initiator stream */
        size=1;
        break;
    }
    acl(link,link->signalling.there,response,size+2);
}

static unsigned receive(h2_a2dp *link,uint8_t *packet,unsigned capacity,unsigned timeout)
{
    unsigned length=h2_h4_packet(packet,capacity,timeout);
    if (length>=3 && packet[0]==4) {
        if (link->event_count<sizeof link->events)
            link->events[link->event_count++]=packet[1];
        if (packet[1]==0x05)
            return 1;
        if (packet[1]==0x13 && length>=4) {
            for (unsigned n=4;n+4<=length;n+=4)
                if ((le16(packet+n)&0xfff)==link->handle) {
                    link->credit+=le16(packet+n+2);
                    if (link->credit>8)
                        link->credit=8;
                }
        }
        if (packet[1]==0x06 && length==6 && (le16(packet+4)&0xfff)==link->handle)
            link->auth_result=packet[3];
        if (packet[1]==0x08 && length==7 && (le16(packet+4)&0xfff)==link->handle)
            link->encrypt_result=packet[3] ? packet[3] : packet[6] ? 0 : 0x100;
        peer_pairing(link,packet,length);
    }
    if (length<9 || packet[0]!=2 || (le16(packet+1)&0xfff)!=link->handle ||
        (le16(packet+1)&0x3000)==0x1000 || le16(packet+3)!=length-5 ||
        le16(packet+5)!=length-9)
        return 0;
    if (le16(packet+7)==1 && length>=15 && packet[9]==10 && le16(packet+11)==2) {
        unsigned kind=le16(packet+13);
        uint8_t data[8];
        put16(data,kind); put16(data+2,kind==2 ? 0 : 1);
        for (unsigned j=4;j<sizeof data;++j)
            data[j]=0;
        signal(link,11,packet[10],data,kind==2 ? 8 : 4);
    }
    incoming_sdp(link,packet,length);
    incoming_avdtp(link,packet,length);
    return length;
}


static int authenticate(h2_a2dp *link,unsigned *result)
{
    uint8_t packet[1040];
    uint8_t cmd[6]={0x11,4,2,0,0,1};
    put16(cmd+3,link->handle);
    link->auth_result=link->encrypt_result=0xffff;
    if (!h2_h4_write(1,cmd,5))
        return 0;
    for (unsigned n=0;n<140 && link->auth_result==0xffff;++n)
        if (receive(link,packet,sizeof packet,160)==1)
            break;
    *result=link->auth_result;
    if (*result)
        return 0;
    cmd[0]=0x13; cmd[2]=3;
    if (!h2_h4_write(1,cmd,6))
        return 0;
    for (unsigned n=0;n<40 && link->encrypt_result==0xffff;++n)
        if (receive(link,packet,sizeof packet,160)==1)
            break;
    *result=link->encrypt_result;
    return *result==0;
}

static void peer_config(h2_channel *c,const uint8_t *p,unsigned length)
{
    if (length<4 || le16(p)!=c->here)
        return;
    for (unsigned i=4;i+1<length;) {
        unsigned n=p[i+1];
        if (n>length-i-2)
            return;
        if ((p[i]&127)==1 && n==2)
            c->peer_mtu=le16(p+i+2);
        i+=2+n;
    }
}
static int open_psm(h2_a2dp *link,h2_channel *c,unsigned psm,unsigned *error)
{
    uint8_t packet[1040], p[8];
    unsigned connect_id=++link->request, config_id=0;
    int peer_ready=0, local_ready=0;
    put16(p,psm); put16(p+2,c->here);
    if (!signal(link,2,connect_id,p,4))
        return 0;
    for (unsigned poll=0;poll<100;++poll) {
        unsigned n=receive(link,packet,sizeof packet,160);
        if (n==1)
            return 0;
        if (n<13 || le16(packet+7)!=1)
            continue;
        for (unsigned i=9;i+4<=n;) {
            unsigned code=packet[i], id=packet[i+1], length=le16(packet+i+2);
            const uint8_t *data=packet+i+4;
            if (length>n-i-4)
                break;
            i+=length+4;
            if (code==3 && id==connect_id && length>=8 && le16(data+2)==c->here) {
                *error=le16(data+4);
                if (*error==1)
                    continue;
                if (*error || le16(data)<0x40)
                    return 0;
                c->there=le16(data);
                put16(p,c->there); put16(p+2,0);
                p[4]=1; p[5]=2; put16(p+6,672);
                config_id=++link->request;
                if (!signal(link,4,config_id,p,8))
                    return 0;
            } else if (code==4 && c->there && length>=4 && le16(data)==c->here) {
                peer_config(c,data,length);
                put16(p,c->there); put16(p+2,0); put16(p+4,0);
                if (!signal(link,5,id,p,6))
                    return 0;
                peer_ready=1;
            } else if (code==5 && config_id && id==config_id && length>=6) {
                *error=le16(data+4);
                if (!*error)
                    local_ready=1;
                else if (*error!=4)
                    return 0;
            }
            if (local_ready && peer_ready)
                return 1;
        }
    }
    return 0;
}

static unsigned command(h2_a2dp *link,h2_channel *c,unsigned transaction,unsigned message,
                        const uint8_t *parameters,unsigned length,uint8_t reply[48],unsigned *status)
{
    uint8_t packet[1040], request[32];
    if (length>sizeof request-2)
        return 0;
    request[0]=transaction<<4; request[1]=message;
    for (unsigned i=0;i<length;++i)
        request[i+2]=parameters[i];
    if (!acl(link,c->there,request,length+2))
        return 0;
    for (unsigned poll=0;poll<25;++poll) {
        unsigned n=receive(link,packet,sizeof packet,160);
        if (n==1)
            return 0;
        if (n<11 || le16(packet+7)!=c->here || packet[9]>>4!=transaction || packet[10]!=message)
            continue;
        *status=packet[9]&15;
        if (*status!=2 || n-11>48)
            return 0;
        for (unsigned i=11;i<n;++i)
            reply[i-11]=packet[i];
        return n-11+1; /* Distinguish success with no parameters from timeout. */
    }
    return 0;
}


void h2_avdtp_setup_paired(h2_a2dp *link,unsigned handle,const uint8_t peer[6],const uint8_t *key,
                          uint32_t report[16])
{
    for (unsigned i=0;i<sizeof *link;++i)
        ((volatile uint8_t *)link)[i]=0;
    link->handle=handle&0xfff;
    link->peer=peer;
    if (key) {
        for (unsigned i=0;i<sizeof link->key;++i)
            link->key[i]=key[i];
        link->key_valid=1;
    }
    link->signalling=(h2_channel){.here=0x40,.peer_mtu=672};
    link->media=(h2_channel){.here=0x41,.peer_mtu=672};
    h2_channel *sig=&link->signalling;
    uint8_t reply[48];
    unsigned result=0xffff, stage=0x10;
    if (!authenticate(link,&result))
        goto done;
    stage=1;
    if (!open_psm(link,sig,0x19,&result))
        goto done;
    stage=2;
    unsigned n=command(link,sig,0,1,0,0,reply,&result);
    if (!n)
        goto done;
    uint8_t candidates[24];
    unsigned count=0, transaction=1;
    for (unsigned i=0;i+1<n-1;i+=2) {
        if (!(reply[i]&2) && (reply[i+1]&0xf8)==8)
            candidates[count++]=reply[i]&0xfc;
    }
    if (!count)
        goto done;
    stage=3;
    uint8_t remote=0;
    unsigned best_pool=0, min_pool=2;
    for (unsigned c=0;c<count && best_pool<H2_SBC_MAX_POOL;++c) {
        n=command(link,sig,(transaction++)&15,2,&candidates[c],1,reply,&result);
        if (n<2)
            continue;
        for (unsigned i=0;i+2<=n-1;) {
            unsigned len=reply[i+1];
            if (len>n-1-i-2)
                break;
            if (reply[i]==7 && len==6 && !reply[i+2] && !reply[i+3] &&
                (reply[i+4]&0x12)==0x12 && (reply[i+5]&0x15)==0x15 &&
                reply[i+6]>=2 && reply[i+6]<=reply[i+7] && reply[i+6]<=H2_SBC_MAX_POOL) {
                unsigned pool=reply[i+7]<H2_SBC_MAX_POOL ? reply[i+7] : H2_SBC_MAX_POOL;
                if (pool>best_pool) {
                    remote=candidates[c];
                    best_pool=pool;
                    min_pool=reply[i+6];
                }
            }
            i+=2+len;
        }
    }
    stage=4;
    if (!remote)
        goto done;
    link->seid=remote>>2;
    report[5]=n-1;
    for (unsigned i=0;i<n-1 && i<16;++i)
        ((uint8_t *)(report+6))[i]=reply[i];
    uint8_t config[2+sizeof caps];
    config[0]=remote; config[1]=4;
    for (unsigned i=0;i<sizeof caps;++i)
        config[2+i]=caps[i];
    config[sizeof config-2]=min_pool;
    config[sizeof config-1]=best_pool;
    link->bitpool=best_pool;
    if (!command(link,sig,(transaction++)&15,3,config,sizeof config,reply,&result))
        goto done;
    stage=5;
    if (!command(link,sig,(transaction++)&15,6,&remote,1,reply,&result))
        goto done;
    stage=6;
    if (!open_psm(link,&link->media,0x19,&result))
        goto done;
    unsigned mtu=link->media.peer_mtu;
    if (mtu<13+H2_SBC_FRAME_BYTES(min_pool))
        goto done;
    if (13+H2_SBC_FRAME_BYTES(link->bitpool)>mtu)
        link->bitpool=(mtu-25)/2;
    link->transaction=transaction;
    link->credit=8;
    link->volume=10;
    link->configured=1;
    stage=0;
done:
    report[0]=stage; report[1]=result;
    report[2]=sig->there; report[3]=link->media.there; report[4]=link->seid;
    report[10]=link->event_count;
    for (unsigned i=0;i<link->event_count && i<20;++i)
        ((uint8_t *)(report+11))[i]=link->events[i];
}

void h2_avdtp_setup(h2_a2dp *link,unsigned handle,const uint8_t peer[6],uint32_t report[16])
{
    h2_avdtp_setup_paired(link,handle,peer,0,report);
}

unsigned h2_a2dp_select_frame(h2_a2dp *link,unsigned row,uint32_t frame)
{
    if (link->playing)
        return 1;
#ifdef H2_ORIGINAL_AUDIO
    h2_original_close();
    link->source_checked=0;
#endif
#ifdef H2_PCM_TAP
    h2_pcm_tap_reset(&link->tap);
#endif
    unsigned error=h2_media_open(&link->library,row,0);
    link->selected=error ? 0 : row+1;
    if (!error) {
        trip_player *player=&link->library.player;
        player->position=frame<player->frames ? frame : player->frames;
    }
    for (unsigned i=0;i<sizeof link->encoder;++i)
        ((volatile uint8_t *)&link->encoder)[i]=0;
    return error;
}

unsigned h2_a2dp_select(h2_a2dp *link,unsigned row)
{
    return h2_a2dp_select_frame(link,row,0);
}

unsigned h2_a2dp_play(h2_a2dp *link,unsigned on)
{
    if (!link->configured || !link->selected)
        return 1;
    if (on==link->playing)
        return 0;
#ifdef H2_ORIGINAL_AUDIO
    if (on && !link->source_checked) {
        h2_original_open(&link->library);
        link->source_checked=1;
    }
#endif
    uint8_t reply[48], remote=link->seid<<2;
    unsigned result=0;
    if (!command(link,&link->signalling,(link->transaction++)&15,on ? 7 : 9,
                 &remote,1,reply,&result))
        return 2;
    link->playing=on;
    if (on)
        link->due=OST;
    return 0;
}

static void be32(uint8_t *p,uint32_t x)
{
    for (unsigned i=0;i<4;++i)
        p[i]=x>>(24-8*i);
}

void h2_a2dp_tick(h2_a2dp *link)
{
    if (!link->configured)
        return;
    uint8_t received[1040];
    uint32_t start=OST;
    if (receive(link,received,sizeof received,0)==1)
        link->configured=link->playing=0;
    uint32_t elapsed=OST-start;
    if (elapsed>link->receive_ticks)
        link->receive_ticks=elapsed;
    if (!link->playing || !link->credit || (int32_t)(OST-link->due)<0)
        return;
    unsigned mtu=link->media.peer_mtu<MEDIA_MTU ? link->media.peer_mtu : MEDIA_MTU;
    unsigned frame_bytes=H2_SBC_FRAME_BYTES(link->bitpool);
    unsigned limit=mtu>13 ? (mtu-13)/frame_bytes : 0;
    if (!limit) {
        link->stream_error=4;
        link->playing=0;
        return;
    }
    uint8_t packet[MEDIA_MTU];
    int16_t pcm[H2_SBC_SAMPLES*2];
    trip_player *p=&link->library.player;
    unsigned frames=0;
    link->read_ticks=link->encode_ticks=0;
    for (unsigned i=0;i<MEDIA_FRAMES && i<limit && p->position<p->frames;++i) {
        start=OST;
        unsigned used=0;
        while (used<H2_SBC_SAMPLES && p->position<p->frames) {
            unsigned wanted=H2_SBC_SAMPLES-used;
#ifdef H2_ORIGINAL_AUDIO
            if (wanted>p->frames-p->position) wanted=p->frames-p->position;
            unsigned native=h2_original_pull(pcm+2*used,wanted);
            if (native) {
                used+=native;
                p->position+=native;
                continue;
            }
#endif
            int n=trip_pull(p,pcm+2*used,wanted);
            if (n<=0) {
                link->stream_error=3;
                link->playing=0;
                return;
            }
            used+=(unsigned)n;
        }
        for (unsigned k=0;k<H2_SBC_SAMPLES*2;++k) {
            pcm[k]=k<2*used ? pcm[k]*(int)link->volume/100 : 0;
            unsigned magnitude=pcm[k]<0 ? -(int)pcm[k] : pcm[k];
            if (magnitude>link->peak[k&1])
                link->peak[k&1]=magnitude;
        }
#ifdef H2_PCM_TAP
        h2_pcm_tap_push(&link->tap,pcm,used,p->position-used,link->volume);
#endif
        uint32_t cut=OST;
        link->read_ticks+=cut-start;
        h2_sbc_encode_pool(&link->encoder,pcm,packet+13+frame_bytes*i,link->bitpool);
        link->encode_ticks+=OST-cut;
        frames+=used;
        packet[12]=i+1;
    }
    if (!frames) {
        link->stream_error=h2_a2dp_play(link,0);
        return;
    }
    packet[0]=0x80; packet[1]=0x60;
    packet[2]=link->sequence>>8; packet[3]=link->sequence;
    be32(packet+4,link->stamp);
    be32(packet+8,0x57345044u);
    unsigned size=13+packet[12]*frame_bytes;
    start=OST;
    if (size>link->media.peer_mtu || !acl(link,link->media.there,packet,size)) {
        link->stream_error=4;
        link->playing=0;
        return;
    }
    link->uart_ticks=OST-start;
    --link->credit;
    link->sequence++;
    link->stamp+=(unsigned)packet[12]*H2_SBC_SAMPLES;
    link->packet_count++;
    link->submitted_pcm+=frames;
    int32_t period=packet[12]*H2_SBC_SAMPLES*125;
    link->due+=period;
    if ((int32_t)(OST-link->due)>period) {
        link->missed_deadlines++;
        link->due=OST;
    }
}

void h2_a2dp_status(h2_a2dp *link,uint32_t report[16])
{
    report[0]=link->configured;
    report[1]=link->playing;
    report[2]=link->selected;
    report[3]=link->selected ? link->library.player.position : 0;
    report[4]=link->selected ? link->library.player.frames : 0;
    report[5]=link->packet_count;
    report[6]=link->stamp;
    report[7]=link->stream_error;
    report[8]=link->volume;
    report[9]=link->missed_deadlines;
    report[10]=link->credit;
    report[11]=link->read_ticks;
    report[12]=link->encode_ticks;
    report[13]=link->uart_ticks;
    report[14]=link->receive_ticks;
    report[15]=link->peak[0]|((uint32_t)link->peak[1]<<16);
    link->receive_ticks=0;
    link->peak[0]=link->peak[1]=0;
}
