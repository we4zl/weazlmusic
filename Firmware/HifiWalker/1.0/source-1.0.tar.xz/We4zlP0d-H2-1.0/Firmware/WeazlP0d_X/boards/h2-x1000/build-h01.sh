#!/usr/bin/env bash
set -euo pipefail
board=$(cd "$(dirname "$0")" && pwd -P)
root=$(git -C "$board" rev-parse --show-toplevel)
out="$root/Firmware/HifiWalker/H01"
work="$root/build/hifih2/H01"
mkdir -p "$work" "$out"
flags=(--target=mipsel-none-elf -march=mips32r2 -msoft-float -mno-abicalls -fno-pic -G0 -Os -ffreestanding -fno-builtin -fno-stack-protector -Wall -Wextra -Werror)
clang "${flags[@]}" -c "$board/start.S" -o "$work/start.o"
clang "${flags[@]}" -c "$board/boot_usb.c" -o "$work/usb.o"
ld.lld -m elf32ltsmip -T "$board/sram.ld" "$work/start.o" "$work/usb.o" -o "$work/H01.elf"
llvm-objcopy -O binary "$work/H01.elf" "$out/H01.bin"
(cd "$out" && sha256sum H01.bin > SHA256SUMS)
