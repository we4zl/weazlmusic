.set noreorder
.set noat
.section .entry,"ax",@progbits
.globl start_packed
start_packed:
    di
    mfc0 $t0, $16
    addiu $t1, $zero, -8
    and $t0, $t0, $t1
    ori $t0, $t0, 3
    mtc0 $t0, $16
    ehb
    mtc0 $zero, $28
    mtc0 $zero, $29
    ehb
    lui $t0, 0x8000
    ori $t1, $t0, 0x4000
1:  cache 8, 0($t0)
    cache 9, 0($t0)
    addiu $t0, $t0, 32
    bne $t0, $t1, 1b
    nop
    sync
    lui $sp, 0x8070
    lui $t0, %hi(h2_unpack_player)
    addiu $t0, $t0, %lo(h2_unpack_player)
    jr $t0
    addiu $sp, $sp, -16
