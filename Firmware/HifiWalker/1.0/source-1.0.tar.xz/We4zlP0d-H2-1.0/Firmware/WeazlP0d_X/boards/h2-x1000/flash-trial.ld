OUTPUT_ARCH(mips)
ENTRY(start_flash_trial)
SECTIONS {
    . = 0xa0400018;
    .text : SUBALIGN(4) { KEEP(*(.entry)) *(.text*) }
    .rodata : { *(.rodata*) }
    .data : { *(.data*) BYTE(0); . = ALIGN(4); }
    /DISCARD/ : { *(.MIPS.abiflags .reginfo .pdr .got .comment .note.*) }
    ASSERT(start_flash_trial == 0xa0400018, "Install trial must match USB slot")
    ASSERT(SIZEOF(.bss) == 0, "Install trial has no BSS initialization")
    ASSERT(. < 0xa04f0000, "Install trial must leave room for stack")
}
