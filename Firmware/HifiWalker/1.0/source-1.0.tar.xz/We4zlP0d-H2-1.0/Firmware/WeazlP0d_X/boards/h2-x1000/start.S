.set noreorder
.set noat
.section .start,"ax",@progbits
.globl _start
_start:
    di
    ehb
    lui $sp, 0xf400
    ori $sp, $sp, 0x3ff0
    lui $t0, %hi(__bss_start)
    addiu $t0, $t0, %lo(__bss_start)
    lui $t1, %hi(__bss_end)
    addiu $t1, $t1, %lo(__bss_end)
1:  beq $t0, $t1, 2f
    nop
    sw $zero, 0($t0)
    b 1b
    addiu $t0, $t0, 4
2:
#ifdef H2_COLD_STAGE
    jal h2_cold_main
#else
    jal h2_main
#endif
    nop
3:  b 3b
    nop
