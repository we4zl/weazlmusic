"""Exercise the X1000 cold-stage binary from SRAM without changing NAND."""
import argparse
import json
from pathlib import Path
import struct
import time
import zlib

import usb.core

from boot_pack import SRAM_LIMIT
from slot_update import player_status
from trial import Supervisor


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("port")
    cli.add_argument("bridge", type=Path)
    cli.add_argument("stage", type=Path)
    cli.add_argument("--expect", type=int, choices=(5, 13, 15), default=5)
    cli.add_argument("--return-to", type=int, help="Require return to this installed build after a timed SRAM trial")
    args = cli.parse_args()
    image = args.stage.read_bytes()
    if not 0 < len(image) <= SRAM_LIMIT or len(image) % 4:
        cli.error("Cold stage does not fit the SRAM program region")
    sup = Supervisor(args.port)
    if (args.expect==5 and sup.version!=4) or sup.status()["ddr"]!=1:
        cli.error("Expected a supported H2 supervisor with working DDR")
    if sup.version not in (4, 5, 11, 13, 15):
        before=player_status(sup.usb)
        if before["playing"] or before["volume"]:
            cli.error("Pause and mute the active player before the SRAM trial")
    if sup.status()["active"] == 0 and sup.switch(0x48)["active"] != 1:
        raise RuntimeError("Could not return to the known fallback trial")
    if sup.stage(0, 0x4830324c, args.bridge.read_bytes())["state"] != 2:
        raise RuntimeError("X rejected the SRAM bridge")
    sup.cmd(0x47)

    def read(command):
        return bytes(sup.usb.ctrl_transfer(0xc0, command, 0, 0, 4, timeout=2500))

    def word(command, value):
        sup.cmd(command, value & 65535, value >> 16)

    if read(0x60) != b"H02L":
        raise RuntimeError("X did not enter the SRAM bridge")
    try:
        word(0x61, len(image))
        for (value,) in struct.iter_unpack("<I", image):
            word(0x62, value)
        word(0x63, zlib.crc32(image))
        if read(0x64) != b"\x01\0\0\0":
            raise RuntimeError("The SRAM bridge could not verify the stage")
    except Exception:
        sup.cmd(0x66)
        raise
    print(json.dumps({"sram_bytes": len(image), "crc32": zlib.crc32(image)}), flush=True)
    try:
        sup.cmd(0x65)
    except usb.core.USBError as error:
        if error.errno not in (5, 19):
            raise
    saw_candidate = False
    for _ in range(70):
        time.sleep(.2)
        try:
            stage = Supervisor(args.port)
            state = stage.status()
            if not saw_candidate and stage.version == args.expect and state["ddr"] == 1:
                saw_candidate = True
                print(json.dumps({"event": "sram_candidate", "version": stage.version, **state}), flush=True)
                if args.return_to is None:
                    return
            if (args.return_to is not None and stage.version == args.return_to
                    and stage.usb.address != sup.usb.address):
                final = player_status(stage.usb)
                print(json.dumps({"event": "installed_return", "version": stage.version,
                                  "address": stage.usb.address, **final}), flush=True)
                if final["volume"] or final["playing"]:
                    raise RuntimeError("The installed build returned without pausing and muting")
                if not saw_candidate:
                    raise RuntimeError("Watchdog returned to the installed build before the SRAM candidate identified")
                return
        except (OSError, ValueError, usb.core.USBError):
            continue
    if saw_candidate:
        raise TimeoutError(f"The installed H{args.return_to:02} did not return after the SRAM trial")
    raise TimeoutError(f"The cold-stage trial did not return a new H{args.expect:02} nonce")


if __name__ == "__main__":
    main()
