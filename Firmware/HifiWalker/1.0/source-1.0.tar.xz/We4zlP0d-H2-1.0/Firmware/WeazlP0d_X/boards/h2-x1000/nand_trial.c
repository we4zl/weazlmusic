/* Temporary USB owner for the read-only flash and SD inventories. */
#include <stdint.h>
#include "a2dp.h"
#define USB(off) (*(volatile uint32_t *)(0xb3500000u+(off)))
#define CLOCK(off) (*(volatile uint32_t *)(0xb0000000u+(off)))
#define OST (*(volatile uint32_t *)0xb2000020u)
unsigned h2_nand_info(uint32_t info[4]);
unsigned h2_nand_page(unsigned page, uint32_t words[528], unsigned *status);
unsigned h2_sd_open(uint32_t *sectors);
void h2_pmic_probe(uint32_t report[8]);
void h2_hci_probe(uint32_t report[9],unsigned rails,unsigned keep);
void h2_hci_stop(void);
void h2_hci_link(const uint8_t peer[6],uint32_t report[8],int keep);
unsigned h2_media_probe(uint32_t report[16],unsigned row,unsigned offset_ms);
unsigned h2_sd_read_diagnostic(uint32_t lba, uint8_t *out);

static unsigned cycle_counter(void)
{
    unsigned count;
    __asm__ volatile ("mfc0 %0, $9" : "=r"(count));
    return count;
}

static void measure_clock(uint32_t report[4])
{
    report[0]=CLOCK(0);
    report[1]=CLOCK(0x14);
    uint32_t start=OST, count=cycle_counter();
    unsigned limit=1000000;
    while (limit && OST-start<12000)
        --limit;
    report[2]=cycle_counter()-count;
    report[3]=!limit;
}

static void reply(const uint32_t *data, unsigned length)
{
    USB(0x910) = (1u<<19) | length;
    USB(0x900) |= 0x84000000;
    for (unsigned i=0; i<length/4; ++i)
        USB(0x1000) = data[i];
}

uint32_t inspect_nand(uint32_t cookie)
{
    extern volatile uint32_t __bss_start[],__bss_end[];
    for (volatile uint32_t *out=__bss_start; out<__bss_end; ++out) *out=0;
    uint32_t words[528], info[5], result[2] = {1,0};
    for (unsigned i=0; i<5; ++i) ((volatile uint32_t *)info)[i]=0;
    uint32_t setup[2];
    uint32_t sd[2] = {0,0};
    uint32_t media[16], hci[9], pmic[8], link[8], avdtp[16];
    uint32_t clock_report[4]={0,0,0,0};
    for (unsigned i=0;i<16;++i) ((volatile uint32_t *)media)[i]=0;
    uint8_t peer[6];
    h2_a2dp stream;
    stream.configured=0;
    stream.selected=0;
    stream.playing=0;
    uint32_t stream_report[16];
    for (unsigned i=0;i<16;++i) ((volatile uint32_t *)stream_report)[i]=0;
    unsigned peer_first=0;
    int got = 0, finish = 0;
    info[4] = h2_nand_info(info);
    for (unsigned i=0;i<9;++i) ((volatile uint32_t *)hci)[i]=0;
    for (unsigned i=0;i<8;++i) ((volatile uint32_t *)pmic)[i]=((volatile uint32_t *)link)[i]=0;
    for (unsigned i=0;i<16;++i) ((volatile uint32_t *)avdtp)[i]=0;
    uint32_t id = info[0]&65535;
    int known_nand = id==0xaaef || id==0x51c8 || id==0xd1c8 || id==0xc1c8 ||
                     id==0x119b || id==0x110b || id==0x719b ||
                     id==0x71e5 || id==0x21e5 || id==0x41c8 || id==0x129b;
    for (;;) {
        uint32_t in = USB(0x908);
        if (in&1) {
            USB(0x908) = in;
            if (finish)
                break;
        }
        if (USB(0x14)&(1u<<12))
            break;
        h2_a2dp_tick(&stream);
        while (USB(0x14)&(1u<<4)) {
            uint32_t st = USB(0x20);
            unsigned length=(st>>4)&2047, is_setup=(st&0x1e000f)==0xc0000 && length==8;
            for (unsigned i=0; i<(length+3)/4; ++i) {
                uint32_t data=USB(0x1000);
                if (is_setup)
                    setup[i]=data;
            }
            got |= is_setup;
        }
        uint32_t out = USB(0xb08);
        if (!out)
            continue;
        USB(0xb08) = out;
        if ((out&8) && got) {
            unsigned req=setup[0]&65535, val=setup[0]>>16, idx=setup[1]&65535, len=setup[1]>>16;
            got=0;
            if (req==0x70c0 && !val && !idx && len==sizeof info)
                reply(info,sizeof info);
            else if (req==0x7140 && !idx && !len && !info[4] && known_nand) {
                reply(0,0);
                result[0]=h2_nand_page(val,words,&result[1]);
            } else if (req==0x72c0 && !idx && !result[0] && len && len<=64 && !(len&3) &&
                       !(val&3) && val+len<=sizeof words)
                reply(words+val/4,len);
            else if (req==0x73c0 && !val && !idx && len==sizeof result)
                reply(result,sizeof result);
            else if (req==0x7440 && !val && !idx && !len) {
                finish=1;
                reply(0,0);
            } else if (req==0x7540 && !val && !idx && !len) {
                reply(0,0);
                sd[1]=0;
                sd[0]=h2_sd_open(&sd[1]);
            } else if (req==0x76c0 && !val && !idx && len==sizeof sd) {
                reply(sd,sizeof sd);
            } else if (req==0x7740 && !len && !sd[0] && sd[1]) {
                reply(0,0);
                result[1]=h2_sd_read_diagnostic(val|((uint32_t)idx<<16), (uint8_t *)words);
                result[0]=result[1] ? 7 : 0;
                /* Only expose the 512-byte sector through request 0x72. */
                for (unsigned w=128;w<528;++w) ((volatile uint32_t *)words)[w]=0;
            } else if (req==0x7840 && !len) {
                reply(0,0);
                media[0]=h2_media_probe(media,val,idx);
            } else if (req==0x79c0 && !val && !idx && len==sizeof media) {
                reply(media,sizeof media);
            } else if (req==0x7a40 && !len && !(val&~0x3eu) && idx<=1) {
                reply(0,0);
                for (unsigned i=0;i<9;++i) ((volatile uint32_t *)hci)[i]=0;
                h2_hci_probe(hci,val,idx);
            } else if (req==0x7bc0 && !val && !idx && len==sizeof hci) {
                reply(hci,sizeof hci);
            } else if (req==0x7c40 && !len && !val && !idx) {
                reply(0,0);
                h2_pmic_probe(pmic);
            } else if (req==0x7dc0 && !val && !idx && len==sizeof pmic) {
                reply(pmic,sizeof pmic);
            } else if (req==0x7e40 && !len) {
                peer[0]=val; peer[1]=val>>8; peer[2]=idx; peer[3]=idx>>8;
                peer_first=1;
                reply(0,0);
            } else if (req==0x7f40 && !len && idx<=1 && peer_first) {
                peer[4]=val; peer[5]=val>>8;
                peer_first=0;
                reply(0,0);
                for (unsigned i=0;i<8;++i) ((volatile uint32_t *)link)[i]=0;
                h2_hci_link(peer,link,idx);
            } else if (req==0x80c0 && !val && !idx && len==sizeof link) {
                reply(link,sizeof link);
            } else if (req==0x8140 && !val && !idx && !len && !link[0] && link[3]) {
                reply(0,0);
                h2_avdtp_setup(&stream,link[3],peer,avdtp);
            } else if (req==0x82c0 && !val && !idx && len==sizeof avdtp) {
                reply(avdtp,sizeof avdtp);
            } else if (req==0x8340 && !idx && !len && stream.configured) {
                reply(0,0);
                stream.stream_error=h2_a2dp_select(&stream,val);
            } else if (req==0x8440 && !idx && !len && val<=1 && stream.configured) {
                reply(0,0);
                stream.stream_error=h2_a2dp_play(&stream,val);
            } else if (req==0x85c0 && !val && !idx && len==sizeof stream_report && stream.configured) {
                h2_a2dp_status(&stream,stream_report);
                reply(stream_report,sizeof stream_report);
            } else if (req==0x8640 && !idx && !len && val<=40 && stream.configured) {
                stream.volume=val;
                reply(0,0);
            } else if (req==0x8740 && !idx && !len && !val && !stream.configured) {
                reply(0,0);
                measure_clock(clock_report);
            } else if (req==0x88c0 && !val && !idx && len==sizeof clock_report) {
                reply(clock_report,sizeof clock_report);
            } else {
                USB(0x900)|=1u<<21;
                USB(0xb00)|=1u<<21;
            }
        }
        USB(0xb10)=0x60080040;
        USB(0xb00)|=0x84000000;
    }
    h2_hci_stop();
    return 0x4830334eu ^ cookie;
}
