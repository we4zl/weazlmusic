/* One RGB565 scanline at a time. Album and receiver data still come from the player. */
enum shop_scene { COUNTER, BINS, BOOTH, BENCH };
struct shop_banner { uint16_t palette[256]; uint8_t pixels[80][256]; };
#if BUILD_MINOR >= 55 && BUILD_MINOR < 59
static struct shop_banner shop_banners[4];
extern const uint8_t shop_packed[], shop_packed_end[];
#else
extern const struct shop_banner shop_banners[4];
#endif

#if BUILD_MINOR >= 45
static void recent_row(unsigned y,uint8_t *line)
{
#if BUILD_MINOR >= 47
    /* This RAM previously held the legacy Home wallpaper. Cache the dimmed scene. */
    static unsigned prepared;
    if (!prepared) {
        const struct shop_banner *b=&shop_banners[BINS];
        for (unsigned sy=0;sy<H;++sy) for (unsigned x=0;x<W;++x) {
            unsigned c=b->palette[b->pixels[sy/3][145+x/3]];
            c=(c&0xf7de)>>1;
            if (sy>=24) c=(c&0xf7de)>>1;
            wallpaper[(sy*W+x)*2]=c>>8; wallpaper[(sy*W+x)*2+1]=c;
        }
        prepared=1;
    }
#if BUILD_MINOR >= 48
    for (unsigned j=0;j<W/2;++j)
        ((uint32_t *)line)[j]=((const uint32_t *)wallpaper)[y*(W/2)+j];
#else
    for (unsigned j=0;j<W*2;++j) line[j]=wallpaper[y*W*2+j];
#endif
#else
    const struct shop_banner *b=&shop_banners[BINS];
    const uint8_t *src=b->pixels[y/3];
    for (unsigned x=0;x<W;++x) {
        unsigned c=b->palette[src[145+x/3]];
        c=((c & 0xf7de)>>1);
        if (y>=24) c=((c & 0xf7de)>>1);
        line[2*x]=c>>8; line[2*x+1]=c;
    }
#endif
    if (y<24) {
        draw_text(y,8,1,229,1,"New in the Crates",INK,line);
        if ((int32_t)(volume_until-now)>0) {
            char level[]={'V','o','l',' ', '0'+volume/10,'0'+volume%10,'%',0};
            draw_text(y,BUILD_MINOR>=52 ? 184 : 235,2,84,0,volume==100 ? "Vol 100%" : level,ACCENT,line);
        }
        return;
    }
    unsigned slot=(y-24)/24, dy=(y-24)%24, row=first+slot;
    if (!count) {
        draw_text(y,10,42,300,1,storage_error ? "Insert the library card" : "No recent albums",INK,line);
        return;
    }
    if (row>=count) return;
    int active=row==cursor;
#if BUILD_MINOR >= 49
    if (active) span(line,0,4,0xfdaf);
#else
    if (active) span(line,0,W,0xfdaf);
#endif
    const struct recent_album *album=&recent_albums[row%RECENT_CACHE];
    if (album->tag==row+1 && album->received==COVER_BYTES && dy>=2 && dy<22) {
        for (unsigned j=0;j<40;++j) line[12+j]=album->thumb[40*(dy-2)+j];
    }
#if BUILD_MINOR >= 50
    if (album->tag==row+1 && (!active || album->width<=281)) {
        uint16_t color=active ? 0xfdaf : INK;
        for (unsigned j=0;j<sizeof album->glyphs[dy];++j) {
            unsigned bits=album->glyphs[dy][j];
            while (bits) {
                unsigned bit=__builtin_ctz(bits);
                unsigned at=2*(33+8*j+bit);
                line[at]=color>>8; line[at+1]=color;
                bits&=bits-1;
            }
        }
        return;
    }
#endif
    unsigned top=25+slot*24;
#if BUILD_MINOR >= 64
    if (active) focused_text(y,33,top,281,1,labels[slot],0xfdaf,line);
#else
    if (active) ui_marquee_row(y,33,top,281,1,labels[slot],BUILD_MINOR>=49 ? 0xfdaf : 0x1882,now,line);
#endif
    else draw_text(y,33,top,281,1,labels[slot],INK,line);
}
#endif

#if BUILD_MINOR >= 52
static void battery_row(unsigned y,uint8_t *line)
{
    if (y>=18) return;
    char text[]="100%";
    const char *label="--%";
    if (battery_percent>=0) {
        text[1]='0'+battery_percent/10%10;
        text[2]='0'+battery_percent%10;
        label=text+(battery_percent==100 ? 0 : battery_percent>=10 ? 1 : 2);
    }
    draw_text(y,261,1,34,0,label,INK,line);
    if (y<4 || y>13) return;
    span(line,296,19,MUTED);
    if (y>4 && y<13) {
        span(line,297,17,0x18a2);
        if (battery_percent>0)
            span(line,297,(battery_percent*17+99)/100,battery_percent<=15 ? 0xfdaf : 0xc7ce);
    }
    if (y>=7 && y<=10) span(line,315,2,MUTED);
}
#endif
static void shop_row(unsigned y,uint8_t *line)
{
#if BUILD_MINOR >= 45
    if (recent_page()) {
        recent_row(y,line);
#if BUILD_MINOR >= 52
        battery_row(y,line);
#endif
        return;
    }
#endif
    const int broadcast=page==PLAYING && !storage_error && on_station();
    enum shop_scene scene=BENCH;
    const char *title="";
    switch (page) {
    case HOME: scene=alternate_home; title="Home"; break;
#if BUILD_MINOR >= 58
    case MUSIC: scene=BINS; title="Music"; break;
#endif
    case SHELVES: scene=BINS; title=shelf_title(); break;
    case TRACKS: scene=BINS; title=view.title; break;
    case PLAYING: scene=broadcast ? BOOTH : COUNTER; title=broadcast ? "On air" : "Now Playing"; break;
    case STATIONS: scene=BOOTH; title="Flight Recorder"; break;
    case RADIO: title="Bluetooth"; break;
    case SETTINGS: title="Settings"; break;
    case DOCK: title="USB Dock"; break;
#if BUILD_MINOR >= 55
    case RESTART_RECORDING: scene=BOOTH; title="Flight Recorder"; break;
#endif
    }
    static const uint16_t accents[]={0xc7ce,0xfdaf,0xfd7b,0xf66e};
    uint16_t accent=accents[scene];
#if BUILD_MINOR >= 63
    const unsigned compact=browse_list();
    const unsigned list_top=compact ? BROWSE_TOP : LIST_TOP;
    const unsigned row_height=compact ? BROWSE_ROW : LIST_ROW;
#else
    const unsigned list_top=118, row_height=25;
#endif
#if BUILD_MINOR >= 55
    if (page==RESTART_RECORDING) {
        span(line,0,W,0x18a2);
        if (y<36 || y>=206) return;
        span(line,14,292,0x2924);
        if (y<39) span(line,14,292,accent);
        draw_text(y,25,55,266,2,"Restart recording?",INK,line);
        draw_text(y,25,90,266,0,"This clears your saved position.",MUTED,line);
        for (unsigned i=0;i<2;++i) {
            unsigned top=119+35*i;
            if (cursor==i && y>=top && y<top+30) span(line,24,272,accent);
            draw_text(y,34,top+5,250,1,labels[i],cursor==i ? BACKGROUND : INK,line);
        }
        return;
    }
#endif
    span(line,0,W,y>=218 ? 0x2924 : 0x18a2);
    if (y<18) {
        draw_text(y,8,1,BUILD_MINOR>=52 ? 204 : 260,0,library.pod_name[0] ? library.pod_name : "We4zlP0d X",INK,line);
        #if BUILD_MINOR >= 52
        draw_text(y,216,1,42,0,version,MUTED,line);
        battery_row(y,line);
#else
        draw_text(y,270,1,48,0,version,MUTED,line);
#endif
    } else if (y<list_top) {
        const struct shop_banner *b=&shop_banners[scene];
        const uint8_t *row=b->pixels[(y-18)*4/5];
        for (unsigned x=0;x<W;++x) {
            unsigned color=b->palette[row[x*4/5]];
#if BUILD_MINOR >= 63
            if (compact) color=(color&0xe79c)>>2;
#endif
            line[2*x]=color>>8; line[2*x+1]=color;
        }
#if BUILD_MINOR >= 63
        if (compact) {
#if BUILD_MINOR >= 64
            focused_text(y,10,19,300,1,title,INK,line);
#else
            ui_marquee_row(y,10,19,300,1,title,INK,now,line);
#endif
            return;
        }
#endif
        if (page==SHELVES && shelf_kind==TRIP_RECENT) {
            draw_text(y,9,42,145,2,"New in",INK,line);
            draw_text(y,9,68,150,2,"the Crates",INK,line);
        } else if (page==TRACKS) {
            ui_marquee_row(y,8,52,165,1,title,INK,now,line);
        } else draw_text(y,8,51,185,2,title,INK,line);
    } else if (y<218 && count) {
        unsigned i=(y-list_top)/row_height, row=first+i;
#if BUILD_MINOR >= 63
        if (compact && i>=BROWSE_COUNT) return;
#endif
        if (row<count) {
            int active=row==cursor;
            if (active) {
#if BUILD_MINOR >= 63
                if (compact) {
                    span(line,0,W,0x3986);
                    span(line,0,4,accent);
                } else
#endif
                    span(line,0,W,accent);
            }
#if BUILD_MINOR >= 63
            else if (compact && (row&1)) span(line,0,W,0x20e3);
#endif
            unsigned left=11;
            if (page==SHELVES) {
                if (TILE(i).offset && TILE(i).received==COVER_BYTES) {
                    unsigned dy=(y-list_top)%row_height;
                    if (dy>=2 && dy<22) {
                        const uint8_t *src=TILE(i).pixels+2*COVER_SIDE*((dy-2)*4);
                        for (unsigned x=0;x<20;++x) {
                            line[2*(7+x)]=src[8*x];
                            line[2*(7+x)+1]=src[8*x+1];
                        }
                    }
                }
                left=34;
            }
            unsigned top=list_top+2+i*row_height;
            uint16_t selected=0x1882;
#if BUILD_MINOR >= 63
            if (compact) selected=INK;
#endif
#if BUILD_MINOR >= 64
            if (active) focused_text(y,left,top,W-left-8,1,labels[i],selected,line);
#else
            if (active) ui_marquee_row(y,left,top,W-left-8,1,labels[i],selected,now,line);
#endif
            else draw_text(y,left,top,W-left-8,1,labels[i],INK,line);
        }
    }
    if (page==PLAYING && y>=118 && y<218) {
        unsigned left=cover_ready ? 95 : 10;
        if (cover_ready && y>=123 && y<203) {
            const uint8_t *src=cover+(y-123)*160;
            for (unsigned i=0;i<160;++i) line[16+i]=src[i];
        }
#if BUILD_MINOR >= 64
        focused_text(y,left,125,W-left-6,1,library.player.title,INK,line);
        focused_text(y,left,151,W-left-6,0,library.player.artist,MUTED,line);
#else
        ui_marquee_row(y,left,125,W-left-6,1,library.player.title,INK,now,line);
        ui_marquee_row(y,left,151,W-left-6,0,library.player.artist,MUTED,now,line);
#endif
        draw_text(y,left,179,W-left-4,0,audio.playing ? "Playing" : audio.configured ? "Paused" : "Connect Bluetooth",accent,line);
        if (y>=207 && y<210) {
            uint32_t frames=library.player.frames, pos=active_position();
            if (pos>frames) pos=frames;
            if (frames>UINT32_MAX/300u) {frames>>=9; pos>>=9;}
            span(line,10,300,0x3986);
            if (frames) span(line,10,300u*pos/frames,accent);
        }
    } else if (page==DOCK) {
        draw_text(y,10,135,298,1,"SD card on USB",INK,line);
        draw_text(y,10,174,300,0,"Eject the card to resume playback",MUTED,line);
    } else if (!count && (page==SHELVES || page==TRACKS || page==STATIONS))
        draw_text(y,10,135,300,0,storage_error ? "Insert the library card" : "No entries available",MUTED,line);

    if (y<218) return;
#if BUILD_MINOR >= 64
    const char *footer="";
#else
    const char *footer="We4zlP0d X";
#endif
    char status[64], time[10];
    if (page==RADIO) {
        if (audio.configured) {receiver_label(status,sizeof status,"Connected: ",peer_name,peer); footer=status;}
        else footer=connecting ? "Connecting..." : nearby.phase || scan_pending ? "Scanning..." :
                    radio_error ? "Try pairing mode and scan again" : save_pending ? "Saving receiver..." :
                    scanned && !nearby.count ? "No nearby devices found" : "Select a receiver";
    } else if (page==SETTINGS) footer=storage_error ? "SD library unavailable" : "SD library ready";
    else if (page==PLAYING) {playback_time(active_position(),time);footer=time;}
#if BUILD_MINOR >= 55
    else if (page==STATIONS && count) {
        playback_time(on_station() ? active_position() : station_frame,time);
        receiver_label(status,sizeof status,"Resume at ",time,peer);
        footer=status;
    }
#endif
    if ((int32_t)(volume_until-now)>0 || page==PLAYING) {
        char level[]={'V','o','l',' ', '0'+volume/10,'0'+volume%10,'%',0};
        draw_text(y,238,220,80,0,volume==100 ? "Vol 100%" : level,accent,line);
    }
    draw_text(y,9,220,225,0,footer,MUTED,line);
}
