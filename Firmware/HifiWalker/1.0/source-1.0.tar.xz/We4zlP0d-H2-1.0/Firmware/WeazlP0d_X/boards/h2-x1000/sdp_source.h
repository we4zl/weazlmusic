#ifndef H2_SDP_SOURCE_H
#define H2_SDP_SOURCE_H
#include <stdint.h>
unsigned h2_sdp_reply(const uint8_t *packet,unsigned size,uint8_t *response,unsigned capacity);
#endif
