/* Bluetooth menu and reconnection policy for the H2 player. */
#include "discovery.h"

static h2_discovery nearby;
static h2_bond bonds[H2_SAVED];
static unsigned saved_count, next_saved, scan_pending, auto_enabled, scanned;
static unsigned replace_key, skip_key, connecting;
static uint32_t retry_at;
static char peer_name[H2_NAME];

static int same_receiver(const uint8_t a[6],const uint8_t b[6])
{
    for (unsigned i=0;i<6;++i) if (a[i]!=b[i]) return 0;
    return 1;
}

static void reload_bonds(void)
{
    int n=h2_bonds_load(bonds);
    saved_count=n>0 ? (unsigned)n : 0;
    bond_available=n<0 ? -1 : !!n;
    if (saved_count) saved_bond=bonds[0];
}

static void receiver_label(char *out,unsigned size,const char *prefix,const char *name,const uint8_t addr[6])
{
    char address[18];
    const char hex[]="0123456789ABCDEF";
    for (unsigned i=0;i<6;++i) {
        unsigned v=addr[5-i];
        address[3*i]=hex[v>>4];
        address[3*i+1]=hex[v&15];
        address[3*i+2]=i==5 ? 0 : ':';
    }
    unsigned at=0;
    while (*prefix && at+1<size) out[at++]=*prefix++;
    copy_text(out+at,*name ? name : address,size-at);
}

static unsigned receiver_rows(void)
{
#if BUILD_MINOR >= 55
    if (connecting) return 1;
#endif
    return 1+!!audio.configured+saved_count+nearby.count;
}

static void receiver_row(unsigned row,char *out,unsigned size)
{
    if (!row) {
#if BUILD_MINOR >= 55
        if (connecting) {
            copy_text(out,"Cancel connection",size);
            return;
        }
#endif
        copy_text(out,scan_pending || nearby.phase ? "Scanning..." :
                  audio.configured ? "Disconnect and scan" : "Scan for headphones",size);
    } else if (audio.configured && row==1) {
        copy_text(out,"Disconnect",size);
    } else {
        unsigned i=row-1-!!audio.configured;
        if (i<saved_count)
            receiver_label(out,size,"Saved: ",bonds[i].name,bonds[i].peer);
        else {
            h2_receiver *r=&nearby.receivers[i-saved_count];
            receiver_label(out,size,"",r->name,r->addr);
        }
    }
}

static void release_receiver(void)
{
#if BUILD_MINOR >= 55
    checkpoint_station();
#endif
    parked_frame=active_position();
#ifdef H2_ORIGINAL_AUDIO
    h2_original_close();
#endif
    audio.configured=audio.playing=audio.selected=audio.key_valid=0;
    h2_hci_stop();
    nearby.phase=scan_pending=connect_pending=connecting=save_pending=0;
    peer_set=radio_error=bond_result=0;
}

static void queue_receiver(const uint8_t addr[6],const char *name,int discovered)
{
#if BUILD_MINOR >= 57
    automatic_receiver=0;
#endif
    for (unsigned i=0;i<6;++i) peer[i]=addr[i];
    copy_text(peer_name,name,sizeof peer_name);
    peer_set=connect_pending=connecting=1;
    auto_enabled=1;
    replace_key=discovered;
    skip_key=0;
    bond_result=radio_error=0;
    for (unsigned i=0;i<saved_count;++i)
        if (same_receiver(peer,bonds[i].peer)) {
            saved_bond=bonds[i];
            break;
        }
}

static void select_receiver(unsigned row)
{
    if (row>=receiver_rows()) return;
    if (!row) {
        release_receiver();
        nearby.count=scanned=auto_enabled=0;
        scan_pending=1;
    } else if (audio.configured && row==1) {
        release_receiver();
        auto_enabled=0;
    } else {
        unsigned i=row-1-!!audio.configured;
        release_receiver();
        if (i<saved_count)
            queue_receiver(bonds[i].peer,bonds[i].name,0);
        else {
            h2_receiver *r=&nearby.receivers[i-saved_count];
            queue_receiver(r->addr,r->name,1);
        }
    }
    cursor=0;
}

static void receiver_tick(void)
{
    if (scan_pending) {
        /* Let the first complete menu frame display the scan feedback. */
        if (page==RADIO && !screen_dark && !paint_idle()) return;
        uint32_t info[9]={0};
        scan_pending=0;
        scanned=1;
#if BUILD_MINOR >= 55
        radio_cancel=0;
        radio_busy=1;
#endif
        h2_hci_probe(info,4,1);
        radio_error=info[0];
        if (!radio_error && !h2_scan_begin(&nearby,now))
            radio_error=nearby.error;
#if BUILD_MINOR >= 55
        radio_busy=0;
        if (radio_cancel) release_receiver();
#endif
        refresh();
    } else if (nearby.phase) {
        if (h2_scan_poll(&nearby,now)) {
            radio_error=nearby.error;
            if (!nearby.phase) h2_hci_stop();
            refresh();
        }
    } else if (!connect_pending && !audio.configured && auto_enabled && saved_count &&
#if BUILD_MINOR >= 55
#if BUILD_MINOR == 55
               !waiting_to_undock &&
#endif
               frame_rows==H &&
#else
               page!=RADIO &&
#endif
               (int32_t)(now-retry_at)>=0) {
        unsigned i=next_saved++%saved_count;
        queue_receiver(bonds[i].peer,bonds[i].name,0);
#if BUILD_MINOR >= 57
        automatic_receiver=1;
#endif
        refresh();
    }
}
