#ifndef H2_INPUT_H
#define H2_INPUT_H

#include <stdint.h>

enum h2_button {
    H2_PLAY=1, H2_VOLUME_UP=2, H2_VOLUME_DOWN=4, H2_BACK=8,
    H2_MENU=16, H2_PREVIOUS=32, H2_NEXT=64, H2_POWER=128,
};

typedef struct {
    uint32_t changed;
    uint8_t candidate, stable, last_wheel, armed;
    int8_t wheel;
} h2_input;

typedef struct { uint8_t pressed, released; int wheel; } h2_input_event;

void h2_input_begin(h2_input *);
h2_input_event h2_input_poll(h2_input *,uint32_t now);
#endif
