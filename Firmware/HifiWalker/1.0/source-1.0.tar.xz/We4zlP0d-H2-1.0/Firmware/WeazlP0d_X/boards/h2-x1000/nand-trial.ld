OUTPUT_ARCH(mips)
ENTRY(start_nand_trial)
SECTIONS {
    . = 0xa0400018;
    .entry : SUBALIGN(4) { KEEP(*(.entry)) }
    . = ALIGN(16) - 0x20000000;
    .text : AT(ADDR(.text) + 0x20000000) SUBALIGN(4) { *(.text*) }
    .rodata : AT(ADDR(.rodata) + 0x20000000) { *(.rodata*) }
    .data : AT(ADDR(.data) + 0x20000000) { *(.data*) BYTE(0); . = ALIGN(4); }
    .bss (NOLOAD) : SUBALIGN(4) { __bss_start = .; *(.bss*) *(.sbss*) . = ALIGN(4); __bss_end = .; }
    /DISCARD/ : { *(.MIPS.abiflags .reginfo .pdr .got .comment .note.*) }
    ASSERT(SIZEOF(.bss) <= 16, "Initialize the board trial state before entering")
    ASSERT(start_nand_trial == 0xa0400018, "NAND trial entry must match USB slot")
    ASSERT(__bss_end <= 0x804f0000, "Hold room for the media trial stack")
}
