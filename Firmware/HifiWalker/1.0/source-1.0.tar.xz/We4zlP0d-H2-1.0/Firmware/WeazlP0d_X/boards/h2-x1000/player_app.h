#ifndef H2_PLAYER_APP_H
#define H2_PLAYER_APP_H
#include <stdint.h>

void h2_player_begin(void);
void h2_player_tick(void);
void h2_player_usb_staging(void);
int h2_player_usb(unsigned request,unsigned value,unsigned index,unsigned length,uint8_t *out);
#endif
