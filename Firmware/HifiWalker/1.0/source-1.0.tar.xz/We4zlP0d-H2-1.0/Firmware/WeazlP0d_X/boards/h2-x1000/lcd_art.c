/* Decode the bounded block produced by the host's LZ4 asset packer. */
#include <stddef.h>
#include <stdint.h>

static int extend(unsigned *count,const uint8_t **source,const uint8_t *end)
{
    if (*count!=15)
        return 1;
    unsigned n;
    do {
        if (*source==end || *count>153600)
            return 0;
        n=*(*source)++;
        *count+=n;
    } while (n==255);
    return 1;
}

int h2_decode_art(const uint8_t *source,size_t length,uint8_t *output,size_t capacity)
{
    const uint8_t *end=source+length;
    size_t used=0;
    while (source<end) {
        unsigned tag=*source++, count=tag>>4;
        if (!extend(&count,&source,end) || count>(size_t)(end-source) || count>capacity-used)
            return 0;
        for (unsigned i=0;i<count;++i)
            output[used++]=*source++;
        if (source==end)
            return used==capacity;
        if (end-source<2)
            return 0;
        unsigned back=source[0]|((unsigned)source[1]<<8);
        source+=2;
        count=tag&15;
        if (!back || back>used || !extend(&count,&source,end) || count+4>capacity-used)
            return 0;
        for (unsigned i=0;i<count+4;++i) {
            output[used]=output[used-back];
            ++used;
        }
    }
    return 0;
}
