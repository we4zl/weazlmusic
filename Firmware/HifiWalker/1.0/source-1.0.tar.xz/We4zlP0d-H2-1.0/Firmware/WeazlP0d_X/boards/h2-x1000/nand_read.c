/* H2 SPI NAND inventory. Program operations are built for the installer. */
#include <stdint.h>
#ifdef H2_NAND_INSTALLER
#include "boot_slot.h"
#endif
#define IO(base, off) (*(volatile uint32_t *)((uintptr_t)(base)+(off)))
#define SFC(off) IO(0xb3440000u, off)
#define CPM(off) IO(0xb0000000u, off)
#define GPIO(off) IO(0xb0010000u, off)

static int wait(volatile uint32_t *where, uint32_t bit, uint32_t expected)
{
    for (unsigned i=0; i<100000; ++i)
        if ((*where & bit) == expected)
            return 1;
    return 0;
}
static int read_spi(unsigned op, unsigned address, unsigned address_bytes,
                    unsigned dummy_bits, uint32_t *words, unsigned count)
{
#ifdef H2_NAND_INSTALLER
    SFC(0)&=~(1u<<13);
#endif
    SFC(0x14) = (address_bytes<<26) | (1u<<24) | (dummy_bits<<17) |
                (count ? 1u<<16 : 0) | op;
    SFC(0x30) = address;
    SFC(0x48) = 0;
    SFC(0x2c) = count*4;
    SFC(0x6c) = 31;
    SFC(0x64) = 4;
    SFC(0x64) = 1;
    for (unsigned i=0; i<count; ++i) {
        if (!wait(&SFC(0x68),4,4))
            return 0;
        SFC(0x6c) = 4;
        words[i] = SFC(0x1000);
    }
    if (!wait(&SFC(0x68),16,16))
        return 0;
    SFC(0x6c) = 16;
    return 1;
}
static int feature(unsigned address, unsigned *value)
{
    uint32_t data;
    if (!read_spi(0x0f,address,1,0,&data,1))
        return 0;
    *value = data&255;
    return 1;
}

unsigned h2_nand_info(uint32_t info[4])
{
    const uint32_t pins = 0xfc000000;
    GPIO(0x18) = pins;
    GPIO(0x28) = pins;
    GPIO(0x38) = pins;
    GPIO(0x44) = pins;
    CPM(0x20) &= ~(1u<<2);
    /* 600 MHz MPLL / 50. Single-bit transfers at a conservative 12 MHz. */
    CPM(0x74) = 0xa0000031u;
    if (!wait(&CPM(0x74),1u<<28,0))
        return 1;
    CPM(0x74) &= ~(1u<<29);
    SFC(0x00) = 0x8c; /* one phase, slave mode, 1-word threshold */
    SFC(0x04) = 0xe7;
    SFC(0x70) = 31;
    SFC(0x78) = 0;

    if (!read_spi(0x9f,0,1,0,info,1) ||
        !read_spi(0x9f,0,0,8,info+1,1) ||
        !feature(0xb0,info+2) || !feature(0xa0,info+3))
        return 2;
    return 0;
}

unsigned h2_nand_page(unsigned page, uint32_t words[528], unsigned *status)
{
    if (page >= 65536 || !read_spi(0x13,page,3,0,0,0))
        return 3;
    for (unsigned i=0; i<200; ++i) {
        if (!feature(0xc0,status))
            return 4;
        if (!(*status&1)) {
            return read_spi(0x03,0,2,8,words,528) ? 0 : 6;
        }
    }
    return 5;
}

#ifdef H2_NAND_INSTALLER
static int write_spi(unsigned op,unsigned address,unsigned address_bytes,
                     const uint32_t *words,unsigned bytes)
{
    SFC(0)|=1u<<13;
    SFC(0x14)=(address_bytes<<26)|(1u<<24)|(1u<<16)|op;
    SFC(0x30)=address;
    SFC(0x48)=0;
    SFC(0x2c)=bytes;
    SFC(0x6c)=31;
    SFC(0x64)=4;
    SFC(0x64)=1;
    for (unsigned i=0;i<(bytes+3)/4;++i) {
        if (!wait(&SFC(0x68),8,8))
            return 0;
        SFC(0x6c)=8;
        SFC(0x1000)=words[i];
    }
    if (!wait(&SFC(0x68),16,16))
        return 0;
    SFC(0x6c)=16;
    return 1;
}

static int nand_ready(unsigned *status)
{
    for (unsigned tries=0;tries<8192;++tries) {
        if (!feature(0xc0,status))
            return 0;
        if (!(*status&1))
            return 1;
    }
    return 0;
}

static int enable_write(void)
{
    unsigned status;
    return read_spi(0x06,0,0,0,0,0) && feature(0xc0,&status) && (status&3)==2;
}

static int set_protection(uint32_t bits)
{
    unsigned result;
    return enable_write() && write_spi(0x1f,0xa0,1,&bits,1) &&
        nand_ready(&result) && feature(0xa0,&result) && result==bits;
}

static int install_area(unsigned page)
{
#ifdef H2_BOND_STORAGE
    return page>=1024 && page<1088;
#else
    return page<64 || (page>=448 && page<512) ||
           (page>=H2_BOOT_SLOT_A && page<H2_BOOT_SLOT_B+H2_BOOT_SLOT_PAGES);
#endif
}

static int allow_write(unsigned page,unsigned *protection)
{
    uint32_t id;
    unsigned config, previous;
    if (!install_area(page) || !read_spi(0x9f,0,0,8,&id,1) ||
        (id&0xffffff)!=0x21aaef || !feature(0xb0,&config) || (config&0xf8)!=0x18 ||
        !feature(0xa0,&previous) || (previous&~0x7c))
        return 0;
    *protection=previous;
    return set_protection(0);
}

static int protect_again(unsigned protection)
{
    int ok=set_protection(protection);
    return read_spi(0x04,0,0,0,0,0) && ok;
}

unsigned h2_nand_erase_install_block(unsigned first,uint32_t *scratch)
{
    unsigned status, protection=0xff;
    if (first%64 || !install_area(first))
        return 1;
    for (unsigned i=0;i<2;++i)
        if (h2_nand_page(first+i,scratch,&status) ||
            (status&0x30)==0x20 || (scratch[512]&255)!=255)
            return 2;
    unsigned code=0;
    if (!allow_write(first,&protection))
        code=3;
    else if (!enable_write() || !read_spi(0xd8,first,3,0,0,0) ||
             !nand_ready(&status) || (status&4))
        code=4;
    if (protection!=0xff && !protect_again(protection))
        return 6;
    return code;
}

unsigned h2_nand_program_install_page(unsigned page,const uint32_t data[512],uint32_t *scratch)
{
    unsigned status, protection=0xff;
    if (!install_area(page) || h2_nand_page(page,scratch,&status) || status)
        return 1;
    for (unsigned i=0;i<528;++i)
        if (scratch[i]!=0xffffffff)
            return 2;
    unsigned code=0;
    if (!allow_write(page,&protection))
        code=3;
    else if (!enable_write() || !write_spi(0x02,0,2,data,2048) ||
             !read_spi(0x10,page,3,0,0,0) || !nand_ready(&status) || (status&8))
        code=4;
    if (protection!=0xff && !protect_again(protection))
        return 6;
    if (code)
        return code;
    if (h2_nand_page(page,scratch,&status) || (status&0x30)==0x20)
        return 7;
    for (unsigned i=0;i<512;++i)
        if (data[i]!=scratch[i])
            return 8;
    return 0;
}
#endif
