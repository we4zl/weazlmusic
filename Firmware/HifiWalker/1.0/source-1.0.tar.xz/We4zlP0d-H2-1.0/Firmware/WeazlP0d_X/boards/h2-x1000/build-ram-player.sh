#!/usr/bin/env bash
set -euo pipefail
board=$(cd "$(dirname "$0")" && pwd -P)
root=$(git -C "$board" rev-parse --show-toplevel)
build=${1:-H16}
[[ "$build" =~ ^H[0-9]{2}$ ]]
archive="$root/Firmware/HifiWalker/$build"
work="$root/build/hifih2/player/$build/ram-trial"
mkdir -p "$work"
image=${2:-$archive/$build.bin}
if (( $# < 2 )); then
    (cd "$archive" && sha256sum -c SHA256SUMS >/dev/null)
fi
image=$(realpath "$image")
cat >"$work/ram-image.S" <<EOF
.section .rodata.application,"a",@progbits
.balign 4
.globl h2_ram_image
.globl h2_ram_image_end
h2_ram_image:
.incbin "$image"
h2_ram_image_end:
EOF
flags=(--target=mipsel-none-elf -march=mips32r2 -msoft-float -mno-abicalls -fno-pic -G0 -Os -ffreestanding -fno-builtin -fno-stack-protector -Wall -Wextra -Werror -ffunction-sections -fdata-sections)
for name in flash-entry.S ram_player.c boot_health.c; do
    clang "${flags[@]}" -c "$board/$name" -o "$work/${name%.*}.o"
done
clang "${flags[@]}" -c "$work/ram-image.S" -o "$work/ram-image.o"
ld.lld -m elf32ltsmip --gc-sections -T "$board/flash-trial.ld" "$work/flash-entry.o" "$work/ram_player.o" "$work/boot_health.o" "$work/ram-image.o" -o "$work/ram-player.elf"
llvm-objcopy -O binary "$work/ram-player.elf" "$work/ram-player.bin"
llvm-readelf -h "$work/ram-player.elf" | awk '/Entry point address/ {e=tolower($NF)} END {exit e!="0xa0400018"}'
