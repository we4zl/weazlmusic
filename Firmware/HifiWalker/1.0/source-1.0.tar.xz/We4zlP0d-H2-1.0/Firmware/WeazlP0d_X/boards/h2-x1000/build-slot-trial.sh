#!/usr/bin/env bash
set -euo pipefail
board=$(cd "$(dirname "$0")" && pwd -P)
root=$(git -C "$board" rev-parse --show-toplevel)
minor=${1:-6}
gen=${2:-1}
defines=()
pack_flags=()
case "$minor" in
    6|7|8|9|10) ;;
    12|14|16|17|18|19|20|21|22|23|24|25|26|27|28|29|30|31|32|33|34|35|36|38|39|41|42|43|44|45|46|47|48|49|50|51|52|53|54|55|56|57|58|59|60|61|62|63|64)
        defines+=(-DH2_BOOT_GUARD)
        pack_flags+=(--guarded)
        ;;
    *) exit 2 ;;
esac
printf -v build 'H%02d' "$minor"
work="$root/build/hifih2/player/$build"
temp=$(mktemp -d "$work/stage.XXXXXX")
trap 'rm -f "$temp/application.bin"; rmdir "$temp"' EXIT
variant=slot
if [[ "$gen" == rollback ]]; then
    : >"$work/rollback.application"
    package="$work/rollback.application"
    variant=rollback
else
    decimal_id=$((0x480000+(0x30+minor/10)*256+0x30+minor%10))
    python "$board/boot_pack.py" app "$work/player.bin" "$temp/application.bin" --generation "$gen" --build-id "$decimal_id" "${pack_flags[@]}"
    install -m 644 "$temp/application.bin" "$work/application.bin"
    package="$work/application.bin"
fi
cat >"$work/package.S" <<EOF
.section .rodata.application,"a",@progbits
.balign 4
.globl h2_package
.globl h2_package_end
h2_package:
.incbin "$package"
h2_package_end:
EOF
flags=(--target=mipsel-none-elf -march=mips32r2 -msoft-float -mno-abicalls -fno-pic -G0 -Os -ffreestanding -fno-builtin -fno-stack-protector -Wall -Wextra -Werror)
for name in flash-entry.S slot_trial.c nand_read.c boot_slot.c player_clock.c; do
    clang "${flags[@]}" "${defines[@]}" -DH2_NAND_INSTALLER -c "$board/$name" -o "$work/${name%.*}-slot.o"
done
clang "${flags[@]}" -c "$work/package.S" -o "$work/package.o"
objects=("$work/flash-entry-slot.o" "$work/slot_trial-slot.o" "$work/nand_read-slot.o" "$work/boot_slot-slot.o" "$work/player_clock-slot.o" "$work/package.o")
ld.lld -m elf32ltsmip -T "$board/flash-trial.ld" "${objects[@]}" -o "$work/$variant.elf"
llvm-objcopy -O binary "$work/$variant.elf" "$work/$variant.bin"
llvm-readelf -h "$work/$variant.elf" | awk '/Entry point address/ {e=tolower($NF)} END {exit e!="0xa0400018"}'
