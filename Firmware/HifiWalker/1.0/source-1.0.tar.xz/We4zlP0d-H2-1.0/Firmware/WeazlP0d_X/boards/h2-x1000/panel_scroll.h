/* The hw4 controller trial established these SLCD timings after panel rail enable.
 * Keep the slow GPIO writer available for recovery and other screens. */
#define SLCD(off) IO(0xb3050000u,off)
static int scroll_lcd_state;
static unsigned scroll_lcd_faults;
unsigned h2_panel_scroll_faults(void) { return scroll_lcd_faults; }

static bool scroll_wait(volatile uint32_t *reg,uint32_t mask)
{
    for (unsigned i=0;i<8192;++i) if (!(*reg & mask)) return true;
    return false;
}
static bool scroll_send(uint32_t value)
{
    if (!scroll_wait(&SLCD(0xa8),1)) return false;
    SLCD(0xac)=value;
    return true;
}
static void scroll_mux(unsigned bank,unsigned pins)
{
    PORT(bank,0x18)=pins; PORT(bank,0x38)=pins;
    PORT(bank,0x44)=pins; PORT(bank,0x28)=pins;
}
static bool scroll_init(void)
{
    if (scroll_lcd_state) return scroll_lcd_state>0;
    scroll_lcd_state=-1;
    if ((IO(0xb0000000u,0x14)&0xfffc0083u)!=0x98000083u) return false;
    IO(0xb0000000u,0x20)&=~(1u<<23);
    IO(0xb0000000u,0x64)=(1u<<31)|(1u<<28)|29u;
    if (!scroll_wait(&IO(0xb0000000u,0x64),1u<<27)) return false;
    IO(0xb0000000u,0x64)&=~(1u<<28);
    SLCD(0xa0)=1u<<8; SLCD(0xb8)=0; SLCD(0xa4)=(1u<<8)|(1u<<4);
    SLCD(0xb0)=0; SLCD(0xb4)=0; SLCD(0xbc)=0;
    scroll_lcd_state=1;
    return true;
}
bool h2_panel_scroll_span(unsigned y,unsigned left,unsigned end,const uint8_t *line)
{
    if (!scroll_init()) return false;
    scroll_mux(A,255); scroll_mux(B,WR|DC);
    const unsigned cmd=1u<<30;
    unsigned setup[]={cmd|0x2a,left>>8,left&255,(end-1)>>8,(end-1)&255,
                      cmd|0x2b,0,y,0,y,cmd|0x2c};
    bool ok=true;
    for (unsigned i=0;i<sizeof setup/sizeof setup[0] && ok;++i) ok=scroll_send(setup[i]);
    for (unsigned x=left;x<end && ok;++x)
        ok=scroll_send(line[x*2+1]) && scroll_send(line[x*2]);
    ok=ok && scroll_wait(&SLCD(0xa8),1);
    PORT(B,0x44)=WR|DC; PORT(B,0x24)=WR|DC;
    PORT(A,0x48)=255; PORT(A,0x24)=255;
    if (!ok) {++scroll_lcd_faults;scroll_lcd_state=-1;}
    return ok;
}

#if BUILD_MINOR >= 47
/* Two aligned descriptors for one bounded RGB565 rectangle. The recovery
 * supervisor's RAM slots end below the framebuffer, at a different address. */
static bool scroll_rect_dma(unsigned x,unsigned y,unsigned width,unsigned rows,const uint8_t *fb)
{
    if (!scroll_init() || !rows || y+rows>240 || !width || x+width>320 || width%2) return false;
    const uint32_t desc_phys=0x008b0000u;
    volatile uint32_t *desc=(volatile uint32_t *)0xa08b0000u;
    unsigned bytes=rows*width*2;
    for (uintptr_t a=(uintptr_t)fb;a<(uintptr_t)fb+bytes;a+=32)
        __asm__ volatile("cache 0x19,0(%0)"::"r"(a):"memory");
    for (unsigned i=0;i<16;++i) desc[i]=0;
    desc[0]=desc_phys+32; desc[1]=desc_phys+64; desc[2]=0xc0;
    desc[3]=(1u<<29)|1u; desc[6]=4;
    desc[8]=desc_phys; desc[9]=(uintptr_t)fb & 0x1fffffffu; desc[10]=0xf0;
    desc[11]=(1u<<30)|(1u<<26)|(bytes/4); desc[14]=4u<<27;
    desc[15]=(width-1)|((rows-1)<<12); desc[16]=0x2c2c2c2c;
    __asm__ volatile("sync":::"memory");
    scroll_mux(A,255); scroll_mux(B,WR|DC);
    const unsigned cmd=1u<<30;
    unsigned setup[]={cmd|0x2a,x>>8,x&255,(x+width-1)>>8,(x+width-1)&255,cmd|0x2b,0,y,0,y+rows-1};
    bool ok=true;
    for (unsigned i=0;i<sizeof setup/sizeof setup[0] && ok;++i) ok=scroll_send(setup[i]);
    if (ok) {
        SLCD(0x30)=4u<<28; SLCD(0x10)=width; SLCD(0x14)=rows;
        SLCD(0xb8)=0x101; SLCD(0xa4)=0x116;
        ok=scroll_wait(&SLCD(0xa8),1);
        if (ok) {
            SLCD(0xa4)|=1; SLCD(0x34)=0; SLCD(0x40)=desc_phys; SLCD(0x30)|=8;
            uint32_t start=OST(0x20);
            while (!(SLCD(0x34)&0x20) && OST(0x20)-start<180000u) {}
            ok=(SLCD(0x34)&0x20) && scroll_wait(&SLCD(0xa8),1);
        }
        SLCD(0x30)&=~8u; SLCD(0xa4)=0x110; SLCD(0xb8)=0; SLCD(0x34)=0;
    }
    PORT(B,0x44)=WR|DC; PORT(B,0x24)=WR|DC;
    PORT(A,0x48)=255; PORT(A,0x24)=255;
    if (!ok) ++scroll_lcd_faults;
    return ok;
}
bool h2_panel_scroll_rect(unsigned x,unsigned y,unsigned width,unsigned rows,const uint8_t *fb)
{
    static int dma_failed;
    if (dma_failed) return false;
    if (scroll_rect_dma(x,y,width,rows,fb)) return true;
    dma_failed=1;
    return false;
}
#endif
