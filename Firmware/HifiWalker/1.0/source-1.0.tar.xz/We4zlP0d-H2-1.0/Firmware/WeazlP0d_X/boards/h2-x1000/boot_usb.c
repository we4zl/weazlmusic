/* H2 H01. The X1000 ROM hands off with its UTMI PHY and clock running.
 * Take ownership of DWC2 endpoint zero in slave (FIFO) mode. No DMA or DDR. */
#include <stdint.h>
#include <stddef.h>
#ifdef H2_SERVICE
#include "ram_service.h"
#ifndef BUILD_MINOR
#define BUILD_MINOR 2
#endif
#else
#define BUILD_MINOR 1
#endif
#ifdef H2_PLAYER
#include "player_app.h"
#endif
#define REG(offset) (*(volatile uint32_t *)(0xb3500000u + (offset)))
enum {
    GAHBCFG = 8, GUSBCFG = 12, GRSTCTL = 16, GINTSTS = 20, GINTMSK = 24,
    GRXSTSP = 32, GRXFSIZ = 36, GNPTXFSIZ = 40, DCFG = 0x800, DCTL = 0x804,
    DIEPMSK = 0x810, DOEPMSK = 0x814, DAINTMSK = 0x81c, DIEPCTL = 0x900,
    DIEPINT = 0x908, DIEPTSIZ = 0x910, DOEPCTL = 0xb00, DOEPINT = 0xb08,
    DOEPTSIZ = 0xb10, FIFO = 0x1000
};
enum { RX = 1u<<4, RESET = 1u<<12, ENUM_DONE = 1u<<13, SETUP = 1u<<3 };
static unsigned configuration;
static uint32_t setup[2], polls;
static int got_setup;
#if defined(H2_PLAYER) && BUILD_MINOR >= 57
static unsigned radio_poll;
void h2_usb_poll_radio(void);
#endif
enum { BUILD_BCD=(BUILD_MINOR/10)*16+BUILD_MINOR%10 };
#if !defined(H2_PLAYER) || BUILD_MINOR < 42
static const
#else
static
#endif
uint8_t device[] = {18,1,0,2,0,0,0,64,9,0x12,1,0,BUILD_BCD,1,1,2,0,1};
#if defined(H2_PLAYER) && BUILD_MINOR >= 27
#define USB_CARD
#include "usb_card.h"
static uint8_t config[]={9,2,41,0,2,1,0,0x80,50,9,4,0,0,0,0xff,0,0,0,
    9,4,1,0,2,8,6,0x50,0,7,5,0x81,2,64,0,0,7,5,1,2,64,0,0};
#else
static const uint8_t config[] = {9,2,18,0,1,1,0,0x80,50,9,4,0,0,0,0xff,0,0,0};

#endif

static void arm_out(void)
{
    REG(DOEPTSIZ) = (3u<<29) | (1u<<19) | 64;
    REG(DOEPCTL) |= (1u<<31) | (1u<<26);
}
static void send(const uint8_t *data, unsigned size, unsigned wanted)
{
    if (size > wanted) size = wanted;
    REG(DIEPTSIZ) = (1u<<19) | size;
    REG(DIEPCTL) |= (1u<<31) | (1u<<26);
    for (unsigned i=0; i<size; i+=4) {
        uint32_t word=0;
        for (unsigned j=0; j<4 && i+j<size; ++j)
            word |= (uint32_t)data[i+j] << (8*j);
        REG(FIFO) = word;
    }
}
#if defined(H2_PLAYER) && BUILD_MINOR >= 42
/* Read the first 96 bits of the X1000 chip ID. Keep programming disabled.
 * The descriptor fits in one EP0 packet. A blank ID leaves iSerial unset. */
static char hardware_serial[25];
static void read_hardware_serial(void)
{
    volatile uint32_t *gate=(volatile uint32_t *)0xb0000020u;
    volatile uint32_t *otp=(volatile uint32_t *)0xb3540000u;
    uint32_t gates=*gate;
    *gate=gates & ~2u;
    uint32_t timing=otp[1];
    otp[1]=(timing & ~0x370000u) | 0x370000u;
    otp[2]=0;
    otp[0]=(11u<<16)|1u;
    for (unsigned wait=0;wait<100000;++wait) {
        if (!(otp[2]&1u)) continue;
        const char hex[]="0123456789abcdef";
        uint32_t any=0, all=~0u;
        for (unsigned i=0;i<3;++i) {
            uint32_t word=otp[3+i];
            any|=word; all&=word;
            for (unsigned j=0;j<8;++j)
                hardware_serial[8*i+j]=hex[(word>>(28-4*j))&15u];
        }
        if (any && all!=~0u) device[16]=3;
        break;
    }
    otp[0]=0;
    otp[2]=0;
    otp[1]=timing;
    *gate=gates;
}
#endif
static void handle_setup(void)
{
    unsigned req=setup[0]&0xffff, val=setup[0]>>16, index=setup[1]&0xffff, len=setup[1]>>16;
    uint8_t buf[64];
    for (unsigned i=0;i<sizeof buf;++i) ((volatile uint8_t *)buf)[i]=0;
    if (req==0x0680 && val==0x100) {
#if defined(H2_PLAYER) && BUILD_MINOR >= 42
        static unsigned checked;
        if (!checked) {checked=1;read_hardware_serial();}
#endif
        send(device,sizeof device,len);
    }
#ifdef USB_CARD
    else if (req==0x0680 && val==0x600 && high_speed_capable) {
        const uint8_t qualifier[]={10,6,0,2,0,0,0,64,1,0};
        send(qualifier,sizeof qualifier,len);
    } else if (req==0x0680 && (val==0x200 || (val==0x700 && high_speed_capable))) {
        unsigned size=val==0x200 ? packet_size : (packet_size==512 ? 64 : 512);
        config[1]=val>>8;
        config[31]=config[38]=size;
        config[32]=config[39]=size>>8;
        send(config,sizeof config,len);
    }
#else
    else if (req==0x0680 && val==0x200) send(config,sizeof config,len);
#endif
    else if (req==0x0680 && val==0x300) {
        const uint8_t lang[]={4,3,9,4};
        send(lang,4,len);
    } else if (req==0x0680 && (val==0x301 || val==0x302 || (val==0x303 && device[16]==3))) {
        const char *s=val==0x301 ? "WeazlMusic" : "WeazlP0d X H2";
#if defined(H2_PLAYER) && BUILD_MINOR >= 42
        if (val==0x303) s=hardware_serial;
#endif
        unsigned n=2;
        buf[1]=3;
        while (*s) {buf[n]=(uint8_t)*s++; n+=2;}
        buf[0]=(uint8_t)n;
        send(buf,n,len);
    } else if (req==0x0500 && val<128 && !index && !len) {
        REG(DCFG)=(REG(DCFG)&~0x7f0u)|(val<<4);
        send(0,0,0);
    } else if (req==0x0900 && val<=1 && !index && !len) {
        configuration=val;
#ifdef USB_CARD
        if (val) bulk_init();
#endif
        send(0,0,0);
    } else if (req==0x0880) {buf[0]=(uint8_t)configuration; send(buf,1,len);}
    else if (req==0x0080 || req==0x0081) send(buf,2,len);
    else if (req==0x0a81 && configuration) send(buf,1,len);
    else if (req==0x0b01 && configuration && !val && !index && !len) send(0,0,0);
#ifdef USB_CARD
    else if (req==0xfea1 && index==1 && len==1) send(buf,1,1);
#if BUILD_MINOR == 37
    else if (req==0xbac0 && ejected && !val && !index && len==8) {
        uint32_t result[]={ram_bytes,ram_digest};
        send((const uint8_t *)result,sizeof result,len);
    }
#endif
    else if (req==0xff21 && index==1 && !len) { bulk_init(); send(0,0,0); }
    else if (req==0x0102 && !val && (index==1 || index==0x81)) {
        if (index==1) OUT1(0)=(OUT1(0)&~(1u<<21))|(1u<<28);
        else IN1(0)=(IN1(0)&~(1u<<21))|(1u<<28);
        send(0,0,0);
    }
#endif
    else if (req==0x42c0 && configuration && len==12) {
        buf[0]='H'; buf[1]='0'+BUILD_MINOR/10; buf[2]='0'+BUILD_MINOR%10; buf[3]='X';
        buf[4]=val; buf[5]=val>>8; buf[6]=index; buf[7]=index>>8;
        for (unsigned k=0;k<4;++k) buf[8+k]=polls>>(8*k);
        send(buf,12,len);
#ifdef H2_SERVICE
    } else if (configuration &&
#if defined(H2_PLAYER) && BUILD_MINOR >= 57
               (!radio_poll || req==0x43c0) &&
#endif
#ifdef USB_CARD
               (!h2_card_busy() || req==0x43c0) &&
#endif
               h2_request(req, val, index, len, buf)) {
#if defined(H2_PLAYER) && BUILD_MINOR >= 26
        if (req==0x4440 || req==0x4540) h2_player_usb_staging();
#endif
        send(buf, len, len);
#endif
#ifdef H2_PLAYER
    } else if (configuration && h2_player_usb(req,val,index,len,buf)) {
        send(buf,len,len);
#endif
    } else {
        REG(DIEPCTL)|=1u<<21;
        REG(DOEPCTL)|=1u<<21;
    }
}
static void delay_disconnect(void)
{
#ifdef H2_PLAYER
    volatile uint32_t *ticks=(volatile uint32_t *)0xb2000020u;
    uint32_t start=*ticks;
    for (unsigned i=0;i<16000000 && *ticks-start<720000;++i) {}
#else
    /* Long enough for a hub to retire the ROM attachment even at full CPU clock. */
    for (volatile unsigned i=0;i<3000000;++i) __asm__ volatile("nop");
#endif
}
#if BUILD_MINOR >= 4
static void reset_fifos(void)
{
    REG(GRSTCTL)=(0x10u<<6)|(1u<<5);
    for (unsigned i=0; i<100000 && (REG(GRSTCTL)&(1u<<5)); ++i) {}
    REG(GRSTCTL)=1u<<4;
    for (unsigned i=0; i<100000 && (REG(GRSTCTL)&(1u<<4)); ++i) {}
}
static void enable_timer(void)
{
    volatile uint32_t *ost=(volatile uint32_t *)0xb2000000u;
    ost[0]=(ost[0]&~12u)|4u;
    ost[0x34/4]=2; /* enable-set, the status register itself is read-only */
}
#endif

#if defined(H2_PLAYER) && BUILD_MINOR >= 57
static void poll_usb(void);
#endif

void h2_main(void)
{
#if BUILD_MINOR >= 4
    enable_timer();
#endif
#ifdef H2_PLAYER
    h2_player_begin();
#endif
    REG(DCTL)|=2;
    delay_disconnect();
    REG(GINTMSK)=0;
    REG(GAHBCFG)=0;
    while (!(REG(GRSTCTL)&0x80000000u)) {}
    REG(GRSTCTL)=1;
    while (REG(GRSTCTL)&1) {}
    REG(DCTL)|=2;
    REG(GUSBCFG)=(1u<<30)|(5u<<10)|(1u<<3)|7u;
    REG(0xe00)=0;
    REG(DCFG)=1u | (1u<<2);
    REG(GRXFSIZ)=128;
    REG(GNPTXFSIZ)=(64u<<16)|128;
#ifdef USB_CARD
    high_speed_capable=BUILD_MINOR>=28 && (REG(0x4c)>>16)>=512;
    if (high_speed_capable) {
        REG(DCFG)=1u<<2;
        REG(GRXFSIZ)=256;
        REG(GNPTXFSIZ)=(64u<<16)|256;
        REG(0x104)=(192u<<16)|320;
    } else REG(0x104)=(32u<<16)|192;
#endif
    REG(GRSTCTL)=(0x10u<<6)|(1u<<5);
    while (REG(GRSTCTL)&(1u<<5)) {}
    REG(GRSTCTL)=1u<<4;
    while (REG(GRSTCTL)&(1u<<4)) {}
    REG(DIEPMSK)=1;
    REG(DOEPMSK)=SETUP|1;
    REG(DAINTMSK)=0x10001;
    REG(GINTSTS)=0xffffffff;
    REG(GINTMSK)=RESET|ENUM_DONE|RX|(3u<<18);
    REG(GAHBCFG)=1;
    REG(DCTL)&=~2u;
    for (;;) {
#if defined(H2_PLAYER) && BUILD_MINOR >= 57
        poll_usb();
        h2_trial_tick();
        h2_player_tick();
    }
}

static void poll_usb(void)
{
#endif
        ++polls;
        uint32_t events=REG(GINTSTS);
        if (events&RESET) {
            configuration=0; got_setup=0;
#ifdef USB_CARD
#if defined(H2_WRITE_PIPELINE)
            bulk_abort_write();
#endif
            ejected=0;
#endif
#if BUILD_MINOR >= 4
            reset_fifos();
            REG(DIEPCTL)&=~(1u<<21);
            REG(DOEPCTL)&=~(1u<<21);
#endif
            REG(DCFG)&=~0x7f0u;
            REG(DIEPINT)=REG(DOEPINT)=0xffff;
            REG(DAINTMSK)=0x10001;
            arm_out();
            REG(GINTSTS)=RESET;
#if defined(H2_PLAYER) && BUILD_MINOR >= 57
            return;
#else
            continue;
#endif
        }
        if (events&ENUM_DONE) {
#ifdef USB_CARD
            packet_size=high_speed_capable && !(REG(0x808)&6) ? 512 : 64;
#endif
            REG(DIEPCTL)&=~3u;
            REG(DCTL)|=1u<<8;
            arm_out();
            REG(GINTSTS)=ENUM_DONE;
        }
        while (REG(GINTSTS)&RX) {
            uint32_t st=REG(GRXSTSP);
            unsigned n=(st>>4)&2047, kind=(st>>17)&15;
#ifdef USB_CARD
            uint32_t packet[128];
#if BUILD_MINOR >= 34
            unsigned write_data=(st&15)==1 && kind==2 && bot_phase==DATA_OUT &&
                                n<=packet_size && n<=out_batch && n<=residue &&
                                at+n<=WRITE_BUFFER_SIZE && !(n&3);
#endif
#endif
            for (unsigned i=0;i<(n+3)/4;++i) {
                uint32_t word=REG(FIFO);
#ifdef USB_CARD
#if BUILD_MINOR >= 34
                if (write_data)
                    write_words[at/4+i]=word;
                else
#endif
                if ((st&15)==1 && kind==2 && n<=packet_size)
                    packet[i]=word;
#endif
                if (kind==6 && n==8 && !(st&15)) setup[i]=word;
            }
#ifdef USB_CARD
            if ((st&15)==1 && kind==2 && n<=packet_size) bulk_out((const uint8_t *)packet,n);
#endif
            if (kind==6 && n==8 && !(st&15)) got_setup=1;
        }
#ifdef USB_CARD
        if (configuration) {
            unsigned done=IN1(8);
            if (done) IN1(8)=done;
            if (done&1) bulk_next();
            done=OUT1(8);
            if (done) OUT1(8)=done;
#if defined(H2_WRITE_PIPELINE)
            bulk_drain_write(done);
#elif BUILD_MINOR >= 34
            if ((done&1) && bot_phase==DATA_OUT && !out_batch) bulk_arm();
#endif
        }
#endif
        uint32_t in=REG(DIEPINT);
        if (in) REG(DIEPINT)=in;
#if !defined(H2_PLAYER) || BUILD_MINOR < 57
#ifdef H2_SERVICE
        h2_trial_tick();
#endif
#ifdef H2_PLAYER
#if defined(H2_WRITE_PIPELINE)
        if (!write_dma_busy)
#endif
        h2_player_tick();
#endif
#endif
        uint32_t out=REG(DOEPINT);
        if (out) {
            REG(DOEPINT)=out;
            if ((out&SETUP) && got_setup) {
                got_setup=0;
                handle_setup();
            }
            arm_out();
        }
#if defined(H2_PLAYER) && BUILD_MINOR >= 57
}

void h2_usb_poll_radio(void)
{
    radio_poll=1;
    poll_usb();
    radio_poll=0;
#else
    }
#endif
}
