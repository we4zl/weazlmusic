/* The RTC scratch register carries the candidate's health across watchdog
 * resets. The main NAND and SD card need no writes during startup. */
#include "boot_health.h"

#define RTC(off) (*(volatile uint32_t *)(0xb0003000u+(off)))
#define TCU(off) (*(volatile uint32_t *)(0xb0002000u+(off)))
#define WATCHDOG_CLOCK (1u<<16)

static int rtc_ready(volatile uint32_t *reg,uint32_t mask)
{
    for (unsigned n=0;n<120000;++n)
        if (*reg&mask)
            return 1;
    return 0;
}

uint32_t h2_health_read(void)
{
    return rtc_ready(&RTC(0),1u<<7) ? RTC(0x34) : 0;
}

int h2_health_write(uint32_t value)
{
    if (!rtc_ready(&RTC(0),1u<<7))
        return 0;
    RTC(0x3c)=0xa55a;
    if (!rtc_ready(&RTC(0x3c),1u<<31) || !rtc_ready(&RTC(0),1u<<7))
        return 0;
    RTC(0x34)=value;
    return rtc_ready(&RTC(0),1u<<7) && RTC(0x34)==value;
}

void h2_health_arm(void)
{
    TCU(0x3c)=WATCHDOG_CLOCK;
    TCU(0x04)=0;
    TCU(0x0c)=0x2c; /* 24 MHz external source, /1024 */
    TCU(0x08)=0;
    TCU(0x00)=60000; /* 2.56 seconds */
    TCU(0x04)=1;
}

int h2_health_confirm(void)
{
    uint32_t state=h2_health_read();
    unsigned pending=(state>>2)&3u;
    if ((state&0xff000000u)!=H2_HEALTH_MARK || (pending!=1 && pending!=2))
        return 1;

    /* X1000 section 15.2.2 requires TSSR to stop a running watchdog. */
    TCU(0x2c)=WATCHDOG_CLOCK;
    if (!(TCU(0x1c)&WATCHDOG_CLOCK))
        return 0;
    if (h2_health_write(h2_health_confirmed(state)))
        return 1;
    TCU(0x3c)=WATCHDOG_CLOCK;
    return 0;
}
