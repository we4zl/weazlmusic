OUTPUT_ARCH(mips)
ENTRY(_start)
MEMORY { sram (rwx) : ORIGIN = 0xf4001800, LENGTH = 0x2800 }
SECTIONS {
  .text : { KEEP(*(.start)) *(.text .text.*) } >sram
  .rodata : { *(.rodata .rodata.*) } >sram
  .data : { *(.data .data.* .sdata .sdata.*) *(.got) } >sram
  .bss (NOLOAD) : {
    . = ALIGN(4); __bss_start = .;
    *(.bss .bss.* .sbss .sbss.* COMMON)
    . = ALIGN(4); __bss_end = .;
  } >sram
  ASSERT(__bss_end <= 0xf4003a00, "H01 needs 1.5 KiB of stack")
  /DISCARD/ : { *(.MIPS.abiflags .reginfo .pdr .comment .note.* .eh_frame*) }
}
