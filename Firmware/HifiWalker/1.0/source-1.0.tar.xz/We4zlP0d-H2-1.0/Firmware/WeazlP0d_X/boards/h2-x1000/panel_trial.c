#include "panel.h"
#ifdef H2_PANEL_SLCD
/* The running H21 already decoded this RGB565 wallpaper in shared DDR. */
static const uint8_t *const trial_art=(const uint8_t *)0x80800000u;
#else
extern const uint8_t h2_art[];
#define trial_art h2_art
#endif
enum { W = 320, H = 240, ID = 0x48303350 };

#ifdef H2_PANEL_SLCD
bool h2_slcd_trial_begin(void);
bool h2_slcd_trial_row(unsigned y,const uint8_t *row);
void h2_slcd_trial_end(bool complete);
#endif

#ifdef H2_PANEL_LIVE
uint32_t flash_trial(uint32_t cookie)
#else
__attribute__((section(".entry")))
uint32_t panel_trial(uint32_t cookie)
#endif
{
#ifdef H2_PANEL_SLCD
    if (!h2_slcd_trial_begin()) {
        h2_slcd_trial_end(false);
        return 0;
    }
#else
    if (!h2_panel_begin())
        return 0;
#endif
    for (unsigned y=0; y<H; ++y) {
        uint8_t row[W*2];
        for (unsigned x=0; x<W; ++x) {
            uint16_t color;
            if (x==0 || x==W-1 || y==0 || y==H-1)
                color = 0xffff;
            else if (y>=H-16) {
                static const uint16_t test[] = {0xf800,0x07e0,0x001f,0xffff};
                color = test[x/80];
            } else {
                unsigned i=2*(y*W+x);
                color = trial_art[i] | ((uint16_t)trial_art[i+1]<<8);
            }
            row[2*x]=color;
            row[2*x+1]=color>>8;
        }
#ifdef H2_PANEL_SLCD
        if (!h2_slcd_trial_row(y,row)) {
            h2_slcd_trial_end(false);
            return 0;
        }
#else
        h2_panel_row(y,row);
#endif
    }
#ifdef H2_PANEL_SLCD
    h2_slcd_trial_end(true);
#endif
    h2_panel_light();
#ifdef H2_PANEL_LIVE
    return cookie;
#else
    return ID ^ cookie;
#endif
}
