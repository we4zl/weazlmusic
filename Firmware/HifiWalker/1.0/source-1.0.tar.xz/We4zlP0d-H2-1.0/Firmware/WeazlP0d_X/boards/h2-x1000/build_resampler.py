"""Emit the Q15 stereo interpolator for the 147:160 sample rate conversion."""
from math import cos, pi, sin
from pathlib import Path
import sys


def build(path):
    taps, phases, scale = 16, 160, 32768
    rows = []
    for phase in range(phases):
        kernel = []
        for tap in range(taps):
            x = tap - (taps // 2 - 1) - phase / phases
            window = (1 + cos(pi * x / (taps / 2))) / 2
            angle = 0.94 * pi * x
            kernel.append(window * (sin(angle) / angle if angle else 1))
        total = sum(kernel)
        weights = [round(value * scale / total) for value in kernel]
        weights[taps // 2 - 1] += scale - sum(weights)
        assert max(weights) < scale and sum(abs(value) for value in weights) < 2 * scale - 1
        rows.append("    {" + ", ".join(map(str, weights)) + "},\n")
    path.write_text(f"enum {{ RESAMPLE_PHASES = {phases}, RESAMPLE_TAPS = {taps} }};\n"
                    "static const int16_t resample_coefficients[RESAMPLE_PHASES][RESAMPLE_TAPS] = {\n" +
                    "".join(rows) + "};\n")


if __name__ == "__main__":
    build(Path(sys.argv[1]))
