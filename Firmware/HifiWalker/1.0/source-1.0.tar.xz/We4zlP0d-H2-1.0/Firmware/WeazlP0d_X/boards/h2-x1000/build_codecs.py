"""Compile the same fixed-point providers as the Echo Mini for freestanding MIPS."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT / "tools"))
from post_mvp_codec_feasibility import SHIMS, units


def main(out, flags):
    headers = out / "codec-headers"
    for name, contents in SHIMS.items():
        header = headers / name
        header.parent.mkdir(parents=True, exist_ok=True)
        header.write_text(contents)
    runtime = ["udivdi3", "udivmoddi4", "ashldi3", "ashrdi3", "lshrdi3",
               "floatdidf", "fixunsdfdi", "divdf3", "muldf3"]
    sources = [(f"third_party/compiler-rt/{name}.c", []) for name in runtime]
    sources.append(("src/codec_runtime.c", []))
    for source, options in units():
        if source == "third_party/libmad/layer12.c":
            continue
        if source.startswith(("third_party/faad2/", "third_party/libmad/")) or source in {
            "src/codec.c", "src/codec_m4a.c", "src/codec_mp3.c"
        }:
            options = [opt for opt in options if opt != "-DCODEC_COOPERATIVE_PROGRESS=1"]
            sources.append((source, options))

    def compile_unit(unit):
        source, options = unit
        obj = out / (source.replace("/", "_") + ".o")
        subprocess.run(["clang", *flags, "-Oz", "-Wno-error", f"-I{headers}",
                        "-DCODEC_ENABLE_OPUS=0", "-DCODEC_ENABLE_VORBIS=0", "-DCODEC_FAULT_ON_ALLOC=1",
                        "-DDRFLAC_INLINE=inline", "-DWEAZL_LAYER3_ONLY",
                        *options, "-c", source, "-o", obj], cwd=ROOT, check=True)
        return obj

    with ThreadPoolExecutor(max_workers=4) as pool:
        objects = list(pool.map(compile_unit, sources))
    archive = out / "codecs.a"
    archive.unlink(missing_ok=True)
    subprocess.run(["llvm-ar", "rcs", archive, *objects], check=True)


if __name__ == "__main__":
    main(Path(sys.argv[1]), sys.argv[2:])
