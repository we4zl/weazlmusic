#ifndef H2_MEDIA_PROBE_H
#define H2_MEDIA_PROBE_H
#include "fs.h"
#include "trip.h"
typedef struct {
#if BUILD_MINOR >= 42
    char pod_name[33];
#endif
    fs volume;
    fs_file directory, clip;
    uint32_t clip_id, block_at;
    uint8_t block[512];
    int block_valid;
    trip_player player;
} h2_library;
unsigned h2_media_mount(h2_library *media);
#if BUILD_MINOR >= 55
int h2_media_radio_bookmark(h2_library *media);
int h2_media_radio_read(unsigned slot, uint8_t data[512]);
int h2_media_radio_write(unsigned slot, const uint8_t data[512]);
#endif
unsigned h2_media_open(h2_library *media,unsigned row,unsigned offset_ms);
unsigned h2_media_probe(uint32_t report[16],unsigned row,unsigned offset_ms);
#endif
