/* The final written page of a slot is its manifest. Interrupted transfers have
 * no valid header and an existing verified slot remains independently bootable. */
#include "boot_slot.h"
#ifdef H2_BOOT_GUARD
#include "boot_health.h"
#endif

static uint32_t accumulate(uint32_t crc,const uint8_t *p,unsigned bytes)
{
    for (unsigned n=0; n<bytes; ++n) {
        crc^=p[n];
        for (unsigned bit=0; bit<8; ++bit)
            crc=(crc>>1)^(0xedb88320u&-(crc&1));
    }
    return crc;
}

int h2_read_header(h2_read_page read,void *context,unsigned first,uint32_t *header,h2_image *image)
{
    if (!read(context,first+H2_BOOT_SLOT_PAGES-1,header) ||
        header[0]!=H2_BOOT_BOARD ||
#ifndef H2_BOOT_GUARD
        header[1]!=H2_BOOT_FORMAT ||
#endif
        !header[2] ||
        !header[3] || (header[3]&3) || header[3]>H2_BOOT_IMAGE_LIMIT ||
        header[5]!=H2_BOOT_BASE || !header[6] ||
        header[7]!=~accumulate(~0u,(const uint8_t *)header,28))
        return 0;
#ifdef H2_BOOT_GUARD
    if (header[1]!=H2_BOOT_FORMAT &&
        (header[1]!=H2_BOOT_FORMAT_GUARDED || header[2]>H2_HEALTH_GENERATION_MAX))
        return 0;
#endif
    *image=(h2_image){.generation=header[2],.length=header[3],.crc=header[4],.id=header[6]};
#ifdef H2_BOOT_GUARD
    image->format=header[1];
#endif
    return 1;
}

static int load(h2_read_page read,void *context,unsigned first,const h2_image *image,uint32_t *page,uint8_t *out)
{
    uint32_t crc=~0u;
    for (unsigned offset=0; offset<image->length;) {
        unsigned bytes=image->length-offset;
        if (bytes>H2_NAND_PAGE)
            bytes=H2_NAND_PAGE;
        if (!read(context,first+offset/H2_NAND_PAGE,page))
            return 0;
        crc=accumulate(crc,(const uint8_t *)page,bytes);
        for (unsigned i=0;i<bytes;++i)
            out[offset+i]=((const uint8_t *)page)[i];
        offset+=bytes;
    }
    return ~crc==image->crc;
}

int h2_load_best(h2_read_page read,void *context,unsigned avoid,uint32_t *scratch,uint8_t *out,h2_image *chosen)
{
    static const unsigned first[]={H2_BOOT_SLOT_A,H2_BOOT_SLOT_B};
    h2_image images[2];
    int valid[2];
    for (unsigned i=0;i<2;++i)
        valid[i]=h2_read_header(read,context,first[i],scratch,&images[i]);
    unsigned preferred=!valid[0] || (valid[1] && images[1].generation>images[0].generation);
    for (unsigned k=0;k<2;++k) {
        unsigned slot=preferred^k;
        if (valid[slot] && first[slot]!=avoid && load(read,context,first[slot],&images[slot],scratch,out)) {
#ifdef H2_BOOT_GUARD
            volatile h2_image *selected=chosen;
            selected->generation=images[slot].generation;
            selected->length=images[slot].length;
            selected->crc=images[slot].crc;
            selected->id=images[slot].id;
            selected->format=images[slot].format;
#else
            *chosen=images[slot];
#endif
            return slot+1;
        }
    }
    return 0;
}
