#ifndef H2_BOOT_LAUNCH_H
#define H2_BOOT_LAUNCH_H

#include "boot_slot.h"
#include "boot_health.h"

typedef unsigned (*h2_boot_loader)(unsigned avoid,h2_image *chosen);

static inline int h2_boot_launchable(unsigned slot,h2_image *chosen,h2_boot_loader load)
{
    uint32_t previous=h2_health_read();
    uint32_t health=h2_health_resume(previous,chosen->generation);
    if (health&(1u<<(slot-1))) {
        slot=(health&3u)==3u ? 0 : load(slot==1 ? H2_BOOT_SLOT_A : H2_BOOT_SLOT_B,chosen);
        if (!slot) {
            if (health!=previous)
                h2_health_write(health);
            return 0;
        }
    }
    int guarded=chosen->format==H2_BOOT_FORMAT_GUARDED;
    if (guarded)
        health=h2_health_attempt(health,slot-1);
    if ((health&15u) && health!=previous && !h2_health_write(health))
        return 0;
    if (guarded)
        h2_health_arm();
    return 1;
}

#endif
