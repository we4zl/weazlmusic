#!/usr/bin/env bash
set -euo pipefail
board=$(cd "$(dirname "$0")" && pwd -P)
root=$(git -C "$board" rev-parse --show-toplevel)
minor=${1:-5}
defines=()
sources=(start.S cold_start.c ddr.c nand_read.c boot_slot.c boot_usb.c ram_service.c)
stack_floor=0xf4003a00
bridge_limit=0x2200
stack_kib=1.5
case "$minor" in
    5) ;;
    11|13|15)
        defines+=(-DH2_BOOT_GUARD)
        sources+=(boot_health.c)
        stack_floor=0xf4003c00
        bridge_limit=0x2400
        stack_kib=1
        ;;
    *) exit 2 ;;
esac
if [[ "$minor" == 13 || "$minor" == 15 ]]; then
    defines+=(-DH2_BOOT_RAM_TRIAL)
fi
if [[ "$minor" == 15 ]]; then
    defines+=(-DH2_INHERIT_USB_PHY)
fi
printf -v build 'h%02d' "$minor"
work="$root/build/hifih2/boot/$build"
mkdir -p "$work"
sed "s/0xf4003a00/$stack_floor/;s/H01 needs 1.5 KiB/${build^^} needs $stack_kib KiB/" "$board/sram.ld" >"$work/sram.ld"
sed 's/0xf4000818/0xa0400018/;s/\.text : {/\.text : SUBALIGN(4) {/' "$board/bridge.ld" >"$work/bridge.ld"
flags=(--target=mipsel-none-elf -march=mips32r2 -msoft-float -mno-abicalls -fno-pic -G0 -Oz -ffreestanding -fno-builtin -fno-stack-protector -ffunction-sections -fdata-sections -Wall -Wextra -Werror)
objects=()
for f in "${sources[@]}"; do
    object="$work/${f%.*}.o"
    clang "${flags[@]}" "${defines[@]}" -fstack-usage -DBUILD_MINOR="$minor" -DH2_SERVICE -DH2_DDR_SERVICE -DH2_COLD_STAGE -c "$board/$f" -o "$object"
    objects+=("$object")
done
ld.lld -m elf32ltsmip --gc-sections -T "$work/sram.ld" "${objects[@]}" -o "$work/$build.elf"
llvm-objcopy -O binary "$work/$build.elf" "$work/$build.tmp"
published="$root/Firmware/HifiWalker/${build^^}/${build^^}.bin"
if [[ -f "$published" ]] && ! cmp -s "$work/$build.tmp" "$published"; then
    echo "The published ${build^^} differs. Use a new build ID." >&2
    exit 1
fi
mv "$work/$build.tmp" "$work/$build.bin"
clang "${flags[@]}" "${defines[@]}" -DH2_BRIDGE_DEST=0xf4001800 -DH2_BRIDGE_LIMIT="$bridge_limit" -c "$board/bridge.c" -o "$work/bridge.o"
ld.lld -m elf32ltsmip --gc-sections -T "$work/bridge.ld" "$work/bridge.o" -o "$work/bridge.elf"
llvm-objcopy -O binary "$work/bridge.elf" "$work/bridge.bin"
llvm-readelf -h "$work/bridge.elf" | awk '/Entry point address/ {e=tolower($NF)} END {exit e!="0xa0400018"}'
if [[ "$minor" == 13 || "$minor" == 15 ]]; then
    clang "${flags[@]}" "${defines[@]}" -DH2_BRIDGE_DEST=0xf4001800 -DH2_BRIDGE_LIMIT="$bridge_limit" -DH2_TIMED_RAM_TRIAL -c "$board/bridge.c" -o "$work/timed-bridge.o"
    ld.lld -m elf32ltsmip --gc-sections -T "$work/bridge.ld" "$work/timed-bridge.o" -o "$work/timed-bridge.elf"
    llvm-objcopy -O binary "$work/timed-bridge.elf" "$work/timed-bridge.bin"
    llvm-readelf -h "$work/timed-bridge.elf" | awk '/Entry point address/ {e=tolower($NF)} END {exit e!="0xa0400018"}'
fi
if [[ "$minor" == 15 ]]; then
    clang "${flags[@]}" -DH2_RTC_PROBE -c "$board/bridge.c" -o "$work/rtc-probe.o"
    ld.lld -m elf32ltsmip --gc-sections -T "$work/bridge.ld" "$work/rtc-probe.o" "$work/boot_health.o" -o "$work/rtc-probe.elf"
    llvm-objcopy -O binary "$work/rtc-probe.elf" "$work/rtc-probe.bin"
    llvm-readelf -h "$work/rtc-probe.elf" | awk '/Entry point address/ {e=tolower($NF)} END {exit e!="0xa0400018"}'
fi
tmp=$(mktemp -d "$work/pack.XXXXXX")
trap 'rm -f "$tmp/$build-spl.img"; rmdir "$tmp"' EXIT
python "$board/boot_pack.py" rom "$work/$build.bin" "$tmp/$build-spl.img"
install -m 644 "$tmp/$build-spl.img" "$work/$build-spl.img"
llvm-size "$work/$build.elf"
