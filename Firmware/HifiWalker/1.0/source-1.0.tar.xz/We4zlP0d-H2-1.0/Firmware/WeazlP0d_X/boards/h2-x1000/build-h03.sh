#!/usr/bin/env bash
set -euo pipefail
board=$(cd "$(dirname "$0")" && pwd -P)
root=$(git -C "$board" rev-parse --show-toplevel)
work="$root/build/hifih2/H03"
out="$root/Firmware/HifiWalker/H03"
mkdir -p "$work" "$out"
flags=(--target=mipsel-none-elf -march=mips32r2 -msoft-float -mno-abicalls -fno-pic -G0 -Os -ffreestanding -fno-builtin -fno-stack-protector -Wall -Wextra -Werror)
for src in ddr-entry.S boot_usb.c ram_service.c; do
    clang "${flags[@]}" -DH2_SERVICE -DH2_DDR_SERVICE -DBUILD_MINOR=3 -c "$board/$src" -o "$work/${src%.*}.o"
done
ld.lld -m elf32ltsmip -T "$board/ddr.ld" "$work/ddr-entry.o" "$work/boot_usb.o" "$work/ram_service.o" -o "$work/H03.elf"
llvm-objcopy -O binary "$work/H03.elf" "$work/H03.bin"
clang "${flags[@]}" -c "$board/bridge.c" -o "$work/bridge.o"
ld.lld -m elf32ltsmip -T "$board/bridge.ld" "$work/bridge.o" -o "$work/bridge.elf"
llvm-objcopy -O binary "$work/bridge.elf" "$work/bridge.bin"
for item in H03.bin bridge.bin; do
    if [[ -f "$out/$item" ]] && ! cmp -s "$out/$item" "$work/$item"; then
        echo "The published H03 $item differs. Give your build a new ID." >&2
        exit 1
    fi
    install -m 644 "$work/$item" "$out/$item"
done
(cd "$out" && sha256sum H03.bin bridge.bin > SHA256SUMS)
