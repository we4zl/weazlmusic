#ifndef H2_BOOT_SLOT_H
#define H2_BOOT_SLOT_H

#include <stdint.h>

#define H2_BOOT_FORMAT 0x10001u
#define H2_BOOT_FORMAT_GUARDED 0x10002u
#define H2_BOOT_BOARD 0x48325734u
#define H2_BOOT_BASE 0xa0600000u
#define H2_BOOT_HEADER_WORDS 8u
#define H2_NAND_PAGE 2048u
#define H2_NAND_BLOCK_PAGES 64u
#define H2_BOOT_SLOT_A 512u   /* NAND offset 1 MiB */
#define H2_BOOT_SLOT_B 768u   /* NAND offset 1.5 MiB */
#define H2_BOOT_SLOT_PAGES 256u
#define H2_BOOT_IMAGE_LIMIT 0x38000u /* Reserve the resident service's stack. */

typedef struct {
    uint32_t generation, length, crc, id;
#ifdef H2_BOOT_GUARD
    uint32_t format;
#endif
} h2_image;

typedef int (*h2_read_page)(void *context, unsigned page, uint32_t data[H2_NAND_PAGE/4]);
int h2_read_header(h2_read_page read, void *context, unsigned page, uint32_t *header, h2_image *image);
int h2_load_best(h2_read_page read, void *context, unsigned avoid, uint32_t *scratch, uint8_t *out, h2_image *chosen);
#endif
