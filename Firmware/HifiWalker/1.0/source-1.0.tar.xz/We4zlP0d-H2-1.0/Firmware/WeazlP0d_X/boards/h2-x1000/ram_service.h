#ifndef H2_RAM_SERVICE_H
#define H2_RAM_SERVICE_H
#include <stdint.h>
int h2_request(unsigned request, unsigned value, unsigned index, unsigned length, uint8_t *response);
void h2_trial_tick(void);
#endif
