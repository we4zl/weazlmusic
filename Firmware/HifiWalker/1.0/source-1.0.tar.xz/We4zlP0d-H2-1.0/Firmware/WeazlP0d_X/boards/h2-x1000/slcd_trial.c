/* X1000 SLCD register and pin trial for the H2's 8-bit 8080 panel. */
#include "panel.h"
#include "panel_profile.h"

#define IO(base,off) (*(volatile uint32_t *)((uintptr_t)(base)+(off)))
#define LCD(off) IO(0xb3050000u,off)
#define CPM(off) IO(0xb0000000u,off)
#define GPIO(bank,off) IO(0xb0010000u,0x100u*(bank)+(off))
#define OST IO(0xb2000000u,0x20)
enum {
    A, B, RESET=1u<<13, RD=1u<<16, WR=1u<<17, CE=1u<<18, DC=1u<<20,
    LCD_GATE=1u<<23, CLOCK_SOURCE=1u<<31, DIV_ENABLE=1u<<28, DIV_BUSY=1u<<27,
    LCD_CONFIG=0xa0, LCD_CONTROL=0xa4, LCD_STATUS=0xa8, LCD_DATA=0xac,
    LCD_WRITE_TIME=0xb0, LCD_SETUP_HOLD=0xb4, LCD_BUS=0xb8, LCD_WAIT=0xbc,
    LCD_BUSY=1u, LCD_COMMAND=1u<<30, IGNORE_TE=1u<<8, FAST_MODE=1u<<4,
    COMMAND_WIDTH_8=1u<<8, DATA_PINS=0xffu, CONTROL_PINS=WR|DC,
};

/* The host reads this brief receipt through H21's last framebuffer chunk.
   The harness redraws Home before releasing the USB lock. */
enum { AUDIT_MAGIC=0x534c4344u, AUDIT_WORDS=16 };
static volatile uint32_t *const audit=(volatile uint32_t *)(0x80840000u+320*240*2-64);

#ifdef H2_PANEL_LCD_RAILS
void h2_pmic_pins(void);
int h2_pmic_read(uint8_t reg,uint8_t *value);
int h2_pmic_display_enable(void);
static volatile uint32_t *const audit_saved=(volatile uint32_t *)(0x80840000u+320*240*2);

static bool enable_lcd_supply_candidates(void)
{
    uint8_t gates,value;
    h2_pmic_pins();
    if (!h2_pmic_read(0x90,&gates))
        return false;
    audit[11]=gates;
    if (!h2_pmic_display_enable() || !h2_pmic_read(0x90,&value))
        return false;
    audit[12]=value;
    return value==(gates|0x3a);
}
#endif

static bool delay(unsigned ms)
{
    uint32_t start=OST;
    for (unsigned n=0;n<ms*240000u;++n)
        if (OST-start>=ms*6000u)
            return true;
    return false;
}

static bool ready(volatile uint32_t *reg,uint32_t bits)
{
    uint32_t start=OST;
    for (unsigned n=0;n<10000 && OST-start<1200;++n)
        if (!(*reg&bits))
            return true;
    return false;
}

static bool send(uint32_t value)
{
    if (!ready(&LCD(LCD_STATUS),LCD_BUSY))
        return false;
    LCD(LCD_DATA)=value;
    if (LCD(LCD_STATUS)&LCD_BUSY)
        ++audit[6];
    ++audit[7];
    return true;
}

static bool command(unsigned code,const uint8_t *data,unsigned count)
{
    if (!send(LCD_COMMAND|code))
        return false;
    for (unsigned i=0;i<count;++i)
        if (!send(data[i]))
            return false;
    return true;
}

static void select_slcd(unsigned port,uint32_t pins)
{
    GPIO(port,0x18)=pins;
    GPIO(port,0x38)=pins;
    GPIO(port,0x44)=pins;
    GPIO(port,0x28)=pins;
}

void h2_slcd_trial_end(bool complete)
{
    /* Return both banks to the GPIO writer's idle pin state. */
    GPIO(B,0x44)=WR|DC;
    GPIO(B,0x24)=CONTROL_PINS;
    GPIO(A,0x48)=DATA_PINS;
    GPIO(A,0x24)=DATA_PINS;
    if (audit[1]>=2)
        audit[8]=LCD(LCD_STATUS);
    audit[9]=complete;
}

bool h2_slcd_trial_begin(void)
{
#ifdef H2_PANEL_LCD_RAILS
    for (unsigned i=0;i<AUDIT_WORDS;++i)
        audit_saved[i]=audit[i];
#endif
    for (unsigned i=0;i<AUDIT_WORDS;++i)
        audit[i]=0;
    audit[0]=AUDIT_MAGIC;
    audit[1]=1;
    audit[2]=CPM(0x14);
    /* The docked X player has already locked MPLL at 600 MHz. */
    if ((audit[2]&0xfffc0083u)!=0x98000083u)
        return false;
    h2_panel_blank();
    GPIO(B,0x18)=RESET|RD|CE;
    GPIO(B,0x44)=RD|CE;
    GPIO(B,0x48)=RESET;
    GPIO(B,0x38)=RESET|RD|CE;
    GPIO(B,0x24)=RESET|RD|CE;
#ifdef H2_PANEL_LCD_RAILS
    if (!enable_lcd_supply_candidates() || !delay(80))
        return false;
#endif
    CPM(0x20)&=~LCD_GATE;
    CPM(0x64)=CLOCK_SOURCE|DIV_ENABLE|29u;
    if (!ready(&CPM(0x64),DIV_BUSY))
        return false;
    CPM(0x64)&=~DIV_ENABLE;
    audit[1]=2;
    audit[3]=CPM(0x64);

    LCD(LCD_CONFIG)=COMMAND_WIDTH_8;
    LCD(LCD_BUS)=0;     /* 8-bit parallel, 8080, active low write */
    LCD(LCD_CONTROL)=IGNORE_TE|FAST_MODE;
    LCD(LCD_WRITE_TIME)=0;
    LCD(LCD_SETUP_HOLD)=0;
    LCD(LCD_WAIT)=0;
    audit[4]=LCD(LCD_CONTROL);
    audit[5]=LCD(LCD_STATUS);
    select_slcd(A,DATA_PINS);
    select_slcd(B,CONTROL_PINS);
    if (!delay(20))
        return false;
    GPIO(B,0x44)=RESET;
    if (!delay(20))
        return false;
    GPIO(B,0x48)=CE;
    audit[1]=3;
    for (unsigned i=0;i<sizeof panel_setup/sizeof panel_setup[0];++i)
        if (!command(panel_setup[i].command,panel_setup[i].data,panel_setup[i].count))
            return false;
    if (!command(0x11,0,0) || !delay(120) || !command(0x29,0,0) || !delay(20))
        return false;
    audit[1]=4;
    return true;
}

bool h2_slcd_trial_row(unsigned y,const uint8_t *row)
{
    const uint8_t columns[]={0,0,1,63};
    const uint8_t rows[]={0,y,0,y};
    if (!command(0x2a,columns,4) || !command(0x2b,rows,4) || !command(0x2c,0,0))
        return false;
    for (unsigned x=0;x<320;++x)
        if (!send(row[2*x+1]) || !send(row[2*x]))
            return false;
    if (!ready(&LCD(LCD_STATUS),LCD_BUSY))
        return false;
    ++audit[10];
    return true;
}
