.set noreorder
.text
.globl h2_codec_guard
.ent h2_codec_guard
h2_codec_guard:
    sw $sp, 0($a0)
    sw $ra, 4($a0)
    sw $fp, 8($a0)
    sw $s0, 12($a0)
    sw $s1, 16($a0)
    sw $s2, 20($a0)
    sw $s3, 24($a0)
    sw $s4, 28($a0)
    sw $s5, 32($a0)
    sw $s6, 36($a0)
    sw $s7, 40($a0)
    jr $ra
    move $v0, $zero
.end h2_codec_guard

.globl h2_codec_unwind
.ent h2_codec_unwind
h2_codec_unwind:
    lw $sp, 0($a0)
    lw $ra, 4($a0)
    lw $fp, 8($a0)
    lw $s0, 12($a0)
    lw $s1, 16($a0)
    lw $s2, 20($a0)
    lw $s3, 24($a0)
    lw $s4, 28($a0)
    lw $s5, 32($a0)
    lw $s6, 36($a0)
    lw $s7, 40($a0)
    jr $ra
    addiu $v0, $zero, 1
.end h2_codec_unwind
