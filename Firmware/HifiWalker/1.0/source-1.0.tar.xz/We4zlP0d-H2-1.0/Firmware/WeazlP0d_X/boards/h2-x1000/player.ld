OUTPUT_ARCH(mips)
ENTRY(start_player)
SECTIONS {
    . = DEFINED(h2_expanded) ? 0xa0a00000 : 0xa0600000;
    .entry : SUBALIGN(4) { KEEP(*(.entry)) }
    . = ALIGN(16) - 0x20000000;
    .text : AT(ADDR(.text)+0x20000000) SUBALIGN(4) { *(.text*) }
    .rodata : AT(ADDR(.rodata)+0x20000000) { *(.rodata*) }
    .data : AT(ADDR(.data)+0x20000000) { *(.data*) BYTE(0); . = ALIGN(4); }
    .bss (NOLOAD) : SUBALIGN(DEFINED(h2_expanded) ? 32 : 4) { __bss_start = .; *(.bss*) *(.sbss*) . = ALIGN(4); __bss_end = .; }
    /DISCARD/ : { *(.MIPS.abiflags .reginfo .pdr .got .comment .note.*) }
    ASSERT(start_player == (DEFINED(h2_expanded) ? 0xa0a00000 : 0xa0600000), "Unexpected player entry")
    ASSERT(DEFINED(h2_expanded) || LOADADDR(.data) + SIZEOF(.data) <= 0xa0638000, "Player must fit the NAND slot")
    ASSERT(__bss_end <= (DEFINED(h2_expanded) ? 0x80b00000 : 0x806f0000), "Player overlaps reserved DDR")
}
