.set noreorder
.set noat
.section .entry,"ax",@progbits
.globl start_nand_trial
start_nand_trial:
    /* USB places verified bytes through KSEG1. Enter their KSEG0 alias
       with empty primary caches and a stack separate from the supervisor. */
    mfc0 $t0, $16
    addiu $t1, $zero, -8
    and $t0, $t0, $t1
    ori $t0, $t0, 3
    mtc0 $t0, $16
    ehb
    mtc0 $zero, $28
    mtc0 $zero, $29
    ehb
    lui $t0, 0x8000
    ori $t1, $t0, 0x4000
1:  cache 8, 0($t0)
    cache 9, 0($t0)
    addiu $t0, $t0, 32
    bne $t0, $t1, 1b
    nop
    sync
    addiu $sp, $sp, -24
    sw $ra, 20($sp)
    sw $s0, 16($sp)
    move $s0, $sp
    lui $sp, 0x8050
    addiu $sp, $sp, -16
    lui $t0, %hi(inspect_nand)
    addiu $t0, $t0, %lo(inspect_nand)
    jalr $t0
    nop
    move $sp, $s0
    lw $s0, 16($sp)
    lw $ra, 20($sp)
    jr $ra
    addiu $sp, $sp, 24
