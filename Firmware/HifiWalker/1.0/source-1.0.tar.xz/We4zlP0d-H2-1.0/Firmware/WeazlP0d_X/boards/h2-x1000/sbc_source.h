#ifndef H2_SBC_SOURCE_H
#define H2_SBC_SOURCE_H
#include <stdint.h>
#define H2_SBC_SAMPLES 128
#define H2_SBC_FRAME_BYTES(pool) (12u + 2u * (pool))
#define H2_SBC_MAX_POOL 79u /* 510 kb/s at 48 kHz, stereo, 16 blocks */
typedef struct { int16_t delay[2][80]; unsigned offset; } h2_sbc;
void h2_sbc_encode(h2_sbc *state,const int16_t pcm[256],uint8_t *out);
void h2_sbc_encode_pool(h2_sbc *state,const int16_t pcm[256],uint8_t *out,unsigned pool);
#endif
