/* H2 hw4, 8-bit 8080 panel. The GPIO path is a diagnostic reference for
 * later migration to the SoC's LCD DMA. Pixel words are native RGB565. */
#include "panel.h"
#include "panel_profile.h"
#define IO(base, off) (*(volatile uint32_t *)((uintptr_t)(base)+(off)))
#define PORT(port, off) IO(0xb0010000u, (port)*0x100+(off))
#define TCU(off) IO(0xb0002000u, off)
#define OST(off) IO(0xb2000000u, off)
#ifdef H2_PANEL_POWER
int h2_pmic_display_enable(void);
#endif
enum {
    A, B, C, D, LCD_WIDTH=320, LCD_HEIGHT=240,
    RESET=1u<<13, RD=1u<<16, WR=1u<<17, CE=1u<<18, DC=1u<<20, BL=1u<<25,
};
static void outputs(unsigned port, uint32_t pins, uint32_t initial)
{
    PORT(port,0x18) = pins;
    PORT(port,0x44) = initial & pins;
    PORT(port,0x48) = ~initial & pins;
    PORT(port,0x38) = pins;
    PORT(port,0x24) = pins;
}
static void bus_hold(void)
{
    __asm__ volatile("sync" ::: "memory");
    uint32_t start=OST(0x20);
    /* Time the strobe after the GPIO write has reached the peripheral bus. */
    for (unsigned n=0;n<1024 && OST(0x20)-start<4;++n) {}
}

static void out_byte(uint8_t value)
{
    PORT(B,0x48) = WR;
    PORT(A,0x44) = value;
    PORT(A,0x48) = (~value)&255;
    bus_hold();
    PORT(B,0x44) = WR;
    bus_hold();
}
static void instruction(unsigned code, const uint8_t *args, unsigned count)
{
    PORT(B,0x48) = DC;
    out_byte(code);
    PORT(B,0x44) = DC;
    for (unsigned i=0;i<count;++i)
        out_byte(args[i]);
}

static void backlight(void)
{
    IO(0xb0000000u,0x20) &= ~(1u<<18);
    TCU(0x18) = 1;
    TCU(0x3c) = 1;
    TCU(0x48) = 0;
    TCU(0x40) = 720;
    TCU(0x44) = 540; /* 25% duty */
    TCU(0x4c) = (1u<<7)|4u; /* EXTAL, PWM */
    PORT(C,0x18) = BL;
    PORT(C,0x38) = BL;
    PORT(C,0x48) = BL;
    PORT(C,0x28) = BL;
    TCU(0x14) = 1;
}

static void next_phase(h2_panel_startup *startup,enum h2_panel_phase phase,unsigned ms)
{
    startup->phase=phase;
    startup->deadline=OST(0x20)+ms*6000u;
}

bool h2_panel_step(h2_panel_startup *startup)
{
    if (startup->phase!=H2_PANEL_IDLE &&
        (int32_t)(OST(0x20)-startup->deadline)<0)
        return false;
    switch (startup->phase) {
    case H2_PANEL_IDLE:
        outputs(C,BL,0);
        outputs(A,255,0);
        outputs(B,RESET|RD|WR|CE|DC,RD|WR|CE|DC);
#ifdef H2_PANEL_POWER
        if (!h2_pmic_display_enable()) {
            startup->phase=H2_PANEL_FAILED;
            return false;
        }
        next_phase(startup,H2_PANEL_RESET_LOW,100);
#else
        next_phase(startup,H2_PANEL_RESET_LOW,20);
#endif
        break;
    case H2_PANEL_RESET_LOW:
        PORT(B,0x44)=RESET;
        next_phase(startup,H2_PANEL_RESET_HIGH,20);
        break;
    case H2_PANEL_RESET_HIGH:
        PORT(B,0x48)=CE;
        for (unsigned i=0;i<sizeof panel_setup/sizeof panel_setup[0];++i)
            instruction(panel_setup[i].command,panel_setup[i].data,panel_setup[i].count);
        instruction(0x11,0,0);
        next_phase(startup,H2_PANEL_SLEEP_OUT,120);
        break;
    case H2_PANEL_SLEEP_OUT:
        instruction(0x29,0,0);
        next_phase(startup,H2_PANEL_DISPLAY_ON,20);
        break;
    case H2_PANEL_DISPLAY_ON:
        startup->phase=H2_PANEL_READY;
        return true;
    case H2_PANEL_READY:
        return true;
    case H2_PANEL_FAILED:
        return false;
    }
    return false;
}

bool h2_panel_begin(void)
{
    h2_panel_startup startup={0};
    for (unsigned tries=0;tries<180u*240000u;++tries)
        if (h2_panel_step(&startup))
            return true;
    return false;
}
void h2_panel_row(unsigned y, const uint8_t *line)
{
    if (y >= LCD_HEIGHT)
        return;
    const uint8_t columns[4] = {0,0,(LCD_WIDTH-1)>>8,(LCD_WIDTH-1)&255};
    uint8_t row[4] = {0,y,0,y};
    instruction(0x2a,columns,4);
    instruction(0x2b,row,4);
    instruction(0x2c,0,0);
    for (unsigned x=0; x<LCD_WIDTH; ++x) {
        out_byte(line[2*x+1]);
        out_byte(line[2*x]);
    }
}
void h2_panel_light(void)
{
    backlight();
}

void h2_panel_blank(void)
{
    TCU(0x18)=1;
    outputs(C,BL,0);
}

#if BUILD_MINOR >= 46
#include "panel_scroll.h"
#endif
