/* Cooperative X application trials under the resident SRAM USB service.
 * The ROM upload entry is above these slots. Once running, reserve the
 * former ROM scratch for candidate apps and keep the service's own stack high. */
#include "ram_service.h"
#include <stddef.h>

enum { HEADER_SIZE = 24, COOKIE = 0x58324832u };
enum { EMPTY, RECEIVING, VERIFIED, INCOMPATIBLE, DAMAGED, RUNNING, REJECTED };
enum { NONE = 2 };
#ifdef H2_DDR_SERVICE
enum { SLOT_SIZE = 0x100000 };
static const uintptr_t slot_base[] = {0xa0400000u, 0xa0500000u};
#else
enum { SLOT_SIZE = 2048 };
static const uintptr_t slot_base[] = {0xf4000000u, 0xf4000800u};
#endif
static unsigned active = NONE, previous = NONE, staged = NONE, pending = NONE;
static unsigned transferred, size, state, ticks;
static uint32_t build[2], result[2], current;
#if defined(H2_DDR_SERVICE) && !defined(H2_COLD_STAGE)
static unsigned memory_state = 1;
#else
static unsigned memory_state;
#endif
#ifdef H2_COLD_STAGE
void h2_set_ddr_status(unsigned state) { memory_state=state; }
#endif
#ifndef H2_DDR_SERVICE
static unsigned memory_pending;
unsigned h2_ddr_initialize(void);
#endif

static volatile uint32_t *words(unsigned slot)
{
    return (volatile uint32_t *)slot_base[slot];
}

static uint32_t crc32(const volatile uint8_t *data, size_t length)
{
    uint32_t crc = 0xffffffff;
    while (length--) {
        crc ^= *data++;
        for (unsigned bit = 0; bit < 8; ++bit)
            crc = (crc >> 1) ^ (0xedb88320u & -(crc & 1));
    }
    return ~crc;
}

static void encode(uint8_t *out, uint32_t value)
{
    for (unsigned i = 0; i < 4; ++i)
        out[i] = (uint8_t)(value >> (8*i));
}

static unsigned verify(void)
{
    volatile uint32_t *p = words(staged);
    if (p[0] != 0x41325857 || p[1] != 0x00020101 ||
        p[2] != (uint32_t)(slot_base[staged] + HEADER_SIZE) ||
        p[3] != size - HEADER_SIZE || !p[4])
        return INCOMPATIBLE;
    if (crc32((const volatile uint8_t *)p + HEADER_SIZE, size - HEADER_SIZE) != p[5])
        return DAMAGED;
    build[staged] = p[4];
    return VERIFIED;
}

int h2_request(unsigned request, unsigned value, unsigned index, unsigned length, uint8_t *out)
{
    uint32_t word = value | ((uint32_t)index << 16);
#ifdef H2_DDR_SERVICE
    unsigned slot = word >> 31;
    unsigned requested_size = word & 0x7fffffffu;
#else
#define slot index
#define requested_size value
#endif
#ifdef H2_COLD_STAGE
    if (memory_state!=1 && request!=0x43c0)
        return 0;
#endif
    switch (request) {
    case 0x43c0:
        if (length != 32 || word)
            return 0;
        encode(out, state);
        encode(out+4, active);
        encode(out+8, active == NONE ? 0 : build[active]);
        encode(out+12, current);
        encode(out+16, previous);
        encode(out+20, transferred);
        encode(out+24, ticks);
        encode(out+28, memory_state);
        return 1;
    case 0x4440:
        if (length || requested_size < HEADER_SIZE+4 || requested_size > SLOT_SIZE || (requested_size & 3) || slot > 1 ||
            slot == active || pending != NONE)
            return 0;
        staged = slot;
        if (staged == previous)
            previous = NONE;
        transferred = 0;
        size = requested_size;
        state = RECEIVING;
        return 1;
    case 0x4540:
        if (length || state != RECEIVING || transferred >= size)
            return 0;
        words(staged)[transferred/4] = word;
        transferred += 4;
        return 1;
    case 0x4640:
        if (length || word || state != RECEIVING || transferred != size)
            return 0;
        state = verify();
        return 1;
    case 0x4740:
        if (length || word || state != VERIFIED || pending != NONE)
            return 0;
        pending = staged;
        state = RUNNING;
        return 1;
    case 0x4840:
        if (length || word || previous == NONE || pending != NONE)
            return 0;
        pending = previous;
        state = RUNNING;
        return 1;
#ifndef H2_DDR_SERVICE
    case 0x4940:
        if (length || word || memory_state || memory_pending)
            return 0;
        memory_pending = 1;
        return 1;
#endif
    default:
        return 0;
    }
#undef slot
#undef requested_size
}

void h2_trial_tick(void)
{
    ++ticks;
#ifndef H2_DDR_SERVICE
    if (memory_pending) {
        memory_pending = 0;
        memory_state = h2_ddr_initialize();
    }
#endif
    if (pending == NONE)
        return;
    /* Candidate entry point is only reached through a validated slot. This
     * initial ABI calls cooperative diagnostics, which must return to USB. */
    typedef uint32_t (*entry_fn)(uint32_t);
    entry_fn run = (entry_fn)(slot_base[pending] + HEADER_SIZE);
    __asm__ volatile("sync" ::: "memory");
    result[pending] = run(COOKIE);
    if (result[pending] == (build[pending] ^ COOKIE)) {
        previous = active;
        active = pending;
        current = result[pending];
        state = RUNNING;
    } else {
        state = REJECTED;
    }
    pending = NONE;
}
