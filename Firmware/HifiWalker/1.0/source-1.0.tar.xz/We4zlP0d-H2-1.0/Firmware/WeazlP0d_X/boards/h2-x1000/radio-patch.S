.section .rodata
.globl h2_radio_patch
.globl h2_radio_patch_end
h2_radio_patch:
    .incbin H2_RADIO_PATCH
h2_radio_patch_end:
