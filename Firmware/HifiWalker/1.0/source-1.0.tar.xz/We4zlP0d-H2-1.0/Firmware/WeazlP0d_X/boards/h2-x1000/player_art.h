/* H2 album shelves and Now Playing, drawn one native RGB565 scanline at a time. */
#if BUILD_MINOR >= 63
enum { TILE_COUNT=BROWSE_COUNT };
#define TILE(i) tiles[(first+(i))%TILE_COUNT]
#else
enum { TILE_COUNT=4 };
#define TILE(i) tiles[i]
#endif
enum { COVER_SIDE=80, TILE_SIDE=68, COVER_BYTES=COVER_SIDE*COVER_SIDE*2 };
static struct {
    uint32_t offset;
    unsigned received;
    uint8_t pixels[COVER_BYTES];
} tiles[TILE_COUNT];

static void invalidate_tiles(void)
{
    for (unsigned i=0;i<TILE_COUNT;++i) {
        tiles[i].offset=0;
        tiles[i].received=0;
    }
}

static void span(uint8_t *line,unsigned x,unsigned width,uint16_t color)
{
    for (unsigned end=x+width;x<end;++x) {
        line[x*2]=color>>8;
        line[x*2+1]=color;
    }
}

#if BUILD_MINOR < 63
static void cassette(unsigned y,unsigned x,unsigned top,unsigned size,uint8_t *line)
{
    unsigned h=size*2/3;
    if (y<top || y>=top+h)
        return;
    unsigned row=y-top;
    span(line,x,size,MUTED);
    if (row==0 || row+1==h)
        return;
    span(line,x+1,size-2,FOCUS);
    if (row>=4 && row<=7)
        span(line,x+6,size-12,0xec5b);
    unsigned radius=h/5;
    int dy=(int)row-(int)(h*3/5);
    for (unsigned reel=1;reel<=2;++reel) {
        unsigned center=x+size*reel/3;
        for (int dx=-(int)radius;dx<=(int)radius;++dx) {
            unsigned d=dx*dx+dy*dy;
            if (d<=radius*radius)
                span(line,center+dx,1,d>=(radius-2)*(radius-2) ? ACCENT :
                     d<=radius*radius/9 ? 0xec5b : BACKGROUND);
        }
    }
}
#endif

/* Read one sector per player tick, outside the renderer and after the audio pump. */
static int load_tile_chunk(void)
{
    if (page!=SHELVES)
        return 0;
#if BUILD_MINOR >= 63
    if (!paint_idle()) return 0;
#endif
    for (unsigned i=0;i<TILE_COUNT && first+i<count;++i) {
        if (!TILE(i).offset || TILE(i).received==COVER_BYTES)
            continue;
        unsigned at=TILE(i).received;
        unsigned n=COVER_BYTES-at<512 ? COVER_BYTES-at : 512;
        trip_player *p=&library.player;
        if (p->read(p->context,0,TILE(i).offset+at,TILE(i).pixels+at,n))
            TILE(i).received+=n;
        else
            TILE(i).offset=0;
        if (TILE(i).received==COVER_BYTES) {
#if BUILD_MINOR >= 63
            unsigned top=BROWSE_TOP+i*BROWSE_ROW;
            repaint(top,top+BROWSE_ROW);
#else
            visible_y=0;
#endif
        }
        return 1;
    }
    return 0;
}

#if BUILD_MINOR < 63
static void album_tiles(unsigned y,uint8_t *line)
{
    for (unsigned i=0;i<TILE_COUNT && first+i<count;++i) {
        unsigned x=53+(i%2)*146, top=48+(i/2)*76;
        if (y<top-2 || y>=top+TILE_SIDE+2)
            continue;
        if (first+i==cursor) {
            span(line,x-2,TILE_SIDE+4,ACCENT);
            if (y>=top && y<top+TILE_SIDE)
                span(line,x,TILE_SIDE,BACKGROUND);
        }
        if (y<top || y>=top+TILE_SIDE)
            continue;
        if (tiles[i].received!=COVER_BYTES || !tiles[i].offset) {
            cassette(y,x,top+10,TILE_SIDE,line);
            continue;
        }
        const uint8_t *src=tiles[i].pixels+2*COVER_SIDE*((y-top)*COVER_SIDE/TILE_SIDE);
        for (unsigned j=0;j<TILE_SIDE;++j) {
            unsigned k=2*(j*COVER_SIDE/TILE_SIDE);
            line[2*(x+j)]=src[k];
            line[2*(x+j)+1]=src[k+1];
        }
    }
    if (count)
        ui_marquee_row(y,16,198,W-32,1,labels[cursor-first],INK,now,line);
}
#endif

static void playback_time(uint32_t frames,char out[10])
{
    unsigned seconds=frames/48000, minutes=seconds/60;
    unsigned divisor=1000;
    while (divisor>1 && minutes<divisor)
        divisor/=10;
    do {
        *out++='0'+minutes/divisor;
        minutes%=divisor;
        divisor/=10;
    } while (divisor);
    *out++=':';
    *out++='0'+seconds%60/10;
    *out++='0'+seconds%10;
    *out=0;
}

#if BUILD_MINOR < 63
static void playback_progress(unsigned y,uint8_t *line)
{
    uint32_t frames=library.player.frames, pos=active_position();
    if (pos>frames)
        pos=frames;
    if (y>=181 && y<185) {
        unsigned width=W-40;
        if (frames>UINT32_MAX/width) {
            frames>>=9;
            pos>>=9;
        }
        span(line,20,width,FOCUS);
        span(line,20,frames ? pos*width/frames : 0,ACCENT);
    } else if (y>=190 && y<210) {
        char elapsed[10], duration[10];
        playback_time(pos,elapsed);
        playback_time(frames,duration);
        ui_text_row(y,20,190,88,0,elapsed,MUTED,line);
        ui_text_row(y,W-20-ui_text_width(0,duration),190,88,0,duration,MUTED,line);
    }
}
#endif
