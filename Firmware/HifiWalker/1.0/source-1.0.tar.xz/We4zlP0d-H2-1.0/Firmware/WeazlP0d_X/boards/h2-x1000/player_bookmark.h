#ifndef H2_PLAYER_BOOKMARK_H
#define H2_PLAYER_BOOKMARK_H

enum { RADIO_STATIONS=6, BOOKMARK_WORDS=11 };
static uint32_t edition[RADIO_STATIONS], saved_frame, bookmark_sequence;
static unsigned station_row, saved_station, bookmark_ready;

static uint32_t bookmark_word(const uint8_t *bytes)
{
    return (uint32_t)bytes[0] | (uint32_t)bytes[1]<<8 |
           (uint32_t)bytes[2]<<16 | (uint32_t)bytes[3]<<24;
}

static uint32_t bookmark_checksum(const uint8_t *bytes)
{
    uint32_t hash=2166136261u;
    for (unsigned i=0;i<(BOOKMARK_WORDS-1)*4;++i)
        hash=(hash^bytes[i])*16777619u;
    return hash;
}

static void restore_station(void)
{
    const trip_player *p=&library.player;
    uint32_t identity[RADIO_STATIONS]={0};
    uint32_t frames[RADIO_STATIONS];
    for (unsigned i=0;i<p->stations;++i) {
        trip_player item=*p;
        if (!trip_select(&item,p->count+i,0)) {
            bookmark_ready=0;
            station_row=station_frame=0;
            return;
        }
        identity[i]=item.offset;
        frames[i]=item.frames;
    }
    unsigned changed=0;
    for (unsigned i=0;i<RADIO_STATIONS;++i) {
        changed|=edition[i]^identity[i];
        edition[i]=identity[i];
    }
    if (changed) station_row=station_frame=0;
    saved_frame=saved_station=bookmark_sequence=0;
    bookmark_ready=p->stations && h2_media_radio_bookmark(&library);
    if (!bookmark_ready) return;

    for (unsigned slot=0;slot<2;++slot) {
        _Alignas(4) uint8_t bytes[512];
        if (!h2_media_radio_read(slot,bytes) || bookmark_word(bytes)!=0x31535257u ||
            bookmark_checksum(bytes)!=bookmark_word(bytes+(BOOKMARK_WORDS-1)*4))
            continue;
        uint32_t sequence=bookmark_word(bytes+4), row=bookmark_word(bytes+8);
        uint32_t frame=bookmark_word(bytes+12);
        if (!sequence || (sequence&1)!=slot || row>=p->stations || frame>frames[row] ||
            (bookmark_sequence && (int32_t)(sequence-bookmark_sequence)<=0))
            continue;
        unsigned different=0;
        for (unsigned i=0;i<RADIO_STATIONS;++i)
            different|=edition[i]^bookmark_word(bytes+16+4*i);
        if (different) continue;
        bookmark_sequence=sequence;
        saved_station=station_row=row;
        saved_frame=station_frame=frame;
    }
}

static void save_station(void)
{
    if (!bookmark_ready || (saved_station==station_row && saved_frame==station_frame))
        return;
    uint32_t sequence=bookmark_sequence==UINT32_MAX ? 2 : bookmark_sequence+1;
    _Alignas(4) uint8_t bytes[512]={0};
    put32(bytes,0x31535257u); /* WRS1 */
    put32(bytes+4,sequence);
    put32(bytes+8,station_row);
    put32(bytes+12,station_frame);
    for (unsigned i=0;i<RADIO_STATIONS;++i)
        put32(bytes+16+4*i,edition[i]);
    put32(bytes+(BOOKMARK_WORDS-1)*4,bookmark_checksum(bytes));
    if (h2_media_radio_write(sequence&1,bytes)) {
        bookmark_sequence=sequence;
        saved_station=station_row;
        saved_frame=station_frame;
    }
}

#endif
