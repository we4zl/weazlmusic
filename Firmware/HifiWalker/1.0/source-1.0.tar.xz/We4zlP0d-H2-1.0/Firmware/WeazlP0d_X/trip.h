#ifndef WXP_TRIP_H
#define WXP_TRIP_H
#include <stdint.h>
#include <stddef.h>

/* Each occurrence has its own directory row, even when audio extents are shared.
 * The two cursors let FAT keep independent cluster walks for directory and PCM. */
typedef int (*trip_read)(void *context, int audio, uint32_t offset, void *out, size_t bytes);
enum {
    TRIP_CONTINUE, TRIP_RECENT, TRIP_ALBUMS, TRIP_ARTISTS, TRIP_GENRES,
    TRIP_PLAYLISTS, TRIP_MODE, TRIP_DEEP, TRIP_NEEDLE, TRIP_SONGS, TRIP_FAVORITES,
    TRIP_BOOKS, TRIP_PODCASTS, TRIP_QURAN, TRIP_WAREZ, TRIP_VIEW_KINDS,
    TRIP_NEEDLE_LIMIT = 40, TRIP_UP_NEXT_LIMIT = 100, TRIP_LABEL_BYTES = 96
};
typedef struct {
    trip_read read;
    void *context;
    uint32_t size, count, index, offset, frames, position;
    char title[TRIP_LABEL_BYTES + 1], artist[TRIP_LABEL_BYTES + 1];
    uint32_t stations, header, stride, cover;
    uint32_t views, play_first, play_end;
    uint32_t warez_map, warez_count;
    uint16_t view_first[TRIP_VIEW_KINDS], view_count[TRIP_VIEW_KINDS];
    uint32_t shuffle_seed, shuffle_anchor, shuffle_cursor;
    uint32_t album_map;
    unsigned album_anchor; /* Nonzero stores the first album's catalog ordinal plus one. */
    uint32_t draw_total;
    uint32_t lyric_map, lyric_end, queue_fingerprint, metadata_map, metadata_end;
    uint32_t favorite_map, favorite_lookup, favorite_entries;
    uint32_t up_next[TRIP_UP_NEXT_LIMIT], up_next_anchor;
    const uint32_t *local_rows;
    uint32_t local_cursor;
    uint8_t up_next_count, from_up_next;
} trip_player;
typedef struct {
    uint32_t kind, first, count;
    char title[49];
} trip_view;

int trip_open(trip_player *, trip_read, void *context, uint32_t size);
int trip_select(trip_player *, uint32_t index, uint32_t milliseconds);
int trip_view_at(const trip_player *, uint32_t index, trip_view *);
unsigned trip_view_count(const trip_player *, unsigned kind);
int trip_view_by_kind(const trip_player *, unsigned kind, unsigned index, trip_view *);
int trip_spoken_queue(const trip_player *, trip_view *);
#define TRIP_FAVORITE_ALBUM UINT32_C(0x80000000)
uint32_t trip_favorite_key(const trip_player *, uint32_t row, int album);
int trip_favorite_target(const trip_player *, uint32_t key, uint32_t *target);
/* Millisecond bounds for the selected cue or blank interval. */
int trip_lyric(const trip_player *, char line[49], uint32_t bounds[2]);
uint32_t trip_permute(uint32_t index, uint32_t count, uint32_t seed);
void trip_shuffle(trip_player *, uint32_t seed);
int trip_shuffle_albums(trip_player *, uint32_t seed);
int trip_draw(trip_player *, uint32_t seed, unsigned slot, uint32_t milliseconds);
int trip_enqueue(trip_player *, uint32_t row, int next);
void trip_clear_up_next(trip_player *);
void trip_open_local_queue(trip_player *, const uint32_t *rows, uint32_t count);
uint32_t trip_queue_cursor(const trip_player *);
int trip_queue_step(const trip_player *, uint32_t cursor, int next, int wrap, uint32_t *result);
int trip_queue_select(trip_player *, uint32_t cursor, uint32_t milliseconds);
int trip_queue_restart(trip_player *);
/* Returns stereo frames, zero at queue end or -1 on media error. */
int trip_last(const trip_player *);
int trip_pull(trip_player *, int16_t *pcm, unsigned capacity);
void screen_row(const trip_player *, const char *status, unsigned y, uint8_t out[960]);
#endif
