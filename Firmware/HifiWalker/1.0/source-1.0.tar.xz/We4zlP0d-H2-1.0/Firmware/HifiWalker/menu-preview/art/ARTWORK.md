The record-shop illustration in crates.webp was made with the built-in image generator using shared/mascots/weazl/weazlhead.png from ~/weazl_image_assets as the character reference.

Prompt: Create one landscape 4:3 retro pixel-art record shop illustration of this exact Weazl character in his backwards acid-green baseball cap and magenta cybernetic monocle, crate digging, one hand pulling a blank neon coral LP sleeve from wooden bins. Chest-up portrait in right half, head fully in frame. Warm amber shop lamps, ink-black and deep violet shadows, shelves receding left. Colorful hand-pixelled 1990s adventure game background with chunky silhouettes that read well at 320x240. No text, no lettering, no UI, no border.

Tunnel Drive and Relay Station use the existing Vol. 3 4:3 illustrations from the same asset library. The Home portrait uses the original Weazl head.
## Weazl character reference

Use `~/weazl_image_assets/shared/mascots/weazl/WeaZL_fullbody.png` as the primary visual reference for each new menu illustration. Use the head portrait for facial detail. Pixel art at 320 × 240 is approved. Check the character in the final menu crop.

Keep the backward acid-green cap, brown forelock, tan muzzle and magenta eyes. The square metal optic sits over **his left eye** (on the viewer’s right in the reference). His outfit is a black hoodie with bright lime sleeve stripes, matching black track pants and black-and-lime high-tops. In wider shots, keep the long brown tail with its light underside.

The Record Shop scene establishes the pixel style, shelving and amber lighting. Its magenta-and-teal jacket differs from the full-body reference. Use the black-and-lime hoodie when illustrating him in this setting again.


## Record Shop menu set

The port 4009 preview uses four native 320 × 100 banners. The counter serves Home and Now Playing, the bins serve Music and album browsing, the booth serves Flight Recorder and On air, and the workbench serves Bluetooth, Settings and USB Dock.

Built-in image generation used the original full-body character sheet and the approved crate-digging scene as references. The atlas prompt called for four edge-to-edge strips in one amber-lit shop with violet shadows. In order, Weazl cues a turntable, pulls a coral sleeve from the new arrivals bin, tunes an analog receiver, and inspects headphones at the repair counter. Each scene reserves its left half for menu text and places the lime cap, square magenta optic, black hoodie and lime-striped sleeves on the right. The selected crops are shop-counter.webp, shop-bins.webp, shop-booth.webp and shop-bench.webp.
