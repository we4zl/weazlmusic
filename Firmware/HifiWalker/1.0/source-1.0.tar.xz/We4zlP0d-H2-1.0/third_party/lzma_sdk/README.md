# LZMA Decoder

The H2 boot wrapper uses Igor Pavlov's public-domain buffer-to-buffer decoder for its NAND application image. The five source files come from the `C` directory and are unmodified. [7-Zip 25.01 source](https://github.com/ip7z/7zip/tree/25.01/C)
