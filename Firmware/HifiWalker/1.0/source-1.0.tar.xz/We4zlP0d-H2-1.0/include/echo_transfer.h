#ifndef WEAZL_ECHO_TRANSFER_H
#define WEAZL_ECHO_TRANSFER_H
#include "echo_usb.h"
#include "echo_volume.h"
#include "metadata_store.h"
/* Controller for explicit UI USB mode. Hook success must mean actual completed
 * work, not a requested/simulated stop or unmount. Return1 complete,-1 pending,
 *0 terminal failure. Each step invokes at most one hook, plus bounded hardware
 * services. Hooks must schedule background work and must not block audio/UI. */
typedef struct {
 void *context;
 int (*stop_audio)(void *);
 int (*stop_scans)(void *);
 int (*sync_metadata)(void *);
 int (*unmount)(void *);
 int (*invalidate)(void *);
 int (*mount)(void *,int read_only);
} echo_transfer_hooks;
typedef enum { TRANSFER_FIRMWARE,TRANSFER_QUIESCE,TRANSFER_USB_INIT,
 TRANSFER_ACTIVE,TRANSFER_DRAIN,TRANSFER_INVALIDATE,TRANSFER_REMOUNT,
 TRANSFER_GEOMETRY,TRANSFER_MOUNT,TRANSFER_FAILED } echo_transfer_state;
typedef struct {
 echo_volume *volume;
 metadata_store *metadata;
 usb_music *music;
 echo_usb *protocol;
 echo_usb_hw *hardware;
 echo_transfer_hooks hooks;
 echo_usb_mmio mmio;
 const echo_usb_descriptors *descriptors;
 echo_transfer_state state,watched_state;
 uint32_t started,steps;
 uint8_t phase,unclean,watched_phase;
} echo_transfer;
int echo_transfer_init(echo_transfer *,echo_volume *,metadata_store *,usb_music *,
 echo_usb *,echo_usb_hw *,echo_transfer_hooks,const echo_usb_mmio *,const echo_usb_descriptors *);
/* Caller requested mode entry/exit. No automatic reconnect/retry/reset recovery.
 * User exit while still host-owned is conservatively an unclean RO remount;
 * actual host START_STOP/eject can complete a clean return after CSW ACK. */
int echo_transfer_enter(echo_transfer *);
int echo_transfer_leave(echo_transfer *);
echo_transfer_state echo_transfer_step(echo_transfer *);
#endif
