#ifndef WEAZL_FS_H
#define WEAZL_FS_H
#include <stddef.h>
#include <stdint.h>

/* Read-only FAT16/FAT32, fixed 512-byte logical sectors. All sectors passed to
 * the injected reader are relative to a verified user volume, never raw eMMC.
 * The caller owns exclusivity/unmount while host storage is exported.
 * Reader returns1=complete,0=I/O error,-1=pending (schedule/retry later).
 * A pending backend must retain at least4 recently requested FAT sectors, so
 * atomic cycle-check steps can complete across fragmented chains without
 * cache thrashing. Audio data buffers are independent of those metadata pages. */
typedef int (*fs_sector_reader)(void *, uint32_t sector, uint8_t out[512]);
typedef enum {
    FS_OK, FS_END, FS_AGAIN, FS_INVALID, FS_UNSUPPORTED, FS_IO,
    FS_CORRUPT, FS_NOT_FOUND, FS_NOT_DIRECTORY, FS_IS_DIRECTORY
} fs_status;
#define FS_NAME_BYTES 766u /* 255 UTF-16 code units, worst UTF-8 expansion +NUL */
#define FS_PATH_BYTES 1024u

typedef struct {
    fs_sector_reader reader;
    void *context;
    uint32_t device_sectors, partition, total_sectors, fat_start, fat_sectors;
    uint32_t data_start, cluster_count, root_start, root_cluster;
    uint32_t cache_sector;
    uint16_t root_entries, info_sector;
    uint8_t sectors_per_cluster, fat_bits, cache_valid, io_pending;
    uint8_t cache[512];
} fs;
typedef struct {
    uint32_t cluster, size;
    /* Packed raw FAT modification date/time (entry bytes22..25). Coarse2second
     * timestamps alone cannot prove content unchanged; combine with fingerprint. */
    uint32_t modified;
    uint8_t attributes;
    char name[FS_NAME_BYTES];
} fs_entry;
typedef struct {
    fs *volume;
    uint32_t start_cluster, cluster, cluster_index, offset, size;
    uint32_t slow, fast, hops;
    uint8_t failed;
} fs_file;
typedef struct {
    fs *volume;
    uint32_t cluster, slot, slow, fast, hops;
    uint16_t lfn[260];
    uint8_t lfn_expected, lfn_checksum, lfn_count, fixed_root, ended;
} fs_dir;

/* Cooperative lookup borrows an immutable path until completion. Allocate this
 * caller-owned state outside the small application stack. One step examines at
 * most32 raw directory slots, plus bounded FAT-cycle checks. */
typedef struct {
    fs *volume;
    fs_dir directory;
    fs_entry entry;
    const char *cursor, *component;
    size_t component_bytes;
    uint8_t searching, done;
} fs_lookup;
fs_status fs_lookup_begin(fs *volume, const char *path, fs_lookup *lookup);
fs_status fs_lookup_step(fs_lookup *lookup, fs_entry *out);
fs_status fs_open_entry(fs *volume, const fs_entry *entry, fs_file *out);
fs_status fs_dir_open_entry(fs *volume, const fs_entry *entry, fs_dir *out);

/* BPB partition_start must come from verified partition geometry. No MBR
 * guessing or media repair. fs_mount clears volume on failure. */
fs_status fs_mount(fs *volume, fs_sector_reader reader, void *context,
                   uint32_t device_sectors, uint32_t partition_start);
void fs_unmount(fs *volume);
/* FAT32's cached free-sector count, or UINT32_MAX when it is unavailable. */
uint32_t fs_free_sectors(fs *volume);
/* Synchronous convenience path helpers can walk a complete directory. Use the
 * cooperative lookup API in the UI/audio foreground scheduler. Convenience
 * helpers require a synchronous backend; FS_AGAIN loses their local walk state. */
fs_status fs_dir_open(fs *volume, const char *path, fs_dir *out);
/* At most32 raw directory slots per call; FS_AGAIN means yield and retry.
 * Entries and long names are copied into caller-owned output. Invalid/orphan
 * LFN records fall back to the short name. ASCII comparison is case-insensitive;
 * other UTF-8 bytes compare exactly; Unicode case folding is not supplied. */
fs_status fs_dir_next(fs_dir *directory, fs_entry *out);
fs_status fs_open(fs *volume, const char *path, fs_file *out);
/* Returned read count includes any bytes obtained before a later failure.
 * No allocation. Host callback failures poison this handle until reopened. */
fs_status fs_read(fs_file *file, void *out, size_t bytes, size_t *read_bytes);
fs_status fs_seek(fs_file *file, uint32_t offset);
#endif
