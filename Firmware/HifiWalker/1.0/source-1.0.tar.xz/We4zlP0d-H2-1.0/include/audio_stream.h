#ifndef WE4ZL_AUDIO_STREAM_H
#define WE4ZL_AUDIO_STREAM_H
#include <stdint.h>
#define AUDIO_BLOCK_FRAMES 128u
#define AUDIO_RING_FRAMES 512u
typedef enum { AUDIO_OK,AUDIO_AGAIN,AUDIO_END,AUDIO_INVALID,AUDIO_IO,AUDIO_FORMAT_CHANGE } audio_status;
typedef struct {
    void *context;
    /* One bounded decode call; output cap is <=128frames. AGAIN preserves
     * progress; END has zero frames. PCM is interleaved signed16. */
    audio_status (*read)(void *,int16_t *,unsigned,unsigned *);
    uint32_t rate;uint16_t channels;
    uint64_t frames;uint32_t delay,padding;uint8_t total_known;
} audio_source;
typedef audio_status (*audio_next_source)(void *,audio_source *);
typedef audio_status (*audio_sink_write)(void *,const int16_t *,unsigned frames,unsigned *accepted);
typedef void (*audio_transform)(void *,int16_t *,unsigned frames,unsigned channels);
typedef struct {
    audio_source source,pending;
    audio_next_source next;void *next_context;
    audio_sink_write sink;void *sink_context;
    audio_transform transform;void *transform_context;
    uint64_t remaining;
    uint32_t skip,rate,transitions,decode_calls,output_calls;
    uint16_t channels,head,used,volume_q15;
    uint8_t known,need_source,paused,ended,failed,format_pending;
    int16_t ring[AUDIO_RING_FRAMES*2],block[AUDIO_BLOCK_FRAMES*2];
} audio_stream;
/* Real sink must implement a bounded copy/submit with exact accepted count;
 * no sink/next callback is installed by firmware until its hardware contract is
 * complete. Tests use explicit host sinks and do not claim hardware audio. */
audio_status audio_stream_init(audio_stream *,audio_next_source,void *,audio_sink_write,void *);
/* Each step first offers queued audio to sink, then at most one decoder call.
 * Trim leading delay/tail padding from explicit total frame counts. Never insert
 * silence. Same-rate/channel transitions keep queued PCM and the sink alive.
 * Different format returns FORMAT_CHANGE once buffered prior PCM has drained;
 * caller must perform proven mute/clock/drain sequence before accept_format. */
audio_status audio_stream_step(audio_stream *);
audio_status audio_stream_accept_format(audio_stream *);
void audio_stream_pause(audio_stream *,int);
void audio_stream_volume(audio_stream *,uint16_t q15);
#endif
