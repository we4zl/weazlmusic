#ifndef WEAZL_CODEC_OGG_H
#define WEAZL_CODEC_OGG_H
#include "codec.h"
/* Internal bounded Ogg framing shared by actual Opus/Vorbis providers. */
typedef struct {
    size_t cursor,payload_at;
    uint64_t granule,packet_granule,packet_no;
    uint32_t serial,sequence;
    uint16_t packet_size;
    uint8_t flags,segments[255],segment_count,segment,have_page,ended,packet_partial,packet_eos;
    uint8_t packet[8192];
} codec_ogg_packets;
codec_status codec_ogg_packet(codec *c,codec_ogg_packets *s);
codec_status codec_ogg_open(codec *c);
codec_status codec_ogg_read(codec *c,int16_t *pcm,size_t capacity,size_t *frames);
void codec_ogg_close(codec *c);
#endif
