#ifndef WEAZL_WAV_H
#define WEAZL_WAV_H

#include <stddef.h>
#include <stdint.h>

typedef enum {
    WAV_OK,
    WAV_INVALID,
    WAV_TRUNCATED,
    WAV_UNSUPPORTED,
    WAV_IO_ERROR
} wav_status;

typedef struct {
    uint32_t sample_rate;
    uint16_t channels;
    uint16_t frame_bytes;
    size_t data_offset;
    uint32_t data_bytes;
    uint32_t frames;
} wav_info;

/* Exact random-access reads; return 1 on success, 0 on short read/error.
 * A filesystem backend supplies file length and this callback. Header parsing
 * reads at most 16 bytes at a time and skips sample/metadata bodies by offset.
 * The file must remain unchanged between parsing and playback. */
typedef int (*wav_read_at)(void *context, size_t offset, uint8_t *out, size_t size);
typedef struct {
    wav_read_at read;
    void *context;
    size_t size;
} wav_reader;

wav_status wav_open(const wav_reader *reader, wav_info *out);

/* Parse a complete little-endian RIFF/WAVE buffer, without allocation.
 * Supports integer PCM (format 1), 16 bits, mono/stereo, 8000..96000 Hz.
 * Unknown chunks are skipped with RIFF padding. Rejects duplicate fmt/data
 * chunks and partial frames. Trailing bytes outside RIFF are ignored.
 * Output is untouched on failure. This is not a streaming/header-only API.
 */
wav_status wav_parse(const uint8_t *bytes, size_t size, wav_info *out);

#endif
