#ifndef WE4ZL_CATALOG_SEARCH_H
#define WE4ZL_CATALOG_SEARCH_H
#include "catalog.h"
typedef struct {catalog *catalog;uint32_t lo,hi,first,end;uint8_t prefix[96],bytes,phase;cat_status error;} cat_search;
/* Validated UTF8; ASCIIcasefold only. Empty query coversalltitles. Existing
 * catalog remains immutable. Borrow no input buffer. No tag/dictionaryreads. */
cat_status cat_search_begin(cat_search *,catalog *,const char *prefix);
/* One persisted key/page request per step. CAT_OKpending,CAT_ENDfinalrange. */
cat_status cat_search_step(cat_search *);
#endif
