#ifndef WE4ZL_LIBRARY_GENERATION_H
#define WE4ZL_LIBRARY_GENERATION_H
#include "catalog_compact.h"
#include "journal.h"
#define LIBRARY_MANIFEST_BYTES 64u
typedef struct {uint32_t generation,count,dictionary,index[4];uint64_t volume;} library_manifest;
int library_manifest_encode(const library_manifest *,uint8_t out[64]);
int library_manifest_decode(library_manifest *,const uint8_t in[64]);
/* Fixed metadata names: dict0/1(2/3),title0/1(4/5),album(6/7),artist(8/9),
 *ID(10/11),work0/1(12/13),delta(14). Manifest journal is scoped separately in
 *scan1(15). Settings and playlists objects0/1 are never generation scratch. */
typedef struct {
 cat_store store;catalog *base,delta;cat_builder builder;cat_compact compact;
 journal *manifest_log;journal_job commit;library_manifest next;
 int (*reset)(void *,unsigned);void *reset_context;
 unsigned delta_object,work[2],index_final;uint32_t copy_at,copy_bytes;
 uint8_t phase,order,slot,manifest[64],buffer[512];cat_status error;
} library_generation;
cat_status library_generation_begin(library_generation *,cat_store,catalog *base,unsigned delta_object,
 unsigned target_slot,journal *manifest_log,int (*reset)(void *,unsigned),void *);
cat_status library_generation_step(library_generation *);
#endif
