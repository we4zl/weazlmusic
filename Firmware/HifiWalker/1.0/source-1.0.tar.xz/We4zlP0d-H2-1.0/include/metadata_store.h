#ifndef WEAZL_METADATA_STORE_H
#define WEAZL_METADATA_STORE_H
#include "fs.h"
#define META_OBJECTS 16u
#define META_DEPTH 8u
/* Preallocated contiguous files under .we4zldap only. No FAT or directory
 * writes, allocation, rename, growth, audio writes or filesystem repair.
 * All callbacks use USER-volume-relative sectors and return1/0/-1 pending.
 * A mounted exclusive firmware owner must stay unchanged for the entire audit
 * and all jobs. Revoke before host export/remount or any external mutation. */
typedef struct {
 int (*read)(void *,uint32_t,uint8_t [512]);
 int (*write)(void *,uint32_t,const uint8_t [512]);
 int (*sync)(void *);
 void *context;
} meta_io;
typedef enum { METASTORE_OK,METASTORE_AGAIN,METASTORE_INVALID,METASTORE_IO,METASTORE_CORRUPT,
 METASTORE_MISSING,METASTORE_UNPROVEN,METASTORE_BOUNDS,METASTORE_BUSY,METASTORE_LIMIT } meta_status;
typedef struct {uint32_t first,clusters,bytes;uint8_t present;} meta_object;
typedef struct metadata_audit metadata_audit;
typedef struct {
 fs *volume;
 meta_io io;
 meta_object object[META_OBJECTS];
 metadata_audit *audit; /* borrowed only during startup audit, cleared at end */
 uint32_t epoch,job_offset,job_bytes,job_done;
 uint8_t active,proven,job,job_phase,owner,read_proven;
 uint8_t *job_read;
 const uint8_t *job_write;
 uint8_t sector[512];
 meta_status error;
} metadata_store;
/* Startup-only scratch; may be released/reused for codec memory after audit.
 * Never share the arena with a running decoder or pending audit callback. */
struct metadata_audit {
 metadata_store *target;
 uint32_t required,seen,cluster,hops,expected,owner,phase,object_at;
 uint8_t depth;
 uint16_t path_length[META_DEPTH];
 char path[FS_PATH_BYTES];
 fs_entry entry;
 union {fs_lookup lookup;fs_dir directories[META_DEPTH];} walk;
};
/* Fixed object names in enum order: settings.bin,playlists.bin,dict0.bin,
 *dict1.bin,title0.idx,title1.idx,album0.idx,album1.idx,artist0.idx,artist1.idx,
 *id0.idx,id1.idx,work0.bin,work1.bin,scan0.bin,scan1.bin. Missing optional objects
 * stay inaccessible. Require a nonzero bitmask of needed objects.
 * Begin uses caller's actual mounted read-only parser and exact target geometry.
 * Each audit step does one bounded directory lookup or one FAT-chain link.
 * Complete whole-volume audit rejects metadata cross-links from any other file
 * or directory before writes become available. Maximum directory depth8.
 * No unrelated chain contents or complete library stay in RAM. */
meta_status metadata_begin(metadata_store *,metadata_audit *,fs *,const meta_io *,uint32_t required);
meta_status metadata_audit_step(metadata_audit *);
/* read_proven becomes1 after all discovered required extents are validated,
 * before the whole-volume collision walk. Capacity/reads then work for fast
 * warm-index boot. Writes/sync still REQUIRE proven=1; no ownership shortcut.
 * Audit pauses while an accepted metadata job owns its shared512B buffer. */
/* Revoke refuses an in-flight job; finish/quiesce it before host export. */
meta_status metadata_revoke(metadata_store *);
const char *metadata_object_name(unsigned object);
/* Capacity is preallocated file length, not a catalog logical EOF. Higher-level
 * journal/objects must persist their own committed lengths/generations. */
meta_status metadata_capacity(metadata_store *,unsigned object,uint32_t *bytes);
/* One active job; borrowed input/output stays valid until completion. Each step
 * performs <=one512B backend read/write/sync. Writes preserve sector neighbors
 * with RMW. On IO failure, latch/revoke proof and do not retry or abort writes.
 * The caller yields to audio/input between steps; synchronous journal/catalog
 * callbacks require an explicit scheduled adapter, never treat pending as1. */
meta_status metadata_read_begin(metadata_store *,unsigned,uint32_t,void *,uint32_t);
meta_status metadata_write_begin(metadata_store *,unsigned,uint32_t,const void *,uint32_t);
meta_status metadata_sync_begin(metadata_store *);
meta_status metadata_job_step(metadata_store *);
#endif
