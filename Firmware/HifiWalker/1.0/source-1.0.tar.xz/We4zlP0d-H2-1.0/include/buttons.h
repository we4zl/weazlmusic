#ifndef WEAZL_BUTTONS_H
#define WEAZL_BUTTONS_H
#include "ui.h"
typedef uint32_t (*button_read)(uintptr_t);
typedef void (*button_write)(uintptr_t,uint32_t);
typedef struct {
    uint32_t started;
    uint16_t sample;
    uint8_t phase, fault;
} button_adc;
void button_adc_init(button_adc *a, button_read read, button_write write, uint32_t now);
/* 1 fresh sample, 0 pending, -1 latched fault; no retry after fault. */
int button_adc_poll(button_adc *a, button_read read, button_write write, uint32_t now);
/* 0 released, 1..5 ladder identity, 255 ambiguous. */
uint8_t button_classify(uint16_t sample);
uint8_t button_combine(uint16_t sample, unsigned gpio);
void button_gpio_init(button_read read, button_write write);
typedef struct {
    uint32_t changed, repeat_at, revision;
    uint8_t candidate, stable, armed, learned, map[5], last;
    uint32_t heartbeat;
    uint16_t adc;
    uint8_t gpio;
} button_input;
void button_input_init(button_input *b);
/* Five guided keys: left, right, play/pause, menu, repeat. */
int button_input_poll(button_input *b, uint8_t raw, uint32_t now, unsigned *action);
void button_navigate(ui_state *s,unsigned action);
void button_status_row(const button_input *b,unsigned y,uint8_t row[960],int fault);
#endif
