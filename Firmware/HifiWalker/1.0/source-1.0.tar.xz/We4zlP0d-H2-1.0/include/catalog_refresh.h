#ifndef WE4ZL_CATALOG_REFRESH_H
#define WE4ZL_CATALOG_REFRESH_H
#include "catalog_query.h"
#include "library_scan.h"
#include "wav.h"
typedef struct {
 void *context;
 int (*open)(void *,const fs_entry *,wav_reader *);
 int (*tags_begin)(void *,wav_reader,cat_record *);
 int (*tags_step)(void *); /*1 done,-1 pending,0 terminalfailure*/
} refresh_io;
typedef struct {
 catalog *base;cat_store store;unsigned delta;refresh_io io;
 uint8_t *visited;size_t visited_bytes;
 uint32_t count,generation,deleted_at,changed,reused,added,removed,tag_calls,fingerprint_reads;
 uint64_t volume;
 cat_query query;cat_record record,old;wav_reader source;
 uint32_t fingerprint;uint8_t phase,failed,finishing,deleted_pending,force;
 uint8_t buffer[512];
} cat_refresh;
/* Fresh delta dictionary object, old ID index stays immutable/readable. Caller
 * supplies ceil(base.count/8) bytes (12.5KiB at100k); no alltrackarray.
 * Tags are parsed only for changed/new files. First/last512B fingerprint plus
 * size/FATmtime is a FAST HEURISTIC; deliberate same-size/timestamp middle edits
 * require force=1 full tag refresh. It is not a whole-file integrity checksum. */
cat_status cat_refresh_begin(cat_refresh *,catalog *base,cat_store,unsigned delta,
                            uint32_t next_generation,uint64_t volume,refresh_io,
                            void *visited,size_t visited_bytes,int force);
/* Pass directly as library_scan's offer callback. Each call does one bounded
 * fingerprint read, one query step, one tag step, or one delta record append. */
int cat_refresh_offer(void *,const fs_entry *,const char *,cat_codec);
/* Call after successful complete directory walk only. Detects deletions by
 * walking old persisted IDs cooperatively. CAT_OK working,CAT_ENDcommitted. */
cat_status cat_refresh_finish(cat_refresh *);
#endif
