#ifndef WE4ZL_ECHO_CLOCK_H
#define WE4ZL_ECHO_CLOCK_H
#include <stdint.h>
/* Injected hardware interface; tests use ordinary register models only.
 * read/write return 0 on bus/access failure. irq_save masks IRQs and returns the
 * previous PRIMASK; restore must restore that exact state. delay is stock's
 * short fixed instruction delay, independent of SysTick/software milliseconds. */
typedef struct {
    void *context;
    int (*read)(void *,uint32_t address,uint32_t *value);
    int (*write)(void *,uint32_t address,uint32_t value);
    uint32_t (*irq_save)(void *);
    void (*irq_restore)(void *,uint32_t);
    void (*short_delay)(void *);
    /* Mandatory independent eligibility proof. No default DMA2 register read:
     *010703a0 is proven only in the calculation-core address view. Production
     *adapter MUST return0 until application-core accessibility or exact reset/
     *gate ownership is established. Host model callback is not that proof. */
    int (*cal_dma_eligible)(void *);
} echo_clock_io;
typedef enum { ECHO_CLOCK_IDLE,ECHO_CLOCK_REFUSED,ECHO_CLOCK_PROGRAM,
               ECHO_CLOCK_LOCK,ECHO_CLOCK_DIVIDERS,ECHO_CLOCK_150MHZ,
               ECHO_CLOCK_FAILED_24MHZ,ECHO_CLOCK_FAILED_UNKNOWN } echo_clock_state;
typedef struct {
    echo_clock_io io;
    echo_clock_state state;
    uint32_t saved_irq, polls, cpu_hz;
    uint8_t step, irq_held;
} echo_clock;
/* Read-only nominal tuple validator: only exact Loader48MHz and selected stock
 *150MHz tuples. Unknown/slow/unlocked sources return0. Not a clock measurement. */
uint32_t echo_clock_cpu_hz(const echo_clock_io *);
/* Before *any* custom display/storage/ADC/audio/USB/DMA initialization only.
 * No reset/gate/voltage writes. Requires CAL reset+gated, both DMA engines idle,
 * GRF clock enabled, nominal48MHz and oscillator divider1. Refusal writes none.
 * begin holds saved IRQ state until terminal step; do not schedule other work. */
void echo_clock_init(echo_clock *);
int echo_clock_begin_stock150(echo_clock *,const echo_clock_io *);
/* Bounded step, <=one PLL-lock poll. Caller drains this startup state machine.
 * Terminal FAILED_24MHZ is a fault, NEVER a normal48MHz/display continuation.
 * If fallback readback cannot establish slow24MHz, FAILED_UNKNOWN/cpu_hz0. */
echo_clock_state echo_clock_step(echo_clock *);
/* Peripheral contracts: after150MHz, APB is75MHz (CLKSEL1 exponent1); PWM periods
 * and SysTick must use validated current rates. Existing SARADC divider23 at
 * CRU+0x2c derives1MHz from24MHz oscillator, independent of CPU; verify divider and oscillator/ADC gates before relying on it. Display VOP timing1021 is deferred to display init.
 * eMMC/I2S/UART must initialize their own proven clocks after this transition. */
uint32_t echo_clock_apb_hz(const echo_clock_io *);
int echo_clock_saradc_1mhz(const echo_clock_io *);
/* Read-only alternative CAL-DMA eligibility proof: exact DMA2 reset55 asserted
 * and HIGH_DMA gate75 disabled, using A-core-accessible CRU registers only.
 * Does not assert/reset/gate anything. Core reset50/gate2 are separate checks.
 * Production adapter may wrap this in cal_dma_eligible after independent review.
 * Unknown inherited Loader values refuse; no0107 address access is involved. */
int echo_clock_cal_dma_held_reset(const echo_clock_io *);
#endif
