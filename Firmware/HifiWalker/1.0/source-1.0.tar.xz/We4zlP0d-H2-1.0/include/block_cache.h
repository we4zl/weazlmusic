#ifndef WE4ZL_BLOCK_CACHE_H
#define WE4ZL_BLOCK_CACHE_H
#include <stdint.h>
#include <stddef.h>
/* Four FAT/metadata pages are retained independently of four streaming pages.
 * This prevents pending cycle-check reads from evicting each other. Main owns
 * the cache; callbacks run only cooperatively, never concurrently in IRQs. */
#define BLOCK_CACHE_PAGES 8u
#define BLOCK_METADATA_PAGES 4u
typedef enum {BLOCK_AUDIO=0,BLOCK_FOREGROUND=1,BLOCK_BACKGROUND=2} block_priority;
typedef struct {
 void *context;
 int (*start)(void *,uint32_t user_sector,uint8_t out[512]); /*1 accepted,0 failed*/
 int (*poll)(void *); /*1 complete,-1 pending,0 terminal failure; no retry*/
} block_backend;
typedef struct {
 uint32_t sector,stamp;uint8_t valid,wanted,priority;
 uint8_t bytes[512];
} block_page;
typedef struct {
 block_backend io;uint32_t sectors,clock,hits,misses,starts,completions;
 block_page page[BLOCK_CACHE_PAGES];int8_t active;uint8_t failed,enabled;
} block_cache;
int block_cache_init(block_cache *,block_backend,uint32_t user_sectors);
/* Metadata selects independently reserved pages; otherwise stream pages. A
 * miss queues work and returns-1; it does not synchronously touch hardware. */
int block_cache_read(block_cache *,uint32_t sector,int metadata,block_priority,uint8_t out[512]);
int block_cache_step(block_cache *); /* one poll or one highest-priority start */
/* Only after backend idle and caller proves all readers stopped. */
int block_cache_quiesce(block_cache *);
int block_cache_resume(block_cache *,int backend_idle,int new_mount_proven);
/* Invalidate both banks for an owned sector write. Refuses an in-flight read
 * of that sector; does not abort a hardware transfer or retry anything. */
int block_cache_invalidate_sector(block_cache *,uint32_t user_sector);
#endif
