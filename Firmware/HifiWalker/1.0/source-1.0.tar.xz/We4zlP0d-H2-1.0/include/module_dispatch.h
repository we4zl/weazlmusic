#ifndef WE4ZL_MODULE_DISPATCH_H
#define WE4ZL_MODULE_DISPATCH_H
#include "overlay.h"
#include "playback_session.h"
#define MODULE_COUNT 6u
#define MODULE_PRIMARY_BYTES 0x025b4200u
#define MODULE_PAYLOAD_START 0x00100000u
typedef enum {MODULE_FLAC,MODULE_MP3,MODULE_AAC,MODULE_VORBIS,MODULE_OPUS,MODULE_USB} module_kind;
typedef struct {overlay_spec spec;uint32_t source_offset;} module_image;
/* Exact immutable primary-image byte reads, serialized with all eMMC users.
 * No device opcode, raw write, allocation or reset is provided by this module.
 * -1 waits on the SAME accepted operation;0 terminalerror;1 complete. */
typedef int (*module_image_read)(void *,uint32_t,void *,size_t);
typedef struct {
 overlay *memory;const module_image *images;module_image_read read;void *context;
 uint32_t generation;uint8_t selected,loading,leased,failed;
} module_dispatch;
int module_dispatch_init(module_dispatch *,overlay *,const module_image [MODULE_COUNT],module_image_read,void *);
/* One<=512B hash/load step.1ready,0pending,-1error. Same leased provider may be
 * requested again. Another provider is refused until release has completed. */
int module_dispatch_select(module_dispatch *,module_kind);
/* Caller certifies: no suspended provider call, close/abandon finished, no
 * retained provider object/function pointer will be used. Lease spans decoder
 * lifetime and ALL worker yields. It is never released merely because main runs.
 * With a failed worker, first prove that worker can NEVER resume. */
int module_dispatch_release(module_dispatch *,int no_live_provider_calls);
/* Close/abandon has already returned. Drain an accepted partial load to its
 * finite hash result before releasing; never abort an in-flight read. */
int module_dispatch_quiesce(module_dispatch *);
int module_dispatch_provider(module_dispatch *,cat_codec,playback_provider *);
int module_dispatch_entry(module_dispatch *,unsigned,uintptr_t *);
#endif
