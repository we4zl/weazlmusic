#ifndef WEAZL_ECHO_ADC_H
#define WEAZL_ECHO_ADC_H
#include <stdint.h>
typedef uint32_t (*echo_adc_read)(uintptr_t);
typedef void (*echo_adc_write)(uintptr_t,uint32_t);
typedef struct { uint32_t generation; uint16_t raw; uint8_t channel; } echo_adc_sample;
typedef struct { uint32_t started,generation; uint8_t channel,active,fault; } echo_adc;
void echo_adc_init(echo_adc *a,echo_adc_read r,echo_adc_write w,uint32_t now);
/* Only key1 / battery0. 1 accepted,0 busy/settling,-1 fault/invalid channel.
 * A valid request token is returned only when accepted. */
int echo_adc_request(echo_adc *a,echo_adc_read r,echo_adc_write w,uint8_t channel,uint32_t now,uint32_t *token);
/* 1 delivers exactly one tagged result;0 pending;-1 latched timeout/data fault. */
int echo_adc_poll(echo_adc *a,echo_adc_read r,echo_adc_write w,uint32_t now,echo_adc_sample *sample);
#endif
