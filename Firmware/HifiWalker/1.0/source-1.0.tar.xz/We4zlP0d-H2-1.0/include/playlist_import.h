#ifndef WE4ZL_PLAYLIST_IMPORT_H
#define WE4ZL_PLAYLIST_IMPORT_H
#include "catalog_query.h"
#include "playlist.h"
#include "playlist_store.h"
#include "wav.h"
typedef enum {
  PIMPORT_AGAIN,
  PIMPORT_OK,
  PIMPORT_INVALID,
  PIMPORT_IO,
  PIMPORT_CHANGED,
  PIMPORT_LIMIT
} playlist_import_status;
typedef struct {
  playlist_parser parser;
  cat_query query;
  cat_record record;
  playlist_store *store;
  catalog *catalog;
  playlist_workspace *workspace;
  wav_reader source;
  uint8_t buffer[64];
  char path[256], base[256];
  uint16_t base_bytes;
  uint8_t *destination;
  uint32_t cursor, generation, catalog_generation, expected, valid_count;
  uint32_t accepted, missing, rejected, unrepresentable, pass_missing,
      pass_unrepresentable;
  uint32_t produced, chunk_first;
  unsigned chunk_count, filled;
  uint64_t playlist_id;
  uint8_t active, phase, have_path, used, available, finishing, eof, writing,
      file_pending, record_valid;
  playlist_import_status error, status;
} playlist_import;
/* Replace an EXISTING playlist atomically from actualUTF8M3U/M3U8 root-relative
 * paths. Two passes resolve full paths against the pinned actualIDcatalog;
 * missing/rejected paths are counted, duplicates/order preserved, no allIDsRAM.
 * Caller exclusively owns store/rawadapter and4096Bworkspace throughout. Source
 * file/catalog must remain immutable; finish/drain beforeUSB/remount. No cancel
 * of acceptedwrites and no failedI/Oretry. Zero-init context; no
 * targetexecution. */
playlist_import_status playlist_import_begin(playlist_import *,
                                             playlist_store *,
                                             playlist_workspace *, catalog *,
                                             uint64_t playlist_id, wav_reader);
/* Sourcefilepath must be canonicaluser-rootrelativeUTF8, <=1023B; itsparent
 * prefix must fit255B. Entries resolve RELATIVE TO THAT PARENT;
 * absolute/traversal entries remain rejected. Overlong combinedcatalogpaths
 * countedunrepresentable. Existingbegin retains root-relative interpretation
 * for explicitroot imports. */
playlist_import_status
playlist_import_begin_at(playlist_import *, playlist_store *,
                         playlist_workspace *, catalog *, uint64_t playlist_id,
                         wav_reader, const char *source_path);
/* BACKGROUNDworker: ≤64parsedbytes ORonefile read ORonecatalogquery/storestep.
 * Query callback may yield throughactualcatalog backend; ownworkerstack
 * required. */
playlist_import_status playlist_import_step(playlist_import *);
#endif
