#ifndef WEAZL_ECHO_DISPLAY_H
#define WEAZL_ECHO_DISPLAY_H
#include <stdint.h>
/* Experimental resident-derived transport. Physical behavior unverified.
 * CPU clock remains the Loader's nominal48MHz; no PLL reprogramming. */
/* Returns0 before any display writes if inherited clock is unsupported. */
int echo_display_init(void);
void echo_display_row(uint16_t y, const uint8_t pixels[960]);
void echo_display_backlight(void);
uint32_t echo_millis(void);
void echo_delay(uint32_t ms);
#endif
