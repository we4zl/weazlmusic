#ifndef WEAZL_PLAYLIST_H
#define WEAZL_PLAYLIST_H
#include <stddef.h>
#include <stdint.h>
#define PLAYLIST_PATH_BYTES 1024u
#define PLAYLIST_FEED_BYTES 64u
/* Emit receives a normalized UTF-8 relative path, borrowed for callback only.
 * Return1 accepted,0 missing/unavailable (counted and skipped),-1 backend failure.
 * Preserve intentional duplicate tracks and order. Resolve paths beneath the
 * playlist's verified music root; callbacks must not block the audio scheduler. */
typedef int (*playlist_emit)(void *,const char *);
typedef int (*playlist_writer)(void *,const uint8_t *,size_t);
typedef enum { PLAYLIST_OK,PLAYLIST_AGAIN,PLAYLIST_INVALID,PLAYLIST_IO } playlist_status;
typedef struct {
    playlist_emit emit;void *context;
    uint32_t accepted,missing,rejected,comments;
    uint16_t used;
    uint8_t overflow,first_line,failed,finished;
    char line[PLAYLIST_PATH_BYTES];
} playlist_parser;
void playlist_begin(playlist_parser *,playlist_emit,void *context);
/* Consume at most64 input bytes/call; caller retries remaining bytes on AGAIN.
 * CRLF, UTF-8 BOM, EXTINF/comments and final line without newline are handled.
 * Malformed UTF-8, absolute paths/URIs, traversal and overlong lines are rejected
 * per-line; parsing continues. M3U8 and UTF-8 M3U are supported; OEM/ANSI M3U
 * conversion requires explicit encoding evidence and is not guessed. */
playlist_status playlist_feed(playlist_parser *,const uint8_t *,size_t,size_t *consumed);
playlist_status playlist_finish(playlist_parser *);
/* Streaming serialization: write one header then one path at a time. Caller
 * provides atomic persistence for a complete playlist; no all-track array. */
playlist_status playlist_write_header(playlist_writer,void *);
playlist_status playlist_write_path(playlist_writer,void *,const char *);
#endif
