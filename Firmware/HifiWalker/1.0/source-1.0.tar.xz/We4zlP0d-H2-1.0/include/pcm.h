#ifndef WE4ZL_PCM_H
#define WE4ZL_PCM_H
#include "wav.h"
typedef enum { PCM_OK, PCM_AGAIN, PCM_END, PCM_INVALID, PCM_UNSUPPORTED, PCM_IO } pcm_status;
typedef struct {
    wav_reader source;
    uint32_t rate, frames, position;
    size_t data_offset, data_bytes, cursor, end;
    uint16_t channels;
    uint8_t big_endian, have_format, have_data, valid, failed;
} pcm_decoder;
/* Incremental open: begin reads12 bytes; each probe_step reads one chunk header
 * and at most18 format bytes, skips payload by checked offset. Never allocates. */
pcm_status pcm_probe_begin(pcm_decoder *,wav_reader);
pcm_status pcm_probe_step(pcm_decoder *);
/* PCM16 mono/stereo,8..96kHz WAV or uncompressed AIFF, max128frames/read. */
pcm_status pcm_decode(pcm_decoder *,int16_t *,unsigned capacity_frames,unsigned *frames);
pcm_status pcm_seek(pcm_decoder *,uint32_t frame);
#endif
