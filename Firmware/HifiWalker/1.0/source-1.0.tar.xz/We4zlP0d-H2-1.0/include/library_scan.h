#ifndef WE4ZL_LIBRARY_SCAN_H
#define WE4ZL_LIBRARY_SCAN_H
#include "fs.h"
#include "catalog.h"
#define LIBRARY_SCAN_DEPTH 8u
/* Borrowed path/entry remain stable while callback returns-1 pending. The
 * consumer must yield tag/fingerprint/index work separately, never parse it all
 * inside this directory walker or an input callback. */
typedef int (*library_scan_offer)(void *,const fs_entry *,const char *,cat_codec);
typedef enum {SCAN_PENDING,SCAN_DONE,SCAN_IO,SCAN_LIMIT,SCAN_INVALID} library_scan_status;
typedef struct {
 fs *volume;fs_dir directory[LIBRARY_SCAN_DEPTH];fs_entry entry;
 char path[256];uint16_t lengths[LIBRARY_SCAN_DEPTH];
 library_scan_offer offer;void *context;
 uint32_t entries,files,ignored,long_paths,deep_paths;
 uint8_t depth,pending,failed,done;cat_codec kind;
} library_scan;
library_scan_status library_scan_begin(library_scan *,fs *,library_scan_offer,void *);
library_scan_status library_scan_step(library_scan *);
#endif
