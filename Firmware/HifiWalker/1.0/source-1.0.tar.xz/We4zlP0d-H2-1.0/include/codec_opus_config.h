#ifndef WEAZL_CODEC_OPUS_CONFIG_H
#define WEAZL_CODEC_OPUS_CONFIG_H
/* Pinned fixed-point decoder-only profile; see post-mvp-codec-opus-scratch.md.
 * Force-include this header for EVERY Opus translation unit. The checked
 * pseudostack limit and caller-owned buffer must remain identical. */
#define CODEC_OPUS_SCRATCH_BYTES 98304
#ifdef OPUS_BUILD
#if !defined(FIXED_POINT) || !defined(DISABLE_FLOAT_API) || !defined(NONTHREADSAFE_PSEUDOSTACK) || !defined(ENABLE_HARDENING)
#error "Unaudited Opus decoder storage profile"
#endif
#if defined(ENABLE_RES24) || defined(ENABLE_QEXT) || defined(ENABLE_DEEP_PLC) || defined(ENABLE_OSCE) || defined(CUSTOM_MODES) || defined(ENABLE_OPUS_CUSTOM_API) || defined(ENABLE_VALGRIND) || defined(SMALL_FOOTPRINT)
#error "Optional Opus profile requires a new scratch audit"
#endif
#endif
#ifdef GLOBAL_STACK_SIZE
#if GLOBAL_STACK_SIZE != CODEC_OPUS_SCRATCH_BYTES
#error "Opus pseudostack limit differs from caller allocation"
#endif
#else
#define GLOBAL_STACK_SIZE CODEC_OPUS_SCRATCH_BYTES
#endif
#endif
