#ifndef WE4ZL_PLAYLIST_VIEW_H
#define WE4ZL_PLAYLIST_VIEW_H
#include "catalog_query.h"
#include "playlist_store.h"
#include "text_picker.h"
#include "ui.h"
#define PLAYLIST_VIEW_ROWS 3u
typedef enum {
  PV_LISTS,
  PV_TRACKS,
  PV_ACTIONS,
  PV_NAME,
  PV_CONFIRM,
  PV_UNAVAILABLE
} playlist_view_mode;
typedef struct {
  uint64_t id;
  uint32_t count;
  uint8_t slot, state;
  char label[96];
} playlist_view_row;
typedef struct {
  void *context;
  /*1 acquired,-1 temporarily busy,0 unavailable. Release exactly once after
   * store job completes; never hand the same scratch to another service. */
  int (*workspace_acquire)(void *, playlist_workspace **);
  void (*workspace_release)(void *, playlist_workspace *);
  /* Resident queue accepts an actual stableID request;1 accepted,0 unavailable.
   * Acceptance is not proof of decoded audio. No callback for unresolved rows.
   */
  int (*play)(void *, uint64_t);
  int (*current_track)(void *, uint64_t *);
  /* Optional nonblocking flag read only; NULL allows. Zero means a playback
   * queue owns store/catalog; opening/editing must not start any store IO. */
  int (*store_available)(void *);
  /* Worker-enqueued real filepicker/import request for selected storedplaylist.
   * 1 accepted,0 unavailable; caller closes view before sharing servicearena.
   */
  int (*import_m3u)(void *, uint64_t playlist_id, uint32_t generation);
} playlist_view_hooks;
typedef struct {
  uint32_t magic;
  playlist_store *store;
  catalog *catalog;
  playlist_view_hooks hooks;
  playlist_workspace *workspace;
  cat_query query;
  cat_record record;
  stored_playlist current;
  union {
    stored_playlist entry;
    stored_playlist_item items[3];
  } pending;
  playlist_view_row rows[3];
  const char *message;
  uint32_t list_offset, item_offset, seen, selected;
  uint64_t add_id;
  text_picker picker;
  uint8_t mode, origin, job, action, edit_kind, focus, count, has_next,
      scan_slot;
  uint8_t resolve_at, query_active, owns_store, active, closing;
} playlist_view;
/* Must be zero initialized. Refuses reinitializing a live context, another
 * store job, missing workspace hooks, or a corrupt/unopened store. */
int playlist_view_init(playlist_view *, playlist_store *, catalog *,
                       playlist_view_hooks);
int playlist_view_open(playlist_view *);
void playlist_view_close(
    playlist_view *); /*drains owned jobs, never cancels I/O*/
int playlist_view_quiescent(const playlist_view *);
int playlist_view_set_catalog(playlist_view *, catalog *); /*quiescent only*/
/* Physical actions0Left,1Right,2Play,3Menu,4Repeat/Back. Events are foreground
 * state updates only; no storage/query/callback runs until worker step. */
int playlist_view_action(playlist_view *, unsigned action);
/* BACKGROUND worker only: cat_query can yield through catalog's scheduled
 * backend. Never call using UI/audio/codec stack. One store/query step perturn.
 */
void playlist_view_step(playlist_view *);
/* Paint only content pane y70..198 into existing480x222 RGB565 row. Branding,
 * top-right battery and bottom globalnavigation remain caller-owned. */
int playlist_view_render_pane_row(const playlist_view *, unsigned y,
                                  uint8_t *out, size_t capacity);
#endif
