#ifndef WE4ZL_PLAYLIST_STORE_H
#define WE4ZL_PLAYLIST_STORE_H
#include "hash256.h"
#include "object_store.h"
#define PLAYLIST_STORE_LISTS 32u
#define PLAYLIST_STORE_NAME 96u
#define PLAYLIST_STORE_PAGE_ITEMS 64u
#define PLAYLIST_STORE_OBJECT 1u
/* Owns RAW scoped preallocated playlists.bin (object1), not object_store's
 * logical-EOF prefix. Exclusive metadata ownership is a required precondition.
 * No FAT allocation, audio writes or raw sector access. Capacity is
 * file-derived. Async callbacks1 complete/-1 pending/0 terminalfailure; no
 * automatic retry of failed I/O. All borrowed buffers/workspaces stay stable
 * through completion. */
typedef enum {
  PSTORE_OK,
  PSTORE_AGAIN,
  PSTORE_EMPTY,
  PSTORE_END,
  PSTORE_INVALID,
  PSTORE_CORRUPT,
  PSTORE_IO,
  PSTORE_BUSY,
  PSTORE_LIMIT,
  PSTORE_READONLY
} playlist_store_status;
typedef struct {
  uint8_t directory[4096];
} playlist_workspace;
typedef struct {
  uint64_t id;
  uint32_t count, first, generation;
  uint8_t slot;
  char name[PLAYLIST_STORE_NAME];
} stored_playlist;
typedef enum {
  PLAYLIST_UNRESOLVED,
  PLAYLIST_PRESENT,
  PLAYLIST_MISSING,
  PLAYLIST_UNAVAILABLE
} playlist_item_state;
typedef struct {
  uint64_t id;
  playlist_item_state state;
} stored_playlist_item;
typedef enum {
  PLAYLIST_CREATE,
  PLAYLIST_RENAME,
  PLAYLIST_DELETE,
  PLAYLIST_ADD,
  PLAYLIST_REMOVE,
  PLAYLIST_MOVE,
  PLAYLIST_REPLACE
} playlist_edit_kind;
typedef struct {
  playlist_edit_kind kind;
  uint64_t playlist_id, track_id;
  uint32_t index, destination;
  const char *name;
} playlist_edit;
typedef struct {
  uint32_t generation, body;
  uint64_t next_id;
  uint8_t digest[32], valid, nonzero;
} playlist_candidate;
/* Source fills exactcount canonicalLE64IDs;1 ready,-1 pending,0
 * terminalfailure. Called with stablepagebuffer/ordinal/count until complete.
 * Must do bounded background work, never allocate allIDs or retry failed
 * backendoperations. */
typedef int (*playlist_items_source)(void *, uint32_t, unsigned, uint8_t *);
typedef struct {
  object_io io;
  playlist_items_source items_source;
  void *items_context;
  playlist_workspace *workspace;
  hash256 hash;
  playlist_candidate candidate[2];
  uint8_t page[512], digest[32];
  uint32_t slot_bytes, generation, body, at, bytes, new_body, new_generation;
  uint32_t item_at, local_at, old_count, index, destination, page_count;
  uint64_t next_id, created_id, track_id, edit_id;
  int32_t delta;
  void *output;
  stored_playlist requested;
  char name[96];
  uint8_t live_slot, valid, operation, phase, checking, target_slot, list_slot,
      edit_slot, kind;
  uint8_t source_slot, failed;
  playlist_store_status status;
} playlist_store;
/* Zero-init store first. Open needs4096B reusable scratch through completion;
 * live reader retains no directory. Invalid/new file isn't silently formatted.
 * EMPTY only means both headers are allzero; first CREATE initializes safely.
 */
playlist_store_status playlist_store_open(playlist_store *, object_io,
                                          playlist_workspace *);
playlist_store_status playlist_store_step(
    playlist_store *); /*<=one512B I/O/barrier or boundedsourcecallback*/
playlist_store_status playlist_store_list_begin(playlist_store *, unsigned slot,
                                                stored_playlist *);
/* Descriptor is revalidated against current generation and actual directory.
 * Reads at most64 IDs; duplicates/order preserved. Availability
 * startsUNRESOLVED. Caller resolves stable IDs against actual current catalog;
 * do not infer missing from an unavailable/unmounted catalog. */
playlist_store_status playlist_store_items_begin(playlist_store *,
                                                 const stored_playlist *,
                                                 uint32_t first, unsigned count,
                                                 stored_playlist_item *);
void playlist_store_item_resolved(stored_playlist_item *, playlist_item_state);
playlist_store_status playlist_store_edit_begin(playlist_store *,
                                                playlist_workspace *,
                                                const playlist_edit *);
/* Atomicstreamreplacement for a knowncount of actualresolvedIDs; caller pins
 * source/cataloggeneration and owns workspace/source through completion. Other
 * playlists streamunchanged; no temporarymetadatafile/allitemsRAM needed. */
playlist_store_status
playlist_store_replace_begin(playlist_store *, playlist_workspace *,
                             uint64_t playlist_id, uint32_t count,
                             playlist_items_source, void *);
/* Operation result CREATE publishes created_id. Source generations are
 * preserved until inactive slot body SHA readback, header-last
 * commit/barrier/headerreadback. Last acknowledged generation remains
 * independently valid after modeled tears. Failure latches; caller must reopen
 * rather than retry a failed write/barrier. */
uint32_t playlist_store_item_capacity(const playlist_store *);
#endif
