#ifndef WE4ZL_TEXT_PICKER_H
#define WE4ZL_TEXT_PICKER_H
#include <stdint.h>
#define TEXT_PICKER_BYTES 96u
typedef struct {
  char text[96];
  uint8_t cursor, limit, active;
} text_picker;
typedef enum {
  TEXT_PICKER_EDIT,
  TEXT_PICKER_SAVE,
  TEXT_PICKER_CANCEL,
  TEXT_PICKER_INVALID
} text_picker_result;
/* Zero-init first; refuse replacing active editor. UTF8initial text is
 * preserved, emptysearchprefix allowed; limit1..95bytes. No
 * allocation/backend/fixture. */
int text_picker_begin(text_picker *, const char *, unsigned limit);
/*0Left/1Right cycle printableASCII atcursor;2Play nextcodepoint/wrap;
 *3Menu save;4Repeat deletespreviouscodepoint, or cancels whenatstart.
 * Replacing/deleting existingUnicode never splits a codepoint. */
text_picker_result text_picker_action(text_picker *, unsigned);
void text_picker_cancel(text_picker *);
/* Horizontalwindow begins atUTF8boundary; column is displaybyteposition for
 * existing ASCIIrenderer (nonASCIIbytes appearas?). Caller keeps text stable.
 */
unsigned text_picker_window(const text_picker *, unsigned visible_bytes,
                            unsigned *column);
#endif
