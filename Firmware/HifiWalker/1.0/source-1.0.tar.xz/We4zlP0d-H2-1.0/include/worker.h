#ifndef WE4ZL_WORKER_H
#define WE4ZL_WORKER_H
#include <stddef.h>
#include <stdint.h>
/* Original cooperative ARMv7-M context. Main stays on MSP; exactly one worker
 * runs on PSP at a time. No IRQ enables, heap, RTOS or peripheral probing.
 * Blocking decoder read callbacks can yield for asynchronous storage while
 * main services audio/input/display. Compute-only regions still need measured
 * latency/admission checks; this is not preemption or a realtime guarantee. */
typedef struct worker worker;
struct worker {
    uintptr_t main_sp,worker_sp;
    void (*entry)(worker *,void *);void *argument;
    uint8_t *bottom;size_t bytes;
    uint32_t switches,fault_reason;
    uint8_t active,done,failed;
};
int worker_init(worker *,void *stack,size_t bytes,void (*entry)(worker *,void *),void *);
int worker_run(worker *);
void worker_yield(worker *);
int worker_guard(const worker *);
size_t worker_stack_used(const worker *);
_Noreturn void worker_fault(uint32_t reason);
void worker_checkpoint(void);
#endif
