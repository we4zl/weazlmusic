#ifndef WEAZL_SPLASH_H
#define WEAZL_SPLASH_H
#include <stddef.h>
#include <stdint.h>
/* Callback returns 1 only after reading exactly length bytes. It must enforce
 * its backing object's bounds. All offsets refer to the SPH1 asset blob. */
typedef int (*splash_read_fn)(void *context, uint32_t offset, uint8_t *out, size_t length);
typedef struct {
    splash_read_fn read;
    void *context;
    uint32_t size, durations, rows, total_ms;
    uint16_t width, height, image_width, image_height, x, y, frames;
    uint8_t pixel_big_endian;
} splash;
/* No heap or full framebuffer. Rice decoding uses a bounded 960-byte encoded
 * row on the stack in addition to the caller output row. Open validates metadata; render validates each
 * compressed row. Asset contents must remain unchanged after open. */
int splash_open(splash *out, splash_read_fn read, void *context, uint32_t size);
int splash_frame_at(const splash *asset, uint32_t elapsed_ms, uint16_t *frame, int *holding);
/* Output is RGB565 bytes in asset-declared order. Needs width*2 bytes (<=960).
 * On error output may be partially written and must not be sent to the panel. */
int splash_render_scanline(const splash *asset, uint16_t frame, uint16_t y,
                           uint8_t *out, size_t capacity);
#endif
