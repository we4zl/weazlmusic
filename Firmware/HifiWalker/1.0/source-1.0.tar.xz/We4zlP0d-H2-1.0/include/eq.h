#ifndef WE4ZL_EQ_H
#define WE4ZL_EQ_H
#include <stdint.h>
#include <stddef.h>
#define EQ_BANDS 5
#define EQ_RATE_COUNT 13
#define EQ_GAIN_STEP_DB 2
#define EQ_MAX_FRAMES 128
/* Five fixed bands, gains-12..12dB in2dB steps, preamp-24..0dB in1dB steps.
 * Stable serialized configuration fields; callers own persistence/journaling. */
typedef struct { int8_t band_db[EQ_BANDS], preamp_db; uint8_t enabled; } eq_config;
typedef struct {
    /* QuantizedQ2.30 [b0,b1==a1,b2,a2], a0=1. Owned values, safe to copy.
     * Prepared outside realtime PCM work from losslessly packed constants. */
    int32_t coefficient[EQ_BANDS][4];
    uint32_t rate, gain_q30;
    uint8_t active;
} eq_plan;
typedef struct { eq_plan plan; int32_t history[2][EQ_BANDS][5]; } eq_bank;
typedef struct {
    eq_bank bank[2];
    uint32_t clipped, transition_frames, transition_done, dry_gain_q30;
    uint8_t current, channels, transition_phase;
} eq;
typedef enum { EQ_FLAT, EQ_BASS, EQ_VOCAL, EQ_SOFT, EQ_PRESET_COUNT } eq_preset;
/* Prepare is control work, never call it in audio refill/interrupt. No allocation,
 * floating point, libm, or file I/O. Unsupported rates/configurations fail. */
int eq_prepare(eq_plan *,const eq_config *,uint32_t rate);
void eq_preset_config(eq_config *,eq_preset);
unsigned eq_band_frequency(uint32_t rate,unsigned band);
int eq_init(eq *,const eq_plan *,unsigned channels);
/* Forty-ms continuousfade oldEQ->conservativedry->newEQ, onebank/frame.
 * Busy/ratechange returns0; caller keeps latest
 * pending config and retries after transition. Ratechanges require drain/reinit. */
int eq_change(eq *,const eq_plan *);
void eq_reset(eq *);
/* PCM16 interleaved mono/stereo, at most128frames. Invalidbatch leaves data alone.
 * Clipping counts numerical guard trips; it must remain zero in acceptance tests.
 * Established bypass returns immediately without touching sample memory. */
int eq_process(eq *,int16_t *,size_t frames);
#endif
