#ifndef WE4ZL_APP_H
#define WE4ZL_APP_H
#include "library_view.h"
#include "catalog_group.h"
#include "settings.h"
#include "catalog_search.h"
#include "playlist_view.h"
typedef enum {APP_UNAVAILABLE,APP_STARTING,APP_PLAYING,APP_PAUSED,APP_STOPPED,APP_ERROR} app_play_state;
typedef enum {APP_PLAY_AT,APP_TOGGLE_PAUSE,APP_SEEK_TO,APP_APPLY_SETTINGS,APP_USB_TRANSFER,APP_RESCAN,APP_PLAY_PLAYLIST,APP_RESUME,APP_FORGET_RESUME} app_command_kind;
typedef struct {app_command_kind kind;catalog *catalog;uint32_t ordinal,first,end,position_ms;player_settings settings;uint64_t playlist_id;uint32_t playlist_generation,playlist_count;} app_command;
typedef int (*app_command_submit)(void *,const app_command *); /* bounded enqueue only */
typedef struct {uint32_t first,end;char title[96],detail[64];uint8_t valid;} app_group_row;
typedef struct {
 ui_state ui;catalog *indexes[4];library_view songs,queue_view;
 union {cat_group group_query;struct {cat_search search;text_picker picker;};};
 app_group_row groups[2];catalog *track_index,*play_index;
 uint32_t play_first,play_end,play_ordinal,playlist_generation;uint64_t playing_playlist;
 uint32_t group_at,scope_first,scope_end,artist_first,artist_end,album_first,album_end,selected;
 uint32_t position_ms,duration_ms,last_edit,now;
 cat_record playing;
 player_settings desired;settings *persistent;app_command command;
 app_command_submit submit;void *backend;
 playlist_view *playlists;char search_prefix[96];
 app_play_state play_state;uint8_t searching;
 uint8_t level,group_focus,group_fetch,group_row,group_error,command_pending;
 uint8_t actions[8],action_read,action_write,actions_dropped;
 uint8_t player_focus,editing,settings_row,preset,dirty,save_error,settings_apply;
} app;
void app_init(app *,app_command_submit,void *);
int app_attach_library(app *,catalog *title,catalog *album,catalog *artist,catalog *id);
void app_attach_settings(app *,settings *);
void app_attach_playlists(app *,playlist_view *);
/* Exact learned physical action order:0Left,1Right,2Play,3Menu,4Repeat/Back.
 * These callbacks only update focus or enqueue requests; no file/tag IO. */
/* app_event is background-owner only; the main input service uses enqueue.
 * Single main producer/single cooperative worker consumer. Overflow is counted. */
void app_event(app *,unsigned action);
int app_enqueue(app *,unsigned action);
/* Backend publishes its actual advancing queue ordinal; browse state stays independent. */
int app_publish_queue(app *,catalog *,uint32_t first,uint32_t end,uint32_t ordinal);
int app_publish_playlist_queue(app *,catalog *id_index,uint64_t playlist_id,uint32_t generation,uint32_t count,uint32_t ordinal);
/* At most one page/query/storage-step/command submit per call. Main must service
 * audio first. Catalog callback work belongs on a background worker when async. */
void app_step(app *,uint32_t now_ms);
/* Backend calls with actual decoder/sink state. No fixture can imply playback. */
void app_publish_playback(app *,app_play_state,const cat_record *,uint32_t position_ms,uint32_t duration_ms);
int app_render_row(const app *,unsigned y,uint8_t *,size_t);
#endif
