#ifndef WE4ZL_CATALOG_H
#define WE4ZL_CATALOG_H
#include <stddef.h>
#include <stdint.h>
/* Versioned LE disk format. No heap or retained pointers into backend buffers.
 * Host and MCU use this same code. Backend is a scoped metadata store, NEVER
 * raw eMMC. Each operation must be finite; old generation stays independently
 * valid until a new index has been synced and its header committed. */
#define CAT_FINGERPRINT_VALID 1u
#define CAT_DELETED 2u /* delta log only; live generation compaction removes it */
#define CAT_RECORD_BYTES 512u
#define CAT_ENTRY_BYTES 160u
#define CAT_HEADER_BYTES 512u
#define CAT_CACHE_ENTRIES 4u
/* Sort scratch is lifetime-shared with the completed scan visited bitmap.
 * A larger initial run removes four complete external merge passes at100k. */
#define CAT_SORT_RUN_ENTRIES 64u
#define CAT_KEY_BYTES 144u
#define CAT_MAX_TRACKS 1000000u

typedef enum { CAT_OK, CAT_END, CAT_INVALID, CAT_IO, CAT_CORRUPT, CAT_LIMIT } cat_status;
typedef enum { CAT_TITLE=0, CAT_ALBUM=1, CAT_ARTIST=2, CAT_ID=3 } cat_order;
typedef enum { CAT_UNKNOWN, CAT_FLAC, CAT_AAC, CAT_MP3, CAT_VORBIS, CAT_OPUS, CAT_WAV, CAT_AIFF } cat_codec;
typedef struct {
    int (*read)(void *, unsigned object, uint32_t offset, void *, size_t);
    int (*write)(void *, unsigned object, uint32_t offset, const void *, size_t);
    int (*sync)(void *, unsigned object);
    int (*size)(void *, unsigned object, uint32_t *);
    void *context;
} cat_store;
typedef struct {
    uint64_t id;
    uint32_t file_bytes, modified, duration_ms, sample_rate;
    uint16_t track, disc;
    uint8_t codec, channels, depth, flags;
    uint32_t fingerprint; /* cheap first/last512B refresh heuristic, NOT wholefilehash */
    char path[256], title[96], artist[64], album[56];
} cat_record;
/* Paths longer than 255 UTF-8 bytes are rejected, never truncated. Metadata
 * import can truncate at UTF-8 codepoint boundaries using cat_text_copy.
 * Normalization is ASCII case folding; non-ASCII UTF-8 is retained bytewise. */
cat_status cat_text_copy(char *, size_t capacity, const char *, size_t bytes);
uint64_t cat_path_id(uint64_t volume_id, const char *relative_path);
uint32_t cat_crc32(const void *, size_t);
cat_status cat_record_encode(const cat_record *, uint8_t out[512]);
cat_status cat_record_decode(const uint8_t in[512], cat_record *);
/* Create/write a NEW dictionary generation, then sync/commit. Never modify a
 * currently mounted generation. Append ordinals monotonically; commit verifies
 * final file extent. Caller owns progress and preserves the prior generation. */
cat_status cat_dictionary_begin(cat_store, unsigned object);
cat_status cat_dictionary_put(cat_store, unsigned object, uint32_t ordinal, const cat_record *);
cat_status cat_dictionary_commit(cat_store, unsigned object, uint32_t count, uint32_t generation, uint64_t volume_id);

typedef struct {
    cat_store store;
    unsigned dictionary, index;
    uint32_t count, generation, cache_start, cache_count;
    uint64_t volume_id;
    uint8_t order, cache[CAT_CACHE_ENTRIES * CAT_ENTRY_BYTES];
    uint32_t index_reads, dictionary_reads;
} catalog;
cat_status cat_open(catalog *, cat_store, unsigned dictionary, unsigned index);
cat_status cat_get(catalog *, uint32_t sorted_ordinal, cat_record *);
/* Lower-bound prefix query in the persisted key order, O(log N) entry reads.
 * Caller supplies a key prefix in the documented order encoding; no tag reads.
 * cat_title_prefix supplies title ASCII folding with UTF-8 validation. */
cat_status cat_title_prefix(catalog *, const char *, uint32_t *first);
cat_status cat_lower_bound(catalog *, const uint8_t *, size_t bytes, uint32_t *first);
/* Stable ID lookup verifies full path; a hash collision is an explicit error. */
cat_status cat_find_path(catalog *, const char *, cat_record *);
cat_status cat_entry_key(catalog *, uint32_t ordinal, uint8_t key[144]);

typedef struct {
    cat_store store;
    unsigned dictionary, work[2], current, final_object;
    uint32_t count, generation, at, width, left, middle, right, lpos, rpos, outpos;
    uint64_t volume_id;
    uint8_t order, phase, have_left, have_right, run_count;
    uint16_t flush_at;
    uint8_t run[CAT_SORT_RUN_ENTRIES][CAT_ENTRY_BYTES];
    uint8_t lentry[CAT_ENTRY_BYTES], rentry[CAT_ENTRY_BYTES];
    cat_status error;
    uint32_t steps, reads, writes;
} cat_builder;
/* Work objects must be new disposable metadata objects distinct from dictionary
 * and any live index. One step: one512-byte record read and insertion into at most64keys,
 * or one<=512-byte initial-run flush, or two index reads plus one160-byte
 * merge write. No whole-run write: underlying metadata jobs yield per512bytes.
 * Caller yields to audio/input between steps. No devices are opened here. */
cat_status cat_builder_begin(cat_builder *, cat_store, unsigned dictionary,
                             unsigned work_a, unsigned work_b, cat_order);
cat_status cat_builder_step(cat_builder *);
#endif
