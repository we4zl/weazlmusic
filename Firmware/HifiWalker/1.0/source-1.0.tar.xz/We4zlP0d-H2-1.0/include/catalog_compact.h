#ifndef WE4ZL_CATALOG_COMPACT_H
#define WE4ZL_CATALOG_COMPACT_H
#include "catalog.h"
typedef struct {
 catalog *base,*delta;cat_store store;unsigned destination;
 cat_record old,change;
 uint32_t old_at,delta_at,written,generation;uint64_t volume;
 uint8_t have_old,have_change,phase;cat_status error;
} cat_compact;
/* Merge persisted ID indexes into a fresh dictionary, preserving prior live
 * generation. Delta contains changed/new records and deletion tombstones.
 * A step performs one record fetch or one append; never sorts or parses tags. */
cat_status cat_compact_begin(cat_compact *,catalog *base,catalog *delta,cat_store,unsigned destination);
cat_status cat_compact_step(cat_compact *);
#endif
