#ifndef WE4ZL_CATALOG_QUERY_H
#define WE4ZL_CATALOG_QUERY_H
#include "catalog.h"
typedef enum {
  QUERY_PENDING,
  QUERY_FOUND,
  QUERY_MISSING,
  QUERY_ERROR
} cat_query_status;
typedef struct {
  catalog *catalog;
  const char *path;
  cat_record *out;
  uint64_t id;
  uint32_t lo, hi;
  uint8_t phase;
  cat_status error;
  cat_query_status result;
} cat_query;
/* One key page or one dictionary record per step; borrowed path/output stay
 * valid until completion. Full path verifies stable ID hash collisions. */
cat_query_status cat_query_begin(cat_query *, catalog *, const char *,
                                 cat_record *);
/* ID-only lookup for persisted playlist IDs. Lower-bound plus adjacentID
 * collision check refuses ambiguous hashes; no guessed path is returned. */
cat_query_status cat_query_id_begin(cat_query *, catalog *, uint64_t,
                                    cat_record *);
cat_query_status cat_query_step(cat_query *);
#endif
