#ifndef WE4ZL_POST_MVP_CLOCK_DISPLAY_H
#define WE4ZL_POST_MVP_CLOCK_DISPLAY_H
#include "echo_clock.h"
typedef struct {
 echo_clock_io io;
 uint32_t previous,fraction,milliseconds,cpu_hz,apb_hz;
 uint8_t initialized,failed;
} post_mvp_display;
/* Separate original driver; preserves installed historical echo_display.c.
 * Recognizes only the reviewed48/150MHz clock tuples before any writes.
 *150MHz still needs clock eligibility/physical timing acceptance. Call only
 *once after clock selection, before audio/storage; no changing clocks later. */
int post_mvp_display_init(post_mvp_display *,const echo_clock_io *);
/* CPU-source24-bit SysTick polling. Must observe at least every100ms at150MHz;
 * a missed full wrap cannot be recovered. No IRQs or guessed hardware timers. */
uint32_t post_mvp_display_millis(post_mvp_display *);
int post_mvp_display_delay(post_mvp_display *,uint32_t ms);
int post_mvp_display_row(post_mvp_display *,uint16_t,const uint8_t pixels[960]);
int post_mvp_display_backlight(post_mvp_display *);
#endif
