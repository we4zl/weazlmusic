#ifndef WE4ZL_LIBRARY_SERVICE_H
#define WE4ZL_LIBRARY_SERVICE_H
#include "catalog_refresh.h"
#include "metadata_any.h"
#include "library_generation.h"
#include "object_store.h"
#define LIBRARY_TARGET_TRACKS 100000u
#define LIBRARY_VISITED_BYTES ((LIBRARY_TARGET_TRACKS+7)/8)
typedef enum {LIBRARY_SCANNING,LIBRARY_REMOVALS,LIBRARY_GENERATING,LIBRARY_UNCHANGED,LIBRARY_PUBLISHED,LIBRARY_FAILED} library_service_state;
typedef struct {
 fs *volume;object_store *objects;catalog *base; journal *manifest;
 fs_file file;metadata_any tags;cat_record fallback;
 union {
  struct {library_scan walk;cat_refresh refresh;uint8_t visited[LIBRARY_VISITED_BYTES];} scan;
  library_generation generation;
 } work;
 uint32_t added,changed,removed,reused,tag_calls,unsupported;
 library_manifest published;
 library_service_state state;uint8_t force,tags_started;
} library_service;
/* Allocate service in the post-splash service arena, never main4KiB stack.
 * Prior live indexes stay mounted. Begin may only reset disposable delta14.
 * Reads and metadata steps are bounded; synchronous catalog/object callbacks
 * must run on the background worker with an independent stack. */
int library_service_begin(library_service *,fs *,object_store *,catalog *base_id,
                          journal *manifest,uint64_t volume_id,int force);
library_service_state library_service_step(library_service *);
#endif
