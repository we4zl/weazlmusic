#ifndef WEAZL_CODEC_M4A_H
#define WEAZL_CODEC_M4A_H
#include "codec.h"
codec_status codec_m4a_open(codec *c);
codec_status codec_m4a_read(codec *c,int16_t *out,size_t capacity,size_t *frames);
void codec_m4a_close(codec *c);
/* Private hooks, one active provider call at a time; arena stays bounded. */
void *codec_pool_alloc(codec *c,size_t size);
void *codec_library_malloc(size_t size);
void codec_library_free(void *ptr);
#endif
