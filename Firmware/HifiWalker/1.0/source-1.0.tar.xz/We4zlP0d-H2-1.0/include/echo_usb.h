#ifndef WEAZL_ECHO_USB_H
#define WEAZL_ECHO_USB_H
#include <stddef.h>
#include <stdint.h>
#include "usb_music.h"
/* EP0 + Bulk-Only transport. This protocol
 * layer owns all buffers and never calls stock code. Packet hooks require an
 * independently initialized hardware transport; this API does NOT initialize
 * PHY/clocks/FIFOs. Never count injected packet tests as device enumeration.
 * send copies/queues one packet: 1 accepted, -1 pending, 0 latched failure.
 * in_complete must be called only after actual endpoint transfer completion.
 * No automatic packet/backend retry following failure. */
typedef struct {
 int (*send)(void *,unsigned endpoint,const uint8_t *,size_t);
 int (*configure)(void *,int configured); /* actual endpoint setup; same returns */
 int (*address)(void *,unsigned); /* only after status IN completion */
 void (*stall)(void *,unsigned endpoint,int in);
 uint32_t (*millis)(void *);
 void *context;
 int (*clear_halt)(void *,unsigned endpoint,int in); /* explicit host request, idle only */
} echo_usb_packets;
typedef struct {
 const uint8_t *device,*configuration;
 size_t device_bytes,configuration_bytes;
 /* Descriptor index0 is languageIDs; each string must include its own header. */
 const uint8_t *strings[4];
 size_t string_bytes[4];
} echo_usb_descriptors;
typedef enum { EUSB_PROGRESS,EUSB_IDLE,EUSB_ARGUMENT,EUSB_PROTOCOL,
 EUSB_TRANSPORT,EUSB_TIMEOUT,EUSB_RESET_REQUIRED } echo_usb_result;
typedef struct {
 echo_usb_packets io;
 echo_usb_descriptors descriptors;
 usb_music *music,*internal,*removable;
 const uint8_t *control;
 uint32_t started,steps,tag,host_bytes,wire_left;
 uint16_t control_left,control_total,control_requested,bulk_packet_size;
 uint8_t control_state,bulk_state,configured,address,pending_address;
 uint8_t pending_config,control_zlp,bulk_status,direction,waiting_in;
 uint8_t queued,queued_ep,bulk_zlp,queued_csw,clean_eject,clear_endpoint,clear_in;
 uint16_t queued_length,packet_length;
 const uint8_t *received;
 echo_usb_result fault;
 uint8_t packet[512],out_packet[512],control_small[4],csw[13];
} echo_usb;
echo_usb_result echo_usb_init(echo_usb *,const echo_usb_packets *,
 const echo_usb_descriptors *,usb_music *);
/* A received valid eight-byte SETUP packet; hardware must abort the old EP0
 * transfer before delivering a new SETUP. Never clears endpoint stalls itself. */
echo_usb_result echo_usb_setup(echo_usb *,const uint8_t setup[8]);
/* A packet from OUT0/OUT1;0-length status packets matter. CBW must be one exact
 *31B transfer. Idle BOT reset and explicit idle CLEAR_FEATURE are supported. Active
 * recovery requests latch reset-required; no guessed endpoint cancellation. */
uint8_t *echo_usb_write_destination(echo_usb *,size_t);
echo_usb_result echo_usb_out(echo_usb *,unsigned endpoint,const uint8_t *,size_t);
echo_usb_result echo_usb_step(echo_usb *);
echo_usb_result echo_usb_in_complete(echo_usb *,unsigned endpoint);
/* Actual bus reset must be established by the hardware layer; this function
 * invalidates host ownership and clears protocol state, not storage or MMIO. */
void echo_usb_bus_reset(echo_usb *);
void echo_usb_disconnect(echo_usb *);
int echo_usb_idle(const echo_usb *);
int echo_usb_accepts_bulk_out(const echo_usb *);
/* Evidence-supported cold-init subset, deliberately stops disconnected. The
 * EP0/bulk PIO event adapter is locally modeled, physically unexecuted; do not
 * count READY_DISCONNECTED as enumerated USB. Every write follows resident
 * provenance. No FIFO sizing writes, DMA, IRQ vectors or automatic recovery. */
typedef struct {
 uint32_t (*read32)(void *,uint32_t);
 void (*write32)(void *,uint32_t,uint32_t);
 uint32_t (*millis)(void *);
 void *context;
} echo_usb_mmio;
typedef enum { EUSB_HW_PROGRESS,EUSB_HW_READY_DISCONNECTED,EUSB_HW_ARGUMENT,
 EUSB_HW_PROFILE,EUSB_HW_IRQ,EUSB_HW_TIMEOUT,EUSB_HW_FIFO,EUSB_HW_ACTIVE,EUSB_HW_CONNECTED,EUSB_HW_PROTOCOL } echo_usb_hw_result;
typedef struct {
 echo_usb_mmio io;
 uint32_t started,steps,absent_started;
 uint16_t phase;
 uint8_t connected,enumerated,configured,out_wait,absent,cable_lost;
 uint8_t control_only;
 echo_usb *protocol;
 uint8_t receive[64];
 echo_usb_hw_result result;
} echo_usb_hw;
echo_usb_hw_result echo_usb_hw_init(echo_usb_hw *,const echo_usb_mmio *);
/* Advance cold initialization through soft-disconnect. A control-only board
 * can then own EP0 without linking the bulk transport or exporting a disk. */
echo_usb_hw_result echo_usb_hw_prepare(echo_usb_hw *);
echo_usb_hw_result echo_usb_hw_step(echo_usb_hw *);
/* Obtain owned PIO callbacks, initialize echo_usb, then connect only after
 * READY_DISCONNECTED and real user-volume export proofs. Host-driven bus reset
 * is serviced; unsupported abort/BOT recovery latches a protocol failure. */
echo_usb_packets echo_usb_hw_packet_io(echo_usb_hw *);
echo_usb_hw_result echo_usb_hw_connect(echo_usb_hw *,echo_usb *);
/* Explicit session exit, not retry/recovery. Requires protocol idle; writes
 * only stock soft-disconnect bit and invalidates policy ownership. */
echo_usb_hw_result echo_usb_hw_disconnect(echo_usb_hw *);
#endif
