#ifndef WE4ZL_ECHO_BLUETOOTH_H
#define WE4ZL_ECHO_BLUETOOTH_H
#include <stdint.h>
#include <stddef.h>
/* Pure wire/transaction fragment. No MMIO, radio activation or audio backend.
 * Opcode letters deliberately retain wire names: complete semantics unresolved. */
#define ECHO_BT_RX_MAX 100
#define ECHO_BT_TX_MAX 10
#define ECHO_BT_NAME_MAX 31
typedef enum { ECHO_BT_VERSION, ECHO_BT_ACK_OK, ECHO_BT_ACK_ERROR,
               ECHO_BT_DISCOVERY, ECHO_BT_QUERY_RECORD, ECHO_BT_MARKER, ECHO_BT_DISCOVERY_END } echo_bt_kind;
typedef struct {
    echo_bt_kind kind;
    uint8_t opcode, version, address[6], name_length, name[ECHO_BT_NAME_MAX];
} echo_bt_frame;
typedef struct { uint8_t data[ECHO_BT_RX_MAX], used, expected; uint32_t rejected; } echo_bt_parser;
void echo_bt_parser_init(echo_bt_parser *);
/* One bounded byte step: 1 complete known frame, 0 pending/rejected. Unknown
 * responses are rejected; absence of an event does not mean radio failure. */
int echo_bt_parse(echo_bt_parser *,uint8_t,echo_bt_frame *);
size_t echo_bt_short(uint8_t out[ECHO_BT_TX_MAX],uint8_t opcode);
size_t echo_bt_address(uint8_t out[ECHO_BT_TX_MAX],uint8_t opcode,const uint8_t address[6]);
size_t echo_bt_parameter_y(uint8_t out[ECHO_BT_TX_MAX],uint8_t value);
typedef enum { ECHO_BT_IDLE,ECHO_BT_TX,ECHO_BT_WAIT,ECHO_BT_DONE,
               ECHO_BT_TIMEOUT,ECHO_BT_IO_ERROR,ECHO_BT_REMOTE_ERROR } echo_bt_state;
typedef struct {
    echo_bt_parser parser;
    uint32_t deadline;
    uint8_t tx[ECHO_BT_TX_MAX], length, sent, expected_opcode;
    echo_bt_state state;
} echo_bt_transaction;
/* write must be nonblocking; return accepted bytes, zero for backpressure,
 * negative for permanent failure. At most one invocation per tick, <=8 bytes. */
typedef int (*echo_bt_write)(void *,const uint8_t *,size_t);
void echo_bt_transaction_init(echo_bt_transaction *);
/* Local policy timeout is caller-selected (1..INT32_MAX ms), not vendor timing.
 * expected_opcode=V accepts proven CV1<digit>; others require matching C?OK/ER.
 * Streaming discovery results do not establish transaction completion. */
int echo_bt_begin(echo_bt_transaction *,const uint8_t *,size_t,uint8_t expected_opcode,uint32_t now,uint32_t timeout);
void echo_bt_tick(echo_bt_transaction *,uint32_t now,echo_bt_write,void *);
int echo_bt_receive(echo_bt_transaction *,uint8_t,uint32_t now,echo_bt_frame *);
/* Exact module identity/PCM routing are unresolved: production enable stays off. */
int echo_bt_hardware_ready(void);
#endif
