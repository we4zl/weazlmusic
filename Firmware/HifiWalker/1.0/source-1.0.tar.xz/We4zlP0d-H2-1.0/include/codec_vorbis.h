#ifndef WEAZL_CODEC_VORBIS_H
#define WEAZL_CODEC_VORBIS_H
#include "codec.h"
codec_status codec_vorbis_open(codec *c);
codec_status codec_vorbis_read(codec *c,int16_t *out,size_t capacity,size_t *frames);
codec_status codec_vorbis_next(codec *c,const wav_reader *next);
void codec_vorbis_close(codec *c);
#endif
