#ifndef WE4ZL_PLAYBACK_SESSION_H
#define WE4ZL_PLAYBACK_SESSION_H
#include "app.h"
#include "fs.h"
#include "codec.h"
#include "pcm.h"
#include "echo_audio_player.h"
#define PLAYBACK_COMMANDS 4u
#define PLAYBACK_MARKERS 8u
/* Seven entries are the pinned overlay ABI, in this order. Only one decoder
 * owner/overlay may exist. Loader must not overwrite a live provider. */
typedef struct {
 codec_status (*open)(codec *,codec_kind,const wav_reader *,void *,size_t);
 codec_status (*read)(codec *,int16_t *,size_t,size_t *);
 void (*close)(codec *);
 codec_status (*reset)(codec *);
 codec_status (*seek)(codec *,uint64_t);
 codec_status (*abandon)(codec *);
 codec_status (*next)(codec *,const wav_reader *);
} playback_provider;
typedef struct {
 void *context;fs *volume;echo_audio_player *player;
 void *decoder_arena;size_t decoder_bytes;
 int16_t *tail;size_t tail_bytes; /* caller-owned32768B, separate from codec arena */
 /* 1 verified provider ready,0 bounded loading,-1 error. catalog kinds1..7;
  * WAV/AIFF use original resident pcm.c and do not request an overlay. */
 int (*load)(void *,cat_codec,playback_provider *);
 /* Step verified-loader quiesce after normal close/abandon:1free,0loading or
  *accepted read draining,-1terminal. No different overlay load before1. */
 int (*release_provider)(void *);
 /* Optional pinned playlist queue; missing IDs return2, unavailable is-1.
  *Callbacks are worker-only and serialized, including audible markers. */
 int (*playlist_begin)(void *,uint64_t,uint32_t,catalog *,uint32_t *);
 int (*playlist_resolve)(void *,uint32_t,cat_record *);
 int (*playlist_close)(void *);
 /* Background worker only: yield while storage is pending. Return0 cancels.
  * Must serialize this fs/cache with scans/USB, preserve worker continuation,
  * and let main service volume/audio/input. Never an automatic USB retry. */
 int (*wait_storage)(void *);
 /* Called in worker after source headers; begin/reformat actual player, never
  * reset live DMA. 1 means correctly configured READY/LEVEL/RUNNING with IRQ armed,0 pending,-1 refuses. */
 int (*prepare_sink)(void *,uint32_t,unsigned);
 void (*publish)(void *,app_play_state,const cat_record *,uint32_t,uint32_t);
 void (*queue)(void *,catalog *,uint32_t,uint32_t,uint32_t);
 void (*external)(void *,app_command_kind); /* USB/rescan after clean stop only */
 uint32_t random_seed; /* nonzero seed supplied from real platform entropy/timing */
} playback_config;
typedef enum {PLAYBACK_IDLE,PLAYBACK_ACTIVE,PLAYBACK_DRAIN,PLAYBACK_RESTART,PLAYBACK_ERROR} playback_state;
typedef struct playback_session playback_session;
typedef struct {playback_session *session;fs_file file;} playback_file;
typedef struct {uint64_t at;uint32_t ordinal,duration,offset_ms;} playback_marker;
struct playback_session {
 playback_config config;audio_stream stream;eq equalizer;eq_plan plan;
 codec decoder;pcm_decoder pcm;playback_provider provider;
 fs_lookup lookup;playback_file files[2];cat_record record,published;
 catalog *catalog;uint32_t first,end,ordinal,chosen,stride,selected,rng;
 uint64_t produced,base,published_at,track_skip,seek_target,completed_total;
 uint32_t completed_last,min_cold_runway,short_cold_handoffs;
 volatile uint32_t tail_read,tail_write;
 uint32_t seek_ms,published_position,published_ordinal,published_offset;
 uint64_t playlist_id;uint32_t playlist_generation,playlist_count,missing_run;
 player_settings desired;
 app_command commands[PLAYBACK_COMMANDS],pending;
 playback_marker markers[PLAYBACK_MARKERS];
 volatile uint8_t command_read,command_write,cancel_requested;
 uint8_t marker_head,marker_used,prepare_phase,file_slot,decoder_open,provider_kind;
 uint8_t source_started,paused,eq_ready,eq_pending,format_wait,restart_pending,external_pending;
 uint8_t provider_leased,tail_started,finish_sent,abandoned;
 uint8_t playlist_active,playlist_opening,restart_phase,marker_resolving;
 volatile uint8_t audio_fault;
 playback_state state;uint32_t commands_dropped,read_calls,storage_yields,source_opens;
};
/* Caller-owned service memory, not4KiB main stack. decoder_bytes <=161760; separate tail32768B;
 * source/settings/command work runs on one background worker. Main independently
 * calls echo_audio_player_step and volume_step; no codec runs in an IRQ. */
int playback_session_init(playback_session *,const playback_config *,const player_settings *);
/* Bounded SPSC enqueue; main producer/worker consumer. Queue has3 usable slots.
 * Publishing/catalog callbacks run only in worker step. Catalog generation and
 * requested range are immutable and must remain pinned until session stops. */
int playback_session_submit(void *,const app_command *);
void playback_session_step(playback_session *);
/* Main only: hardware service then <=128 already transformed frames copied
 *from tail to DMA queue. Must run at codec checkpoints, never invokes storage. */
void playback_session_audio(playback_session *,uint32_t now_ms);
/* Fatal worker cancellation only after caller proves that suspended continuation
 *can NEVER resume. Calls provider abandon before stepped quiesce. Returns1done,
 *0draining,-1refused/error. Never resets/releases hardware DMA ownership. */
int playback_session_abandon(playback_session *,int worker_permanently_stopped);
#endif
