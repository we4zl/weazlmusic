#ifndef WXP_RECEIPT_SHA256_H
#define WXP_RECEIPT_SHA256_H
#include <stdint.h>

static uint32_t receipt_be32(const uint8_t *p)
{
    return (uint32_t)p[0]<<24 | (uint32_t)p[1]<<16 | (uint32_t)p[2]<<8 | p[3];
}

static void receipt_put_be32(uint8_t *p, uint32_t value)
{
    for (unsigned i=0;i<4;++i)
        p[i]=(uint8_t)(value>>(24-8*i));
}

static uint32_t right_rotate(uint32_t x, unsigned bits)
{
    return x >> bits | x << (32-bits);
}

static void receipt_sha256(const uint8_t token[32], uint8_t digest[32])
{
    static const uint32_t constants[64]={
        0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
        0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
        0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
        0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
        0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
        0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
        0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
        0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2};
    static const uint32_t initial[]={0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
                                    0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19};
    uint32_t words[64],state[8];
    for (unsigned i=0;i<8;++i) {words[i]=receipt_be32(token+4*i);state[i]=initial[i];}
    words[8]=0x80000000;
    for (unsigned i=9;i<15;++i) words[i]=0;
    words[15]=256;
    for (unsigned i=16;i<64;++i) {
        uint32_t x=words[i-15],y=words[i-2];
        words[i]=words[i-16]+(right_rotate(x,7)^right_rotate(x,18)^(x>>3))
                 +words[i-7]+(right_rotate(y,17)^right_rotate(y,19)^(y>>10));
    }
    for (unsigned i=0;i<64;++i) {
        uint32_t a=state[0],e=state[4];
        uint32_t t=state[7]+(right_rotate(e,6)^right_rotate(e,11)^right_rotate(e,25))
                   +((e&state[5])^(~e&state[6]))+constants[i]+words[i];
        uint32_t u=(right_rotate(a,2)^right_rotate(a,13)^right_rotate(a,22))
                   +((a&state[1])^(a&state[2])^(state[1]&state[2]));
        for (unsigned j=7;j>0;--j) state[j]=state[j-1];
        state[4]+=t;state[0]=t+u;
    }
    for (unsigned i=0;i<8;++i) receipt_put_be32(digest+4*i,state[i]+initial[i]);
}

#endif
