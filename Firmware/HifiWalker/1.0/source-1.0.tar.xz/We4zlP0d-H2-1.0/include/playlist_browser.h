#ifndef WE4ZL_PLAYLIST_BROWSER_H
#define WE4ZL_PLAYLIST_BROWSER_H
#include "fs.h"
#define PLAYLIST_BROWSER_ROWS 3u
typedef enum {
  PB_CLOSED,
  PB_LOADING,
  PB_READY,
  PB_EMPTY,
  PB_CHOSEN,
  PB_ERROR
} playlist_browser_status;
typedef struct {
  char label[96];
  uint8_t directory;
} playlist_browser_row;
typedef struct {
  void *context;
  /* Required exclusive filesystem/sharedservicearena lease. 1 ready,0busy,-1
   * unavailable. Parent suspends scans and forbids USB unmount while leased. */
  int (*acquire)(void *);
  void (*release)(void *);
} playlist_browser_hooks;
typedef struct {
  fs *volume;
  playlist_browser_hooks hooks;
  char path[FS_PATH_BYTES];
  union {
    fs_lookup lookup;
    struct {
      fs_dir dir;
      fs_entry entry;
    } scan;
  } work;
  playlist_browser_row rows[PLAYLIST_BROWSER_ROWS];
  uint32_t offset, seen, target;
  uint16_t directory_bytes;
  uint8_t phase, owned, closing, selecting, count, focus, has_next, active;
  playlist_browser_status status;
} playlist_browser;
/* Zero-init. State belongs to exclusive sharedservicearena, not main stack.
 * Browses actual user-volume directories and .m3u/.m3u8 files; no fixtures,
 * recursive fulltree scan, symlink, metadata write or arbitrary raw
 * destination. Foreground begin/action/close perform no IO/hooks; worker step
 * takes lease and <=one cooperative lookup/dirnext (<=32rawslots). Rows are
 * three paged names, not fullpaths. Longnames are UTF8-byte-truncated at
 * codepoint boundary. Path <=1023 bytes, fullselectedname retained by rescan
 * instead of truncation.
 */
int playlist_browser_begin(playlist_browser *, fs *, playlist_browser_hooks);
int playlist_browser_action(playlist_browser *,
                            unsigned); /*0left1right2play3parent4cancel*/
playlist_browser_status playlist_browser_step(playlist_browser *);
void playlist_browser_close(playlist_browser *);
/* CHOSEN path is exactuser-rootrelative bytes, immutable and borrowed until
 * close completes. Keep lease through fs_open/reading/import, or copy into a
 * separatelyleased importstate before close; never keep pointer into
 * reusedarena. Existing import resolves paths relative to thisfile's parent
 * directory. */
const char *playlist_browser_path(const playlist_browser *);
#endif
