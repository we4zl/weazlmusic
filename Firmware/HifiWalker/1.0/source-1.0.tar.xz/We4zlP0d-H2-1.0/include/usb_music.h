#ifndef WEAZL_USB_MUSIC_H
#define WEAZL_USB_MUSIC_H
#include <stddef.h>
#include <stdint.h>
/* Portable SCSI/user-volume policy only. No USB registers, descriptors,
 * endpoints, BOT/CBW transport, enumeration or target write backend. Backend
 * addresses are USER-VOLUME-relative; a raw device/firmware backend is forbidden.
 * Return1=complete,0=error,-1=pending from read/write/sync. */
typedef struct {
    int (*read)(void *,uint32_t,uint8_t [512]);
    int (*write)(void *,uint32_t,const uint8_t [512]);
    int (*sync)(void *);
    void *context;
    uint32_t sectors;
} usb_music_store;
typedef int (*usb_music_write_blocks)(void *, uint32_t lba, const uint8_t *, unsigned sectors);
typedef enum { USB_MUSIC_OK,USB_MUSIC_AGAIN,USB_MUSIC_FAILED,USB_MUSIC_PHASE_ERROR,
    USB_MUSIC_INVALID,USB_MUSIC_BUSY,USB_MUSIC_NOT_READY } usb_music_status;
typedef enum { USB_MUSIC_FIRMWARE,USB_MUSIC_QUIESCE,USB_MUSIC_HOST,
    USB_MUSIC_INVALIDATE,USB_MUSIC_REMOUNT,USB_MUSIC_FAULT } usb_music_owner;
typedef enum { USB_MUSIC_NONE,USB_MUSIC_IN,USB_MUSIC_OUT } usb_music_direction;
enum { USB_MUSIC_PLAY_STOPPED=1,USB_MUSIC_SCAN_STOPPED=2,USB_MUSIC_METADATA_SYNCED=4,
    USB_MUSIC_FS_UNMOUNTED=8,USB_MUSIC_GEOMETRY_PROVEN=16,USB_MUSIC_ALL_PROOFS=31 };
typedef struct {
    usb_music_store store;
    usb_music_owner owner;
    uint32_t sector,left,residue,sectors_written;
    uint16_t buffered,cursor,packet_size;
    uint8_t job,active,dirty,prevent_removal,remount_read_only;
    uint8_t sense_key,sense_asc,sense_ascq;
    uint8_t removable, no_media, force_sync, defer_eject;
    uint8_t *write_batch;
    uint16_t write_batch_bytes;
    usb_music_write_blocks write_blocks;
#ifdef WXP_MINI_RECEIPTS
    /* Return 32 for a digest, 0 for an absent revision, or -1 on I/O error. */
    int (*receipt)(unsigned page, uint32_t sectors, uint8_t digest[32]);
#endif
    uint8_t buffer[512];
} usb_music;
usb_music_status usb_music_init(usb_music *,const usb_music_store *);
/* Optional caller-owned sector-aligned buffer, used only for WRITE(10).
 * The callback completes the whole batch, fails it, or reports pending. */
int usb_music_set_write_batch(usb_music *, uint8_t *, size_t, usb_music_write_blocks);
int usb_music_out_has_room(const usb_music *);
usb_music_status usb_music_begin_export(usb_music *);
/* Each proof must reflect actual completed operations. A bitmask is caller
 * evidence, never hardware proof by itself. No host I/O before all five. */
usb_music_status usb_music_export_ready(usb_music *,unsigned proofs);
usb_music_status usb_music_command(usb_music *,const uint8_t *cdb,size_t cdb_bytes,
                                   usb_music_direction,uint32_t host_bytes);
/* At most one USB packet (64 bytes by default) and one backend sector call. Arbitrary
 * endpoint packet sizes/scatter supported; OUT can be called with NULL/0 to
 * finish a pending full sector before SCSI status. No automatic I/O retry. */
usb_music_status usb_music_in(usb_music *,uint8_t *,size_t,size_t *produced);
usb_music_status usb_music_out(usb_music *,const uint8_t *,size_t,size_t *consumed);
usb_music_status usb_music_finish(usb_music *);
void usb_music_disconnect(usb_music *);
usb_music_status usb_music_cache_invalidated(usb_music *);
/* An unclean disconnect requires a successful READ-ONLY remount or an explicit
 * later repair workflow outside this module. Never auto-fsck or resume writes. */
usb_music_status usb_music_remounted(usb_music *,int success,int read_only);
#endif
