#ifndef WE4ZL_METADATA_ANY_H
#define WE4ZL_METADATA_ANY_H
#include "metadata.h"
#include "pcm.h"
/* Original bounded background metadata reader. Same exact-reader interface as
 * wav_reader, extended to accept -1 pending; readers may be called again at the
 * identical offset after pending. Source must remain immutable for whole scan.
 * Own steps issue at most three reads, each at most256B (M4A headers plus
 * small payload); delegated FLAC/PCM keep their documented read bounds. A
 * pending backend needs at least four cached sectors so rollback can replay
 * earlier headers without evicting a later pending payload. Artwork is never
 * allocated. Caller seeds filename fallback; unsupported/malformed text retains
 * it. Record is only valid on META_OK; failure may leave partial fields and
 * must be discarded. MP3 duration requires a complete validated frame walk. Ogg
 * reads page headers through EOS rather than extrapolating. This is background
 * work, never UI lookup. */
typedef struct {
  wav_reader source;
  cat_record *record;
  union {
    metadata_scan flac;
    pcm_decoder pcm;
  } sub;
  size_t cursor, end, stack_end[10];
  uint32_t stack_type[10], atoms, frames, rate, tag, remaining, value, comments,
      comment_length;
  uint32_t serial, sequence, crc, expected_crc, page_bytes, packet_bytes;
  uint64_t granule, media_duration;
  uint32_t media_scale;
  uint16_t text_length, pre_skip;
  uint8_t mode, phase, depth, version, flags, pending, failed, channels,
      have_audio;
  uint8_t segment_count, segment, segment_left, page_flags, have_page,
      packet_no, comment_phase;
  uint8_t number_bytes, text_encoding, ogg_kind, have_serial, tag_done,
      crc_check, tail_tag;
  uint8_t segments[255], prefix[64], text[256];
} metadata_any;
metadata_status metadata_any_begin(metadata_any *, wav_reader, cat_record *);
metadata_status metadata_any_step(metadata_any *);
#endif
