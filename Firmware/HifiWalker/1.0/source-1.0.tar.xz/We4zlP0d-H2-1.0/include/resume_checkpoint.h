#ifndef WE4ZL_RESUME_CHECKPOINT_H
#define WE4ZL_RESUME_CHECKPOINT_H
#include "settings.h"
#define RESUME_CHECKPOINT_INTERVAL_MS 30000u
#define RESUME_CHECKPOINT_DEBOUNCE_MS 1000u
typedef enum {
  RESUME_PLAYING,
  RESUME_PAUSED,
  RESUME_STOPPED
} resume_play_state;
typedef struct {
  uint64_t id, staged_id;
  uint32_t position, staged_position, last_saved, due, revision,
      staged_revision;
  uint8_t state, seen, forced, staged, staged_valid, cleared;
} resume_checkpoint;
void resume_checkpoint_init(resume_checkpoint *, uint32_t now_ms);
/* ONLY actualbackend publication with realresolvedrecord stableID/position.
 * No fixture, requested/queued ID or decoded-ahead position qualifies.
 * id0/refusedstate rejected without mutation; metadata resolution
 * remainscaller. Stop preserves lastactualtrack; never converts silence into
 * track0. */
int resume_checkpoint_publish(resume_checkpoint *, uint64_t id,
                              uint32_t position_ms, resume_play_state,
                              uint32_t now_ms);
/* Explicit UI Forget resume: stages canonicalzero without autoplay. Suppresses
 * rerecording unchangedcurrent playback until newtrack or newPlaystateedge.
 * Continues to honor pendingactualjournal save before clearingnewgeneration. */
void resume_checkpoint_clear(resume_checkpoint *, uint32_t now_ms);
/* Pure boundedpolicy, NOIO.1 means desiredsettings resume changed;0 nochange.
 * Periodicposition saves >=30s after actualack; track/pause/stop edges debounce
 *1s and mayflushsooner. Readonlyplatform must defer actualsettings_save, not
 *acknowledge unpersisted desiredvalues. One stagedsnapshotuntildurableack.
 * Caller merges this into existing configsavecoalescing, preserves
 * allotherfields.
 */
int resume_checkpoint_apply(resume_checkpoint *, player_settings *desired,
                            uint32_t now_ms);
/* Call ONLY after actualdurable SETTINGS_READY for a savedgeneration; accepts
 * matchingstagedresume snapshot. Unrelated/nonmatching saves cannot ack it. */
int resume_checkpoint_ack(resume_checkpoint *, const player_settings *durable,
                          uint32_t now_ms);
#endif
