#ifndef WEAZL_UI_H
#define WEAZL_UI_H
#include <stdint.h>
#include <stddef.h>
#include "battery.h"
#define UI_WIDTH 480
#ifndef UI_HEIGHT
#define UI_HEIGHT 222
#endif
typedef enum { UI_LIBRARY, UI_NOW_PLAYING, UI_QUEUE, UI_SETTINGS, UI_SCREEN_COUNT } ui_screen;
typedef enum { UI_UP, UI_DOWN, UI_LEFT, UI_RIGHT, UI_SELECT, UI_BACK, UI_MENU, UI_KEY_COUNT } ui_key;
typedef struct {
    uint8_t screen, category, content_focus, opened, input_available;
    uint32_t revision;
    battery_state battery;
} ui_state;
void ui_init(ui_state *state, int input_available);
void ui_event(ui_state *state, ui_key key);
/* Real sampler publishes readings; invalid state renders unknown. */
void ui_set_battery(ui_state *state, const battery_state *battery);
/* Exact output capacity enforced. RGB565 in display byte order, one row only. */
/* Shared brand, battery, tabs and footer; live app owns all content panels. */
int ui_render_chrome(const ui_state *,unsigned,uint8_t *,size_t);
int ui_render_row(const ui_state *state, unsigned y, uint8_t *out, size_t capacity);
/* Clipped text primitive used by the renderer and safety tests. Unsupported
 * bytes become '?'; all strings are bounded to 96 input bytes. */
void ui_text_row(unsigned y, int x, int top, int width, unsigned font,
                 const char *text, uint16_t color, uint8_t out[960]);
void ui_marquee_row(unsigned y, int x, int top, int width, unsigned font,
                    const char *text, uint16_t color, unsigned time, uint8_t out[960]);
unsigned ui_text_width(unsigned font, const char *text);
typedef struct {
    uint32_t changed, repeat_at;
    uint8_t candidate, stable, armed;
} ui_debounce;
void ui_debounce_init(ui_debounce *input);
/* Raw zero = released; otherwise key+1. Chords/invalid samples = released.
 * Requires release after boot. 25 ms debounce; directions repeat after450/100ms. */
int ui_debounce_poll(ui_debounce *input, uint8_t raw, uint32_t now, ui_key *event);
#endif
