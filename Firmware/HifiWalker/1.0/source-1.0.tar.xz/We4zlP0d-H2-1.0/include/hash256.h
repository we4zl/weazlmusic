#ifndef WE4ZL_HASH256_H
#define WE4ZL_HASH256_H
#include <stddef.h>
#include <stdint.h>
/* Original SHA-256 implementation, FIPS180-4 arithmetic; no allocation. */
typedef struct {uint32_t h[8];uint64_t bytes;uint8_t block[64],used;} hash256;
void hash256_init(hash256 *);
void hash256_update(hash256 *,const void *,size_t);
void hash256_final(hash256 *,uint8_t out[32]);
#endif
