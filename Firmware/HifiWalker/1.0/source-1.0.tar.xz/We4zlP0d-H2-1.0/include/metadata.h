#ifndef WE4ZL_METADATA_H
#define WE4ZL_METADATA_H
#include "catalog.h"
#include "wav.h"
typedef enum { META_OK,META_AGAIN,META_UNSUPPORTED,META_INVALID,META_IO } metadata_status;
typedef struct {
    wav_reader source;cat_record *record;
    size_t cursor,block_end,comment_cursor;
    uint32_t comments;
    uint8_t phase,last,blocks,streaminfo;
} metadata_scan;
/* Actual native FLAC metadata parser. Each step reads at most one comment prefix
 * (255B) or34B STREAMINFO; skips picture/audio payloads. At most128metadata
 * blocks and4096comments, no all-tag allocation. Oversized text is display-clipped
 * at UTF-8 boundaries; path is independently validated by catalog encoding. */
metadata_status metadata_flac_begin(metadata_scan *,wav_reader,cat_record *);
metadata_status metadata_flac_step(metadata_scan *);
#endif
