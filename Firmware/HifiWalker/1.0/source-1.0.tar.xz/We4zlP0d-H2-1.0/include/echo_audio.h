#ifndef WE4ZL_ECHO_AUDIO_H
#define WE4ZL_ECHO_AUDIO_H
#include <stdint.h>
#include <stddef.h>
typedef enum { ECHO_AUDIO_I2C_OWNER,ECHO_AUDIO_DMA5_SINK,ECHO_AUDIO_I2S1_OWNER,ECHO_AUDIO_DAC_POWER_READY,ECHO_AUDIO_POWER_OWNER,ECHO_AUDIO_DMA5_IRQ_OWNER,ECHO_AUDIO_RADIO_ROUTE } echo_audio_proof;
typedef struct {
    void *context;
    int (*read)(void *,uint32_t,uint32_t *);
    int (*write)(void *,uint32_t,uint32_t);
    /* I2C: exclusive exact GPIO2 10/11 bus ownership; verified APB rate.
     * DMA5: DAC mute/init, selected I2S1 clock/pins/format, startup and exclusive
     * channel5 ownership and noncompeting IRQ handling established. Missing proof
     * refuses, never guesses. */
    int (*eligible)(void *,echo_audio_proof);
    /* DMA-visible SRAM range/alignment and caller ownership must be reviewed. */
    int (*dma_buffer)(void *,uint32_t address,size_t bytes);
    void (*barrier)(void *);
} echo_audio_io;
typedef enum { ECHO_I2C_IDLE,ECHO_I2C_RESET_WAIT,ECHO_I2C_READY,ECHO_I2C_START,
    ECHO_I2C_TRANSFER,ECHO_I2C_STOP,ECHO_I2C_DONE,ECHO_I2C_NAK,
    ECHO_I2C_TIMEOUT,ECHO_I2C_IO_ERROR,ECHO_I2C_REFUSED } echo_i2c_state;
typedef struct {
    echo_audio_io io;
    uint32_t deadline,divider;
    uint8_t data[6],length,receive,read_byte,nak;
    echo_i2c_state state;
} echo_audio_i2c;
void echo_audio_i2c_init(echo_audio_i2c *);
/* Bounded I2C0 initialization. Only observed speeds300/400kHz; APB24/75MHz.
 * Caller supplies current validated milliseconds; reset hold is >=1ms. */
int echo_audio_i2c_setup(echo_audio_i2c *,const echo_audio_io *,uint32_t apb_hz,unsigned khz,uint32_t now);
/* Payload excludes raw address byte. Restricted to exact DAC addresses60/66,
 * <=5 bytes. DAC pointer read is write4, STOP, then separate read1 as stock. */
int echo_audio_i2c_write(echo_audio_i2c *,uint8_t raw,const uint8_t *,size_t,uint32_t now,uint32_t timeout_ms);
int echo_audio_i2c_read_one(echo_audio_i2c *,uint8_t raw,uint32_t now,uint32_t timeout_ms);
echo_i2c_state echo_audio_i2c_step(echo_audio_i2c *,uint32_t now);
/* Builds exact24bit register/count/value payload; per-chip mono-phase fields
 * are handled from the selected raw address. No chip identity claim. */
int echo_audio_dac_payload(uint8_t out[5],uint8_t raw,uint32_t reg,uint8_t value);
typedef enum { ECHO_DMA_IDLE,ECHO_DMA_ACTIVE,ECHO_DMA_COMPLETE,ECHO_DMA_REFUSED,
               ECHO_DMA_QUARANTINED } echo_audio_dma_state;
typedef struct {
    echo_audio_io io;
    uint32_t source,words,deadline;
    echo_audio_dma_state state;
    uint8_t owns_buffer,timed_out_busy;
} echo_audio_dma;
void echo_audio_dma_init(echo_audio_dma *);
/* Raw32bit I2S slots only: no unproven PCM16 scaling/channel-order conversion.
 * Max256 words. Caller must retain unchanged DMA-visible buffer until COMPLETE.
 * Failure/timeout quarantines it; no forced abort/reset/free/retry is provided. */
int echo_audio_dma_submit(echo_audio_dma *,const echo_audio_io *,uint32_t source,unsigned words,uint32_t now,uint32_t timeout_ms);
/* Same exact transfer with channel5 TFR IRQ unmasked (source mask2020).
 * Requires additional DMA5_IRQ_OWNER route/concurrency proof; never installs
 *vectors or enables CPU/NVIC IRQs itself. */
int echo_audio_dma_submit_irq(echo_audio_dma *,const echo_audio_io *,uint32_t source,unsigned words,uint32_t now,uint32_t timeout_ms);
echo_audio_dma_state echo_audio_dma_poll(echo_audio_dma *,uint32_t now);
int echo_audio_dma_release(echo_audio_dma *);
typedef enum { ECHO_I2S_IDLE,ECHO_I2S_CLEAR_WAIT,ECHO_I2S_PLL_WAIT,
    ECHO_I2S_READY,ECHO_I2S_RUNNING,ECHO_I2S_REFUSED,ECHO_I2S_FAULT } echo_i2s_state;
typedef struct {
    echo_audio_io io;
    uint32_t deadline,rate;
    echo_i2s_state state;
} echo_audio_i2s;
/* Initialize contexts only before first use or after an externally established
 * safe reset. Reinitializing a live context is not an abort/recovery operation. */
void echo_audio_i2s_init(echo_audio_i2s *);
/* Exact stock selected I2S1/32-bit slot branch, restricted to44.1/48kHz.
 * I2S1_OWNER must prove exclusive GPIO1 0..3/audio PLL ownership, accessible
 * ungated register buses, DMA5 idle, and valid caller millisecond timebase.
 * No DAC startup/unmute or physical playback claim. FIFO clear timeout faults;
 * stock's unsafe fallthrough after its iteration limit is deliberately absent. */
int echo_audio_i2s_setup(echo_audio_i2s *,const echo_audio_io *,uint32_t rate,uint32_t now);
echo_i2s_state echo_audio_i2s_step(echo_audio_i2s *,uint32_t now);
int echo_audio_i2s_start(echo_audio_i2s *);
/* Requires DMA5 idle before clearing XFER bit0. Does not abort DMA, clear its
 * requests, release buffers, or claim that the DAC/output rails are off. */
int echo_audio_i2s_stop(echo_audio_i2s *);
typedef enum { ECHO_POWER_IDLE,ECHO_POWER_WAIT,ECHO_POWER_READY,ECHO_POWER_REFUSED,ECHO_POWER_FAULT } echo_power_state;
typedef struct {
    echo_audio_io io;
    uint32_t deadline;
    echo_power_state state;
    uint8_t defer_amp;
#if defined(WXP_ECHO_MINI) && (WXP_MINI_REVISION == 9 || WXP_MINI_REVISION == 18 || WXP_MINI_REVISION == 19)
    uint8_t pin_phase;
#endif
} echo_audio_power;
void echo_audio_power_init(echo_audio_power *);
/* Stock music GPIO ordering. Mini N09 also exercises the GPIO2.1 pulse.
 * POWER_OWNER must establish accessible clocked GPIO1/GPIO2/GRF buses and sole
 * ownership of GPIO2 pins1/2/14 and GPIO1 pin4. No guessed net names or shutdown.
 * Unrelated GPIO data/direction bits are preserved by explicit RMW. */
int echo_audio_power_begin(echo_audio_power *,const echo_audio_io *,uint32_t now);
echo_power_state echo_audio_power_step(echo_audio_power *,uint32_t now);
typedef enum { ECHO_DAC_IDLE,ECHO_DAC_ACTIVE,ECHO_DAC_WAIT,ECHO_DAC_MUTED,
    ECHO_DAC_REFUSED,ECHO_DAC_FAULT } echo_dac_state;
typedef struct {
    echo_audio_i2c *bus;
    uint32_t deadline,wait_until;
    uint8_t operation,phase,chip_read[2],bus_pending,enable_amp_after_precharge;
    echo_dac_state state;
} echo_audio_dac;
void echo_audio_dac_init(echo_audio_dac *);
/* Exact default-filter/default-output script, with both volume registers forced
 *0xff mute. Requires externally established exact music GPIO power/reset order,
 * exclusive initialized I2C0, stable verified timebase and ownership throughout.
 * No physical identity or sound acceptance. Any failure terminal; no retry or
 * automatic shutdown writes into an uncertain bus. Stock100us waits are rounded
 * upward to1ms, never converted into guessed scheduler ticks. */
int echo_audio_dac_begin_muted(echo_audio_dac *,echo_audio_i2c *,uint32_t now);
echo_dac_state echo_audio_dac_step(echo_audio_dac *,uint32_t now);
/* Full wired startup/readiness still unavailable until DAC/I2S sequence and
 * conservative unmute are integrated and independently validated. */
int echo_audio_startup_complete(void);
#endif
