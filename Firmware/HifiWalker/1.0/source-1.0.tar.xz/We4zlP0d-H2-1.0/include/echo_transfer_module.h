#ifndef WEAZL_ECHO_TRANSFER_MODULE_H
#define WEAZL_ECHO_TRANSFER_MODULE_H
#include "echo_transfer.h"
#define ECHO_TRANSFER_MODULE_ABI 1u
#define ECHO_TRANSFER_MODULE_ENTRIES 6u
/* This module shares the CODEC code bank. Resident MUST stop the decoder and
 * release every codec task/frame before loading it; its stop_audio hook cannot
 * stop code which was already overwritten. Context lives in caller-owned arena,
 * not resident BSS. Only volume/MMC/cache/FS/metadata persist across bank reuse.
 * All six entries have this signature; entry indices are fixed below. */
typedef struct {
 uint32_t abi;
 echo_transfer controller;
 usb_music music;
 echo_usb protocol;
 echo_usb_hw hardware;
} echo_transfer_module;
typedef struct {
 uint32_t abi;
 echo_volume *volume;
 metadata_store *metadata;
 echo_transfer_hooks hooks;
 echo_usb_mmio mmio;
 const echo_usb_descriptors *descriptors;
 /* Resident attests all old overlay tasks/call frames and decoder DMA reads
  * are gone BEFORE load. This is a necessary precondition, not proof by model. */
 int old_overlay_released;
} echo_transfer_module_config;
typedef struct {
 echo_transfer_state state;
 echo_usb_result protocol;
 echo_usb_hw_result hardware;
 usb_music_owner owner;
 uint8_t connected,read_only,failed;
} echo_transfer_module_status;
typedef int (*echo_transfer_module_entry)(echo_transfer_module *,void *);
/*0 open(config),1 enter(NULL),2 leave(NULL),3 step(optional status out),
 *4 status(status out),5 can_unload(NULL). No function has hidden static state.
 * Return1 success/eligible,0 failure/ineligible; step result is in status.
 * can_unload cannot inspect task stacks: resident separately proves no active
 * module frames or pending callbacks, then drops ALL module pointers before
 * overlay_release. Failed modules require explicit recovery, never bank reuse. */
int echo_transfer_module_open(echo_transfer_module *,void *);
int echo_transfer_module_enter(echo_transfer_module *,void *);
int echo_transfer_module_leave(echo_transfer_module *,void *);
int echo_transfer_module_step(echo_transfer_module *,void *);
int echo_transfer_module_snapshot(echo_transfer_module *,void *);
int echo_transfer_module_can_unload(echo_transfer_module *,void *);
#endif
