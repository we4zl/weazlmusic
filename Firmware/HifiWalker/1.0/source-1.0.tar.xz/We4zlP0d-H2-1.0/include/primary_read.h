#ifndef WE4ZL_PRIMARY_READ_H
#define WE4ZL_PRIMARY_READ_H
#include "echo_mmc.h"
#include <stddef.h>
/* Read-only immutable embedded module payloads in current primary. Physical
 * mapping8192 derives from exact Loader IMAGE evidence, not user-LUN geometry.
 * No write/erase/reset/USB retry operation exists in this adapter. */
typedef int (*primary_quiesce)(void *,int acquire);
typedef struct {
 echo_mmc *mmc;primary_quiesce quiesce;void *context;
 uint8_t *destination;uint32_t offset,bytes,done;
 uint8_t phase,failed,cache_owned;uint8_t sector[512];
} primary_reader;
void primary_reader_init(primary_reader *,echo_mmc *,primary_quiesce,void *);
/*1complete,-1same accepted request pending,0terminalfailure. Destination and
 * exact parameters remain immutable until completion. Allows only module byte
 * range1MiB..primary_end-512; never headers/boot/secondary/user music. */
int post_mvp_primary_read(void *,uint32_t,void *,size_t);
/* Main must step this INSTEAD OF volume/cache while it owns the controller.
 * Quiesce(acquire1): all other storage callers suspended, accepted metadata job
 * drained, volume/cache reads finished and cache disabled. -1meanskeepdraining.
 * Quiesce(acquire0): resume unchanged proven filesystem/cache; no external host
 * access occurred. The callbacks supply actual ownership proof, not a flag. */
int primary_reader_step(primary_reader *);
int primary_reader_active(const primary_reader *);
#endif
