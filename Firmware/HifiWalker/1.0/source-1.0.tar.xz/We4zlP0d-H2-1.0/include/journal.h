#ifndef WEAZL_JOURNAL_H
#define WEAZL_JOURNAL_H
#include <stddef.h>
#include <stdint.h>
#define JOURNAL_HEADER_BYTES 32u
#define JOURNAL_MAX_PAYLOAD 4096u
/* The injected byte store must be confined to caller-owned metadata, never
 * boot/firmware/audio bytes. Exact reads/writes return1; no retry. A sync must
 * truthfully implement the backend's durability barrier. No filesystem or
 * hardware write implementation is supplied here. */
typedef struct {
    int (*read)(void *,uint32_t,uint8_t *,size_t);
    int (*write)(void *,uint32_t,const uint8_t *,size_t);
    int (*sync)(void *);
    void *context;
    uint32_t bytes;
} journal_store;
typedef enum { JOURNAL_OK,JOURNAL_EMPTY,JOURNAL_INVALID,JOURNAL_IO,JOURNAL_CORRUPT,JOURNAL_TOO_LARGE,JOURNAL_PENDING,JOURNAL_BUSY } journal_status;
typedef struct {
    journal_store store;
    uint32_t slot_bytes,generation,length,payload_crc;
    uint8_t slot,valid,ready;
} journal;
/* Bounded by4096 payload bytes,64byte transfer chunks; schedule these operations
 * as background work. Two alternating slots preserve the previous generation. */
journal_status journal_open(journal *,const journal_store *,uint32_t slot_bytes);
journal_status journal_load(journal *,void *out,size_t capacity,size_t *length);
journal_status journal_save(journal *,const void *payload,size_t length);
/* Cooperative equivalents for an asynchronous scoped store. Only these APIs
 * accept -1=pending callbacks. One step performs <=one64-byte read/write or
 * one sync; IO failure ends the job without retry. Borrowed payload/output
 * remains valid until completion. Zero-initialize job before first use; begin
 * refuses active jobs. Serialize all jobs using a journal/store. Previous
 * valid generation remains untouched.
 * Completion stores status in result; ready/valid journal fields change only
 * after all required barriers and readback succeed. */
typedef struct {
 journal *target;
 uint8_t *output;
 const uint8_t *payload;
 size_t *output_length;
 uint32_t pos,crc,length,generation,expected_crc;
 uint32_t slot_generation[2],slot_length[2],slot_crc[2];
 uint8_t phase,slot,slot_valid[2],active,operation;
 uint8_t header[32],chunk[64];
 journal_status result;
} journal_job;
journal_status journal_open_begin(journal_job *,journal *,const journal_store *,uint32_t slot_bytes);
journal_status journal_load_begin(journal_job *,journal *,void *,size_t,size_t *);
journal_status journal_save_begin(journal_job *,journal *,const void *,size_t);
/* JOURNAL_PENDING is a job scheduling status, never a failed operation retry. */
journal_status journal_step(journal_job *);
#endif
