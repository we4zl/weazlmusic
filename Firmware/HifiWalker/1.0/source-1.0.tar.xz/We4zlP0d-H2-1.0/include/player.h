#ifndef WEAZL_PLAYER_H
#define WEAZL_PLAYER_H

#include <stddef.h>

typedef enum {
    PLAYER_STOPPED,
    PLAYER_PLAYING,
    PLAYER_PAUSED
} player_state;

typedef enum {
    PLAYER_REPEAT_OFF,
    PLAYER_REPEAT_ALL,
    PLAYER_REPEAT_ONE
} player_repeat;

/* Tracks and strings remain owned by the caller and must outlive the player.
 * The caller must provide count valid, non-null track names. No audio or file
 * operations are performed here; a hardware/backend layer observes this state.
 */
typedef struct {
    const char *const *tracks;
    size_t count;
    size_t selected;
    player_state state;
    player_repeat repeat;
} player;

void player_init(player *p, const char *const *tracks, size_t count);
const char *player_current(const player *p);
void player_toggle(player *p);
void player_stop(player *p);
/* Manual navigation wraps and preserves play/pause/stop state. */
void player_next(player *p);
void player_previous(player *p);
void player_set_repeat(player *p, player_repeat repeat);
/* Notify once when the currently playing track finishes. */
void player_track_finished(player *p);

#endif
