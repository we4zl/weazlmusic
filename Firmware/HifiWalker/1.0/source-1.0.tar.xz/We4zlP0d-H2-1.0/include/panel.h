#ifndef WEAZL_PANEL_H
#define WEAZL_PANEL_H
#include <stdint.h>

/* Geometry recovered from supplied HIFIEC39, not confirmed on HW 1.1.7. */
#define PANEL_WIDTH 320
#define PANEL_HEIGHT 170
#define PANEL_Y_OFFSET 35
#define PANEL_WINDOW_OPS 11

typedef struct {
    uint8_t data; /* 0 = command, 1 = data byte */
    uint8_t value;
} panel_op;

/* Encode a rectangle as panel commands only. No MMIO, clocks, or GPIO.
 * Returns 1 on success; leaves out untouched for invalid/empty rectangles.
 * Caller provides at least PANEL_WINDOW_OPS entries. */
int panel_window(uint16_t x, uint16_t y, uint16_t width, uint16_t height,
                 panel_op out[PANEL_WINDOW_OPS]);
#endif
