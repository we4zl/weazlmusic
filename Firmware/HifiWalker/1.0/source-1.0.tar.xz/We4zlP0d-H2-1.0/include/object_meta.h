#ifndef WE4ZL_OBJECT_META_H
#define WE4ZL_OBJECT_META_H
#include "object_store.h"
#include "metadata_store.h"
typedef struct {
 metadata_store *store;unsigned object;uint32_t offset;size_t bytes;
 const void *buffer;uint8_t operation,failed;
} object_meta;
/* Adapter is exclusive owner of store.job until all catalog calls have
 * completed. Scheduler yield must service hardware, not metadata_job_step
 * concurrently. Never use in an IRQ/main foreground callback. */
object_io object_meta_backend(object_meta *,metadata_store *,void (*yield)(void *),void *scheduler);
#endif
