#ifndef WE4ZL_OVERLAY_H
#define WE4ZL_OVERLAY_H
#include <stddef.h>
#include <stdint.h>
#include "hash256.h"
/* Reviewed post-splash layout, NOT the installed bring-up layout. All addresses
 * supplied by the platform; portable code never dereferences fixed MMIO. */
#define OVERLAY_CODE_BYTES (88u*1024u)
#define OVERLAY_ARENA_BYTES (224u*1024u)
#define OVERLAY_SERVICE_BYTES (32u*1024u)
#define OVERLAY_STATIC_BYTES 2048u
#define OVERLAY_GUARD_BYTES 32u
#define OVERLAY_STACK_BYTES (32u*1024u)
#define OVERLAY_ABI 1u
#define OVERLAY_ENTRIES 8u
/* Digest is the SHA256 of code then initialized data. Metadata MUST be pinned
 * by the resident build (not trusted from an unverified filesystem header). */
typedef struct {
 uint32_t abi,code_bytes,data_bytes,bss_bytes,entry_count,entries[OVERLAY_ENTRIES];
 uint8_t sha256[32];
} overlay_spec;
typedef int (*overlay_read)(void *,uint32_t,void *,size_t); /* 1 ready, 0 fail, -1 pending */
typedef enum {OVERLAY_BOOT,OVERLAY_FREE,OVERLAY_LOADING,OVERLAY_READY,OVERLAY_BUSY,OVERLAY_FAILED} overlay_phase;
typedef struct {
 uint8_t *code,*arena,*stack;
 size_t code_capacity,arena_capacity,stack_capacity;
 overlay_spec spec;overlay_read read;void *context;
 hash256 digest;uint32_t offset,generation;
 overlay_phase phase;uint8_t *scratch,*services;size_t scratch_bytes,service_bytes;
} overlay;
int overlay_init(overlay *,void *code,size_t,void *arena,size_t,void *stack,size_t);
/* Caller certifies the last splash read is complete and display DMA no longer
 * references splash banks. No owner may read splash bytes after this handoff. */
int overlay_release_splash(overlay *,int final_read_complete,int display_idle);
int overlay_begin(overlay *,const overlay_spec *,overlay_read,void *);
int overlay_step(overlay *); /* <=512 source bytes, 1 done, 0 working, -1 failed */
int overlay_acquire(overlay *,uint32_t *generation);
int overlay_release(overlay *,uint32_t generation);
int overlay_entry(const overlay *,unsigned,uint32_t generation,uintptr_t *);
int overlay_can_read_splash(const overlay *);
#endif
