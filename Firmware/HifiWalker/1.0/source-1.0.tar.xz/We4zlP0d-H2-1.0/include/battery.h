#ifndef WEAZL_BATTERY_H
#define WEAZL_BATTERY_H
#include <stdint.h>
typedef enum { BATTERY_CHARGE_UNKNOWN, BATTERY_DISCHARGING, BATTERY_CHARGING, BATTERY_CHARGED } battery_charge;
typedef struct {
    uint32_t sampled_at;
    uint16_t millivolts;
    uint8_t valid, bars, low;
    battery_charge charge;
} battery_state;
void battery_init(battery_state *b);
/* Returns1 if a fresh sample was accepted,0 if rate-limited,-1 if invalid.
 * Only channel0 belongs here; foreign results are rejected without mutation. */
int battery_sample(battery_state *b,uint8_t channel,uint16_t raw,uint32_t now);
void battery_expire(battery_state *b,uint32_t now);
uint16_t battery_raw_millivolts(uint16_t raw);
#endif
