#ifndef WE4ZL_CATALOG_GROUP_H
#define WE4ZL_CATALOG_GROUP_H
#include "catalog.h"
/* Groups reuse persisted album/artist key indexes. No tag reads or RAM-sized
 * group directory. One step reads <=one cached key page or one record. Caller
 * owns a small cursor history if Back should revisit earlier group pages. */
typedef struct {
 catalog *catalog;uint32_t first,end,lo,hi,anchor;uint8_t prefix[CAT_KEY_BYTES];
 uint8_t prefix_bytes,phase;cat_status error;
 cat_record representative;
} cat_group;
/* first is any ordinal in the group (0 or previous group end for forward).
 * Album groups include artist, so equal album names by different artists remain
 * separate. Artist groups contain all albums/tracks for that artist. */
cat_status cat_group_begin(cat_group *,catalog *,uint32_t first);
cat_status cat_group_begin_prefix(cat_group *,catalog *,uint32_t first,unsigned prefix_bytes);
cat_status cat_group_step(cat_group *); /* CAT_OK working, CAT_END completed */
#endif
