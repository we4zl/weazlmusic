#ifndef WE4ZL_PLAYLIST_QUEUE_H
#define WE4ZL_PLAYLIST_QUEUE_H
#include "catalog_query.h"
#include "playlist_store.h"
#define PLAYLIST_QUEUE_PAGE 4u
typedef enum {
  PQUEUE_CLOSED,
  PQUEUE_READY,
  PQUEUE_PENDING,
  PQUEUE_FOUND,
  PQUEUE_MISSING,
  PQUEUE_END,
  PQUEUE_ERROR,
  PQUEUE_BUSY
} playlist_queue_status;
typedef struct {
  void *context;
  /* Required exclusive playlist-store/edit AND catalog-generation lease.
   * 1 acquired,0 busy,-1 terminal. No allocation or device activity here. */
  int (*acquire)(void *);
  void (*release)(void *);
} playlist_queue_hooks;
typedef struct {
  playlist_store *store;
  catalog *catalog;
  cat_record *record;
  playlist_queue_hooks hooks;
  stored_playlist list;
  stored_playlist_item items[PLAYLIST_QUEUE_PAGE];
  cat_query query;
  uint64_t requested_id, volume_id;
  uint32_t generation, catalog_generation, catalog_count, ordinal, page_first;
  unsigned dictionary, index;
  uint8_t phase, owned, closing, failed, page_count, slot;
  playlist_queue_status status;
} playlist_queue;
/* Zero-init queue once. BeginID finds the actual descriptor incrementally,
 * <=32 directory slots. generation must equal known current store generation.
 * No fixture, stale UI descriptor, entire playlist, extra sectorbuffer or
 * directory workspace is retained. record is borrowed EXCLUSIVELY until close;
 * must not overlap queue/store/catalog or their IO buffers/workspaces. Caller
 * serialization/lease must prevent any other store operation/edit, catalog
 * replacement and borrowed-record use, including playback marker publication.
 * Root's object/storage continuation owns callbacks; do not invoke from IRQ/UI.
 */
playlist_queue_status playlist_queue_begin(playlist_queue *, playlist_store *,
                                           catalog *, uint64_t playlist_id,
                                           uint32_t generation, cat_record *,
                                           playlist_queue_hooks);
/* Begin/step one ordinal; no interleaving reads or different outputbuffer.
 * FOUND publishes borrowedrecord, MISSING means ID absent from available pinned
 * catalog, ERROR means unavailable/corrupt/generation change (never missing).
 * Duplicates/order preserved; caller owns repeat/shuffle/skipmissing policy. */
playlist_queue_status playlist_queue_read(playlist_queue *, uint32_t ordinal);
playlist_queue_status playlist_queue_step(playlist_queue *);
/* Accepted store IO must drain before lease/borrowedrecord release. No abort,
 * automatic retries, writes or formatting. Close invalidates prior record. */
playlist_queue_status playlist_queue_close(playlist_queue *);
#endif
