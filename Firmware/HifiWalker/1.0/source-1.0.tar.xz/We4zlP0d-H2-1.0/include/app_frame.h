#ifndef WE4ZL_APP_FRAME_H
#define WE4ZL_APP_FRAME_H
#include "app.h"
#include "playlist_browser.h"
typedef struct {
 union {app application;struct {ui_state ui;playlist_view view;} playlists;struct {ui_state ui;playlist_browser browser;const char *message;} browser;} snapshot;
 uint32_t revision;uint8_t playlist,valid;
} app_frame;
/* Main captures only between worker resumptions. All index generations and
 * playlist source state remain pinned until frame completion. This is a bounded
 * UI snapshot, never a480x222 framebuffer or an active service copy. */
int app_frame_capture(app_frame *,const app *);
int app_frame_capture_browser(app_frame *,const app *,const playlist_browser *,const char *);
int app_frame_capture_message(app_frame *,const app *,const char *);
int app_frame_row(const app_frame *,unsigned y,uint8_t *,size_t);
#endif
