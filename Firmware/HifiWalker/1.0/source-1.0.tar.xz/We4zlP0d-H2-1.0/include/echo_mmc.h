#ifndef WEAZL_ECHO_MMC_H
#define WEAZL_ECHO_MMC_H
#include <stdint.h>
/* Experimental original F4402E HAL with restricted user-volume writes. No target execution is authorized
 * by this API. Exact evidence: research/post-mvp-storage-contract.md. */
typedef struct {
    uint32_t (*read32)(void *,uint32_t);
    void (*write32)(void *,uint32_t,uint32_t);
    uint32_t (*millis)(void *);
    void *context;
} echo_mmc_io;
typedef enum { EMMC_PROGRESS,EMMC_READY,EMMC_READ_DONE,EMMC_ARGUMENT,
    EMMC_UNSUPPORTED_CLOCK,EMMC_IRQ_OWNERSHIP,EMMC_TIMEOUT,EMMC_CARD_ERROR,
    EMMC_UNSUPPORTED_CARD,EMMC_BOUNDS,EMMC_BAD_STATE,EMMC_WRITE_DONE,
    EMMC_WRITE_PROTECTED,EMMC_VOLUME_UNPROVEN,EMMC_CACHE_UNSUPPORTED } echo_mmc_result;
typedef struct {
    echo_mmc_io io;
    uint32_t phase_started,command_started,ocr_started,flags,argument,response[4];
    uint32_t capacity,read_lba,clock_hz,phase_steps;
    uint16_t phase,command_state,words,ocr_attempts;
    uint8_t command_done,data_done,data_command,command_active,fast_clock;
    uint8_t initialized,reading,writing,volume_proof,write_protected;
    const uint8_t *source;
    echo_mmc_result result;
    uint8_t *destination;
    uint8_t ext_csd[512];
} echo_mmc;
/* Zeroes state, samples known Loader48MHz/stock150MHz guard and vector19/externalIRQ3 disabled BEFORE any
 * MMIO write. All writes remain user-volume-independent card/controller setup.
 * step must be serviced frequently; each call transfers at most16FIFO words.
 * No CPU IRQ handlers/DMA/stock helpers, unscoped storage writes, abort/reset-on-error
 * or retry. Peripheral IRQ generation follows stock; vector19/externalIRQ3 stays disabled.
 * An error latches; use physical reset to establish a fresh initialization. */
echo_mmc_result echo_mmc_init(echo_mmc *,const echo_mmc_io *);
echo_mmc_result echo_mmc_step(echo_mmc *);
/* Physical sector,512byte read only; caller supplies a verified user-volume
 * range adapter before exposing files/USB. Destination stays valid until done. */
echo_mmc_result echo_mmc_read(echo_mmc *,uint32_t physical_sector,uint8_t destination[512]);
/* Restricted single-sector CMD24. Offset is USER-relative, never physical.
 * Requires successful reads by THIS initialization of exact measured MBR at
 *581632 and BPB at581696, cache-disabled supported EXT_CSD/user partition,
 * unprotected CSD and CMD13 readiness/error check before and after writing.
 * Rejects unsupported/unknown state before CMD24/FIFO writes. Source must remain
 * valid until WRITE_DONE. No CMD25, retry, cache-toggle, guessed flush or abort.
 * Local model evidence does not authorize physical execution. */
echo_mmc_result echo_mmc_write_user(echo_mmc *,uint32_t user_sector,const uint8_t source[512]);
/* Cache-disabled sync is a bounded CMD13 readiness/error check; never sends a
 * guessed FLUSH_CACHE. Same profile/volume/write-protection gates apply. */
echo_mmc_result echo_mmc_sync_user(echo_mmc *);
#endif
