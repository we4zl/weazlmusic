#ifndef WE4ZL_OBJECT_STORE_H
#define WE4ZL_OBJECT_STORE_H
#include "catalog.h"
#define OBJECT_STORE_COUNT 16u
#define OBJECT_STORE_PREFIX 1024u
/* Scoped preallocated metadata files, not raw sectors. Callbacks return1 ready,
 * -1 pending (same parameters retried after yield),0 terminal failure. */
typedef struct {
 void *context;
 int (*capacity)(void *,unsigned,uint32_t *);
 int (*read)(void *,unsigned,uint32_t,void *,size_t);
 int (*write)(void *,unsigned,uint32_t,const void *,size_t);
 int (*sync)(void *);
 /* Required even for synchronous media: yields between bounded storage jobs.
  * On target this must suspend a BACKGROUND worker with its OWN stack; it must
  * never spin inside the main input/audio service loop or reuse codec PSP. */
 void (*yield)(void *);void *scheduler;
} object_io;
typedef struct {
 object_io io;uint32_t present,writable;
 uint32_t capacity[16],length[16],generation[16];
 uint8_t slot[16],dirty[16],failed;
} object_store;
cat_status object_store_open(object_store *,object_io,uint32_t required,uint32_t writable);
/* Caller has proved this object is disposable and not referenced by the live
 * generation manifest. Bytes need not be erased; committed logical EOF is0. */
cat_status object_store_reset(object_store *,unsigned);
cat_store object_catalog_backend(object_store *);
#endif
