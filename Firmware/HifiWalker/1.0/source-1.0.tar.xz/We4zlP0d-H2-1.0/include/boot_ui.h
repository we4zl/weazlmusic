#ifndef WEAZL_BOOT_UI_H
#define WEAZL_BOOT_UI_H
#include <stdint.h>
/* Portable cooperative scheduler. Each caller step renders at most one row.
 * Pending/ready/failed are real initialization results, never a progress timer. */
typedef enum { BOOT_PENDING, BOOT_READY, BOOT_FAILED } boot_readiness;
typedef enum { BOOT_SPLASH, BOOT_UI, BOOT_ERROR } boot_phase;
typedef struct {
    uint32_t started, visible_at, frames, cycles;
    uint16_t row, frame;
    uint8_t visible, phase, error;
} boot_ui;
void boot_ui_init(boot_ui *boot, uint32_t now);
/* Call before each cooperative row. Return1 if the next row may be rendered. */
int boot_ui_step(boot_ui *boot, uint32_t now, boot_readiness readiness);
void boot_ui_row_done(boot_ui *boot, uint32_t now);
#endif
