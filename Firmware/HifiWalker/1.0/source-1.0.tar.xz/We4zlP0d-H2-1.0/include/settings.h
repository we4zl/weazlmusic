#ifndef WE4ZL_SETTINGS_H
#define WE4ZL_SETTINGS_H
#include "eq.h"
#include "journal.h"
#define SETTINGS_BYTES 32u
typedef struct {
  uint16_t volume_q15, display_timeout_s;
  uint8_t brightness, repeat, shuffle;
  eq_config equalizer;
  /* Last actual backend publication, never an autoplay request or fixture.
   * Invalid requires canonicalzero ID/position; resolve stableID in real
   * catalog. */
  uint64_t resume_id;
  uint32_t resume_position_ms;
  uint8_t resume_valid;
} player_settings;
typedef enum {
  SETTINGS_DEFAULTS,
  SETTINGS_READY,
  SETTINGS_BUSY,
  SETTINGS_CORRUPT,
  SETTINGS_IO
} settings_status;
typedef struct {
  journal log;
  journal_job job;
  player_settings current, pending;
  uint8_t bytes[SETTINGS_BYTES], operation, writable;
  size_t loaded;
  settings_status status;
} settings;
void settings_defaults(player_settings *);
int settings_valid(const player_settings *);
int settings_encode(const player_settings *, uint8_t out[SETTINGS_BYTES]);
int settings_decode(player_settings *, const uint8_t in[SETTINGS_BYTES]);
/* Encoder writes v2. Decoder accepts canonicalv1(noresume) orv2, never guesses
 * missing bytes; caller must verify actual payloadlength SETTINGS_BYTES. */
/* Actual versioned alternating journal; store must supply a proven metadata
 * backend and truthful durable barrier. Defaults alone do not claim
 * persistence. Zero-initialize settings before first open. Keep it alive
 * through pending IO. */
settings_status settings_open(settings *, const journal_store *,
                              uint32_t slot_bytes);
/* writable defaults1 after open. Platform may set0 during read-only startup
 * verification; this defers saves without discarding dirty UI changes. */
settings_status settings_save(settings *, const player_settings *);
settings_status settings_step(settings *); /*<=one64B storage operation*/
#endif
