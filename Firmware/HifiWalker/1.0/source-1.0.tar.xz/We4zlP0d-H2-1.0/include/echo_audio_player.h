#ifndef WE4ZL_ECHO_AUDIO_PLAYER_H
#define WE4ZL_ECHO_AUDIO_PLAYER_H
#include "echo_audio.h"
#include "audio_stream.h"
/* Mini stock uses GPIO2.0 for the audio selector. Full-size ECHO uses GPIO2.1. */
#ifdef WXP_MINI_ROUTE
#define ECHO_ROUTE_PIN (1u << 0)
#define ECHO_ROUTE_MUX 0x00030000u
#else
#define ECHO_ROUTE_PIN (1u << 1)
#define ECHO_ROUTE_MUX 0x000c0000u
#endif
#define ECHO_ROUTE_MASK (0x4000u | ECHO_ROUTE_PIN)
#define ECHO_PLAYER_FRAMES 128u
#if defined(WXP_ECHO_MINI) && WXP_MINI_REVISION >= 29
#define ECHO_MINI_RADIO_LEVEL 0x20u
#endif
#define ECHO_PLAYER_SLOTS 4u
typedef enum { ECHO_PLAYER_IDLE,ECHO_PLAYER_POWER,ECHO_PLAYER_I2C,
 ECHO_PLAYER_DAC,ECHO_PLAYER_RATE,ECHO_PLAYER_I2S,ECHO_PLAYER_PRIME,ECHO_PLAYER_READY,
 ECHO_PLAYER_LEVEL,ECHO_PLAYER_RUNNING,ECHO_PLAYER_TAIL,ECHO_PLAYER_MUTING,
 ECHO_PLAYER_STOPPED,ECHO_PLAYER_FAULT_MUTING,ECHO_PLAYER_FAULT,ECHO_PLAYER_PAUSED,
 ECHO_PLAYER_RATE_SETTLE,ECHO_PLAYER_READBACK,ECHO_PLAYER_FILTER,ECHO_PLAYER_GAIN } echo_player_state;
enum { ECHO_DAC_FILTER_COUNT = 5 };
typedef struct {
 echo_audio_io hardware;
 /* Must prove the returned DMA address refers to this exact storage for its
  * whole lifetime. Host tests explicitly map buffers; target adapter validates
  * accessible SRAM. Zero refuses. No hardcoded target music/PCM addresses. */
 uint32_t (*address_for)(void *,const void *,size_t);
 uint32_t apb_hz,rate;
 uint16_t channels;
 /* Optional IRQ mode: architecture-reviewed PRIMASK callbacks with compiler memory barriers; shared millis
  *must be IRQ safe. vector_entry must be the actual Thumb entry below in the
  *new image's vector22. Host tests provide an explicit mapped vector model. */
 uint32_t (*irq_save)(void *);
 void (*irq_restore)(void *,uint32_t);
 uint32_t (*millis)(void *);
 uint32_t vector_entry;
 /* Zero selects the original 300 kHz bus and quiet 0x78 DAC level. */
 uint16_t i2c_khz;
 uint8_t dac_level;
 uint8_t allow_rebuffer;
 uint8_t clock_before_dac, readback, test_duplicate_word;
 uint8_t dac_filter,dac_gain_high;
} echo_player_config;
typedef struct {
 echo_audio_power power;echo_audio_i2c i2c;echo_audio_dac dac;
 echo_audio_i2s i2s;echo_audio_dma dma;
 echo_player_config config;echo_audio_io io;
 uint32_t slots[ECHO_PLAYER_SLOTS][ECHO_PLAYER_FRAMES*2],addresses[ECHO_PLAYER_SLOTS];
 uint32_t tail_deadline,last_poll,max_poll_ms;
 volatile uint32_t completed_frames,empty_completions;
 uint16_t frames[ECHO_PLAYER_SLOTS];
 volatile uint8_t head,used,ending,irq_armed,irq_fault,irq_mask_failed;
 uint8_t job_phase,job_pending,poll_started,primed,filter_applied,gain_applied;
 /* Per DAC: power, volume B/A and serial channel selectors B/A. */
 uint8_t dac_values[2][5],readback_valid;
#if defined(WXP_ECHO_MINI) && WXP_MINI_REVISION == 16
 uint32_t dac_status_after;
 uint8_t dac_status[2][5],dac_status_sample;
#endif
 volatile uint8_t control;
 volatile echo_player_state state;
 echo_player_state fault_stage;
} echo_audio_player;
/* Pure conversion: normalized interleaved signed16, first slot LRCK-low,
 * second LRCK-high. Mono duplicates. Physical jack left/right needs acceptance.
 * No input/output overlap. Capacity is measured in32-bit slots. */
int echo_audio_pack16(uint32_t *,unsigned capacity,const int16_t *,unsigned frames,unsigned channels);
/* Only first use/externally proven reset. Live/fault contexts own DMA memory and
 * cannot be reinitialized as an implicit recovery or format change. */
void echo_audio_player_init(echo_audio_player *);
int echo_audio_player_begin(echo_audio_player *,const echo_player_config *,uint32_t now_ms);
echo_player_state echo_audio_player_step(echo_audio_player *,uint32_t now_ms);
/* audio_stream-compatible bounded copying sink. Accepts<=128 frames only into
 * a free slot; AGAIN/accepted0 preserves all caller PCM. Call step before decode
 * or rendering to prioritize completions. No hardware underrun claim from these
 * counters; sub-ms polling/refill margins remain a physical performance gate. */
audio_status echo_audio_player_write(void *,const int16_t *,unsigned frames,unsigned *accepted);
/* End-of-stream only: accepts no more frames, drains both buffers, waits100ms
 * for final serial/filter tail, mutes then stops I2S. Same-format gapless next
 * tracks must remain in audio_stream and must NOT call finish between tracks. */
void echo_audio_player_finish(echo_audio_player *);
/* Pause completes the current DMA, retains queued PCM, waits the serial tail,
 *mutes and stops clocks. Resume restores the conservative level before playing.
 *Stop discards only CPU-owned queued buffers after active DMA releases; faults
 *remain quarantined. Caller must separately pause/stop its decoder producer. */
void echo_audio_player_pause(echo_audio_player *,int paused);
void echo_audio_player_stop(echo_audio_player *);
/* After STOPPED only: change supported rate/channels under established mute and
 *DMA-idle ownership, applying exact track reset/FS/serial setup. Never accepts a
 *FAULT/active context. Same-format gapless transitions do not use this API. */
int echo_audio_player_reformat(echo_audio_player *,uint32_t rate,unsigned channels);
/* Explicit opt-in at READY only. Verifies current own vector22, external NVIC
 *both banks empty, SysTick TICKINT clear, no pending system exceptions,
 *STKALIGN set, thread mode/unmasked priority, >=512B MSP room, DMA idle, and
 *DMA5_IRQ_OWNER. Clears/enables ONLY IRQ6, then unmasks global IRQs. Refusal
 *performs no NVIC writes and preserves PRIMASK. Must be reviewed with a NEW
 *startup/vector artifact; historical startup is not modified by this module. */
int echo_audio_player_arm_irq(echo_audio_player *);
/* Original IRQ entry: bounded RawTfr ACK/completion/requeue only, no codec,
 *storage, rendering, allocator, EQ, I2C or global DMA reset. */
void echo_audio_player_irq_entry(void);
/* Concrete Cortex-M3 adapter, disabled on host. Claims describe reviewed
 *application resource ownership, never physical feature acceptance. It reads
 *only proven register regions, refuses gated/reset buses, restricts writes to
 *the exact audio/IRQ masks, and maps ONLY this player's resident-RAM slots. */
enum { ECHO_TARGET_POWER_PINS=1,ECHO_TARGET_I2C0=2,ECHO_TARGET_I2S1=4,
       ECHO_TARGET_DMA5=8,ECHO_TARGET_IRQ6=16,ECHO_TARGET_BT_OUTPUT=32,
       ECHO_TARGET_WIRED_OUTPUT=64 };
typedef struct {
 echo_audio_player *player;
 void *time_context;
 uint32_t (*milliseconds)(void *);
 uint32_t claims;
 uint16_t bt_test_pins;
 uint8_t bt_test_active;
} echo_audio_target;
int echo_audio_player_target_config(echo_player_config *,echo_audio_target *,echo_audio_player *,uint32_t rate,unsigned channels);
#ifdef WXP_MINI_PCM_TAP
void echo_mini_pcm_arm(unsigned skip);
unsigned echo_mini_pcm_read(unsigned offset, uint8_t *data, unsigned length);
#endif
#endif
