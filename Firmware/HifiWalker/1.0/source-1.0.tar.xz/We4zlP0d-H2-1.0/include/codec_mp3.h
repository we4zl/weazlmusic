#ifndef WEAZL_CODEC_MP3_H
#define WEAZL_CODEC_MP3_H
#include "codec.h"
codec_status codec_mp3_open(codec *);
codec_status codec_mp3_read(codec *,int16_t *,size_t,size_t *);
void codec_mp3_close(codec *);
#endif
