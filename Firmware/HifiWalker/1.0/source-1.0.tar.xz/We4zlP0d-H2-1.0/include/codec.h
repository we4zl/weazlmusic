#ifndef WEAZL_CODEC_H
#define WEAZL_CODEC_H
#include "wav.h"
#ifndef CODEC_COOPERATIVE_PROGRESS
#define CODEC_COOPERATIVE_PROGRESS 0
#endif
#ifndef CODEC_FAULT_ON_ALLOC
#define CODEC_FAULT_ON_ALLOC 0
#endif
#ifndef CODEC_MP3_FIXED
#define CODEC_MP3_FIXED 1
#endif
#ifndef CODEC_ENABLE_FLAC
#define CODEC_ENABLE_FLAC 1
#endif
#ifndef CODEC_ENABLE_MP3
#define CODEC_ENABLE_MP3 1
#endif
#ifndef CODEC_ENABLE_AAC
#define CODEC_ENABLE_AAC 1
#endif
#ifndef CODEC_ENABLE_VORBIS
#define CODEC_ENABLE_VORBIS 1
#endif
#ifndef CODEC_ENABLE_OPUS
#define CODEC_ENABLE_OPUS 1
#endif
typedef enum { CODEC_FLAC, CODEC_MP3, CODEC_AAC_M4A, CODEC_OGG_OPUS, CODEC_OGG_VORBIS } codec_kind;
typedef enum { CODEC_OK, CODEC_END, CODEC_INVALID, CODEC_UNSUPPORTED, CODEC_MEMORY, CODEC_IO, CODEC_BUSY } codec_status;
typedef struct {
    uint32_t rate;
    uint16_t channels, bits;
    uint64_t total_frames;
    uint32_t delay_frames, padding_frames;
    uint8_t total_known, delay_known, padding_known, trimming_applied;
} codec_info;
typedef struct {
    wav_reader source;
    codec_info info;
    void *implementation;
    uint8_t *arena;
    size_t arena_size, arena_used, arena_peak;
    uint64_t position;
    codec_kind kind;
    codec_status status;
    uint8_t allocation_failed;
} codec;
/* Caller owns8-byte aligned arena throughout lifetime; no general heap.
 * FLAC: native16bit,mono/stereo,8..96kHz,max block4096; MP3 LayerIII8..48kHz.
 * AAC: nonfragmented M4A AAC-LC1024frame,AudioSampleEntryv0,one audio
 * track,one nonempty edit-list entry with known priming>=1024. No ADTS.
 * Calls are synchronous bounded-buffer work, not measured real-time deadlines.
 * Internal allocator owner makes concurrent/reentrant decoder calls unsupported. */
codec_status codec_open(codec *c,codec_kind kind,const wav_reader *source,void *arena,size_t bytes);
codec_status codec_read(codec *c,int16_t *pcm,size_t capacity_frames,size_t *frames);
/* FLAC seek uses upstream seektable/search, can require substantial reads.
 * MP3/AAC/Ogg precise seek is explicitly unsupported; no unbounded seek index. */
codec_status codec_seek(codec *c,uint64_t frame);
codec_status codec_reset(codec *c);
/* At decoded EOF only. Reuse Vorbis only when complete identification+setup
 * SHA256 matches. Mismatch/error leaves the old source/state unchanged; callers
 * must plan a cold-open handoff. No measured gapless/hardware timing claim. */
codec_status codec_next(codec *c,const wav_reader *next);
void codec_close(codec *c);
/* Only after the scheduler proves the owning worker cannot resume. Discard
 * partially constructed arena objects without invoking unsafe library cleanup. */
codec_status codec_abandon(codec *c);
#endif
