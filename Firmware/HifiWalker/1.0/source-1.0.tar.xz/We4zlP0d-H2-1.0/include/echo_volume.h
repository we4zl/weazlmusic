#ifndef WEAZL_ECHO_VOLUME_H
#define WEAZL_ECHO_VOLUME_H
#include "echo_mmc.h"
#include "block_cache.h"
#include "usb_music.h"
#define ECHO_USER_BASE 581632u
#define ECHO_USER_SECTORS 7151616u
/* Actual scoped bridge between original MMC HAL, shared block_cache, FAT,
 * metadata jobs and SCSI. No second cache or512B write copy is allocated.
 * All reads/writes exposed here are USER-relative. Init temporarily borrows
 * cache.page[0] as read-only MBR/BPB scratch before enabling normal readers.
 * Service only echo_volume_step; do not separately step its shared cache/HAL.
 * Async write source stays immutable until callback returns1 or0. */
typedef enum { ECHO_VOLUME_PROGRESS,ECHO_VOLUME_READY,ECHO_VOLUME_ERROR,
 ECHO_VOLUME_ARGUMENT,ECHO_VOLUME_BUSY } echo_volume_result;
typedef enum { ECHO_OWNER_NONE,ECHO_OWNER_FIRMWARE,ECHO_OWNER_USB,ECHO_OWNER_REMOUNT } echo_volume_owner;
typedef struct {
 echo_mmc *mmc;
 block_cache *cache;
 const uint8_t *source;
 uint32_t sector;
 uint8_t kind,complete,probe,failed,read_only;
 block_priority priority;
 echo_volume_owner owner;
} echo_volume;
echo_volume_result echo_volume_init(echo_volume *,echo_mmc *,block_cache *);
echo_volume_result echo_volume_step(echo_volume *);
/* Reacquire immutable geometry after a host session, with all readers stopped.
 * Reuses startup cache scratch; fail closed if MBR/BPB changed. */
echo_volume_result echo_volume_revalidate(echo_volume *);
/* Requires no active/pending backend operation, invalidates both cache banks.
 * Input is the actual usb_music owner after completed policy transitions.
 * REMOUNT permits only filesystem reads; writes need FIRMWARE or HOST owner. */
echo_volume_result echo_volume_switch_owner(echo_volume *,const usb_music *);
int echo_volume_fs_read(void *,uint32_t,uint8_t [512]);
int echo_volume_metadata_write(void *,uint32_t,const uint8_t [512]);
int echo_volume_metadata_sync(void *);
int echo_volume_usb_read(void *,uint32_t,uint8_t [512]);
int echo_volume_usb_write(void *,uint32_t,const uint8_t [512]);
int echo_volume_usb_sync(void *);
#endif
