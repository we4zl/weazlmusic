#ifndef WE4ZL_LIBRARY_VIEW_H
#define WE4ZL_LIBRARY_VIEW_H
#include "catalog.h"
#include "ui.h"
#define LIBRARY_VIEW_ROWS 2u
typedef struct {uint64_t id;char title[96],artist[64];} library_row;
typedef struct {
    uint32_t first,total,origin;uint8_t count,focus,valid;
    library_row rows[LIBRARY_VIEW_ROWS];
} library_page;
typedef struct {
    catalog *catalog;
    library_page visible,pending;
    uint32_t wanted,selected,range_first,range_end;uint64_t activation;
    uint8_t fetching,next_row,error;
} library_view;
void library_view_init(library_view *);
cat_status library_view_attach(library_view *,catalog *);
/* Service outside rendering/input: at most one indexed record per call. */
cat_status library_view_attach_range(library_view *,catalog *,uint32_t first,uint32_t end);
cat_status library_view_step(library_view *);
void library_view_move(library_view *,int direction);
/* O(1) direct selection, one bounded page scheduled. */
void library_view_select(library_view *,uint32_t ordinal);
void library_view_activate(library_view *);
uint64_t library_view_take_activation(library_view *);
/* Composes actual supplied catalog rows over the ordinary Library Songs pane.
 * Unattached view leaves the truthful unavailable UI unchanged. No fixture data. */
int library_view_render_pane(const library_view *,const ui_state *,const char *heading,unsigned y,uint8_t *,size_t);
int library_view_render(const library_view *,const ui_state *,unsigned y,uint8_t *,size_t);
#endif
