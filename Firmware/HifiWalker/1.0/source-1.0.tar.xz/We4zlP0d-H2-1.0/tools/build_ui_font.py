#!/usr/bin/env python3
"""Rasterize vendored OFL IBM Plex Mono; no system font lookup."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import argparse
import hashlib
import json

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mini', action='store_true')
    mini = parser.parse_args().mini
    output = Path('build/ui')
    output.mkdir(parents=True, exist_ok=True)
    fonts = [('small', 'IBMPlexMono-Regular.ttf', 12),
             ('body', 'IBMPlexMono-Regular.ttf', 16),
             ('title', 'IBMPlexMono-Bold.ttf', 22)]
    if mini:
        fonts = [(name, 'IBMPlexMono-Bold.ttf', pixels)
                 for name, pixels in [('small', 12), ('body', 16), ('title', 19)]]
    lines = ['/* Generated from assets/fonts; see OFL license there. */',
             'typedef struct { unsigned height; const uint8_t *advance; const uint32_t *rows; } ui_font;']
    manifest = {}
    for name, filename, size in fonts:
        path = Path('assets/fonts') / filename
        font = ImageFont.truetype(str(path), size)
        height = size + 5
        advances, rows = [], []
        for code in range(32, 127):
            glyph = Image.new('L', (32, height))
            ImageDraw.Draw(glyph).text((0, size), chr(code), font=font, fill=255, anchor='ls')
            advance = max(1, round(font.getlength(chr(code))))
            assert advance < 32
            advances.append(advance)
            for y in range(height):
                rows.append(sum((1 << x) for x in range(advance) if glyph.getpixel((x, y)) >= 100))
        lines += [f'static const uint8_t {name}_advance[] = {{'+','.join(map(str, advances))+'};',
                  f'static const uint32_t {name}_rows[] = {{'+','.join(hex(v) for v in rows)+'};',
                  f'static const ui_font font_{name} = {{{height}, {name}_advance, {name}_rows}};']
        manifest[filename] = hashlib.sha256(path.read_bytes()).hexdigest()
    header = ('\n'.join(lines)+'\n').encode()
    (output/'ui_font.h').write_bytes(header)
    (output/'font-manifest.json').write_text(json.dumps({'sources': manifest, 'header_sha256': hashlib.sha256(header).hexdigest()}, indent=2)+'\n')

if __name__ == '__main__':
    main()
