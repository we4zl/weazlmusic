#!/usr/bin/env python3
"""Reproduce actual codec builds and full-track comparisons without device access.
Default caller arena remains224KiB. --arena-kib240 is a separately labeled
post-splash memory profile, never an implicit target/linker change.
Requires existing cc,clang,llvm tools,FFmpeg,and NumPy. No installation/config writes.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import argparse,hashlib,json,subprocess,time,os,shutil
ROOT=Path(__file__).resolve().parents[1]
HARNESS='#include "codec.h"\n#include <stdio.h>\n#include <stdlib.h>\n#include <string.h>\n#include <inttypes.h>\nstatic int read_at(void *ctx,size_t at,uint8_t *out,size_t n)\n{FILE *f=ctx;return fseek(f,(long)at,SEEK_SET)==0 && fread(out,1,n,f)==n;}\nstatic _Alignas(8) unsigned char arena[224*1024];\nint main(int argc,char **argv)\n{\n    if(argc!=3)return 2; FILE *f=fopen(argv[2],"rb");if(!f)return 3;\n    fseek(f,0,SEEK_END);long size=ftell(f);if(size<0)return 4;\n    wav_reader r={read_at,f,(size_t)size};codec c;\n    codec_status s=codec_open(&c,!strcmp(argv[1],"flac")?CODEC_FLAC:!strcmp(argv[1],"aac")?CODEC_AAC_M4A:!strcmp(argv[1],"opus")?CODEC_OGG_OPUS:!strcmp(argv[1],"vorbis")?CODEC_OGG_VORBIS:CODEC_MP3,&r,arena,sizeof(arena));\n    if(s!=CODEC_OK){fprintf(stderr,"open:%d peak:%zu\\n",s,c.arena_peak);return 5;}\n    int16_t pcm[2048];uint64_t frames=0;\n    while(s==CODEC_OK) {\n        size_t n=0;s=codec_read(&c,pcm,1024,&n);\n        if(fwrite(pcm,sizeof(int16_t)*c.info.channels,n,stdout)!=n)return 6; frames+=n;\n    }\n    fprintf(stderr,"{\\"frames\\":%" PRIu64 ",\\"rate\\":%u,\\"channels\\":%u,\\"expected_frames\\":%" PRIu64 ",\\"total_known\\":%u,\\"delay_frames\\":%u,\\"delay_known\\":%u,\\"trimming_applied\\":%u,\\"arena_peak\\":%zu,\\"status\\":%d}\\n",frames,c.info.rate,c.info.channels,c.info.total_frames,c.info.total_known,c.info.delay_frames,c.info.delay_known,c.info.trimming_applied,c.arena_peak,s);\n    codec_close(&c);fclose(f);return s==CODEC_END?0:7;\n}\n'
HARNESS=HARNESS.replace('int main(', 'void codec_runtime_checkpoint(void){}\nint main(')
HARNESS=HARNESS.replace('int main(', '_Noreturn void codec_runtime_fault(unsigned reason){fprintf(stderr,"codec fault:%u\\n",reason);exit(80+(int)reason); }\nint main(')
OPUS=['src/opus.c', 'src/opus_decoder.c', 'src/opus_encoder.c', 'src/extensions.c', 'src/opus_multistream.c', 'src/opus_multistream_encoder.c', 'src/opus_multistream_decoder.c', 'src/repacketizer.c', 'src/opus_projection_encoder.c', 'src/opus_projection_decoder.c', 'src/mapping_matrix.c', 'celt/bands.c', 'celt/celt.c', 'celt/celt_encoder.c', 'celt/celt_decoder.c', 'celt/cwrs.c', 'celt/entcode.c', 'celt/entdec.c', 'celt/entenc.c', 'celt/kiss_fft.c', 'celt/laplace.c', 'celt/mathops.c', 'celt/mdct.c', 'celt/mdct_pfa.c', 'celt/modes.c', 'celt/pitch.c', 'celt/celt_lpc.c', 'celt/quant_bands.c', 'celt/rate.c', 'celt/vq.c', 'celt/celt_tx_tables.c', 'silk/CNG.c', 'silk/code_signs.c', 'silk/init_decoder.c', 'silk/decode_core.c', 'silk/decode_frame.c', 'silk/decode_parameters.c', 'silk/decode_indices.c', 'silk/decode_pulses.c', 'silk/decoder_set_fs.c', 'silk/dec_API.c', 'silk/enc_API.c', 'silk/encode_indices.c', 'silk/encode_pulses.c', 'silk/gain_quant.c', 'silk/interpolate.c', 'silk/LP_variable_cutoff.c', 'silk/NLSF_decode.c', 'silk/NSQ.c', 'silk/NSQ_del_dec.c', 'silk/PLC.c', 'silk/shell_coder.c', 'silk/tables_gain.c', 'silk/tables_LTP.c', 'silk/tables_NLSF_CB_NB_MB.c', 'silk/tables_NLSF_CB_WB.c', 'silk/tables_other.c', 'silk/tables_pitch_lag.c', 'silk/tables_pulses_per_block.c', 'silk/VAD.c', 'silk/control_audio_bandwidth.c', 'silk/quant_LTP_gains.c', 'silk/VQ_WMat_EC.c', 'silk/HP_variable_cutoff.c', 'silk/NLSF_encode.c', 'silk/NLSF_VQ.c', 'silk/NLSF_unpack.c', 'silk/NLSF_del_dec_quant.c', 'silk/process_NLSFs.c', 'silk/stereo_LR_to_MS.c', 'silk/stereo_MS_to_LR.c', 'silk/check_control_input.c', 'silk/control_SNR.c', 'silk/init_encoder.c', 'silk/control_codec.c', 'silk/A2NLSF.c', 'silk/ana_filt_bank_1.c', 'silk/biquad_alt.c', 'silk/bwexpander_32.c', 'silk/bwexpander.c', 'silk/debug.c', 'silk/decode_pitch.c', 'silk/inner_prod_aligned.c', 'silk/lin2log.c', 'silk/log2lin.c', 'silk/LPC_analysis_filter.c', 'silk/LPC_inv_pred_gain.c', 'silk/table_LSF_cos.c', 'silk/NLSF2A.c', 'silk/NLSF_stabilize.c', 'silk/NLSF_VQ_weights_laroia.c', 'silk/pitch_est_tables.c', 'silk/resampler.c', 'silk/resampler_down2_3.c', 'silk/resampler_down2.c', 'silk/resampler_private_AR2.c', 'silk/resampler_private_down_FIR.c', 'silk/resampler_private_IIR_FIR.c', 'silk/resampler_private_up2_HQ.c', 'silk/resampler_rom.c', 'silk/sigm_Q15.c', 'silk/sort.c', 'silk/sum_sqr_shift.c', 'silk/stereo_decode_pred.c', 'silk/stereo_encode_pred.c', 'silk/stereo_find_predictor.c', 'silk/stereo_quant_pred.c', 'silk/LPC_fit.c', 'silk/fixed/LTP_analysis_filter_FIX.c', 'silk/fixed/LTP_scale_ctrl_FIX.c', 'silk/fixed/corrMatrix_FIX.c', 'silk/fixed/encode_frame_FIX.c', 'silk/fixed/find_LPC_FIX.c', 'silk/fixed/find_LTP_FIX.c', 'silk/fixed/find_pitch_lags_FIX.c', 'silk/fixed/find_pred_coefs_FIX.c', 'silk/fixed/noise_shape_analysis_FIX.c', 'silk/fixed/process_gains_FIX.c', 'silk/fixed/regularize_correlations_FIX.c', 'silk/fixed/residual_energy16_FIX.c', 'silk/fixed/residual_energy_FIX.c', 'silk/fixed/warped_autocorrelation_FIX.c', 'silk/fixed/apply_sine_window_FIX.c', 'silk/fixed/autocorr_FIX.c', 'silk/fixed/burg_modified_FIX.c', 'silk/fixed/k2a_FIX.c', 'silk/fixed/k2a_Q16_FIX.c', 'silk/fixed/pitch_analysis_core_FIX.c', 'silk/fixed/vector_ops_FIX.c', 'silk/fixed/schur64_FIX.c', 'silk/fixed/schur_FIX.c']
VORBIS=['third_party/tremor/mdct.c', 'third_party/tremor/block.c', 'third_party/tremor/window.c', 'third_party/tremor/synthesis.c', 'third_party/tremor/info.c', 'third_party/tremor/floor1.c', 'third_party/tremor/floor0.c', 'third_party/tremor/vorbisfile.c', 'third_party/tremor/res012.c', 'third_party/tremor/mapping0.c', 'third_party/tremor/registry.c', 'third_party/tremor/codebook.c', 'third_party/tremor/sharedbook.c', 'third_party/ogg/src/bitwise.c', 'third_party/ogg/src/framing.c']
SHIMS={'stdlib.h': '#ifndef WEAZL_FEASIBILITY_STDLIB_H\n#define WEAZL_FEASIBILITY_STDLIB_H\n#include <stddef.h>\nvoid *malloc(size_t); void *realloc(void *,size_t); void free(void *); int abs(int); void abort(void); void *calloc(size_t,size_t);long labs(long); long long llabs(long long);int rand(void); void qsort(void *,size_t,size_t,int (*)(const void *,const void *));\n\n#endif\n', 'string.h': '#ifndef WEAZL_FEASIBILITY_STRING_H\n#define WEAZL_FEASIBILITY_STRING_H\n#include <stddef.h>\nvoid *memcpy(void *,const void *,size_t); void *memmove(void *,const void *,size_t); void *memset(void *,int,size_t); int memcmp(const void *,const void *,size_t); size_t strlen(const char *);\n\nchar *strcpy(char *,const char *);char *strcat(char *,const char *);void *memchr(const void *,int,size_t);\n#endif\n', 'assert.h': '#define assert(x) ((void)0)\n', 'math.h': '#ifndef WEAZL_FEASIBILITY_MATH_H\n#define WEAZL_FEASIBILITY_MATH_H\n#define M_PI 3.14159265358979323846\n#define HUGE_VAL (__builtin_huge_val())\ndouble sqrt(double); double sin(double); double cos(double); double acos(double); double atan(double); double atan2(double,double); double exp(double); double log(double); double log10(double); double pow(double,double); double floor(double); double ceil(double); double fabs(double); double ldexp(double,int); double frexp(double,int *);\nfloat sqrtf(float);float sinf(float);float cosf(float);float expf(float);float logf(float);float powf(float,float);float floorf(float);float ceilf(float);float fabsf(float);long lrintf(float);long lrint(double);\n#endif\n', 'stdio.h': '#ifndef WEAZL_FEASIBILITY_STDIO_H\n#define WEAZL_FEASIBILITY_STDIO_H\n#include <stddef.h>\ntypedef struct weazl_feasibility_FILE FILE;\nextern FILE *stderr;\n#define SEEK_SET 0\n#define SEEK_CUR 1\n#define SEEK_END 2\n#define EOF (-1)\nint sprintf(char *,const char *,...);int printf(const char *,...);int fprintf(FILE *,const char *,...);int snprintf(char *,size_t,const char *,...);int puts(const char *);int fclose(FILE *);int fseek(FILE *,long,int);long ftell(FILE *);size_t fread(void *,size_t,size_t,FILE *);FILE *fopen(const char *,const char *);\n#endif\n', 'errno.h': 'extern int errno;\n#define EINVAL 22\n#define EIO 5\n#define EAGAIN 11\n', 'ogg/config_types.h': '#include <stdint.h>\ntypedef int16_t ogg_int16_t; typedef uint16_t ogg_uint16_t;\ntypedef int32_t ogg_int32_t; typedef uint32_t ogg_uint32_t;\ntypedef int64_t ogg_int64_t; typedef uint64_t ogg_uint64_t;\n'}
WRAPPERS=['src/hash256.c','src/codec_mp3.c','src/codec.c','src/codec_m4a.c','src/codec_ogg.c','src/codec_vorbis.c']
SAN=['-fsanitize=address,undefined','-fno-omit-frame-pointer']

def run(cmd,**kw):
    return subprocess.run([str(x) for x in cmd],check=True,cwd=ROOT,**kw)
def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block)
    return h.hexdigest()
def units():
    aac=['-DWEAZL_ARENA_SCRATCH','-DFIXED_POINT','-DLC_ONLY_DECODER','-DDISABLE_SBR','-DHAVE_STDINT_H=1','-DHAVE_MEMCPY=1','-DHAVE_STRING_H=1','-DPACKAGE_VERSION="pinned-analysis"','-Dmalloc=codec_library_malloc','-Dfree=codec_library_free','-Ithird_party/faad2/include','-Ithird_party/faad2/libfaad']
    opus=['-include','include/codec_opus_config.h','-DFIXED_POINT','-DOPUS_BUILD','-DDISABLE_FLOAT_API','-DNONTHREADSAFE_PSEUDOSTACK','-DENABLE_HARDENING','-DPACKAGE_VERSION="pinned-analysis"','-Dmalloc=codec_library_malloc','-Dfree=codec_library_free']+['-Ithird_party/opus/'+p for p in ['include','celt','silk','silk/fixed','src','.']]
    vorbis=['-DVAR_ARRAYS','-Dmalloc=codec_library_malloc','-Dcalloc=codec_library_calloc','-Drealloc=codec_library_realloc','-Dfree=codec_library_free','-Ithird_party/tremor','-Ithird_party/ogg/include']
    mad=['-fwrapv','-DFPM_64BIT','-DOPT_SPEED','-DHAVE_ASSERT_H','-DNDEBUG','-Dmalloc=codec_library_malloc','-Dcalloc=codec_library_calloc','-Dfree=codec_library_free']
    return [(p,mad) for p in ['third_party/libmad/bit.c','third_party/libmad/fixed.c','third_party/libmad/frame.c','third_party/libmad/huffman.c','third_party/libmad/layer12.c','third_party/libmad/layer3.c','third_party/libmad/stream.c','third_party/libmad/synth.c','third_party/libmad/timer.c']]+[(str(p.relative_to(ROOT)),aac) for p in sorted((ROOT/'third_party/faad2/libfaad').glob('*.c'))]+[('third_party/opus/'+p,opus) for p in OPUS]+[(p,vorbis) for p in VORBIS]+[(p,['-DFPM_64BIT','-DOPT_SPEED'] if p=='src/codec_mp3.c' else ['-DCODEC_FAULT_ON_ALLOC=1','-DCODEC_COOPERATIVE_PROGRESS=1'] if p=='src/codec.c' else []) for p in WRAPPERS]
def compile_units(out,arm=False,cache=None):
    dest=out/('arm' if arm else 'host');dest.mkdir(exist_ok=True)
    if arm:
        shim=dest/'shim'
        for file,text in SHIMS.items():
            p=shim/file;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
        base=['clang','--target=arm-none-eabi','-mcpu=cortex-m3','-mthumb','-Oz','-ffreestanding','-fno-builtin','-fstack-usage','-fdata-sections','-ffunction-sections','-I'+str(shim)]
    else:base=['cc','-O2','-g']+SAN
    def one(unit):
        source,flags=unit;obj=dest/(source.replace('/','_')+'.o')
        if cache and source in cache and all(flag in cache[source]['command'] for flag in flags):
            record=cache[source]
            if digest(ROOT/record['object'])!=record['object_sha256']:raise RuntimeError('cached object changed')
            shutil.copy2(ROOT/record['object'],obj)
            return {'source':source,'source_sha256':digest(ROOT/source),'object':str(obj),'command':record['command'],'reused_from':record['object'],'object_sha256':digest(obj),'returncode':0,'stderr':''}
        cmd=([v if v!='-O2' or source not in WRAPPERS else '-O1' for v in base])+flags+['-Iinclude','-Ithird_party/ogg/include','-c',source,'-o',str(obj)]
        result=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True)
        return {'source':source,'source_sha256':digest(ROOT/source),'object':str(obj),'command':cmd,'returncode':result.returncode,'stderr':result.stderr}
    with ThreadPoolExecutor(max_workers=4) as pool:report=list(pool.map(one,units()))
    (dest/'compile.json').write_text(json.dumps(report,indent=2)+'\n')
    if any(x['returncode'] for x in report):raise RuntimeError('compile failure; inspect '+str(dest/'compile.json'))
    print(('ARM' if arm else 'host'),'compiled',len(report),'units',flush=True)
    return [x['object'] for x in report]
def arm_resources(out,objects):
    obj=out/'all-codecs-retained.o'
    roots=['codec_open','codec_read','codec_reset','codec_seek','codec_close','codec_abandon','codec_next']
    cmd=['ld.lld','-r','--gc-sections']
    for f in roots:cmd+=['-u',f]
    run(cmd+objects+['-o',obj])
    report={'arm_compile_directory':str(out/'arm'),'retained_object_sha256':digest(obj),'size_output':run(['llvm-size',obj],capture_output=True,text=True).stdout,'undefined_symbols':run(['llvm-nm','--undefined-only',obj],capture_output=True,text=True).stdout,'not_linked_target_firmware':True,'not_realtime_cycles':True}
    stack=[]
    for p in (out/'arm').glob('*.su'):
        for line in p.read_text().splitlines():
            fields=line.split('\t');stack.append({'function':fields[0],'bytes':int(fields[1]),'kind':fields[2]})
    report['stack_usage']=sorted(stack,key=lambda x:x['bytes'],reverse=True)
    (out/'arm-resources.json').write_text(json.dumps(report,indent=2)+'\n')
def compare(exe,kind,path,out):
    import numpy as np
    actual=out/'actual.s16le';reference=out/'reference.s16le';start=time.perf_counter()
    with actual.open('wb') as f:result=subprocess.run([str(exe),kind,str(path)],stdout=f,stderr=subprocess.PIPE,text=True,cwd=ROOT,env=dict(os.environ,UBSAN_OPTIONS='halt_on_error=1'))
    seconds=time.perf_counter()-start
    info=None
    for line in reversed(result.stderr.splitlines()):
        try:info=json.loads(line);break
        except json.JSONDecodeError:pass
    clean='runtime error:' not in result.stderr and 'Sanitizer' not in result.stderr
    item={'kind':kind,'path':str(path),'input_sha256':digest(path),'decoder':info,'returncode':result.returncode,'sanitizer_clean':clean,'stderr':result.stderr,'host_decode_seconds_sanitized':seconds,'target_realtime_measured':False,'actual_pcm_bytes':actual.stat().st_size,'actual_pcm_sha256':digest(actual)}
    if result.returncode==0 and clean:
        reference_cmd=['ffmpeg','-v','error']+(['-c:a','libopus','-request_sample_fmt','flt'] if kind=='opus' else [])+['-i',path,'-map','0:a:0','-f','s16le','-acodec','pcm_s16le','-']
        item['reference_decoder']='system libopus float API via FFmpeg (explicit request_sample_fmt flt)' if kind=='opus' else 'FFmpeg native'
        item['reference_command']=[str(v) for v in reference_cmd]
        with reference.open('wb') as f:run(reference_cmd,stdout=f,stderr=subprocess.PIPE)
        same=actual.stat().st_size==reference.stat().st_size;count=0;ss=0.;peak=0
        if same:
            with actual.open('rb') as a,reference.open('rb') as b:
                while x:=a.read(1048576):
                    d=np.frombuffer(x,dtype='<i2').astype(np.int32)-np.frombuffer(b.read(len(x)),dtype='<i2').astype(np.int32)
                    count+=d.size;f=d.astype(np.float64);ss+=float(np.dot(f,f));peak=max(peak,int(np.max(np.abs(d))))
        item.update(reference_pcm_bytes=reference.stat().st_size,reference_pcm_sha256=digest(reference),framecount_match=same,pcm_exact=digest(actual)==digest(reference),difference_rms_lsb=(ss/count)**.5 if count else None,difference_peak_lsb=peak)
        # Fixed-point lossy references allow declared numerical differences.
        rms_limit={'mp3':1,'aac':2,'vorbis':2,'opus':8}.get(kind,0)
        item['validated']=same and (item['pcm_exact'] if kind=='flac' else count>0 and item['difference_rms_lsb']<=rms_limit)
        reference.unlink()
    else:item['validated']=False
    actual.unlink();return item

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);ap.add_argument('--limit',type=int,default=0);ap.add_argument('--arena-kib',type=int,choices=[224,240],default=224);ap.add_argument('--ogg',action='store_true');ap.add_argument('--reserve-bytes',type=int,default=0);ap.add_argument('--arm',action='store_true');ap.add_argument('--reuse-local-libraries',action='store_true');args=ap.parse_args()
    out=(ROOT/args.out).resolve();out.mkdir(parents=True,exist_ok=True)
    if (out/'validation.json').exists():raise SystemExit('Use a fresh --out path; prior validation evidence is preserved.')
    sources={str(p.relative_to(ROOT)):digest(p) for p in [*(ROOT/source for source,flags in units()),*(ROOT/'include'/name for name in ['codec.h','codec_m4a.h','codec_mp3.h','codec_ogg.h','codec_vorbis.h','codec_opus_config.h','hash256.h'])]}
    arena_bytes=args.arena_kib*1024-args.reserve_bytes
    if arena_bytes<65536 or arena_bytes%8:raise SystemExit('Invalid bounded arena/reservation')
    record={'arena_bytes':arena_bytes,'nominal_arena_bytes':args.arena_kib*1024,'reserved_overlay_data_bytes':args.reserve_bytes,'not_installed':True,'hardware_observed':False,'source_sha256':sources,'cases':[],'complete':False}
    (out/'validation.json').write_text(json.dumps(record,indent=2)+'\n')
    cache=None
    if args.reuse_local_libraries:
        cache_record=json.loads((ROOT/'research/post-mvp-codec-host-library-cache.json').read_text())
        if any(digest(ROOT/p)!=h for p,h in cache_record['input_sha256'].items()):raise RuntimeError('cached library input changed')
        cache={x['source']:x for x in cache_record['objects']}
    objects=compile_units(out,cache=cache)
    harness=out/'decode.c';harness.write_text(HARNESS.replace('arena[224*1024]',f'arena[{arena_bytes}]'))
    exe=out/'decode';run(['cc','-O2','-g']+SAN+['-Iinclude',harness]+objects+['-lm','-o',exe])
    if args.arm:arm_resources(out,compile_units(out,arm=True))
    corpus=[]
    for kind,base,ext in [('flac',ROOT/'staging/music-internal-20261021/Trixie_Mattel','flac'),('mp3',Path.home()/'mp3_out/Trixie_Mattel','mp3'),('aac',Path.home()/'aac_out/Trixie_Mattel','m4a')]:
        paths=sorted(base.rglob('*.'+ext));paths=paths[:args.limit] if args.limit else paths;corpus.extend((kind,p) for p in paths)
    if args.ogg:
        fixtures=out/'fixtures';fixtures.mkdir(exist_ok=True);provenance=[]
        flacs=[p for kind,p in corpus if kind=='flac']
        for index,p in enumerate(flacs):
            for kind,flags in [('vorbis',['-c:a','libvorbis','-q:a','5']),('opus',['-c:a','libopus','-b:a','128k'])]:
                target=fixtures/(str(index)+'-'+kind+'.ogg');cmd=['ffmpeg','-v','error','-i',p,'-map','0:a:0','-vn']+flags+[target];run(cmd)
                corpus.append((kind,target));provenance.append({'source':str(p),'source_sha256':digest(p),'fixture':str(target),'fixture_sha256':digest(target),'command':[str(x) for x in cmd]})
        (out/'fixture-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
    for kind,path in corpus:
        item=compare(exe,kind,path,out);record['cases'].append(item)
        (out/'validation.json').write_text(json.dumps(record,indent=2)+'\n')
        print(kind,path.name,'validated',item['validated'],'frames',(item.get('decoder') or {}).get('frames'),'arena',(item.get('decoder') or {}).get('arena_peak'),flush=True)
    record['complete']=True;record['all_passed']=all(x['validated'] for x in record['cases'])
    record['sources_unchanged_during_run']=all(digest(ROOT/p)==h for p,h in sources.items())
    (out/'validation.json').write_text(json.dumps(record,indent=2)+'\n')
    if not record['all_passed'] or not record['sources_unchanged_during_run']:raise SystemExit('Some local decoder gates failed; see validation.json. No device operations occurred.')
if __name__=='__main__':main()
