# We4zlP0d X 1.0 for HiFi Walker H2

This archive contains the corresponding source and build inputs for the H64
application and USB installer. The Linux packer uses Python 3 with Pillow and
liblzma, Clang and LLVM tools. The verification build used Clang 23.1.3. The
generated font header is included, alongside the font and its generator.

Supply the controller patch from your own USB-C hw4 V2.2 factory update. Place
`BCM4343A1_001.002.009.0122.0538.hcd` under `build/hifih2/v22-root/lib/firmware/`.
The build checks the patch hash before compiling.

```sh
git init -q
board=Firmware/WeazlP0d_X/boards/h2-x1000
bash "$board/build-player.sh" 64
bash "$board/build-slot-trial.sh" 64 64
sha256sum build/hifih2/player/H64/slot.bin
```

Expected USB installer SHA-256 is
`6d1197958bc5fba1c1d76ab87efd658139a9b72b65980268f72605f751ecf4e6`.
The flash kit also provides a Python assembler for the tested installer.

The combined H2 application in this release is distributed under the GNU
General Public License, version 2 or later. See `third_party/faad2/COPYING`.
Third-party components carry their own notices in this archive. The firmware
is experimental and provided without warranty.

Code from FAAD2 is copyright (c) Nero AG, www.nero.com
